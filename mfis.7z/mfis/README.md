## Mfis

Micro Finance Management System

#### License

MIT
