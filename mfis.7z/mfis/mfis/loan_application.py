import frappe
from frappe.utils import getdate, today
from mfis.loan.doctype.loan_application.loan_application import calculate_schedule


@frappe.whitelist(methods=["POST"])
def create(**kwargs):
    """

    Args:
        **kwargs: branch:Branch, loan_product:LoanProduct,
        client:Client, loan_term:Int, principal:Float,
        client_account:Savings Account,
        interest_rate:Float,

    Returns:
        created loan application

    """
    kwargs["doctype"] = "Loan Application"
    kwargs["expected_disbursement_date"] = today()
    kwargs["expected_first_payment"] = today()

    doc = frappe.get_doc(kwargs)

    doc.insert(ignore_permissions=True)

    return doc

@frappe.whitelist(methods=["POST"])
def get_schedules(**kwargs):
    doc = frappe._dict(kwargs["doc"])
    loan_app = frappe.get_doc("Loan Application", doc["name"])
    calculate_schedule(doc=str(doc))

    loan_app.reload()

    return loan_app
@frappe.whitelist(methods=["POST"], allow_guest=True)
def get_client_accounts(client):
    """

    Args:
        client:

    Returns:

    """

    accounts = []

    query = frappe.db.get_list("Savings Account",
                               filters={"client": client},
                               fields=["name"])

    if query:
        accounts = query

    return accounts


@frappe.whitelist(allow_guest=True, methods=["POST"])
def product_details(product):
    if product is None:
        return {}

    principal, interest, term = frappe.db.get_value("Loan Product", product, ["default_principal",
                                                                              "default_interest_rate",
                                                                              "default_loan_term"])

    frappe.local.response["message"] = {
        "principal": principal or 0,
        "interest": interest or 0,
        "term": term or 0,
    }


@frappe.whitelist(methods=["GET"])
def list():
    applications = []

    query = frappe.db.get_list("Loan Application",
                               fields=["branch", "loan_product", "principal",
                                       "application_files", "loan_term",
                                       "client_name", "client", "status",
                                       "interest_rate", "is_paid"
                                       ])

    if query:
        applications = query

    return applications
