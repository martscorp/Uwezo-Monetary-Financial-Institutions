import frappe
import mysql.connector

from mfis.data_import import get_company
from mfis.import_loans import get_import_settings


def create_connection():
    connection = mysql.connector.connect(
        host="db-mysql-fra1-32574-do-user-7716489-0.c.db.ondigitalocean.com",
        user="doadmin",
        password="AVNS_9niWkm44eMXNsYDtoE0",
        port="25060",
        database="uwezo",
    )

    return connection


def import_accounts():
    allow_import = get_import_settings()

    if allow_import == 0:
        print("Importing of clients is disabled")
        return
    connection = create_connection()
    mycursor = connection.cursor(dictionary=True)

    existing_clients = frappe.get_list("Savings Account", fields=["external_id"])

    conditions = ""
    old_clients = []
    for client in existing_clients:
        if client.external_id:
            old_clients.append(str(client.external_id))

    if len(old_clients):
        result_string = '(' + ', '.join(old_clients) + ')'
        conditions += f"and account.id not in {result_string}"

    branches = {
        1: "10",
        2: "20",
    }

    saving_product = {
        "Junior": "JA-JUNIOR ACCOUNT",
        "Junior Savings Account": "JA-JUNIOR ACCOUNT",
        "Joint Business": "JB-JOINT BUSINESS ACCOUNT",
        "Easy Rent": "ER-EASY RENT",
        "Fixed": "FA-FIXED ACCOUNT",
        "Fixed Account": "FA-FIXED ACCOUNT",
        "Vision": "V-VISION",
        "Business Plus": "BPA-BUSINESS PLUS ACCOUNT",
        "Business Plus Account": "BPA-BUSINESS PLUS ACCOUNT",
        "Business": "BA-BUSINESS ACCOUNT",
        "Business Account": "BA-BUSINESS ACCOUNT",
        "Joint Fixed": "JFA-JOINT FIXED ACCOUNT",
        "Health Insurance Account": "HIA-HEALTH INSURANCE ACCOUNT",
        "Joint Business Plus": "JBP-JOINT BUSINESS PLUS ACCOUNT",
        "Staff": "ST-Staff",
        "Staff Account": "ST-Staff",
        "Kuinua": "K-KUINUA"
    }

    mycursor.execute("""
    SELECT  account.id as external_id, account.company_id as branch, 
    account.account_number as external_number, account.type_id as saving_product_id, types.code as code,
    account.borrower_id as client, account.opening_balance as opening_balance
    FROM fgy_client_accounts as account
    LEFT JOIN fgy_accounts_types as types on account.type_id = types.id
    where account.deleted_at is null
    {conditions}
    ORDER BY 
        account.created_at DESC
    LIMIT 500000
    """.format(conditions=conditions))

    data = mycursor.fetchall()

    company = get_company()

    for row in data:
        client_name = row.get("client")
        if frappe.db.exists("Client", client_name) is None:
            continue
        branch_id = row.get("branch")
        branch_value = branches.get(branch_id, "")
        row["branch"] = branch_value

        saving_product = frappe.db.get_value("Saving Product",
                                             filters={"external_number": row.get('saving_product_id')},
                                             fieldname="name") or None

        if saving_product is None:
            saving_product = frappe.db.get_value("Saving Product",
                                                 filters={"code": row.get("code")},
                                                 fieldname="name") or None

        if saving_product is None:
            continue
        row["saving_product"] = saving_product

        row["client_type"] = "Client"
        row["is_old_account"] = 1
        row["is_old_account"] = 1
        row["doctype"] = "Savings Account"
        row["status"] = "Active"
        row["company"] = company

        # print(row["opening_balance"])

        account = frappe.get_doc(row)
        account.insert(ignore_links=True, ignore_mandatory=True,
                       ignore_if_duplicate=True, ignore_permissions=True)

    connection.close()

@frappe.whitelist()
def update_opening_balance(done_accounts=None, account=None):
    allow_import = get_import_settings()

    if allow_import == 0:
        print("Importing of clients is disabled")
        return
    done_accounts = []
    if done_accounts is None and account is None:
        query = """
        SELECT account.name
        FROM `tabSavings Account` as account
        LEFT JOIN `tabSaving Transaction` as trans on account.name = trans.account
        where account.opening_balance is not null
        and trans.is_opening = 1
        """

        if account:
            query += f" and account.name = %(account)s"

        results = frappe.db.sql(query, {"account": account}, as_dict=True)

        if len(results):
            for row in results:
                done_accounts.append(row["name"])

    sql_query = """
    SELECT account.name, account.opening_balance, account.branch
    FROM `tabSavings Account` as account
    LEFT JOIN `tabSaving Transaction` as trans on account.name = trans.account
    where account.opening_balance is not null
    """

    if account:
        sql_query += f" and account.name = %(account)s"

    if len(done_accounts):
        result_string = '(' + ', '.join(done_accounts) + ')'
        sql_query += f" AND account.name not in {result_string}"

    sql_query += " LIMIT 20"

    accounts = frappe.db.sql(sql_query, {"account": account}, as_dict=True)
    if len(accounts) > 1:

        for account in accounts:

            if float(account["opening_balance"]) == 0:
                done_accounts.append(account["name"])
                continue

            if frappe.db.exists("Saving Transaction", {"is_opening": 1, "is_import": 1, "account": account["name"]}):
                done_accounts.append(account["name"])
                continue

            deposit = frappe.new_doc("Saving Transaction")

            deposit.transaction_type = 1
            deposit.transaction_type_name = "Deposit"
            deposit.account = account["name"]
            deposit.amount = account["opening_balance"]
            deposit.branch = account["branch"]
            deposit.description = "Opening balance"
            deposit.is_opening = 1
            deposit.is_import = 1
            deposit.posting_date = frappe.utils.getdate("2021-01-01")

            deposit.insert(ignore_links=True, ignore_permissions=True, ignore_if_duplicate=True)
            deposit.submit()
            done_accounts.append(str(account["name"]))

        frappe.db.commit()
        if account is None:
            update_opening_balance(done_accounts)

    else:
        return
