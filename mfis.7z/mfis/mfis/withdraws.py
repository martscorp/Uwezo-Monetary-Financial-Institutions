import frappe
from frappe.utils.print_format import download_multi_pdf


@frappe.whitelist()
def create(account, amount: float = 0, is_representative=0, representative=None):
    validate_request(account, amount)

    doc = frappe.get_doc({
        "success": 1,
        "doctype": "Withdraw",
        "account": account,
        "amount": amount,
        "is_representative": is_representative,
        "representative": representative
    })

    doc.insert(
        ignore_permissions=True
    )

    frappe.local.response["message"] = {
        "success": 1,
        "id": doc.name,
        "account": doc.account,
        "client_name": doc.client_name,
        "amount": doc.amount,
        "currency": doc.currency,
        "is_representative": is_representative,
        "representative": representative,
        "docstatus": doc.docstatus
    }


@frappe.whitelist()
def submit(id):
    doc = get_withdraw(id)

    doc.flags.ignore_permissions = True
    doc.submit()

    frappe.local.response["message"] = {
        "success": 1,
        "id": doc.name,
        "account": doc.account,
        "client_name": doc.client_name,
        "amount": doc.amount,
        "currency": doc.currency,
        "docstatus": doc.docstatus,
        "transaction": doc.transaction,
        "is_representative": doc.is_representative,
        "representative": doc.representative
    }


def get_withdraw(id):
    doc = frappe.get_doc("Withdraw", id)

    if doc is None:
        frappe.local.response["message"] = {
            "success": 0,
            "message": "Invalid Withdraw"
        }

    return doc

@frappe.whitelist(allow_guest=True)
def get_client_details(account):
    doc = frappe.get_doc("Savings Account", account)

    if doc:
        frappe.local.response["message"] = {
            "success": 1,
            "client_name": doc.client_name,
            "photo": doc.client_photo,
            "signature": doc.client_signature
        }


@frappe.whitelist()
def cancel(id):
    doc = get_withdraw(id)

    doc.flags.ignore_permissions = True
    doc.flagged = 1
    doc.save()

    frappe.local.response["message"] = {
        "success": 1,
        "message": "Document successfully flagged"
    }

@frappe.whitelist()
def get_pdf_print(id):
    return download_multi_pdf(doctype={
                                "Deposit": [id]
                              },
                              name="deposit_slip",
                              format="Deposit Slip",
                              no_letterhead=True,
                              options={"enable-local-file-access": ""}
                              )

def validate_request(account, amount):
    if amount is None or amount <= 0:
        frappe.local.response['message'] = {
            "success": 0,
            "message": "Please enter amount"
        }
    if account is None:
        frappe.local.response['message'] = {
            "success": 0,
            "message": "Please enter a valid account"
        }
    if account:
        exists = frappe.db.exists("Savings Account", {
            "name": account
        })

        if exists is None:
            frappe.local.response['message'] = {
                "success": 0,
                "message": "Please enter a valid account"
            }

@frappe.whitelist()
def get_representatives(account):

    representatives = frappe.db.sql("""
    SELECT rep.client as id,
     rep.client_name
    FROM `tabAccount Representative` as rep
    where rep.account = %(account)s
    """, {"account": account}, as_dict=True)

    return representatives
