import mysql.connector
import re

from datetime import datetime

import frappe
from mfis.import_loans import get_import_settings


def create_connection():
    connection = mysql.connector.connect(
        host="db-mysql-fra1-32574-do-user-7716489-0.c.db.ondigitalocean.com",
        user="doadmin",
        password="AVNS_9niWkm44eMXNsYDtoE0",
        port="25060",
        database="uwezo",
    )

    return connection


def get_company():
    company = frappe.db.get_value("Company", {"is_group": 1}, "name")

    return company


@frappe.whitelist(allow_guest=True)
def import_clients():
    allow_import = get_import_settings()

    if allow_import == 0:
        print("Importing of clients is disabled")
        return
    connection = create_connection()
    mycursor = connection.cursor(dictionary=True)

    existing_clients = frappe.get_list("Client", fields=["external_id"])

    conditions = ""
    old_clients = []
    for client in existing_clients:
        if client.external_id:
            old_clients.append(client.external_id)

    if len(old_clients):
        result_string = '(' + ', '.join(old_clients) + ')'
        conditions += f"and client.id not in {result_string}"

    mycursor.execute("""
    SELECT client.id as external_id, client.title, client.mobile, client.company_id as branch,
    client.fname as first_name, client.sname as last_name, client.lname as middle_name, client.gender, 
    client.marital as marital_status, client.mobile, client.telephone as home_mobile, client.nationality as country,
     client.dob as date_of_birth, client.idNumber as id_number, client.id_type as document_type
    FROM fgy_borrowers as client
    where client.deleted_at is null
    {conditions}
    ORDER BY 
        created_at DESC
    LIMIT 
        100
    """.format(conditions=conditions))

    data = mycursor.fetchall()

    clients = []

    salutaions = frappe.db.sql("""
    SELECT name
    FROM tabSalutation
    """, as_dict=True)

    branches = {
        1: "10",
        2: "20",
    }

    titles = []
    for salutaion in salutaions:
        titles.append(salutaion["name"])

    genders = ['Male', 'Female']

    marital_statuses = ['Single', 'Married']

    # Iterate through the fetched data and convert each row to a dictionary

    company = get_company()
    for row in data:
        title = str(row["title"]).capitalize()

        row["company"] = company

        if title not in titles:
            title = ""

        row["title"] = title

        branch_id = row.get("branch")
        branch_value = branches.get(branch_id, "")
        row["branch"] = branch_value

        if row.get("first_name"):
            row["first_name"] = clean_strings(row.get("first_name"))

        if row.get("last_name"):
            row["last_name"] = clean_strings(row.get("last_name"))

        if row.get("middle_name"):
            row["middle_name"] = clean_strings(row.get("middle_name"))

        gender = str(row.get("gender")).capitalize()

        if gender not in genders:
            gender = ""

        row["gender"] = gender

        marital_status = str(row.get("marital_status")).capitalize()

        if marital_status not in marital_statuses:
            marital_status = "Single"

        row["marital_status"] = marital_status

        row["country"] = clean_countries(row.get("country"))

        # row["date_of_birth"] = formate_date_of_birth(row.get("date_of_birth"))

        row["document_type"] = clean_id_types(row.get("document_type"))

        row["id_number"] = clean_id_number(row.get("id_number"))

        row["doctype"] = "Client"

        row["external_id"] = str(row["external_id"])
        # if not frappe.db.exists("Client", {"external_id": row["external_id"]}):
        client = frappe.get_doc(row)
        client.status = "Approved"
        client.append("identifiers", {
            "document_type": row["document_type"],
            "id_number": row["id_number"],
        })
        client.insert(ignore_permissions=True, ignore_mandatory=True, ignore_if_duplicate=True, ignore_links=True)
        # client.submit()

    # Close the database connection
    connection.close()


def clean_strings(input_string):
    # Remove double spaces, commas, and hyphens using regular expressions
    input_string = re.sub(r'\s+', ' ', input_string)  # Replace multiple spaces with a single space
    input_string = re.sub(r',', '', input_string)  # Remove commas
    input_string = re.sub(r'-', '', input_string)  # Remove hyphens
    input_string = re.sub(r'&', '', input_string)  # Remove hyphens
    input_string = re.sub(r'@', '', input_string)  # Remove hyphens

    return input_string


def clean_countries(country):
    country = re.sub(r'_', ' ', country)

    country = str(country).title()
    if country == 'Ugandan':
        country = "Uganda"

    if country == 'Kenyan':
        country = "Kenya"

    if country == "Drc":
        country = 'Congo, The Democratic Republic of the'

    if country == "South sudan":
        country = 'South Sudan'

    if not frappe.db.exists("Country", country):
        country = "Uganda"

    return country


def formate_date_of_birth(dob):
    # Parse the input date string into a datetime object
    # date_object = datetime.strptime(dob, "%Y-%m-%d")

    # Format the date object as "dd-mm-yyyy"
    formatted_date_string = dob.strftime("%d-%m-%Y")

    return formatted_date_string


def clean_id_types(document_type):
    if document_type == "national_id" or document_type == "National id" or document_type == "National ID":
        document_type = "National ID"

    if document_type == "drivers_license" or document_type == "drivers license" or document_type == "Driver license":
        document_type = "Drivers License"

    if document_type == "passport":
        document_type = "Passport"

    if document_type == "work_id":
        document_type = "Work ID"

    if document_type not in ["National ID", "Passport", "Drivers License", "Any Other ID", "Work ID"]:
        document_type = "Any Other ID"

    return document_type


def clean_id_number(id_number):
    id_number = re.sub(r"\*", 'X', id_number)

    return id_number

def delete_records():
    frappe.db.delete("Loan")
    frappe.db.delete("Loan Transaction")
    frappe.db.delete("Loan Repayment")
    frappe.db.delete("Loan Disbursement")
    frappe.db.delete("Client")
    frappe.db.delete("Client Identifiers")
    frappe.db.delete("Savings Account")
    frappe.db.delete("Saving Transaction")
