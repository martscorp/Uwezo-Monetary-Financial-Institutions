import frappe
from mfis.import_transactions import fetch_and_process_transactions


def execute():
    #log
    frappe.log_error(title="Job", message="Running")