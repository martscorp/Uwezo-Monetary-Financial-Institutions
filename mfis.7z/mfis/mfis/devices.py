import frappe


@frappe.whitelist(allow_guest=True)
def verify(device_no):
    if device_no is None:
        frappe.local.response["message"] = {
            "success": 0,
            "message": "Please enter device id"
        }

    exists = frappe.db.exists("Device", {
        "device_id": device_no,
        "allowed": 1,
        # "active": 0
    })

    if exists:
        frappe.local.response["message"] = {
            "success": 1,
            "message": "Device verified"
        }
    else:
        frappe.local.response["message"] = {
            "success": 0,
            "message": "Invalid Device Number"
        }
