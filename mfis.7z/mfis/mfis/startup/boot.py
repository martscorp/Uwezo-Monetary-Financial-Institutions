import frappe

def boot_session(bootinfo):
    bootinfo.custom_css = frappe.db.get_value("Style Settings", None, "custom_css") or ""

    if frappe.session["user"] != "Guest":
        update_page_info(bootinfo)


def update_page_info(bootinfo):
    bootinfo.page_info.update(
        {
            "Chart of Accounts": {"title": "Chart of Accounts", "route": "Tree/Account"},
            "Chart of Cost Centers": {"title": "Chart of Cost Centers", "route": "Tree/Cost Center"},
        }
    )