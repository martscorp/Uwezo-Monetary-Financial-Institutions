frappe.pages['savings-account--bal'].on_page_load = function(wrapper) {
	var page = frappe.ui.make_app_page({
		parent: wrapper,
		title: 'Savings Account  Balance',
		single_column: true
	});
}