frappe.pages['offer-letter-12'].on_page_load = async function(wrapper) {
    let page = frappe.ui.make_app_page({
        parent: wrapper,
        title: 'Offer Letter 1',
        single_column: true
    });

    let container = $('<div class="offer-letter-container">').appendTo(page.body);

    // Number to Words Function
    function numberToWords(num) {
        const a = [
            '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
            'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
            'Seventeen', 'Eighteen', 'Nineteen'
        ];
        const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

        function inWords(n) {
            if (n < 20) return a[n];
            if (n < 100) return b[Math.floor(n / 10)] + (n % 10 ? ' ' + a[n % 10] : '');
            if (n < 1000) return a[Math.floor(n / 100)] + ' Hundred' + (n % 100 ? ' ' + inWords(n % 100) : '');
            if (n < 1000000) return inWords(Math.floor(n / 1000)) + ' Thousand' + (n % 1000 ? ' ' + inWords(n % 1000) : '');
            if (n < 1000000000) return inWords(Math.floor(n / 1000000)) + ' Million' + (n % 1000000 ? ' ' + inWords(n % 1000000) : '');
            return inWords(Math.floor(n / 1000000000)) + ' Billion' + (n % 1000000000 ? ' ' + inWords(n % 1000000000) : '');
        }

        if (num === 0) return 'Zero';
        return inWords(num);
    }

    // Load Company Details
    function loadCompanyDetails(companyName) {
        frappe.call({
            method: 'frappe.client.get',
            args: {
                doctype: 'Company',
                name: companyName
            },
            callback: function(response) {
                if (response.message) {
                    let company = response.message;
                    let letterhead = $('#letterhead');
                    let logoHTML = company.company_logo ? `<img src="${company.company_logo}" alt="Company Logo" style="max-width: 100px; height: auto;">` : '';
                    let companyDetailsHTML = `
                        ${logoHTML}
                        <h3>${company.name}</h3>
                        <h4>${company.address || ''}</h4>
                        <h4>BRN: ${company.fax || ''}</h4>
                        <h4>TIN: ${company.website || ''}</h4>
                    `;
                    letterhead.html(companyDetailsHTML);
                } else {
                    frappe.msgprint(__('No company details found.'));
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching company details:', error);
                frappe.msgprint(__('An error occurred while fetching company details: ' + error));
            }
        });
    }

    async function renderOfferLetter() {
        const urlParams = new URLSearchParams(window.location.search);
        const refNo = urlParams.get('refNo') || '';
        const loanApprovalDate = urlParams.get('loanApprovalDate') || '';
        const name = urlParams.get('name') || '';
        const nin = urlParams.get('nin') || '';
        const workAddress = urlParams.get('businessAddress') || '';
        const phoneNumber = urlParams.get('phoneNumber') || '0756380026';
var cashCollateral   = urlParams.get('cashCollateral') || '';
        const principalAmount = urlParams.get('principalAmount') || '';
        const principalInWords = numberToWords(principalAmount).toUpperCase() + ' SHILLINGS ONLY';
        var gracePeriod = urlParams.get('gracePeriod') || "0";
        var loanPeriod  = urlParams.get('loanPeriod') || "0";
        var interestRate = urlParams.get('interestRate') || "";
        var collection_fees = urlParams.get('collection_fees') || "";
        const html = `
        <style>
            .offer-letter-container {
                font-family: Arial, sans-serif;
                margin: auto;
                padding: 20px;
                width:900px;
            }
            .print-button {
                text-align: right;
                margin-top: 20px;
            }
            .print-button button {
                padding: 10px 20px;
                background-color: #007bff;
                color: #fff;
                border: none;
                cursor: pointer;
                font-size: 14px;
            }
            .inner-border {
                border: 1px solid #ccc;
                padding: 20px;
                margin-top: 20px;
            }
            .signature-block {
                text-align: center;
                margin-top: 20px;
            }
            @media print {
                .print-button {
                    display: none;
                }
            }
        </style>
        <script>
        
        
            function pprint() {
                (function() {
                    var printContents = document.querySelector('.inner-border');
                    if (printContents) {
                    
                        var originalContents = document.body.innerHTML;
                        document.body.innerHTML = printContents.innerHTML;
                        window.print();
                        document.body.innerHTML = originalContents;
                        location.reload();
                    }
                })();
            }
        </script>

        <div class="print-button">
            <button onclick="pprint()">Print Offer Letter</button>
        </div>

        <div class="inner-border">
            <div id="letterhead" style="text-align: center; margin-bottom: 20px;">
            </div>

            <h3 style="text-align: center;"><u>Loan Offer Letter</u></h3>
            <p><strong>Ref No:</strong> ${refNo}</p>
            <p><strong>Loan Approval Date:</strong> ${loanApprovalDate}</p>
            <p><strong>Name:</strong> ${name}</p>
            <p><strong>NIN:</strong> ${nin}</p>
            <p><strong>Work Address:</strong> ${workAddress}</p>
            <p><strong>Mobile Contact:</strong> ${phoneNumber}</p>

            <p>Dear Sir/Madam,</p>
            <p><strong>Re: Loan Offer</strong></p>
            <p>We are pleased to offer you a loan facility subject to the following terms and conditions:</p>

            <ol>
                <li><strong>Principal:</strong> Ugx ${principalAmount.toLocaleString()} (${principalInWords}).</li>
                <li><strong>Loan Purpose:</strong> Working capital.</li>
                <li><strong>Interest Rate:</strong> ${interestRate-collection_fees}% per Month or ${(((interestRate-collection_fees)/100))/30}  Daily.</li>
                <li><strong>Repayments:</strong> Daily (Principle and interest are paid daily in equal installments).</li>
                <li><strong>Loan Period:</strong> ${loanPeriod} Days. However, the Microfinance may recall the facility before ${loanPeriod} Days.</li>
                <li><strong>Collection Fees:</strong>  ${collection_fees}% per Month.</li>
                <li><strong>Emergency:</strong> 1% one off of the loan amount shall be charged</li>
                <li><strong>Penalty:</strong> 1.25% per Month on Principal not paid.</li>
                <li><strong>Prepayments:</strong> No penalty on early payments.</li>
                <li><strong>Early Loan Settlement:</strong> Encouraged with a minimum charge equivalent to Monthly interest and collection fees otherwise, interest and collection
                 fees are charged on period utilized. </li>
                <li><strong>Guarantors:</strong> All your guarantors as per the application form have been accepted. We may share information about this loan with them.</li>
                <li><strong>Inquiries:</strong> Contact Uwezo Management on WhatsApp +256783217393, Mobile +25675716582. Or contact Uganda Microfinance Regulatory Authority on 0417799700.</li>
                <li><strong>Consult a Lawyer:</strong> Please consult a lawyer before accepting this agreement.</li>
            </ol>

            <p>Yours faithfully,</p>
            <div class="row">
                <div class="signature-block col-6">
                    <p>......................................................</p>
                
                    <p>CREDIT MANAGER</p>
                </div>
                <div class="signature-block col-6">
                    <p>......................................................</p>
              
                    <p>BRANCH MANAGER</p>
                </div>
            </div>

            <hr>
            <h4><strong>Acceptance of Loan Offer</strong></h4>
            <p><strong>Signature & Date:</strong> ____________________________________________</p>
            <p><strong>Name in own handwriting:</strong> ${name}</p>

            <hr>
            <h4><strong>Translation & Interpretation of the Agreement</strong></h4>
            <p>I ________________________ who is fluent in the __________________ and English language do confirm that I have read and interpreted the offer/agreement to ________________________ in the _____________________ language they understand best and they have understood the contents before appending their signature to the offer/agreement.</p>
            <p><strong>Interpreter’s Name, Signature & Date:</strong> _________________________________</p>
        </div>`;

        container.html(html);

        // Load company letterhead
      
        loadCompanyDetails("UWEZO FINANCIAL SERVICES LTD");
    }

    renderOfferLetter();
};
