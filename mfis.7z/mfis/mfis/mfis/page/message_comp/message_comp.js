frappe.pages['message-comp'].on_page_load = function (wrapper) {
    var page = frappe.ui.make_app_page({
        parent: wrapper,
        title: 'Message Composer',
        single_column: true
    });

    // Inject HTML with large message textarea and AI buttons below
	$(`<div class="message-compose p-3">

		<!-- Back button -->
		<div class="mb-3">
			<button class="btn btn-outline-dark btn-sm" id="btn_back">← Back</button>
		</div>
	
		<div class="d-flex align-items-center gap-2 mb-3" style="flex-wrap: wrap; m-2">
			<div style="flex: 2; min-width: 200px;">
				<label for="recipient_select" class="mb-0">Recipients</label>
				<div id="recipient_select" style="width: 100%; height: calc(1.5em + .75rem + 2px);"></div>
				<small class="text-muted">Begin typing for results.</small>
			</div>
	
			<div style="flex: 0 0 120px; margin-left:10px; margin-top:3%;">
				<label for="recipient_select" class="mb-0">Message Type</label>
				<select id="message_type" class="form-control form-control-sm" style="height: calc(1.5em + .75rem + 2px);">
					<option value="sms" selected>SMS</option>
					<option value="whatsapp">WhatsApp</option>
					<option value="email">Email</option>
				</select>
			</div>
		</div>
	
		<!-- Large message textarea -->
		<div class="form-group mb-3">
			<label for="message_body">Message</label>
			<textarea id="message_body" class="form-control" rows="8" style="font-size:1.1rem; line-height:1.5;" placeholder="Write your message..."></textarea>
		</div>
	
		<!-- AI helper buttons -->
	<div class="btn-group mb-3" id="ai_buttons">
    <button class="btn btn-outline-primary" id="btn_summarize">✨ Summarize</button>
    <button class="btn btn-outline-secondary" id="btn_suggest">💡 Suggest</button>
    <button class="btn btn-outline-info" id="btn_loan_birthday">🎂 Loan Birthday Template</button>
    <button class="btn btn-outline-info" id="btn_loan_reminder">⏰ Loan Reminder Template</button>
    <button class="btn btn-outline-info" id="btn_account_statement">📄 Account Statement Template</button>
    <button class="btn btn-outline-info" id="btn_interest_notice">📈 Interest Notification Template</button>
</div>

		<!-- Sample messages -->
		<div class="mb-3" id="sample_messages">
			<label class="mb-1">Sample Messages:</label>
			<div class="d-flex flex-column gap-1">
				<button class="btn btn-sm btn-light sample-msg">Reminder: Your payment is due.</button>
				<button class="btn btn-sm btn-light sample-msg">Thank you for your support!</button>
				<button class="btn btn-sm btn-light sample-msg">Meeting scheduled at 3 PM.</button>
				<button class="btn btn-sm btn-light sample-msg">Please confirm receipt.</button>
				<button class="btn btn-sm btn-light sample-msg">We appreciate your feedback.</button>
				<button class="btn btn-sm btn-light sample-msg">Happy Birthday! 🎉</button>
				<button class="btn btn-sm btn-light sample-msg">Your account has been updated.</button>
			</div>
		</div>

		<!-- Send button -->
		<div>
			<button class="btn btn-success" id="btn_send">🚀 Send</button>
		</div>
	
	</div>`).appendTo(page.body);

	// Click sample message to insert into textarea (delegated)
	$('#sample_messages').on('click', '.sample-msg', function() {
		$('#message_body').val($(this).text());
	});
	

    // Searchable multi-select for clients
    let recipient_control = frappe.ui.form.make_control({
        parent: $("#recipient_select"),
        df: {
            fieldtype: 'MultiSelectPills',
            options: 'Client',
            label: 'Recipients',
            get_data: function(txt) {
                return frappe.db.get_list('Client', {
                    filters: [["full_name", "like", `%${txt}%`]],
                    fields: ["name", "full_name", "mobile"],
                    limit: 20
                }).then(res => res.map(c => ({
                    value: c.name,
                    label: `${c.full_name} (${c.mobile || "No mobile"})`
                })));
            }
        },
        render_input: true
    });

    // Update UI color and placeholder based on message type
    function updateUIByType(type) {
        let btn = $("#btn_send");
        if (type === "sms") {
            btn.removeClass().addClass("btn btn-primary");
            $("#message_body").attr("placeholder", "Write your SMS message...");
        } else if (type === "whatsapp") {
            btn.removeClass().addClass("btn btn-success text-white");
            $("#message_body").attr("placeholder", "Write your WhatsApp message...");
        } else {
            btn.removeClass().addClass("btn btn-secondary");
            $("#message_body").attr("placeholder", "Write your Email...");
        }
    }

    $("#message_type").on("change", function () {
        updateUIByType($(this).val());
    });

    updateUIByType("sms");

    // Free ChatGPT API integration
	async function callChatGPT(prompt, retries = 3, delay = 2000) {
		try {
			const response = await fetch('https://api.openai.com/v1/chat/completions', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'Authorization': 'Bearer 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'
				},
				body: JSON.stringify({
					model: 'gpt-3.5-turbo',
					messages: [{ role: 'user', content: prompt }],
					max_tokens: 300
				})
			});
			
			if (response.status === 429 && retries > 0) {
				await new Promise(r => setTimeout(r, delay));
				return callChatGPT(prompt, retries - 1, delay * 2);
			}
			
			const data = await response.json();
			if (data.choices && data.choices.length > 0) {
				return data.choices[0].message.content;
			} else {
				console.error("No choices returned:", data);
				frappe.msgprint('Insufficient tokens to access Mega AI Cluster. Please top up your tokens to continue.');
				return null;
			}
		} catch (err) {
			console.error(err);
			frappe.msgprint('Failed to call ChatGPT API');
			return null;
		}
	}
	

    // Connect AI buttons to ChatGPT
    $("#btn_summarize").on('click', async function() {
        let msg = $("#message_body").val();
        if (!msg) return;
        let result = await callChatGPT(`Summarize this message: ${msg}`);
        if (result) $("#message_body").val(result);
    });

    $("#btn_suggest").on('click', async function() {
        let msg = $("#message_body").val();
        if (!msg) return;
        let result = await callChatGPT(`Provide suggestions to improve this message: ${msg}`);
        if (result) $("#message_body").val(result);
    });
	$('#btn_back').on('click', function() {
		window.history.back();
		});
    $("#btn_rewrite").on('click', async function() {
        let msg = $("#message_body").val();
        if (!msg) return;
        let result = await callChatGPT(`Rewrite this message in a better way: ${msg}`);
        if (result) $("#message_body").val(result);
    });

    // Send button
    $("#btn_send").on("click", function () {
        let recipients = recipient_control.get_value();
        let message = $("#message_body").val();
        let type = $("#message_type").val();

        if (!recipients || recipients.length === 0) {
            frappe.msgprint("Please select at least one recipient");
            return;
        }

        frappe.call({
            method: "frappe.client.get_list",
            args: {
                doctype: "Client",
                filters: { "name": ["in", recipients] },
                fields: ["name", "full_name", "mobile", "email"]
            },
            callback: function (res) {
				if (!res.message) return;
				frappe.call({
					method: "mfis.clients.send_to_queue_message_mysql",
					args: {
						recipients: res.message,
						message: message,
						message_type: type
					},
					callback: function () {
						frappe.msgprint("Message sent successfully!");
						$("#message_body").val("");
						recipient_control.set_value([]);
					}
				});
			}
        });
    });
};