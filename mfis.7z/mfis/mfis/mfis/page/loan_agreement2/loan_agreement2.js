frappe.pages['loan-agreement2'].on_page_load = function(wrapper) {
    var page = frappe.ui.make_app_page({
        parent: wrapper,
        title: 'Loan Agreement',
        single_column: true
    });

    var container = $('<div class="loan-agreement-container">').appendTo(page.body);

    function numberToWords(num) {
        const a = [
            '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten',
            'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
            'Seventeen', 'Eighteen', 'Nineteen'
        ];
        const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    
        function inWords(n) {
            if (n < 20) return a[n];
            if (n < 100) return b[Math.floor(n / 10)] + (n % 10 ? ' ' + a[n % 10] : '');
            if (n < 1000) return a[Math.floor(n / 100)] + ' Hundred' + (n % 100 ? ' ' + inWords(n % 100) : '');
            if (n < 1000000) return inWords(Math.floor(n / 1000)) + ' Thousand' + (n % 1000 ? ' ' + inWords(n % 1000) : '');
            if (n < 1000000000) return inWords(Math.floor(n / 1000000)) + ' Million' + (n % 1000000 ? ' ' + inWords(n % 1000000) : '');
            return inWords(Math.floor(n / 1000000000)) + ' Billion' + (n % 1000000000 ? ' ' + inWords(n % 1000000000) : '');
        }
    
        if (num === 0) return 'Zero';
        return inWords(num);
    }
    
    
    function calculateWorkingDaysInTerm(startDateTime, loanTerm) {
        // Parse the start date-time correctly as a Date object
        const startDate = new Date(startDateTime);
    
        // Function to check if a date is a Sunday
        const isSunday = (date) => date.getDay() === 0;
    
        let workingDays = 0;
    
        // Loop for the duration of the loan term
        for (let i = 0; i < loanTerm; i++) {
            const currentDate = new Date(startDate); // Create a new Date based on the start date
            currentDate.setDate(startDate.getDate() + i); // Increment the date by 'i' days
    
            if (!isSunday(currentDate)) {
                workingDays++;
            }
        }
    
        return workingDays;
    }
    
      
     
      
    
    function loadCompanyDetails(companyName) {
		frappe.call({
			method: 'frappe.client.get',
			args: {
				doctype: 'Company',
				name: companyName
			},
			callback: function(response) {
				if (response.message) {
					let company = response.message;
					let letterhead = $('#letterhead');
					let logoHTML = company.company_logo ? `<img src="${company.company_logo}" alt="Company Logo" style="max-width: 100px; height: auto;">` : '';
					let companyDetailsHTML = `
						${logoHTML}
						<h3>${company.name}</h3>
						<h4>${company.address || ''}</h4>
						<h4>BRN: ${company.fax || ''}</h4>
						<h4>TIN: ${company.website || ''}</h4>
					`;
					letterhead.html(companyDetailsHTML);
				} else {
					frappe.msgprint(__('No company details found.'));
				}
			},
			error: function(xhr, status, error) {
				console.error('Error fetching company details:', error);
				frappe.msgprint(__('An error occurred while fetching company details: ' + error));
			}
		});
	}

    function formatDateToWord(dateString) {
        var date = new Date(dateString);
        var dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        var monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    
        var dayName = dayNames[date.getDay()];
        var day = date.getDate();
        var monthName = monthNames[date.getMonth()];
        var year = date.getFullYear();
    
        // Add ordinal suffix
        var ordinalSuffix;
        if (day >= 1 && day <= 3 || day >= 21 && day <= 23) {
            ordinalSuffix = 'st';
        } else if (day >= 4 && day <= 20 || day >= 24 && day <= 30) {
            ordinalSuffix = 'th';
        } else if (day === 31) {
            ordinalSuffix = 'st';
        }
    
        return `${dayName} ${day}${ordinalSuffix} ${monthName} ${year}`;
    }
    // Function to fetch data from URL parameters
    function fetchLoanAgreementDetails() {
        loadCompanyDetails("UWEZO FINANCIAL SERVICES LTD");
        var urlParams = new URLSearchParams(window.location.search);
        var refNo = urlParams.get('refNo') || "";
        var borrowerName = urlParams.get('name') || "";
        var borrowerPhoneNumber = urlParams.get('phoneNumber') || "";
        var borrowerNIN = urlParams.get('nin') || "";
        var businessAddress = urlParams.get('businessAddress') || "";
        var loanAmount = urlParams.get('principalAmount') || "";
        var interestRate = urlParams.get('interestRate') || "";
        var collection_fees = urlParams.get('collection_fees') || "";
        var emergencyFee = urlParams.get('emergencyFee') || "";
        var gracePeriod = urlParams.get('gracePeriod') || "0";
        var penaltyRate = urlParams.get('penaltyRate') || "";
        var cashcolla = urlParams.get('cashCollateral') || "";
        var guaratorssesss = urlParams.get('guaratorssesss') || "";
        var guaratorssesss2 = urlParams.get('guaratorssesss2') || "";
        var loanApprovalDate = urlParams.get('loanApprovalDate') || "";
        var grace_period = urlParams.get('gr') || "";
        const formatted = ((d => `${d.getDate().toString().padStart(2, '0')} ${["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"][d.getMonth()]} ${d.getFullYear()}`)(new Date(decodeURIComponent(loanApprovalDate))));
var loan_term  = urlParams.get('loanPeriod') || "";
var loanTimestamp = new Date(loanApprovalDate).getTime();

// Ensure that the loanApprovalDate is in correct format
loanApprovalDate = loanApprovalDate.replace(' ', 'T');  // Convert space to 'T' for proper parsing

 var totalDays = calculateWorkingDaysInTerm(loanApprovalDate, loan_term);

var interest_rate_per_day = (interestRate / 100) / 30;
var daily_interest = loanAmount * interest_rate_per_day;
var grace_period_interest = grace_period * daily_interest;
var total_interest = ((loan_term - grace_period) * daily_interest) + grace_period_interest;
var constant_due_amount = (parseFloat(loanAmount) + parseFloat(total_interest) ) / totalDays;
let htmlString = ``;

if (guaratorssesss2) {
     htmlString = `<strong>20 (B). Uwezo Finacial Services Official</strong>: <u>${guaratorssesss2.replace(/--/g, '\n')}</u>.`;

}

// Now build the HTML safely


        // Generate the HTML for the loan agreement
        var htmlData = `

        <script>
            function pprint () {
                (function() {
                    var printContents = document.querySelector('.loan-agreement-container');
                    if (printContents) {
                        var originalContents = document.body.innerHTML;
                        document.body.innerHTML = printContents.innerHTML;
                        window.print();
                        document.body.innerHTML = originalContents;
                    } else {
                        console.error('Error: Element with class "loan-agreement-container" not found.');
                    }
                })();
            }
        </script>
        
        <style>
            .loan-agreement-container {
                font-family: Arial, sans-serif;
                background-color: #fff;
                padding: 20px;
                border-radius: 8px;
                margin: auto;
                max-width: 900px;
                color: #000;
            }
            .loan-agreement {
                border-top: 2px solid #000;
                padding-top: 20px;
                white-space: pre-line;
                font-size: 15px;
                line-height: 1.6;
            }
            .logo {
                text-align: center;
                margin-bottom: 10px;
            }
                #letterhead{
	font-family: Arial, sans-serif;
	background-color: #fff;
width :100%;
	border-radius: 8px;
	margin: auto;
	flex-direction: column;
	justify-content: center;
	align-items: center;
	
}

                
            .logo img {
                max-width: 150px;
                height: auto;
            }
            .title {
                text-align: center;
                font-size: 22px;
                font-weight: bold;
                margin-bottom: 30px;
                text-transform: uppercase;
            }
            .print-button {
                text-align: right;
                margin-bottom: 20px;
            }
            .print-button button {
                padding: 10px 20px;
                background-color: #007bff;
                color: #fff;
                border: none;
                cursor: pointer;
                font-size: 14px;
                border-radius: 4px;
            }
        </style>
        
        <div class="loan-agreement-container">
            <div class="print-button">
                <button onclick="pprint()">Print Agreement</button>
            </div>
       
        
            <div class="title">
             <div id="letterhead">

     
            </div>
           <u> Loan Agreement</u></div>
        
            <div class="loan-agreement">
        <strong>UWEZO Financial Services LTD.</strong>  
        <strong>Loan Agreement.</strong>  
        This Loan Agreement is executed on this <strong>${formatted}</strong> by and between <strong>${borrowerName}</strong>, Mobile Number; <strong>${borrowerPhoneNumber}</strong>, NIN Number <strong>${borrowerNIN}</strong>, Business Address; <strong>${businessAddress.toUpperCase()}</strong>, hereinafter referred to as the <strong>“Borrower”</strong>  
        And  
        <strong>Uwezo Financial services Limited</strong>, Suit TBC8-16, Plot 2, Namirembe Road, P.O.Box, 29488, Kampala, hereinafter referred to as the <strong>“Lender”</strong>  
        
        WHEREAS at the request of the borrower, the lender has agreed to grant a Loan to the Borrower on terms and conditions hereinafter contained;  
        The parties agree as follows;
        
        <strong>1. Loan Amount</strong>: The Borrower agrees to borrow from the Lender the sum of <strong>UGX ${parseInt(loanAmount).toLocaleString()} (${numberToWords(loanAmount)} shillings only)</strong>, which shall be repaid under the terms of this agreement. The Loan sum is agreed by both parties to be the total amount due for the loan.
        
        <strong>2. Interest Rate</strong>: <strong>${interestRate-collection_fees}% per Month</strong> or <strong> ${(((interestRate-collection_fees)/100))/30}  Daily</strong> 
        
        <strong>3. Loan Repayment</strong>: Monthly Installments as per schedule attached to this agreement.
        
        <strong>4. Emergency fees</strong>: The Borrower hereby pays <strong>2%</strong> of the loan sum amounting to <strong>UGX ${parseInt((2/100)*loanAmount).toLocaleString()}</strong> (Uganda Shillings ${numberToWords(((1/100)*loanAmount))}) as a cover against death and permanent disability.
        
        <strong>5. Collection Fees</strong>: <strong>${collection_fees}% per Month</strong> shall be charged.
        
        <strong>6. Grace Period</strong>:  The borrower shall enjoy Grace period as demostrated in the loan schedule counting from the date of disbursement. Interest shall accrue during the grace period but shall be referred to future date payments.
        
		<strong>7. Penalties</strong>:  1.25% per Month penalty charge shall be levied on any principle due but not paid.
		
        <strong>8. Prepayments</strong>: There shall be no penalty attached to payments made prior to payment due dates.

        <strong>9. Early Loan Settlement</strong>: The Borrower has the right to prepay all or any part of the loan, together with accrued and unpaid interest thereon, at any time without prepayment penalty or premium of any kind. However, in the event that they want to close a loan that is less than one month old, the borrower shall pay a total chargeable interest of one month.
        
        <strong>10. Acceleration</strong>: The lender shall have the right to declare the borrowed money to be immediately due and payable, including interest owed, if any of the events are to occur:  
        a. <strong>Late Payment</strong>: If any payment is late that is due under the payment schedule for more than 1 day  
        b. <strong>Default</strong>: If the Borrower defaults on any condition of this agreement
        
        <strong>11. Costs and Expenses</strong>: Borrower shall pay to the lender all costs of collecting, including reasonable attorney’s fees, the lender incurs in enforcing this agreement.
        
        <strong>12. Waiver</strong>: The Borrower and all sureties, guarantors and endorsers hereof, waive presentment, protest and demand, notice of protest, demand and dishonor and nonpayment of this agreement.
        
        <strong>13. Successors and Assigns</strong>: This agreement will inure to the benefit of and be binding on the respective successors and permitted assigns of the Lender and Borrower.
        
        <strong>14. Amendment</strong>: This agreement may be amended or modified only by a written agreement duly signed by both the Borrower and the Lender.
        
        <strong>15. Notices</strong>: Any notices or communication under this Loan must be in writing and in person delivered only.
        
        <strong>16. No Waiver</strong>: Lender shall not be deemed to have waived any provisions of this agreement or exercise of any rights held under this agreement unless such waiver is made expressly and in writing. Waiver by Lender of a breach or violation of any provision of this agreement shall not constitute a waiver of any other subsequent breach or violation.
        
        <strong>17. Severability</strong>: In the event that any of the provisions of this agreement are held to be invalid or unenforceable in whole or in part, the remaining provisions shall not be affected and shall continue to be valid and enforceable as though the invalid or unenforceable parts had not been included in this agreement.
        
        <strong>18. Assignment</strong>: Borrowers shall not assign this agreement, in whole or in part, without the written consent of Lender. Lender may assign all or any portion of this agreement with written notice of Borrower.
        
        <strong>19. Guarantors</strong>: <u>${guaratorssesss.replace(/--/g, '\n')}</u>.
   
        <strong>20. Governing Law</strong>: This agreement and its enforcement shall be governed by and construed in accordance with the laws of <strong>Uganda</strong>.
        
        <strong>21. Entire Agreement</strong>: This Agreement contains the entire understanding between the parties and supersedes and cancels all prior agreements of the parties, whether oral or written, with respect to such subject matter.
        
        <strong>IN WITNESS WHEREOF</strong>, the parties have executed this agreement as of the date first stated above.
        
        <strong>Borrower Sign:</strong>  
        Name…………………………………………………………………………………….  
        Mobile……………………………………………………………………………………  
        Borrower
        
        <strong>Guarantor Sign:</strong>  
        Name…………………………………………………………………………………….  
        Mobile……………………………………………………………………………………  
        Guarantor
        
        <strong>Guarantor Sign:</strong>  
        Name…………………………………………………………………………………….  
        Mobile……………………………………………………………………………………  
        Guarantor
        
        <strong>Guarantor Sign:</strong>  
        Name…………………………………………………………………………………….  
        Mobile……………………………………………………………………………………  
        Guarantor
        
        <strong>Uwezo Finacial Services Official:</strong>  
        Name……………………………………………………………………………………  
        Mobile…………………………………………………………………………………..  
        For Uwezo Financial Services Limited.
            </div>
        </div>
        `;
        container.html(htmlData);
  

        
    }

    // Fetch and render loan agreement details
    fetchLoanAgreementDetails();
};
