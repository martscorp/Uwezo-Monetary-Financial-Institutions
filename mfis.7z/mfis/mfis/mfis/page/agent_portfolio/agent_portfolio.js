/*
* This script has been modified to fetch data directly from the
* Frappe DocType REST APIs for "Client" and "Loan Application Plus".
* It also includes CSV export functionality for both tables.
*/

frappe.pages['agent-portfolio'].on_page_load = function(wrapper) {
    var page = frappe.ui.make_app_page({
        parent: wrapper,
        title: 'My Portfolio',
        single_column: false
    });

    // Get user session data
    const user = frappe.session.user_fullname;
    const user_email = frappe.session.user_email;
    const userRoles = frappe.session.user;

    // Create the main container and user info HTML
    var container = $('<div class="row user-profile"></div>').appendTo(page.main);
    container.append(`
        <div class="row g-4">
            <div class="col-12">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="dashboard-header-title">
                        <h5 class="mb-0">Welcome, <span class="text-info">${user}</span></h5>
                        <p class="mb-0">Account Information:</p>
                        <ul class="mb-0">
                            <li>Email: <span class="text-info">${user_email}</span></li>
                            <li>Membership Level: <span class="text-info">${userRoles}</span></li>
                            <li>Cash Account Balance: <span class="text-success" id="data_well">Loading...</span></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-12 mt-2">
                <div class="card">
                    <div class="card-body">
                        <div class="card-title d-flex align-items-center justify-content-between">
                            <h6 class="mb-0">Clients Attached</h6>
                        </div>
                        <div class="table-responsive text-nowrap">
                            <button onclick="exportTable('client-table','clients.csv')" class="btn btn-sm btn-primary mb-2">Export Clients</button>
                            <table id="client-table" class="table table-centered table-nowrap table-hover mb-0">
                                <thead>
                                    <tr>
                                      <th>#</th>
                                        <th>Account</th>
                                        <th>Client</th>
                                        <th>Mobile</th>
                                        <th>Gender</th>
                                        <th>Date created</th>
                                    </tr>
                                </thead>
                                <tbody id="client-table-body"></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12 mt-5">
                <div class="card">
                    <div class="card-body">
                        <div class="card-title d-flex align-items-center justify-content-between">
                            <h6 class="mb-0">Loans Attached</h6>
                        </div>
                        <div class="table-responsive text-nowrap">
                            <button onclick="exportTable('loan-table','loans.csv')" class="btn btn-sm btn-primary mb-2">Export Loans</button>
                            <table id="loan-table" class="table table-centered table-nowrap table-hover mb-0">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                         <th>Account</th>
                                        <th>Client</th>
                                        <th>Mobile</th>
                                        <th>Details</th>
                                        <th>Status</th>
                                        <th>Date created</th>
                                    </tr>
                                </thead>
                                <tbody id="loan-table-body"></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `);
let cc=0;
    // Step 1: Get the employee linked to the current user
    frappe.call({
        method: 'frappe.client.get_list',
        args: {
            doctype: 'Employee',
            filters: { user: frappe.session.user },
            fields: ['name'],
            limit: 1
        },
        callback: function(res) {
            if (res.message && res.message.length > 0) {
                const employeeName = res.message[0].name;
                

                // Step 2: Fetch Clients for this employee
                frappe.call({
                    method: 'frappe.client.get_list',
                    args: {
                        doctype: 'Client',
                        filters: { staff_id: employeeName },
                        fields: ['name', 'full_name', 'mobile', 'gender', 'creation'],
                        limit_page_length: 100   // instead of "limit"
                    },
                    callback: function(r) {
                        if (r.message && r.message.length > 0) {
                         
                            const clientRows = r.message.map(item => `
                                <tr>
                                 <td>${++cc}</td>
                                    <td><a href="savings-account/view/list?client=${item.name}">${item.name}</a></td>
                                    <td><a href="savings-account/view/list?client=${item.name}">${item.full_name}</a></td>
                                    <td class="text-success">${item.mobile}</td>
                                    <td>${item.gender}</td>
                                    <td>${item.creation}</td>
                                </tr>
                            `);
                            document.getElementById('client-table-body').innerHTML = clientRows.join('');
                        } else {
                            document.getElementById('client-table-body').innerHTML = '<tr><td colspan="5">No clients found.</td></tr>';
                        }
                    }
                });

                // Step 3: Fetch Loans for this employee
                frappe.call({
                    method: 'frappe.client.get_list',
                    args: {
                        doctype: 'Loan Application Plus',
                        filters: { loan_portfolio: employeeName },
                        fields: ['name', 'client_name', 'mobile_contacts', 'principal', 'loan_interest', 'status', 'creation'],
                        limit_page_length: 0   // instead of "limit"
                    },
                    callback: function(r) {
                        let cc=0;
                        if (r.message && r.message.length > 0) {
                          
                            const loanRows = r.message.map(item => `
                                <tr>
                                    <td>${++cc}</td>
                                    <td><a href="loan-application-plus/${item.name}">${item.name}</a></td>
                                    <td>${item.client_name}</td>
                                    <td class="text-success">${item.mobile_contacts}</td>
                                    <td>Principal : ${item.principal}<br>Interest rate : ${item.loan_interest}%</td>
                                    <td>${item.status}</td>
                                    <td>${item.creation}</td>
                                </tr>
                            `);
                            document.getElementById('loan-table-body').innerHTML = loanRows.join('');
                        } else {
                            document.getElementById('loan-table-body').innerHTML = '<tr><td colspan="6">No loans found.</td></tr>';
                        }
                    }
                });

            } else {
                document.getElementById('client-table-body').innerHTML = '<tr><td colspan="5">No employee linked to this user.</td></tr>';
                document.getElementById('loan-table-body').innerHTML = '<tr><td colspan="6">No employee linked to this user.</td></tr>';
            }
        }
    });
};

// Export table to CSV
function exportTable(tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) {
        alert("Table not found: " + tableId);
        return;
    }

    let csv = [];

    // Include only visible table header (neat column names)
    const headers = Array.from(table.querySelectorAll("thead th"))
        .map(th => '"' + th.innerText.trim().replace(/"/g, '""') + '"');
    if (headers.length) csv.push(headers.join(","));

    // Loop through tbody rows only
    const rows = table.querySelectorAll("tbody tr");
    rows.forEach(row => {
        let cols = [];
        row.querySelectorAll("td").forEach(cell => {
            let text = cell.innerText.trim().replace(/"/g, '""');
            cols.push('"' + text + '"');
        });
        csv.push(cols.join(","));
    });

    // Create downloadable CSV
    const csvFile = new Blob([csv.join("\n")], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(csvFile);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}
