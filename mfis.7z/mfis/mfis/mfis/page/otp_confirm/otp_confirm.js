frappe.pages['otp-confirm'].on_page_load = async function(wrapper) {
    $('.container').hide();
    var userId = frappe.session.user;

    // Retrieve Employee document
// Make the AJAX call
$.ajax({
    url: "/Employee/get_employee_data",
    method: "GET",
    success: function(response) {
        // Handle the response data
        console.log(response);
    },
    error: function(xhr, status, error) {
        console.error("Error fetching employee data:", error);
    }
});



    var page = frappe.ui.make_app_page({
        parent: wrapper,
        title: 'Enter OTP Sent to ' + userId,
        single_column: true
    });

    var body = $('<div>').appendTo(page.body);
    var otpContainer = $('<div class="otp-container">').appendTo(body);

    // OTP Input Fields
    var otpInputs = '';
    for (var i = 0; i < 1; i++) {
        otpInputs += '<input type="password" maxlength="6" class="otp-input" />';
    }
    otpContainer.append(otpInputs);

    // Resend Button
    var resendButton = $('<br><br><button class="btn btn-default">Resend OTP</button>');
    resendButton.appendTo(otpContainer);
    resendButton.on('click', function() {
    
        var otp = '';
        $('.otp-input').each(function() {
            otp += $(this).val();
        });
        sendOTP('0758593071').then(response => {
            console.log(response);
        }).catch(error => {
            console.error(error);
        });
    
    });

    // Function to send OTP
    async function sendOTP(numbersString) {
        const url = 'http://45.77.66.10/api/send_sms';
        const headers = {
            'Content-Type': 'application/json',
            'Accept': '*/*',
            'Authorization': 'Bearer 68o3IgTdNwAvm0BBGDVeklrdUoJKXDIzRWRpYzRVIP5MKr4CPkpfZJAjc38He1lDtDTGXIJy6BwLkO8x'
        };
        var userId = frappe.session.user;
        const otp = Math.floor(Math.random() * (999999 - 100000 + 1)) + 100000;
        const message = `Dear `+userId+`,  Your Uwezo Desk-Access OTP is: ${otp}`;

        const data = {
            message: message,
            numbers: numbersString
        };

        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: headers,
                body: JSON.stringify(data)
            });
            if (!response.ok) {
                throw new Error('Failed to send OTP');
            }
            return {
                otp,
                message: 'Success: OTP sent successfully'
            };
        } catch (error) {
            console.error('Error:', error.message);
            throw new Error('Failed to send OTP');
        }
    }

    // Submit Button
    var submitButton = $('<button class="btn btn-primary mx-2">Submit</button>');
    submitButton.appendTo(otpContainer);
    submitButton.on('click', function() {


    });

    // Back to Login Button
    var loginButton = $('<br><br> <a class="text-primary mx-2" href="/?cmd=web_logout">Back To Login</a>');
    loginButton.appendTo(otpContainer);
    loginButton.on('click', function() {
        // Code to handle back to login
    });

    // Add responsive styles
    function updateStyles() {
        var screenWidth = $(window).width();

        if (screenWidth <= 600) {
            $('.otp-input').css({
                'width': '30%',
                'height': '30px',
                'font-size': '1em'
            });
            $('.btn').css({
                'font-size': '1em',
                'padding': '8px 15px'
            });
        } else {
            $('.otp-input').css({
                'width': '30%',
                'height': '40px',
                'font-size': '1.2em'
            });
            $('.btn').css({
                'font-size': '1.1em',
                'padding': '10px 20px'
            });
        }
    }

    // Call the function initially and on window resize
    updateStyles();
    $(window).on('resize', updateStyles);
};
