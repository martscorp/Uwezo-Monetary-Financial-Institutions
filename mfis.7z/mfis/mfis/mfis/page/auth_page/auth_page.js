frappe.pages['auth-page'].on_page_load = function(wrapper) {
    var page = frappe.ui.make_app_page({
        parent: wrapper,
        title: 'Device Auth Page',
        single_column: true
    });

    // Add a heading and an image
    $(page.body).append('<h3 style="text-align: center; font-size: 20px; color: #333;">Authenticate Your Device</h3>');
    $(page.body).append('<img id="auth_image" src="https://media.lordicon.com/icons/wired/flat/478-computer-display.gif" alt="Authentication Image" style="display: block; margin: 0 auto; width: 150px; margin-bottom: 20px;" />');
    
    // Add a status message
    var status_text = $('<p id="status_text" style="text-align: center; font-size: 14px; color: #333;">Please wait, authenticating your device...</p>');
    $(page.body).append(status_text);

    // Add a modern progress bar (hidden initially)
    var progress_bar = $('<div id="progress_bar" style="width: 100%; background-color: #f3f3f3; height: 15px; margin-bottom: 20px; border-radius: 10px;">' +
        '<div id="progress" style="width: 0%; height: 100%; background-color: #4caf50; border-radius: 10px;"></div>' +
        '</div>');
    $(page.body).append(progress_bar);

    // Create a container for displaying data from the URL
    var data_container = `
        <div style="text-align: center; margin-bottom: 15px;">
            <h4 id="device_id_display" style="font-size: 14px; color: #555;">Device ID: Loading...</h4>
        </div>
        <div style="text-align: center; margin-bottom: 15px;">
            <h4 id="otp_display" style="font-size: 14px; color: #555;">User OTP: Loading...</h4>
        </div>
        <div style="text-align: center;">
            <button id="auth_button" style="padding: 10px 18px; font-size: 14px; background-color: #4caf50; color: white; border: none; border-radius: 5px; cursor: pointer; margin-top: 10px;">Authenticate</button>
        </div>
    `;
    $(page.body).append(data_container);

    // Add a cancel button with modern styling
    var cancel_button = $('<button id="cancel_button" style="padding: 10px 18px; font-size: 14px; background-color: red; color: white; border: none; border-radius: 5px; cursor: pointer; margin-top: 10px;">Cancel</button>');
    $(page.body).append(cancel_button);

    // Automatically trigger the authentication process
    setTimeout(function() {
        $('#auth_button').click(); // Automatically click the authenticate button
    }, 1000); // Adjust the timeout as needed

    // Retrieve query parameters from the URL
    var urlParams = new URLSearchParams(window.location.search);
    var device_id_from_url = urlParams.get('device_id');
    var otp_from_url = urlParams.get('otp');

    if (device_id_from_url && otp_from_url) {
        // Display fetched data in h4 elements
        $('#device_id_display').text('Device ID: ' + device_id_from_url);
        $('#otp_display').text('User ID: ' + otp_from_url);
    } else {
        $('#device_id_display').text('Device ID: Not provided.');
        $('#otp_display').text('User ID: Not provided.');
    }

    // Handle button click
    $('#auth_button').on('click', function() {
        var device_id = $('#device_id_display').text().replace('Device ID: ', '');
        var otp = $('#otp_display').text().replace('User ID: ', '');

        // Show the progress bar and status message
        $('#progress_bar').show();
        $('#status_text').text('Authenticating, please wait...');
        $('#progress').css('width', '0%'); // Reset the progress bar

        // Simulate progress (replace this with actual backend logic)
        var progress = 0;
        var interval = setInterval(function() {
            progress += 10;

            // Update progress bar
            $('#progress').css('width', progress + '%');

            // Check if progress is complete
            if (progress >= 100) {
                clearInterval(interval);
                // Perform authentication logic
                frappe.call({
                    method: 'mfis.clients.create_device?device_id='+device_id_from_url+'&owner='+device_id_from_url+'&branch=10&user='+otp_from_url+'',
                    args: {
                        device_id: device_id,
                        otp: otp
                    },
                    callback: function(response) {
                        if (response.message && response.message.message === 'Device created successfully') {
                          
                            $('#progress').css('width', '100%');
                        } else {
                            $('#status_text').text('Authentication failed. Please try again.');
                            $('#progress').css('width', '100%');
                        }

                        // Hide most elements and change image after authentication
                        setTimeout(function() {
                            // Hide most elements
                            $('h3, #device_id_display, #otp_display, #auth_button, #cancel_button, #progress_bar').hide();
							$('#status_text').text('Device authenticated successfully, Please wait to be redirected !');
                            // Change image source
                            $('#auth_image').attr('src', 'https://i.pinimg.com/originals/30/3e/f1/303ef12fdda83daaff43f8460d27c053.gif');
                        }, 3000); // 3 seconds delay after authentication
                    }
                });
            }
        }, 500); // Adjust the interval as needed (currently every 0.5 seconds)
    });

    // Cancel button functionality
    $('#cancel_button').on('click', function() {
        clearInterval(interval);  // Stop progress
        $('#status_text').text('Authentication canceled.');
        $('#progress').css('width', '0%');
        $('#progress_bar').hide();
    });

    // Get the IP address details from a URL (using a service to get the IP)
    $.get('https://api.ipify.org?format=json', function(data) {
        var ip_address = data.ip;
        console.log("User IP Address: " + ip_address);
        // Optionally, display the IP address in the UI
        $(page.body).append('<p style="text-align: center;">Your IP address: ' + ip_address + '</p>');
    });
};
