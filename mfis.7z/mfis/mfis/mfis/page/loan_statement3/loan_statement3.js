frappe.pages['loan-statement3'].on_page_load = function(wrapper) {
	var page = frappe.ui.make_app_page({
		parent: wrapper,
		title: 'Loan Statement',
		single_column: true
	});


    page.main.html(`
        <section class="content">
	
            <div class="container ">
				<div style="display: flex; justify-content: center; align-items: center; height: 15px; flex-direction: column;">
    <!-- Progress Bar HTML -->
    <div style="width: 100%; background-color: #f3f3f3; border-radius: 5px; margin-top: 20px;">
        <div id="progress-bar" style="width: 0%; height: 10px; background-color: orange; border-radius: 5px; text-align: center; color: white;"></div>
    </div>
    <div id="progress-text" style="text-align: center; margin-top: 10px;">0% </div>
	 
</div>
   <h4 class="m-2">Loan Statement</h4>
	  <div style="display: flex; justify-content: center; margin-bottom: 10px; margin-top:2%;">

    
                    <button class="btn btn-primary btn-icon mx-1" type="button" onclick="printdiv()">
                        <i class="zmdi zmdi-print"></i> Print Statement 
                    </button>
                   <button class="btn btn-success btn-icon mx-1" type="button" onclick="printdiv()">
                        <i class="zmdi zmdi-print"></i> Export to Excel
                    </button>
                </div>
                <div id="loan-simulator-content"></div>
            </div>

            
              
        </section>
    `);

    window.printdiv = function() {
       
		const divToPrint = document.getElementById('loan-simulator-content');
		const originalContent = document.body.innerHTML;
  
		// Replace the page's content with the div content temporarily
		document.body.innerHTML = divToPrint.outerHTML;
		window.print();
  
		// Restore the original content after printing
		document.body.innerHTML = originalContent;
		
    };

    window.goBack = function() {
        window.history.back();
    };

    function getQueryParam(name) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(name);
    }

// Retrieve parameters from URL and safely remove '%' if value exists
var name = getQueryParam('name') ? getQueryParam('name').replace(/%/g, '') : '';
var refNo = getQueryParam('refNo') ? getQueryParam('refNo').replace(/%/g, '') : '';
var loan_date = getQueryParam('loanApprovalDate') ? getQueryParam('loanApprovalDate').replace(/%/g, '') : '';
var loan_amount = getQueryParam('principalAmount') ? parseFloat(getQueryParam('principalAmount').replace(/%/g, '')) : 0;
var loan_purpose = getQueryParam('loanPurpose') ? getQueryParam('loanPurpose').replace(/%/g, '') : '';
var loan_interest = getQueryParam('interestRate') ? parseFloat(getQueryParam('interestRate').replace(/%/g, '')) : 0;
var collection_fees = getQueryParam('collection_fees') ? parseFloat(getQueryParam('collection_fees').replace(/%/g, '')) : 0;
var loan_term = getQueryParam('loanPeriod') ? parseInt(getQueryParam('loanPeriod').replace(/%/g, '')) : 0;
var repayment_type = getQueryParam('payment_intervals') ? getQueryParam('payment_intervals').replace(/%/g, '') : '';
var compulsory_saving_percentage = getQueryParam('compulsorySavingPercentage') ? parseFloat(getQueryParam('compulsorySavingPercentage').replace(/%/g, '')) : 0;
var grace_period = getQueryParam('grace_period_on_disbursment') ? getQueryParam('grace_period_on_disbursment').replace(/%/g, '') : '';
var early_settlement_charge = getQueryParam('earlySettlementCharge') ? getQueryParam('earlySettlementCharge').replace(/%/g, '') : '';
var cash_collateral = getQueryParam('cashCollateral') ? getQueryParam('cashCollateral').replace(/%/g, '') : '';
var guarantors = getQueryParam('guarantors') ? getQueryParam('guarantors').replace(/%/g, '') : '';
var phone_number = getQueryParam('phoneNumber') ? getQueryParam('phoneNumber').replace(/%/g, '') : '';
var lastloandate = new Date(loan_date);

var lastpr = grace_period;
var lastpr2 = grace_period;
var runnintotal = loan_amount;
	var loan_amount2 =loan_amount;
	var payments_amounter =0;
	var extradaysrepaid =0;
	let response = frappe.call({
		method: 'mfis.clients.get_total_repayments',
		args: {
			loan_id: refNo // Replace with your dynamic loan ID
		},
		callback: function(data) {
			if (data.message) {
				payments_amounter  = data.message
				loan_amount = loan_amount - payments_amounter
				fetchSkippedDaysAndGenerateSchedule();

			} else {
				
			}
		}
	});
	
    // Check if parameters are missing
    if (!loan_date || isNaN(loan_amount) || isNaN(loan_interest) || isNaN(loan_term)) {
        // Prompt user for loan details if not available in URL
        frappe.prompt([
            { fieldtype: 'Date', label: 'Loan Approval Date', fieldname: 'loanApprovalDate', reqd: true },
            { fieldtype: 'Currency', label: 'Principal Amount', fieldname: 'principalAmount', reqd: true },
            { fieldtype: 'Float', label: 'Interest Rate (%)', fieldname: 'interestRate', reqd: true },
            { fieldtype: 'Int', label: 'Loan Period (Days)', fieldname: 'loanPeriod', reqd: true },
            { fieldtype: 'Select', fieldname: 'repaymentType', label: 'Repayment Type', options: 'Days\nWeeks\nMonths\nYears', default: repayment_type },
            { fieldtype: 'Int', label: 'Grace Period (Days)', fieldname: 'gracePeriod', reqd: false },
            { fieldtype: 'Float', label: 'Compulsory Saving (%)', fieldname: 'compulsorySavingPercentage', reqd: false }
        ], 
        function(values) {
            loan_date = values.loanApprovalDate;
            loan_amount = parseFloat(values.principalAmount);
            loan_interest = parseFloat(values.interestRate);
            loan_term = parseInt(values.loanPeriod);
            grace_period = parseInt(values.gracePeriod) || 0;
            compulsory_saving_percentage = parseFloat(values.compulsorySavingPercentage) || 0;
            repayment_type = values.repaymentType || 'Days';

           
        }, 
        'Enter Loan Details', 
        'Submit');
    } else {
        // If parameters are available, generate loan schedule directly
       
    }

    function fetchSkippedDaysAndGenerateSchedule() {
        frappe.call({
            method: 'frappe.client.get',
            args: {
                doctype: 'Loan Application Plus',
                name: refNo
            },
            callback: function(response) {
                if (response.message) {
                    var calendarSettings = response.message['calendar_settings']; // Assuming this is the field pointing to Calendar Settings

                    // Fetch No Working Days2 from each Calendar Settings record
                    if (calendarSettings && calendarSettings.length > 0) {
              

                        Promise.all(calendarSettings).then(function(results) {
                            var allNoWorkingDays2 = results.flat();

                            var skipped_days = allNoWorkingDays2.map(record => record.day);
                            var skipped_dates = allNoWorkingDays2.map(record => record.date);

                            // Generate the loan schedule with the fetched data
                            generateLoanSchedule(skipped_days, skipped_dates);
                        });
                    } else {
                        console.error('No Calendar Settings records found.');
                    }
                } else {
                    console.error('No data received from server.');
                }
            },
            error: function(err) {
                console.error('Error fetching Loan Application Plus record:', err);
            }
        });
    }

    

    function formatDateToWord(dateString) {
        var date = new Date(dateString);
        var dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        var monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    
        var dayName = dayNames[date.getDay()];
        var day = date.getDate();
        var monthName = monthNames[date.getMonth()];
        var year = date.getFullYear();
    
        // Add ordinal suffix
        var ordinalSuffix;
        if (day >= 1 && day <= 3 || day >= 21 && day <= 23) {
            ordinalSuffix = 'st';
        } else if (day >= 4 && day <= 20 || day >= 24 && day <= 30) {
            ordinalSuffix = 'th';
        } else if (day === 31) {
            ordinalSuffix = 'st';
        }
    
        return `${dayName} ${day}${ordinalSuffix} ${monthName} ${year}`;
    }

	function formatDateString(dateString) {
		// Remove the day of the week and the ordinal suffix (e.g., "th", "rd", etc.)
		const cleanDate = dateString.replace(/^\w+\s|\d+(st|nd|rd|th)/g, (match) => {
			return /\d/.test(match) ? match.replace(/\D/g, '') : '';
		});
	
		// Parse the date string into a Date object
		const dateObj = new Date(cleanDate);
	
		// Format as YYYY-MM-DD
		return `${dateObj.getFullYear()}-${(dateObj.getMonth() + 1).toString().padStart(2, '0')}-${dateObj.getDate().toString().padStart(2, '0')}`;
	}
	let completedRequests = 0;
	function updateProgressBar(percentage) {
		const progressBar = document.getElementById('progress-bar');
		const progressText = document.getElementById('progress-text');
		progressBar.style.width = `${percentage}%`;
		progressText.innerHTML = `${Math.round(percentage)}% Completed`;
		if (percentage >= 100) {
			progressBar.style.display = 'none';  // Hide the progress bar
			progressText.innerHTML = '';  // Change text to "Completed"
		}
	}

    async  function generateLoanSchedule(skipped_days, skipped_dates) {
        var loanTimestamp = new Date(loan_date).getTime();

        var interest_rate_per_day = (loan_interest / 100) / 30;
        var daily_interest = loan_amount2 * interest_rate_per_day;


 		var interest_rate_per_day2 = (2.5 / 100) / 30;
		var daily_interest2 = loan_amount2 * interest_rate_per_day2;


		var interest_rate_per_day3 = (1.5 / 100) / 30;
		var daily_interest3 = loan_amount2 * interest_rate_per_day3;
		
		

        // Normalize skipped_dates to "YYYY-MM-DD" format
        var normalizedSkippedDates = skipped_dates.map(date => {
            var d = new Date(date);
            return d.toISOString().split('T')[0]; // "YYYY-MM-DD" format
        });

        var repayment_dates = [];
        var last_date = "";
        var grace_period_interest = 0;
		var grace_period_interest2 = 0;
		var grace_period_interest3 = 0;
        var accumulated_interest = 0;
		var accumulated_interest2 = 0;
		var accumulated_interest3 = 0;
				// Assuming `loan` is the loan ID you want to filter by
				

        if (repayment_type === "Days") {
            var actual_repayment_days = loan_term;

            for (var i = 0; i < grace_period; i++) {
                grace_period_interest += daily_interest;
				grace_period_interest2 += daily_interest2;
				grace_period_interest3 += daily_interest3;
            }

            for (var i = 0; i < loan_term; i++) {
                var repayment_date = new Date(loanTimestamp + i * 24 * 60 * 60 * 1000);
                var formatted_date = repayment_date.toISOString().split('T')[0]; // "YYYY-MM-DD" format

                if (normalizedSkippedDates.includes(formatted_date) || skipped_days.includes(repayment_date.toLocaleString('en-US', { weekday: 'long' }))) {
                    accumulated_interest += daily_interest;
					accumulated_interest2 += daily_interest2;
					accumulated_interest3 += daily_interest3;
                    continue;
                }

                repayment_dates.push({
                    date: formatDateToWord(repayment_date), // Format the date here
                    accumulated_interest: accumulated_interest,
					accumulated_interest2: accumulated_interest2,
					accumulated_interest3: accumulated_interest3,
                    isMondayAfterSkippedSunday: repayment_date.getDay() === 1 && skipped_days.includes('Sunday')
                });
// if(i < loan_term-(extradaysrepaid)){
// 	  last_date = formatDateToWord(repayment_date);
// }
              
                accumulated_interest = 0;
				accumulated_interest2 = 0;
				accumulated_interest3 = 0;
            }

			let loanRepaymentDates = await getLoanRepaymentDates(refNo); // Await the response

			if (!Array.isArray(loanRepaymentDates)) {
				console.error("loanRepaymentDates is not an array", loanRepaymentDates);
				loanRepaymentDates = []; // Default to an empty array to prevent errors
			}
		
			let repaymentDatesSet = new Set(repayment_dates.map(entry => entry.date)); // Create a Set of existing dates
		
			loanRepaymentDates.forEach(repaymentDate => {
				let formattedRepaymentDate = formatDateToWord(new Date(repaymentDate));
				if (!repaymentDatesSet.has(formattedRepaymentDate)) {
					extradaysrepaid+=1;
					repayment_dates.push({
						date: formattedRepaymentDate,
						accumulatedInterest1: 0,
						accumulatedInterest2: 0,
						accumulatedInterest3: 0,
						isMondayAfterSkippedSunday: false
					});
				}
			});

  
			var total_interest = ((loan_term) * daily_interest) ;

            var constant_due_amount = (loan_amount + total_interest) / repayment_dates.length;
			var constant_due_amount2 = (loan_amount2 + total_interest) / repayment_dates.length;
			grace_period2 = grace_period-1;

			if(grace_period>0){
			constant_due_amount = (loan_amount + total_interest) / (repayment_dates.length-(grace_period2+(extradaysrepaid)));
			constant_due_amount2 = (loan_amount2 + total_interest) / (repayment_dates.length-(grace_period2+(extradaysrepaid)));
			}

						// Assuming repayment_dates contains an array of already formatted `created_on` dates

		


            var tableContent = `
                <div class="boxx">
				

<div class="d-flex align-items-start gap-3 mt-3">
  <div class="container p-3 ">

    <h6>Customer Name : <b>${name}</b></h6>
    <h6>Loan Account  : <b>${refNo}</b></h6>
    <h6>Mobile Contact: <b>${phone_number}</b> </h6>
    <h6>Business Location: -</h6>

  </div>

  <div class="container p-3 ">

    <h6>Disbursement Date: <b>${loan_date }</b></h6>
 
	 <h6>Interest Rate: 
      <b class="text-info mt-2">${loan_interest}%</b>
	  Collection: 
		<b class="text-info mt-2">${collection_fees}%</b>
    </h6>

    <h6>Loan Term: 
      <b class="text-success mt-2">${(loan_term).toFixed(2)}/${repayment_type }</b></b>
    </h6>
    <h6>Loan Repayement Interval : <b>${repayment_type }</b></h6>


  
  </div>

      <div class="container p-3 ">

	  <h6>Disbursed Amount : <b>${(loan_amount2).toLocaleString(2) }</b></h6>
	  <h6>Expected Interest : <b>${(total_interest).toLocaleString(2) } </b> 
  
	  </h6>
	  <h6>Collection Fees : -</h6>
	  <h6>Total Repayments : <b class="text-success mt-2">${(total_interest + loan_amount2).toLocaleString(2)}</b> </h6>

	  
  </div>

    <div class="container p-3 ">

     <h6>Outstanding Principle : <b>${(loan_amount2-payments_amounter).toLocaleString(2)}</b></h6>
    <h6>Interest in Arrears : 
      <b class="text-success mt-2">-</b>
    </h6>
	<h6>Expected Interest : 
      <b class="text-success mt-2">-</b>
    </h6>

  </div>
</div>

                    <table class="table table-bordered table-hover dataTable js-exportable" id="myTable">
              <thead>
        <!-- Main Header -->
        <tr>
            <th rowspan="2" style="background-color: #d9ead3; text-align: center; white-space: nowrap;">Nos</th>
            <th colspan="3" style="background-color: #d9ead3; text-align: center; white-space: nowrap;"></th>
            <th colspan="5" style="background-color: #fce5cd; text-align: center; white-space: nowrap;">Loan Installment </th>
            <th colspan="4" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">Distribution of Payment</th>
            <th rowspan="2" style="background-color: #fff2cc; text-align: center; white-space: nowrap;">Debit</th>
            <th rowspan="2" style="background-color: #fff2cc; text-align: center; white-space: nowrap;">Credit</th>
          
            <th colspan="4" rowspan="1" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">Totals Due</th>
            <th rowspan="2" style="background-color: #f4cccc; text-align: center; white-space: nowrap;">Penalties</th>
            <th rowspan="2" style="background-color: #f4cccc; text-align: center; white-space: nowrap;">Days in Arrears</th>
            <th rowspan="2" style="background-color: #f4cccc; text-align: center; white-space: nowrap;">Total Outstanding</th>
        </tr>
        <!-- Sub Headers -->
        <tr>
            <th style="background-color: #eafaf1; text-align: center; white-space: nowrap;">Payment Date</th>
            <th style="background-color: #eafaf1; text-align: center; white-space: nowrap;">Description</th>
           <th style="background-color: #eafaf1; text-align: center; white-space: nowrap;">Transaction ID</th>
            <th style="background-color: #fce5cd; text-align: center; white-space: nowrap;">Principle</th>
            <th style="background-color: #fff2cc; text-align: center; white-space: nowrap;">Total Charge</th>
			<th style="background-color: #fce5cd; text-align: center; white-space: nowrap;">Interest</th>
			<th style="background-color: #fce5cd; text-align: center; white-space: nowrap;">Collection</th>
            <th style="background-color: #fce5cd; text-align: center; white-space: nowrap;">Total</th>
            <th style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">Principle</th>
            <th style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">Interest</th>
			<th style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">Penalty</th>
            <th style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">Total Payment</th>

              <th style="background-color: #e6b8af; text-align: center; white-space: nowrap;">Principle</th>
            <th style="background-color: #e6b8af; text-align: center; white-space: nowrap;">Interest</th>
            <th style="background-color: #e6b8af; text-align: center; white-space: nowrap;">Penalty</th>
			 <th style="background-color: #e6b8af; text-align: center; white-space: nowrap;">Total Principle</th>
         
        </tr>
    </thead>

                        <tbody>
            `;

			total_interest + loan_amount2
			tableContent += `
			<tr>
				<td style="background-color: #d9ead3; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #eafaf1; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #eafaf1; text-align: center; white-space: nowrap;">Disburesement</td>
		<td style="background-color: #eafaf1; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #fce5cd; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #fff2cc; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #fce5cd; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #fce5cd; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #fce5cd; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #d9d2e9; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #d9d2e9; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #d9d2e9; text-align: center; white-space: nowrap;"></td>
					<td style="background-color: #d9d2e9; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #fff2cc; text-align: center; white-space: nowrap;">${(loan_amount2).toFixed(2)}</td>
				<td style="background-color: #fff2cc; text-align: center; white-space: nowrap;"></td>
	
				<td style="background-color: #e6b8af; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #e6b8af; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #e6b8af; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #e6b8af; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #f4cccc; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #f4cccc; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #f4cccc; text-align: center; white-space: nowrap;"></td>
			</tr>
			`;
			
			tableContent += `
			<tr>
				<td style="background-color: #d9ead3; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #eafaf1; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #eafaf1; text-align: center; white-space: nowrap;">Interest</td>
		<td style="background-color: #eafaf1; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #fce5cd; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #fff2cc; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #fce5cd; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #fce5cd; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #fce5cd; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #d9d2e9; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #d9d2e9; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #d9d2e9; text-align: center; white-space: nowrap;"></td>
					<td style="background-color: #d9d2e9; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #fff2cc; text-align: center; white-space: nowrap;">${(total_interest ).toFixed(2)}</td>
				<td style="background-color: #fff2cc; text-align: center; white-space: nowrap;"></td>
	
				<td style="background-color: #e6b8af; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #e6b8af; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #e6b8af; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #e6b8af; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #f4cccc; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #f4cccc; text-align: center; white-space: nowrap;"></td>
				<td style="background-color: #f4cccc; text-align: center; white-space: nowrap;"></td>
			</tr>
			`;


            var totalPrincipal = 0;
            var totalInterest = 0;
            var totalSavings = 0;
            var totalDue = 0;
            var totalBalance = loan_amount2;
			var totalBalance2 = 0;
			let totalRequests = repayment_dates.length-(extradaysrepaid);

			var totalPrincipal2 = 0;
            var totalInterest2 = 0;
			var totalInterest23 = 0;
			var totalInterest24 = 0;
            var totalDue2 = 0;
				

			var rela_loop = 0;
            for (var i = 0; i < repayment_dates.length; i++) {

				if((i) < (repayment_dates.length-(extradaysrepaid))){
				rela_loop+=1;
				if(i>=grace_period-1){
                var interest = daily_interest + repayment_dates[i].accumulated_interest;
				var interest2 = daily_interest2 + repayment_dates[i].accumulated_interest2;
				var interest3 = daily_interest3 + repayment_dates[i].accumulated_interest3;

                if (rela_loop === grace_period) {
					if(grace_period>0){
						interest += grace_period_interest;
						interest2 += grace_period_interest2;
						interest3 += grace_period_interest3;
					}else{
						interest += grace_period_interest;
						interest2 += grace_period_interest2;
						interest3 += grace_period_interest3;
					}
                  
                }

				var formattedDate = formatDateString(repayment_dates[i].date);

				var cleanedRefNo = refNo.replace('%', '');
		 		let totalAmount = 0;
				
				
				 const repaymentPromises = repayment_dates.map((repayment, i) => {
					return new Promise((resolve) => {
						
						frappe.call({
							method: 'frappe.client.get_list',
							args: {
								doctype: 'Loan Repayment',
								filters: {
									loan: refNo.replace('%', ''), // Cleaned refNo
									created_on: repayment.date // Pass the formatted date
								},
								fields: ['name', 'created_on', 'amount', 'loan']
							},
							callback: function (r) {
								const repaymentData = {
									index: i + 1,
									name : name,
									date: repayment.date,
									principal: constant_due_amount - daily_interest,
									interest: daily_interest,
									total: constant_due_amount,
									repaid: r.message ? r.message.reduce((sum, item) => sum + item.amount, 0) : 0,
									names: r.message ? r.message.map(item => item.name) : [],
								};
								resolve(repaymentData);

								       // Update progress bar inside the callback
									   completedRequests++;
									   const progressPercentage = (completedRequests / totalRequests) * 100;
									   if(progressPercentage<=100){
							

										updateProgressBar(progressPercentage);
									   }
									   
							}
						});
					});
				});

				const repaymentPromises2 = repayment_dates.map((repayment, i) => {
					return new Promise((resolve) => {
						completedRequests = 0;
						frappe.call({
							method: 'frappe.client.get_list',
							args: {
								doctype: 'Loan Repayment',
								filters: {
									loan: refNo.replace('%', ''), // Cleaned refNo
									created_on: repayment.date // Pass the formatted date
								},
								fields: ['name', 'created_on', 'amount', 'loan']
							},
							callback: function (r) {
								const repaymentData = {
									index: i + 1,
								
									date: repayment.date,
									principal: constant_due_amount - daily_interest,
									interest: daily_interest,
									total: constant_due_amount,
									repaid: r.message ? r.message.reduce((sum, item) => sum + item.amount, 0) : 0,
									names: r.message ? r.message.map(item => item.name) : [],

								};
								resolve(repaymentData);
								

								
								       // Update progress bar inside the callback
							
									   
							}
						});
					});
				});

				var ccppl = 0;
				var totalpaid_before = 0;
				var totalpaid_beforei = 0;
				var data_grte = 0;

						
				function formatDate(date) {
					// Ensure the input is a valid Date object, if not, create a Date object
					if (!(date instanceof Date)) {
						date = new Date(date); // Convert from string to Date
					}
				
					// Check if the date is still invalid
					if (isNaN(date)) {
						console.error("Invalid date:", date);
						return 'Invalid Date'; // Or return an empty string or placeholder
					}
				
					// Extract the date part in YYYY-MM-DD format
					return date.toISOString().split('T')[0]; 
				}
				
var latsestlopr =0;
var latsestlopr2 =0;
			
					Promise.all(repaymentPromises).then((results) => {
						var payments_amounter2 = payments_amounter;
						runnintotal = loan_amount2+total_interest;
						 var total_priciple = 0;
						var totaliterstpaid = 0;
						var totaliterstpaid2= 0;
						 lastpr = grace_period;
						 lastpr2 = grace_period;

					
						document.getElementById(`ttotalamount`).innerHTML = "0";
							results.forEach((data) => {
	
								totalpaid_before += data.repaid;
							
							// Get the amount repaid from the repayment data
							const repaidAmount = data.repaid;
							var principal =  0;
							var interest =   0;
							var ppg =   0;
							var date2 = loan_date; // Ensure loan_date is valid
							
							
							var amount  = repaidAmount;
						
				
							
							if(repaidAmount>0){
								latsestlopr+=1;
								runnintotal -= repaidAmount;
								total_priciple += amount;
	
							var date1  =   convertToISO(data.date);
							let dateOnly = date2.split(" ")[0]; 
							var date11 = new Date(date1);
							var date21 = new Date(dateOnly);
							var date21e = new Date(dateOnly);
							date21e.setDate(date21.getDate() + loan_term-1);
							date21.setDate(date21.getDate() + grace_period);
							
	
							const diffTime = date11 - date21; // Difference in milliseconds
							const diffTimel = date21e - date11; // Difference in milliseconds
							const diffDays = diffTime / (1000 * 60 * 60 * 24); 
							const diffDayse = diffTimel / (1000 * 60 * 60 * 24); 
	
	
					
							if (diffDays < 1 ) {
	
								while (amount > 0) {
						
									principal = parseFloat(document.getElementById(`col-8-${lastpr2}`).innerHTML);
									interest = parseFloat(document.getElementById(`col-9-${lastpr2}`).innerHTML);
								
									datageter = (totalpaid_before-total_interest)
									if (totaliterstpaid2 >  datageter) {
								
										amount=0;
										break;
									}else{
								
										amount -= principal;
										totaliterstpaid2 += principal;
	
										
										let principleField = document.getElementById(`col-11-${lastpr2}`);
										if (principleField) {
											principleField.innerHTML = principal.toFixed(2);
										}
										lastpr2++;
									
									}
									
									
								}
	
							}else if (diffDayse >= 0 ) {
								
							
	
								var date1  =   convertToISO(data.date);
								
								var date112 = new Date(date1);
								
							
								while (amount > 0) {
	
									date_looped  = document.getElementById(`col-2-${lastpr}`).innerHTML;
									var date212 = new Date(date_looped);
									const diffTime2 =  date112 - date212; // Difference in milliseconds
									const diffDays2 = diffTime2 / (1000 * 60 * 60 * 24); 
								
	
									 
									if(diffDays2<0){
									datageter = (totalpaid_before-totaliterstpaid)
	
										
										
								while (amount > 0) {
									
									principal = parseFloat(document.getElementById(`col-8-${lastpr2}`).innerHTML);
									interest = parseFloat(document.getElementById(`col-9-${lastpr2}`).innerHTML);
								
									
									if (totaliterstpaid2 >  datageter) {
										
									amount -= principal;
										totaliterstpaid2 += principal;
	
										
									
										lastpr2++;
	
									}else{
										amount -= principal;
										totaliterstpaid2 += principal;
	
										
										lastpr2++;
										
									
									}
									
								
								}
	
							}else{
	
									
								if (totaliterstpaid < total_interest) {
									principal = parseFloat(document.getElementById(`col-8-${lastpr}`).innerHTML);
									interest = parseFloat(document.getElementById(`col-9-${lastpr}`).innerHTML);
									
								
									
									amount -= interest;
									totaliterstpaid += interest;
									lastpr++;
	
									if(totaliterstpaid>totalpaid_beforei){
										totalpaid_beforei = totaliterstpaid;
									}
							
	
								}
							
								}
							}
	
								
	
							}else if (diffDayse <= 0 ) {
								
								
								while (amount > 0) {
									// Adjust principal to not exceed the remaining amount
									if (totaliterstpaid < total_interest) {
										principal = parseFloat(document.getElementById(`col-8-${lastpr}`).innerHTML);
										interest = parseFloat(document.getElementById(`col-9-${lastpr}`).innerHTML);
										
									
										
										amount -= interest;
										totaliterstpaid += interest;
										lastpr++;
									} else {
									
											principal = parseFloat(document.getElementById(`col-8-${lastpr2}`).innerHTML);
											interest = parseFloat(document.getElementById(`col-9-${lastpr2}`).innerHTML);
																											
																			
										
											datageter = (totalpaid_before-total_interest)
											if (totaliterstpaid2 >  datageter) {
										
												amount=0;
												break;
											}else{
												amount -= principal;
												totaliterstpaid2 += principal;
		
												datageter = (totalpaid_before-total_interest)
												if (totaliterstpaid2 >  datageter) {
													
													principal_older =  parseFloat(document.getElementById(`col-11-${lastpr2-1}`).innerHTML);
		
													var valll = principal_older - (totaliterstpaid2 - datageter);
													// totaliterstpaid2 -= principal;
													// totaliterstpaid2 -= principal;
											
													
		
													amount=0;
													break;
												}else{
		
											
													lastpr2++;
												}
		
											
		
												
											
											}
											
											
											
									}
									
							
								}
								
							}
							
						
						
					
						
	
							var lastamount =   parseFloat(document.getElementById(`ttotalamount`).innerHTML);
	
	
							var pp1 =   parseFloat(document.getElementById(`col-11-${data.index}`).innerHTML);
							var pp2 =   parseFloat(document.getElementById(`col-12-${data.index}`).innerHTML);
	
							var pp3 =   parseFloat(document.getElementById(`col-23-${data.index}`).innerHTML);
							var dddtr =   document.getElementById(`col-2-${data.index}`).innerHTML;
	
							
													
							const formattedLastLoanDate =lastloandate;
							const formattedDate2 = dddtr;
	
							// Parse the converted strings back into Date objects
							const lastLoanDateParsed = new Date(formattedLastLoanDate);
							const date2Parsed = new Date(formattedDate2);
	
							// Calculate the difference in milliseconds
							const diffInMilliseconds = date2Parsed - lastLoanDateParsed;
	
							// Convert the difference into days
							const diffInDays = Math.floor(diffInMilliseconds / (1000 * 60 * 60 * 24));
	
							lastloandate  = dddtr;
	
				
	
								ccppl+=1;
	
	
	
	
	
						
						}
						
					
					
	
						});
						
			
					});
			
				Promise.all(repaymentPromises).then((results) => {
					var payments_amounter2 = payments_amounter;
					runnintotal = loan_amount2+total_interest;
				 	var total_priciple = 0;
					var totaliterstpaid = 0;
					var totaliterstpaid2= 0;
					 lastpr = grace_period;
					 lastpr2 = grace_period;

					  ccppl = 0;
					
					  data_grte = 0;
					document.getElementById(`ttotalamount`).innerHTML = "0";
						results.forEach((data) => {

						
						
						// Get the amount repaid from the repayment data
						const repaidAmount = data.repaid;
						var principal =  0;
						var interest =   0;
						var ppg =   0;
						var date2 = loan_date; // Ensure loan_date is valid
						
						
						var amount  = repaidAmount;
					
			
						
						if(repaidAmount>0){


							latsestlopr2++;

								const progressPercentage2 = (latsestlopr2 / latsestlopr) * 100;
								if(progressPercentage2<=100){
									const progressBar = document.getElementById('progress-bar');
									progressBar.style.display = 'Block';
									progressBar.style.backgroundColor = 'green';

								 updateProgressBar(progressPercentage2);
								}else{
									const progressBar = document.getElementById('progress-bar');
									progressBar.style.display = 'none';
								
								}



							const debitColumnId231 = `col-25-${data.index}`;
							const debitColumn231 = document.getElementById(debitColumnId231);
							if (debitColumn231) {
								debitColumn231.innerHTML = runnintotal.toFixed(2);
							}

							runnintotal -= repaidAmount;
							total_priciple += amount;

						var date1  =   convertToISO(data.date);
						let dateOnly = date2.split(" ")[0]; 
						var date11 = new Date(date1);
						var date21 = new Date(dateOnly);
						var date21e = new Date(dateOnly);
						date21e.setDate(date21.getDate() + loan_term-1);
						date21.setDate(date21.getDate() + grace_period);
						

						const diffTime = date11 - date21; // Difference in milliseconds
						const diffTimel = date21e - date11; // Difference in milliseconds
						const diffDays = diffTime / (1000 * 60 * 60 * 24); 
						const diffDayse = diffTimel / (1000 * 60 * 60 * 24); 


				
						if (diffDays < 1 ) {

							while (amount > 0) {
					
								principal = parseFloat(document.getElementById(`col-8-${lastpr2}`).innerHTML);
								interest = parseFloat(document.getElementById(`col-9-${lastpr2}`).innerHTML);
							
								datageter = (totalpaid_before-totalpaid_beforei)
								if (totaliterstpaid2 >  datageter) {
							
									amount=0;
									break;
								}else{
									amount -= principal;
									totaliterstpaid2 += principal;

									
									let principleField = document.getElementById(`col-11-${lastpr2}`);
									if (principleField) {
										principleField.innerHTML = principal.toFixed(2);
									}
									lastpr2++;
									
								
								}
								
								const debitColumnIdtt1 = `ttotalamount0`;
								const debitColumntt1 = document.getElementById(debitColumnIdtt1);
								if (debitColumntt1) {
									debitColumntt1.innerHTML = (totalpaid_before-total_interest).toLocaleString(2);
								}
							
								const debitColumnIdtt12 = `ttotalamount1`;
								const debitColumntt12 = document.getElementById(debitColumnIdtt12);
								if (debitColumntt12) {
									debitColumntt12.innerHTML = totaliterstpaid.toLocaleString(2);
								}
							}

						}else if (diffDayse >= 0 ) {
							
						

							var date1  =   convertToISO(data.date);
							
							var date112 = new Date(date1);
							
						
							while (amount > 0) {

								date_looped  = document.getElementById(`col-2-${lastpr}`).innerHTML;
								var date212 = new Date(date_looped);
								const diffTime2 =  date112 - date212; // Difference in milliseconds
								const diffDays2 = diffTime2 / (1000 * 60 * 60 * 24); 
							

								 
								if(diffDays2<0){
								datageter = (totalpaid_before-totalpaid_beforei);
// alert(datageter+"---"+totaliterstpaid2);
									
									
							while (amount > 0) {

								
								principal = parseFloat(document.getElementById(`col-8-${lastpr2}`).innerHTML);
								interest = parseFloat(document.getElementById(`col-9-${lastpr2}`).innerHTML);
																								
																
							
							
						
								if (totaliterstpaid2 >  datageter) {
							
									amount=0;
									break;
								}else{
									amount -= principal;
									totaliterstpaid2 += principal;
								
									let result =  Math.round(total_interest - totalpaid_beforei); // 500
									if(result==2000){
										totalpaid_beforei = total_interest;
									}
									datageter = (totalpaid_before-totalpaid_beforei)
									if (totaliterstpaid2 >  datageter) {
										

								
										datageter = (totalpaid_before-totalpaid_beforei);
										
										principal_older =  parseFloat(document.getElementById(`col-11-${lastpr2-1}`).innerHTML);

										var valll = principal_older - (totaliterstpaid2 - datageter);
										// totaliterstpaid2 -= principal;
										// totaliterstpaid2 -= principal;
								
										let principleField = document.getElementById(`col-11-${lastpr2}`);
										if (principleField) {
											principleField.innerHTML = valll.toFixed(2);
										}

totalpaid_before = 0;
										const debitColumnIdtt1 = `ttotalamount0`;
								const debitColumntt1 = document.getElementById(debitColumnIdtt1);
								if (debitColumntt1) {
									debitColumntt1.innerHTML = (totalpaid_before-total_interest).toLocaleString(2);
								}
							
								const debitColumnIdtt12 = `ttotalamount1`;
								const debitColumntt12 = document.getElementById(debitColumnIdtt12);
								if (debitColumntt12) {
									debitColumntt12.innerHTML = totaliterstpaid.toLocaleString(2);
								}

										amount=0;
										break;
									}else{

										let principleField = document.getElementById(`col-11-${lastpr2}`);
										if (principleField) {
											principleField.innerHTML = principal.toFixed(2);
										}
										lastpr2++;
									}

								

									
								
								}
								
							
							}

						}else{

								
							if (totaliterstpaid < total_interest) {
								principal = parseFloat(document.getElementById(`col-8-${lastpr}`).innerHTML);
								interest = parseFloat(document.getElementById(`col-9-${lastpr}`).innerHTML);
								
								let pinterestField = document.getElementById(`col-12-${lastpr}`);
								if (pinterestField) {
									pinterestField.innerHTML = interest.toFixed(2);
								}
								
								amount -= interest;
								totaliterstpaid += interest;
								lastpr++;

						

							}
						
							}
						}

							
						updata_total_due2(data);
						}else if (diffDayse <= 0 ) {
							
							
							while (amount > 0) {
								// Adjust principal to not exceed the remaining amount
								if (totaliterstpaid < total_interest) {
									principal = parseFloat(document.getElementById(`col-8-${lastpr}`).innerHTML);
									interest = parseFloat(document.getElementById(`col-9-${lastpr}`).innerHTML);
									
									let pinterestField = document.getElementById(`col-12-${lastpr}`);
									if (pinterestField) {
										pinterestField.innerHTML = interest.toFixed(2);
									}
									
									amount -= interest;
									totaliterstpaid += interest;
									lastpr++;
								} else {
								
										principal = parseFloat(document.getElementById(`col-8-${lastpr2}`).innerHTML);
										interest = parseFloat(document.getElementById(`col-9-${lastpr2}`).innerHTML);
																										
																		
									
										datageter = (totalpaid_before-totalpaid_beforei)
										if (totaliterstpaid2 >  datageter) {
									
											amount=0;
											break;
										}else{
											amount -= principal;
											totaliterstpaid2 += principal;
	
											datageter = (totalpaid_before-totalpaid_beforei)
											if (totaliterstpaid2 >  datageter) {
												
												principal_older =  parseFloat(document.getElementById(`col-11-${lastpr2-1}`).innerHTML);
	
												var valll = principal_older - (totaliterstpaid2 - datageter);
												// totaliterstpaid2 -= principal;
												// totaliterstpaid2 -= principal;
										
												let principleField = document.getElementById(`col-11-${lastpr2}`);
												if (principleField) {
													principleField.innerHTML = valll.toFixed(2);
												}
												totalpaid_before = 0;
												const debitColumnIdtt1 = `ttotalamount0`;
												const debitColumntt1 = document.getElementById(debitColumnIdtt1);
												if (debitColumntt1) {
													debitColumntt1.innerHTML = (totalpaid_before-total_interest).toLocaleString(2);
												}
											
												const debitColumnIdtt12 = `ttotalamount1`;
												const debitColumntt12 = document.getElementById(debitColumnIdtt12);
												if (debitColumntt12) {
													debitColumntt12.innerHTML = totaliterstpaid.toLocaleString(2);
												}
												amount=0;
												break;
											}else{
	
												let principleField = document.getElementById(`col-11-${lastpr2}`);
												if (principleField) {
													principleField.innerHTML = principal.toFixed(2);
												}
												lastpr2++;
											}
	
										
	
											
										
										}
										
										
										
								}
						
							}
							
						}
						
					
					
						
						const debitColumnIdtt1 = `ttotalamount0`;
						const debitColumntt1 = document.getElementById(debitColumnIdtt1);
						if (debitColumntt1) {
							debitColumntt1.innerHTML = (totalpaid_before-total_interest).toLocaleString(2);
						}
					
						const debitColumnIdtt12 = `ttotalamount1`;
						const debitColumntt12 = document.getElementById(debitColumnIdtt12);
						if (debitColumntt12) {
							debitColumntt12.innerHTML = totaliterstpaid.toLocaleString(2);
						}
					

						var lastamount =   parseFloat(document.getElementById(`ttotalamount`).innerHTML);

						const debitColumnIdtt = `ttotalamount`;
						const debitColumntt = document.getElementById(debitColumnIdtt);
						if (debitColumntt) {
							debitColumntt.innerHTML = (repaidAmount+lastamount).toFixed(2);
						}	


					
					

						const debitColumnId = `col-15-${data.index}`;
						const debitColumn = document.getElementById(debitColumnId);
						if (debitColumn) {
							debitColumn.innerHTML = repaidAmount.toFixed(2);
						}	

						var pp1 =   parseFloat(document.getElementById(`col-11-${data.index}`).innerHTML);
						var pp2 =   parseFloat(document.getElementById(`col-12-${data.index}`).innerHTML);

						var pp3 =   parseFloat(document.getElementById(`col-23-${data.index}`).innerHTML);
						var dddtr =   document.getElementById(`col-2-${data.index}`).innerHTML;

						
												
						const formattedLastLoanDate =lastloandate;
						const formattedDate2 = dddtr;

						// Parse the converted strings back into Date objects
						const lastLoanDateParsed = new Date(formattedLastLoanDate);
						const date2Parsed = new Date(formattedDate2);

						// Calculate the difference in milliseconds
						const diffInMilliseconds = date2Parsed - lastLoanDateParsed;

						// Convert the difference into days
						const diffInDays = Math.floor(diffInMilliseconds / (1000 * 60 * 60 * 24));

						lastloandate  = dddtr;

			
		
						if(data.index>=grace_period){
						const debitColumnId23 = `col-24-${data.index}`;
						const debitColumn23 = document.getElementById(debitColumnId23);
						if (debitColumn23) {
							debitColumn23.innerHTML = diffInDays.toFixed(2);
						}
					}
					

						const debitColumnId3 = `col-3-${data.index}`;
						const debitColumn3 = document.getElementById(debitColumnId3);
						if (debitColumn3) {
							debitColumn3.innerHTML = "Loan Repayment";
						}	

						const debitColumnId3r = `col-3r-${data.index}`;
						const debitColumn3r = document.getElementById(debitColumnId3r);
						if (debitColumn3r) {
							debitColumn3r.innerHTML =  data.names;
						}	
						
				
				

							ccppl+=1;




							
					
					}else{
						updata_total_due(data);
						const debitColumnId231 = `col-25-${data.index}`;
						const debitColumn231 = document.getElementById(debitColumnId231);
						if (debitColumn231) {
							debitColumn231.innerHTML = runnintotal.toFixed(2);
						}
					}
					
				
				

					});
					
		
				});

			
				function updata_total_due(data) {

					if(data.index>=grace_period){

					var pp1 =   parseFloat(document.getElementById(`col-8-${data.index}`).innerHTML);
					var pp2 =   parseFloat(document.getElementById(`col-9-${data.index}`).innerHTML);

					var pp11 =   parseFloat(document.getElementById(`col-11-${data.index}`).innerHTML);
					var pp22 =   parseFloat(document.getElementById(`col-12-${data.index}`).innerHTML);


					const debitColumnId2 = `col-19-${data.index}`;
					const debitColumn2 = document.getElementById(debitColumnId2);
					if (debitColumn2) {
						debitColumn2.innerHTML = (pp1-pp11).toFixed(2);
					}	

					const debitColumnId21 = `col-20-${data.index}`;
					const debitColumn21 = document.getElementById(debitColumnId21);
					if (debitColumn21) {
						debitColumn21.innerHTML = (pp2-pp22).toFixed(2);
					}	
				var resl = (pp1-pp11);
				var resl2 = 0;

					const debitColumnId22 = `col-22-${data.index}`;
					const debitColumn22 = document.getElementById(debitColumnId22);
					if (debitColumn22) {
						debitColumn22.innerHTML = (resl+resl2).toFixed(2);
					}


				}
					
				}

				function updata_total_due2(data) {
					if(data.index>=grace_period){

					var pp1 =   parseFloat(document.getElementById(`col-8-${data.index}`).innerHTML);
					var pp2 =   parseFloat(document.getElementById(`col-9-${data.index}`).innerHTML);

					var pp11 =   parseFloat(document.getElementById(`col-11-${data.index}`).innerHTML);
					var pp22 =   parseFloat(document.getElementById(`col-12-${data.index}`).innerHTML);


					const debitColumnId2 = `col-19-${data.index}`;
					const debitColumn2 = document.getElementById(debitColumnId2);
					if (debitColumn2) {
						debitColumn2.innerHTML = (pp1-pp11).toFixed(2);
					}	

					const debitColumnId21 = `col-20-${data.index}`;
					const debitColumn21 = document.getElementById(debitColumnId21);
					if (debitColumn21) {
						debitColumn21.innerHTML = (pp2-pp22).toFixed(2);
					}	
				var resl = (pp1-pp11);
				var resl2 = (1.25 / 100 / 30)*resl;

					const debitColumnId22r = `col-21-${data.index}`;
					const debitColumn22r = document.getElementById(debitColumnId22r);
					if (debitColumn22r) {
						debitColumn22r.innerHTML = ((1.25 / 100 / 30)*resl).toFixed(2);
					}	

					const debitColumnId22 = `col-22-${data.index}`;
					const debitColumn22 = document.getElementById(debitColumnId22);
					if (debitColumn22) {
						debitColumn22.innerHTML = (resl+resl2).toFixed(2);
					}

				}
					
					
				}

				var principal = constant_due_amount - interest;
				var principal2 = constant_due_amount2 - interest;
				var savings = compulsory_saving_percentage;
				var balance = totalBalance - principal;
				
				tableContent += `
					<tr id="row-${i + 1}">
						<td id="col-1-${i + 1}" data-id="principal-${i + 1}" style="background-color: #d9ead3; text-align: center; white-space: nowrap;">${i + 1}</td>
						<td id="col-2-${i + 1}" data-id="date-${i + 1}" style="background-color: #eafaf1; text-align: center; white-space: nowrap;">${formattedDate}</td>
						<td id="col-3-${i + 1}" data-id="principal-${i + 1}" style="background-color: #eafaf1; text-align: center; white-space: nowrap;"></td>
			<td id="col-3r-${i + 1}" data-id="principal-${i + 1}" style="background-color: #eafaf1; text-align: center; white-space: nowrap;"></td>
						<td id="col-8-${i + 1}" data-id="paid-principal-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;">${principal2.toFixed(2)}</td>
						<td id="col-9-${i + 1}" data-id="paid-interest-${i + 1}" style="background-color: #fff2cc; text-align: center; white-space: nowrap;">${interest.toFixed(2)}</td>
						<td id="col1-9-${i + 1}" data-id="paid-interest-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;">${interest2.toFixed(2)}</td>
						<td id="col2-9-${i + 1}" data-id="paid-interest-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;">${interest3.toFixed(2)}</td>
						<td id="col-10-${i + 1}" data-id="total-due-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;">${constant_due_amount2.toFixed(2)}</td>
						<td id="col-11-${i + 1}" data-id="total-principal-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
						<td id="col-12-${i + 1}" data-id="total-interest-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
						<td id="colg-12-${i + 1}" data-id="total-penalty-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
						<td id="col-13-${i + 1}" data-id="total-amount-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
						<td id="col-14-${i + 1}" data-id="debit-${i + 1}" style="background-color: #fff2cc; text-align: center; white-space: nowrap;">0</td>
						<td id="col-15-${i + 1}" data-id="credit-${i + 1}" style="background-color: #fff2cc; text-align: center; white-space: nowrap;">0</td>
					
						<td id="col-19-${i + 1}" data-id="penalties-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-20-${i + 1}" data-id="arrears-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-21-${i + 1}" data-id="outstanding-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-22-${i + 1}" data-id="adjusted-total-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-23-${i + 1}" data-id="penalties-${i + 1}" style="background-color: #f4cccc; text-align: center; white-space: nowrap;">0</td>
						<td id="col-24-${i + 1}" data-id="arrears-${i + 1}" style="background-color: #f4cccc; text-align: center; white-space: nowrap;">0</td>
						<td id="col-25-${i + 1}" data-id="outstanding-${i + 1}" style="background-color: #f4cccc; text-align: center; white-space: nowrap;">0</td>
					</tr>
				`;
			
				totalPrincipal += principal;
				totalInterest += interest;
				totalPrincipal2 += principal2;
				totalInterest2 += interest;
				totalInterest23 += interest2;
				totalInterest24 += interest3;
				totalSavings += savings;
				totalDue += constant_due_amount;
				totalDue2 += constant_due_amount2;
				totalBalance = balance;
            }else{
				var interest = 0;

              
				var formattedDate = formatDateString(repayment_dates[i].date);

				var cleanedRefNo = refNo.replace('%', '');
		 		let totalAmount = 0;
				
			
				
				
				var principal = constant_due_amount - interest;
				var savings = compulsory_saving_percentage;
				var balance = totalBalance ;
			
				tableContent += `
					<tr id="row-${i + 1}">
						<td id="col-1-${i + 1}" data-id="principal-${i + 1}" style="background-color: #d9ead3; text-align: center; white-space: nowrap;">${i + 1}</td>
						<td id="col-2-${i + 1}" data-id="date-${i + 1}" style="background-color: #eafaf1; text-align: center; white-space: nowrap;">${formattedDate}</td>
						<td id="col-3-${i + 1}" data-id="principal-${i + 1}" style="background-color: #eafaf1; text-align: center; white-space: nowrap;">-</td>
								<td id="col-3r-${i + 1}" data-id="principal-${i + 1}" style="background-color: #eafaf1; text-align: center; white-space: nowrap;"></td>
			
						<td id="col-8-${i + 1}" data-id="paid-principal-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;">-</td>
						<td id="col1-9-${i + 1}" data-id="paid-interest-${i + 1}" style="background-color: #fff2cc; text-align: center; white-space: nowrap;"></td>
						<td id="col2-9-${i + 1}" data-id="paid-interest-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;"></td>
						<td id="col-9-${i + 1}" data-id="paid-interest-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;">-</td>
						<td id="col-10-${i + 1}" data-id="total-due-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;">-</td>
						<td id="col-11-${i + 1}" data-id="total-principal-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
						<td id="col-12-${i + 1}" data-id="total-interest-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
						<td id="colg-12-${i + 1}" data-id="total-penalty-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
						<td id="col-13-${i + 1}" data-id="total-amount-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
						<td id="col-14-${i + 1}" data-id="debit-${i + 1}" style="background-color: #fff2cc; text-align: center; white-space: nowrap;">0</td>
						<td id="col-15-${i + 1}" data-id="credit-${i + 1}" style="background-color: #fff2cc; text-align: center; white-space: nowrap;">0</td>
				
						<td id="col-19-${i + 1}" data-id="penalties-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-20-${i + 1}" data-id="arrears-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-21-${i + 1}" data-id="outstanding-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-22-${i + 1}" data-id="adjusted-total-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-23-${i + 1}" data-id="penalties-${i + 1}" style="background-color: #f4cccc; text-align: center; white-space: nowrap;">0</td>
						<td id="col-24-${i + 1}" data-id="arrears-${i + 1}" style="background-color: #f4cccc; text-align: center; white-space: nowrap;">0</td>
						<td id="col-25-${i + 1}" data-id="outstanding-${i + 1}" style="background-color: #f4cccc; text-align: center; white-space: nowrap;">0</td>
					</tr>
				`;
			

				totalBalance = balance;
			}
			}else{

				rela_loop+=1;
				if(i>=grace_period-1){
					var interest = daily_interest + repayment_dates[i].accumulated_interest;
					var interest2 = daily_interest2 + repayment_dates[i].accumulated_interest2;
					var interest3 = daily_interest3 + repayment_dates[i].accumulated_interest3;
	
					if (rela_loop === grace_period) {
						if(grace_period>0){
							interest += grace_period_interest;
							interest2 += grace_period_interest2;
							interest3 += grace_period_interest3;
						}else{
							interest += grace_period_interest;
							interest2 += grace_period_interest2;
							interest3 += grace_period_interest3;
						}
					  
					}

				var formattedDate = formatDateString(repayment_dates[i].date);

				var cleanedRefNo = refNo.replace('%', '');
		 		let totalAmount = 0;
				
				
				 const repaymentPromises = repayment_dates.map((repayment, i) => {
					return new Promise((resolve) => {
						frappe.call({
							method: 'frappe.client.get_list',
							args: {
								doctype: 'Loan Repayment',
								filters: {
									loan: refNo.replace('%', ''), // Cleaned refNo
									created_on: repayment.date // Pass the formatted date
								},
								fields: ['name', 'created_on', 'amount', 'loan']
							},
							callback: function (r) {
								const repaymentData = {
									index: i + 1,
									date: repayment.date,
									principal: constant_due_amount - daily_interest,
									interest: daily_interest,
									total: constant_due_amount,
									repaid: r.message ? r.message.reduce((sum, item) => sum + item.amount, 0) : 0,
								};
								resolve(repaymentData);

								       // Update progress bar inside the callback
									   completedRequests++;
									   const progressPercentage = (completedRequests / totalRequests) * 100;
									   if(progressPercentage<=100){
										updateProgressBar(progressPercentage);
									   }
									   
							}
						});
					});
				});
				var ccppl=0;
				Promise.all(repaymentPromises).then((results) => {
					var payments_amounter2 = payments_amounter
						
						results.forEach((data) => {
						// Get the amount repaid from the repayment data
						const repaidAmount = data.repaid;
						var principal =  parseFloat(document.getElementById(`col-8-${data.index}`).innerHTML);
						var interest =   parseFloat(document.getElementById(`col-9-${data.index}`).innerHTML);
						var ppg =   parseFloat(document.getElementById(`col-1-${data.index}`).innerHTML);
				
				
					
						if(repaidAmount>0){

					
						var principal =  parseFloat(document.getElementById(`col-8-${data.index}`).innerHTML);
						var principal =  parseFloat(document.getElementById(`col-8-${data.index}`).innerHTML);
						
	// distributeAmount(repaidAmount,principal,interest ,ppg,grace_period);
	// 							ccppl+=1;

							
							


						const debitColumnId = `col-15-${data.index}`;
						const debitColumn = document.getElementById(debitColumnId);
						if (debitColumn) {
							debitColumn.innerHTML = repaidAmount.toFixed(2);
						}	}
					
					});
		
				});

		
				
			
				var principal = constant_due_amount - interest;
				var principal2 = constant_due_amount2 - interest;
				var savings = compulsory_saving_percentage;
				var balance = totalBalance - principal;
				
				tableContent += `
					<tr id="row-${i + 1}">
						<td id="col-1-${i + 1}" data-id="principal-${i + 1}" style="background-color: #d9ead3; text-align: center; white-space: nowrap;">${i + 1}</td>
						<td id="col-2-${i + 1}" data-id="date-${i + 1}" style="background-color: #eafaf1; text-align: center; white-space: nowrap;">${formattedDate}</td>
						<td id="col-3-${i + 1}" data-id="principal-${i + 1}" style="background-color: #eafaf1; text-align: center; white-space: nowrap;">-</td>
								<td id="col-3r-${i + 1}" data-id="principal-${i + 1}" style="background-color: #eafaf1; text-align: center; white-space: nowrap;"></td>
						<td id="col-8-${i + 1}" data-id="paid-principal-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;">-</td>
						<td id="col-9-${i + 1}" data-id="paid-interest-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;">-</td>
							<td id="col1-9-${i + 1}" data-id="paid-interest-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;"></td>
						<td id="col2-9-${i + 1}" data-id="paid-interest-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;"></td>
						<td id="col-10-${i + 1}" data-id="total-due-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;">-</td>
						<td id="col-11-${i + 1}" data-id="total-principal-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
						<td id="col-12-${i + 1}" data-id="total-interest-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
							<td id="colg-12-${i + 1}" data-id="total-penalty-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
						<td id="col-13-${i + 1}" data-id="total-amount-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
						<td id="col-14-${i + 1}" data-id="debit-${i + 1}" style="background-color: #fff2cc; text-align: center; white-space: nowrap;">0</td>
						<td id="col-15-${i + 1}" data-id="credit-${i + 1}" style="background-color: #fff2cc; text-align: center; white-space: nowrap;">0</td>
				
						<td id="col-19-${i + 1}" data-id="penalties-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-20-${i + 1}" data-id="arrears-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-21-${i + 1}" data-id="outstanding-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-22-${i + 1}" data-id="adjusted-total-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-23-${i + 1}" data-id="penalties-${i + 1}" style="background-color: #f4cccc; text-align: center; white-space: nowrap;">0</td>
						<td id="col-24-${i + 1}" data-id="arrears-${i + 1}" style="background-color: #f4cccc; text-align: center; white-space: nowrap;">0</td>
						<td id="col-25-${i + 1}" data-id="outstanding-${i + 1}" style="background-color: #f4cccc; text-align: center; white-space: nowrap;">0</td>
					</tr>
				`;
			
				// totalPrincipal += principal;
				// totalInterest += interest;
				// totalPrincipal2 += principal2;
				// totalInterest2 += interest;
				// totalSavings += savings;
				// totalDue += constant_due_amount;
				// totalDue2 += constant_due_amount2;
				// totalBalance = balance;
            }else{
				var interest = 0;

              
				var formattedDate = formatDateString(repayment_dates[i].date);

				var cleanedRefNo = refNo.replace('%', '');
		 		let totalAmount = 0;
				
			
				
				
				var principal = constant_due_amount - interest;
				var savings = compulsory_saving_percentage;
				var balance = totalBalance ;
			
				tableContent += `
					<tr id="row-${i + 1}">
						<td id="col-1-${i + 1}" data-id="principal-${i + 1}" style="background-color: #d9ead3; text-align: center; white-space: nowrap;">${i + 1}</td>
						<td id="col-2-${i + 1}" data-id="date-${i + 1}" style="background-color: #eafaf1; text-align: center; white-space: nowrap;">${formattedDate}</td>
						<td id="col-3-${i + 1}" data-id="principal-${i + 1}" style="background-color: #eafaf1; text-align: center; white-space: nowrap;">-</td>
								<td id="col-3r-${i + 1}" data-id="principal-${i + 1}" style="background-color: #eafaf1; text-align: center; white-space: nowrap;"></td>
						<td id="col-8-${i + 1}" data-id="paid-principal-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;">-</td>
						<td id="col-9-${i + 1}" data-id="paid-interest-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;">-</td>
						<td id="col1-9-${i + 1}" data-id="paid-interest-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;"></td>
						<td id="col2-9-${i + 1}" data-id="paid-interest-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;"></td>
						<td id="col-10-${i + 1}" data-id="total-due-${i + 1}" style="background-color: #fce5cd; text-align: center; white-space: nowrap;">-</td>
						<td id="col-11-${i + 1}" data-id="total-principal-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
						<td id="col-12-${i + 1}" data-id="total-interest-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
						<td id="colg-12-${i + 1}" data-id="total-penalty-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
						<td id="col-13-${i + 1}" data-id="total-amount-${i + 1}" style="background-color: #d9d2e9; text-align: center; white-space: nowrap;">0</td>
						<td id="col-14-${i + 1}" data-id="debit-${i + 1}" style="background-color: #fff2cc; text-align: center; white-space: nowrap;">0</td>
						<td id="col-15-${i + 1}" data-id="credit-${i + 1}" style="background-color: #fff2cc; text-align: center; white-space: nowrap;">0</td>
					
						<td id="col-19-${i + 1}" data-id="penalties-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-20-${i + 1}" data-id="arrears-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-21-${i + 1}" data-id="outstanding-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-22-${i + 1}" data-id="adjusted-total-${i + 1}" style="background-color: #e6b8af; text-align: center; white-space: nowrap;">0</td>
						<td id="col-23-${i + 1}" data-id="penalties-${i + 1}" style="background-color: #f4cccc; text-align: center; white-space: nowrap;">0</td>
						<td id="col-24-${i + 1}" data-id="arrears-${i + 1}" style="background-color: #f4cccc; text-align: center; white-space: nowrap;">0</td>
						<td id="col-25-${i + 1}" data-id="outstanding-${i + 1}" style="background-color: #f4cccc; text-align: center; white-space: nowrap;">0</td>
					</tr>
				`;
			

				totalBalance = balance;
			}
			}
		
		
		}
		tableContent += `
		</tbody>
		<tfoot>
			<tr class="bg-dark text-light" style="text-align: center;">
				<td colspan="4">Totals</td>
			
	
				<td>${totalPrincipal2.toLocaleString()}</td>
				<td>${totalInterest2.toLocaleString()}</td>
				<td>${totalInterest23.toLocaleString()}</td>
				<td>${totalInterest24.toLocaleString()}</td>
				<td>${totalDue2.toLocaleString()}</td>

					<td id="ttotalamount0">0</td>
				<td id="ttotalamount1">0</td>
				<td>0</td>
					<td >0</td>
				<td>${(total_interest + loan_amount2).toLocaleString(2)}</td>
				
				<td id="ttotalamount" >${payments_amounter.toLocaleString()}</td>
			
				<td>0</td>
				<td>0</td>
				<td>0</td>
				<td></td>
				<td>0</td>
				<td>0</td>
				<td>0</td>
		
			</tr>
		</tfoot>
	</table>
	</div>
	`;
	

            page.main.find('#loan-simulator-content').html(tableContent);

        } 
		 else {
            console.error('IN progress.');
        }
    }
    

};
var lastInterestIndex = 0;
var lastPrincipalIndex = 0;





function distributeAmount(amount, principal, interest, principlr, gracep) {
    principlr = parseInt(principlr);
    gracep = parseInt(gracep);


        while (amount > 0) {
            let palll = document.getElementById(`col-8-${lastpr}`);
            if (palll) {
                principal = parseFloat(palll.innerHTML) || 0;
            }

            // Adjust principal to not exceed the remaining amount
            if (amount < principal) {
                principal = amount;
            }
            amount -= principal;

            // Update the corresponding field
            let principleField = document.getElementById(`col-11-${lastpr}`);
            if (principleField) {
                principleField.innerHTML = principal.toFixed(2);
            }

            lastpr++; // Move to the next ID
        }
}



// Function to convert a date to YYYY-MM-DD
function toYYYYMMDD(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

async function getLoanRepaymentDates(loanId) {
    try {
        // Use frappe.call to fetch loan repayment dates
        let response = await frappe.call({
            method: 'mfis.clients.get_loan_repayment_dates', // Replace with your actual method
            args: {
                loan_id: loanId // Pass the loan ID as an argument
            }
        });

        if (!response.exc) {
            // Extract repayment dates from the response
            const repaymentDates = response.message; // Assuming the response contains an array of dates
            return repaymentDates;
        } else {
            frappe.msgprint(__('Error fetching loan repayment dates for loan ID: {0}', [loanId]));
            return []; // Return an empty array in case of an error
        }
    } catch (error) {
        console.error("Error fetching loan repayment dates:", error);
        frappe.msgprint(__('Error fetching loan repayment dates for loan ID: {0}', [loanId]));
        return []; // Return an empty array in case of an error
    }
}

function convertToISO(dateStr) {
    const months = {
        "January": "01", "February": "02", "March": "03", "April": "04",
        "May": "05", "June": "06", "July": "07", "August": "08",
        "September": "09", "October": "10", "November": "11", "December": "12"
    };

    // Remove day suffix (st, nd, rd, th)
    let parts = dateStr.replace(/(\d+)(st|nd|rd|th)/, '$1').split(" ");

    let day = parts[1].padStart(2, '0'); // Ensure two-digit day
    let month = months[parts[2]]; // Convert month name to number
    let year = parts[3];

    return `${year}-${month}-${day}`;
}