import frappe

def execute(filters=None):
    columns, data = [], []

    # Define columns for your report
    columns = [
        {"label": "Name", "fieldname": "name", "fieldtype": "Data", "width": 150},
        {"label": "Description", "fieldname": "description", "fieldtype": "Data", "width": 200},
        # Add more columns as needed
    ]

    # Fetch data for your report
    data = frappe.get_all("my_card_item", filters=filters, fields=["name", "description"])
    # You can add more fields to fetch in the fields list

    return columns, data

from frappe import _

def get_route_config():
    return [
        {
            "name": "My Report",
            "route": "/my-report",
            "in_standard_nav": 1,
            "label": _("My Report"),
            "reference_doctype": "my_card_item",
            "role": "System Manager",
        },
    ]
