# myapp/myapp/api.py

from frappe import _

@frappe.whitelist()
def get_transaction_data(from_date, to_date):
    sql_query = """
        SELECT * FROM tabTransaction
        WHERE transaction_date BETWEEN %s AND %s
    """
    data = frappe.db.sql(sql_query, (from_date, to_date), as_dict=True)
    return data
