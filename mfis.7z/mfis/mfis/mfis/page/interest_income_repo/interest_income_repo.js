frappe.pages['interest-income-repo'].on_page_load = function(wrapper) {
	var page = frappe.ui.make_app_page({
		parent: wrapper,
		title: 'Interest Income Report',
		single_column: true
	});
}