frappe.pages['balance-sheet2'].on_page_load = function(wrapper) {
    var page = frappe.ui.make_app_page({
        parent: wrapper,
        title: 'Trial Balance',
        single_column: true
    });

    // Displaying company details and logo at the top
    fetchCompanyDetails();

    // HTML structure for the Balance Sheet page
    page.main.html(`
        <div id="filters" style="margin: auto!important; " class="m-2 container offset-4">
            <div class="col-2">
                <div class="col-md-auto ">
                    <select id="financialYear" class="form-control">
                        <!-- Financial years will be dynamically loaded here -->
                    </select>
                </div>
                	<div class="col-md-auto ">
							<select id="financialYear2" class="form-control">
									<option value="All">All</option>
								<option value="10">Kikuubo</option>
								<option value="20" >Mbarara</option>
							</select>
						</div>
                <div class="col-md-auto mt-1">
                    <button class="btn btn-primary w-100" id="loadDataButton">Load Data</button>
                </div>
                <div class="col-md-auto mt-1">
                    <button class="btn btn-primary w-100">Print Report</button>
                </div>
                <div class="col-md-auto mt-1">
                    <label><input type="checkbox" id="toggleCategories" checked> Show Categories</label>
                </div>
            </div>
        </div>

        <div class="container" style="border: 1px solid #ccc; width:950px; padding: 5px; border-radius: 5px;">
            <!-- Letterhead Section -->
            <div id="letterhead" style="text-align: center; margin-bottom: 20px;">
                <!-- Company details will be dynamically loaded here -->
            </div>
     
 <h4 class="text-center">TRIAL BALANCE as at <span id="currentDate"></span></h4>

					
					<div id="balanceSheetContent">
						<table id="balanceSheetTable" class="table table-striped table-bordered">
							<thead>
								<tr>
									<th>Account</th>
									<th class="text-right">Debit</th>
									<th class="text-right">Credit</th>
									
								</tr>
							</thead>
							<tbody id="balanceSheetBody"></tbody>
						
						</table>
					</div>
				</div>
			`);

			
   
		
			// Load financial years into dropdown and set the current year
			loadFinancialYears();
			const today = new Date();
			const formattedDate = today.toLocaleDateString(undefined, {
				year: 'numeric',
				month: 'numeric',
				day: 'numeric'
			});
		
			// Insert today's date into the span
			document.getElementById('currentDate').textContent = formattedDate;

    // Event listener for Load Data button
    $('#loadDataButton').on('click', function() {
        fetchBalanceSheetData();
    });

    // Event listener for the checkbox
    $('#toggleCategories').on('change', function() {
        let isChecked = $(this).is(':checked');
        toggleCategoryRows(isChecked);
    });

    // Function to fetch company details and logo based on user
    function fetchCompanyDetails() {
        frappe.call({
            method: 'frappe.client.get_value',
            args: {
                doctype: 'Employee',
                filters: {
                    user: frappe.session.user
                },
                fieldname: 'company'
            },
            callback: function(response) {
                if (response.message && response.message.company) {
                    const companyName = response.message.company;
                    loadCompanyDetails(companyName);
                } else {
                    frappe.call({
                        method: 'frappe.client.get_list',
                        args: {
                            doctype: 'Company',
                            fields: ['name'],
                            limit: 1
                        },
                        callback: function(companyResponse) {
                            if (companyResponse.message && companyResponse.message.length > 0) {
                                const defaultCompanyName = companyResponse.message[0].name;
                              
                                if (response.message && response.message[0].branch) {
                                    const companyName2 = response.message[0].branch;
                                    let financialYearSelect = $('#financialYear2');
                                    financialYearSelect.empty();
                                    financialYearSelect.append('<option value="">Select Branch</option>');
                                    financialYearSelect.append(new Option(companyName2, companyName2)).val(companyName2);
                                    financialYearSelect.val(companyName2);
                                } 
                                loadCompanyDetails(defaultCompanyName);
                            } else {
                                frappe.msgprint(__('No company details found.'));
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('Error fetching default company details:', error);
                            frappe.msgprint(__('An error occurred while fetching default company details: ' + error));
                        }
                    });
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching user company details:', error);
                frappe.msgprint(__('An error occurred while fetching user company details: ' + error));
            }
        });
    }

    // Function to load company details and display in letterhead
    function loadCompanyDetails(companyName) {
        frappe.call({
            method: 'frappe.client.get',
            args: {
                doctype: 'Company',
                name: companyName
            },
            callback: function(response) {
                if (response.message) {
                    let company = response.message;
                    let letterhead = $('#letterhead');
                    let logoHTML = company.company_logo ? `<img src="${company.company_logo}" alt="Company Logo" style="max-width: 100px; height: auto;">` : '';
                    let companyDetailsHTML = `
                        ${logoHTML}
                        <h3>${company.name}</h3>
                        <h4>${company.address || ''}</h4>
                        <h4>BRN: ${company.fax || ''}</h4>
                        <h4>TIN: ${company.website || ''}</h4>
                    `;
                    letterhead.html(companyDetailsHTML);
                } else {
                    frappe.msgprint(__('No company details found.'));
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching company details:', error);
                frappe.msgprint(__('An error occurred while fetching company details: ' + error));
            }
        });
    }

    // Function to load financial years into dropdown
    function loadFinancialYears() {
        frappe.call({
            method: 'frappe.client.get_list',
            args: {
                doctype: 'Fiscal Year',
                fields: ['name', 'year_start_date', 'year_end_date'],
                limit_page_length: 100
            },
            callback: function(response) {
                let financialYearSelect = $('#financialYear');
                financialYearSelect.empty();
                financialYearSelect.append('<option value="">Select Financial Year</option>');

                let currentYear = new Date().getFullYear();  // Get the current year
                let foundCurrentYear = false;

                if (response.message) {
                    response.message.forEach(year => {
                        let option = `<option value="${year.name}" data-start="${year.year_start_date}" data-end="${year.year_end_date}">${year.name}</option>`;
                        financialYearSelect.append(option);

                        // Set the current year as selected
                        if (year.name.includes(currentYear)) {
                            foundCurrentYear = true;
                            financialYearSelect.val(year.name);
                        }
                    });

                    // If current year found, trigger the load data button
                    if (foundCurrentYear) {
                        $('#loadDataButton').click();
                    }
                } else {
                    frappe.msgprint(__('No financial years found.'));
                }
            },
            error: function(xhr, status, error) {
                console.error('Error fetching financial years:', error);
                frappe.msgprint(__('An error occurred while fetching financial years: ' + error));
            }
        });
    }

    // Function to fetch data from Saving Transaction doctype
    function fetchBalanceSheetData() {
        let selectedYear = $('#financialYear').val();

        if (!selectedYear) {
            frappe.msgprint(__('Please select a financial year.'));
            return;
        }

        let selectedOption = $('#financialYear option:selected');
        let startDate = selectedOption.data('start');
        let endDate = selectedOption.data('end');

        // Fetching Saving Transactions using Frappe call
        let branch = $('#financialYear2').val();
        if (branch == 'All') {

        frappe.call({
            method: 'frappe.client.get_list',
            args: {
                doctype: 'General Ledger II',
                filters: {
                    posting_date: ['between', [startDate, endDate]],
					flagged:0
                },
                fields: ['account', 'debit', 'credit', 'posting_date', 'transaction_type_name', 'category', 'main_parent', 'sub_parent'],
                limit_page_length: 7000000
            },
            freeze: true,
            freeze_message: __("Fetching Trial Balance data... Please wait."),
        
            callback: function(response) {
                frappe.hide_progress();
        
                if (response.message && response.message.length > 0) {
                    processBalanceSheetData(response.message);
                } else {
                    frappe.msgprint(__('No data found for the selected financial year.'));
                }
            },
        
            error: function(xhr, status, error) {
                frappe.hide_progress();
                console.error('Error fetching Trial Balance data:', error);
                frappe.msgprint(__('An error occurred while fetching Trial Balance data: ') + JSON.stringify(error));
            }
        });
    }else{
       
        frappe.call({
            method: 'frappe.client.get_list',
            args: {
                doctype: 'General Ledger II',
                filters: {
                    posting_date: ['between', [startDate, endDate]],
                    branch: $('#financialYear2').val(),
					flagged:0
                },
                fields: ['account', 'debit', 'credit', 'posting_date', 'transaction_type_name', 'category', 'main_parent', 'sub_parent'],
                limit_page_length: 7000000
            },
            freeze: true,
            freeze_message: __("Fetching Trial Balance data... Please wait."),
        
            callback: function(response) {
                frappe.hide_progress();
        
                if (response.message && response.message.length > 0) {
                    processBalanceSheetData(response.message);
                } else {
                    frappe.msgprint(__('No data found for the selected financial year.'));
                }
            },
        
            error: function(xhr, status, error) {
                frappe.hide_progress();
                console.error('Error fetching Trial Balance data:', error);
                frappe.msgprint(__('An error occurred while fetching Trial Balance data: ') + JSON.stringify(error));
            }
        }); 
    }

        
    }
	
    
	function processBalanceSheetData(data) {
		let balanceSheetBody = $('#balanceSheetBody');
		balanceSheetBody.empty();
	
		let totals = { debit: 0, credit: 0, balance: 0 };
		let aggregatedData = {
			'Assets': { subCategories: {}, totals: { debit: 0, credit: 0, balance: 0 } },
			'Liabilities': { subCategories: {}, totals: { debit: 0, credit: 0, balance: 0 } },
			'Equity': { subCategories: {}, totals: { debit: 0, credit: 0, balance: 0 } },
            'Income': { subCategories: {}, totals: { debit: 0, credit: 0, balance: 0 } },
			'Expenses': { subCategories: {}, totals: { debit: 0, credit: 0, balance: 0 } }
		};
		let totalIncome = 0;
		let totalExpenses = 0;
	
		// Aggregate data by main_parent, sub_parent, and category
		data.forEach(entry => {
			let mainCategory = entry.main_parent || 'Other';
			let subCategory = entry.sub_parent || 'Other';
			let category = entry.category || 'Other';
			let debit = parseFloat(entry.debit || 0);
			let credit = parseFloat(entry.credit || 0);
			let balance = 0;
	
			// Determine balance based on category type
			if (mainCategory === 'Assets') {
				debit = debit - credit;
				credit = 0;
				balance = 0
			} else if (mainCategory === 'Liabilities') {
				credit = credit - debit;
				debit = 0;
				balance = 0
			} else if (mainCategory === 'Equity') {
				credit = credit - debit;
				debit = 0;
				balance = 0
			} else if (mainCategory === 'Income') {
				balance = credit - debit;
			} else if (entry.transaction_type_name === 'Expenses') {
				balance = debit - credit;
			}
	
			if (!aggregatedData[mainCategory]) {
				aggregatedData[mainCategory] = { subCategories: {}, totals: { debit: 0, credit: 0, balance: 0 } };
			}
	
			if (!aggregatedData[mainCategory].subCategories[subCategory]) {
				aggregatedData[mainCategory].subCategories[subCategory] = { categories: {}, totals: { debit: 0, credit: 0, balance: 0 } };
			}
	
			if (!aggregatedData[mainCategory].subCategories[subCategory].categories[category]) {
				aggregatedData[mainCategory].subCategories[subCategory].categories[category] = { debit: 0, credit: 0, balance: 0 };
			}
	
			// Aggregate the amounts
			aggregatedData[mainCategory].subCategories[subCategory].categories[category].debit += debit;
			aggregatedData[mainCategory].subCategories[subCategory].categories[category].credit += credit;
			aggregatedData[mainCategory].subCategories[subCategory].categories[category].balance += balance;
	
			// Update subcategory totals
			aggregatedData[mainCategory].subCategories[subCategory].totals.debit += debit;
			aggregatedData[mainCategory].subCategories[subCategory].totals.credit += credit;
			aggregatedData[mainCategory].subCategories[subCategory].totals.balance += balance;
	
			// Update main category totals
			aggregatedData[mainCategory].totals.debit += debit;
			aggregatedData[mainCategory].totals.credit += credit;
			aggregatedData[mainCategory].totals.balance += balance;
	
			// Update overall totals
			totals.debit += debit;
			totals.credit += credit;
			totals.balance += balance;
	
			// Track income and expenses
			if (mainCategory === 'Income') {
				totalIncome += credit;
			} else if (entry.transaction_type_name === 'Expenses') {
				totalExpenses += debit;
			}
		});
	
		// Define the order in which to display the main categories
		let categoryOrder = ['Assets', 'Liabilities', 'Equity', 'Income','Expenses'];
	
		// Render aggregated data in the specified order with totals
		categoryOrder.forEach(mainCategory => {
			let mainCategoryData = aggregatedData[mainCategory];
	
			balanceSheetBody.append(`
				<tr class="table-primary">
					<td><strong>${mainCategory}</strong></td>
					<td class="text-right"><strong>${formatCurrency(mainCategoryData.totals.debit)}</strong></td>
					<td class="text-right"><strong>${formatCurrency(mainCategoryData.totals.credit)}</strong></td>
					
				</tr>
			`);
	
			for (let subCategory in mainCategoryData.subCategories) {
				let subCategoryData = mainCategoryData.subCategories[subCategory];
				let subCategoryId = 'subCategory-' + escapeId(subCategory);
	
				balanceSheetBody.append(`
					<tr class="table-secondary" style="cursor: pointer;" id="row-${subCategoryId}">
						<td><strong>${subCategory}</strong></td>
						<td class="text-right"><strong>${formatCurrency(subCategoryData.totals.debit)}</strong></td>
						<td class="text-right"><strong>${formatCurrency(subCategoryData.totals.credit)}</strong></td>
						
					</tr>
				`);
	
				// Add category rows with unique IDs, initially hidden
				balanceSheetBody.append(`<tbody id="${subCategoryId}" class="d-none">`);
				for (let category in subCategoryData.categories) {
					let categoryData = subCategoryData.categories[category];
	
					balanceSheetBody.append(`
						<tr class="category-row">
							<td>${category}</td>
							<td class="text-right">${formatCurrency(categoryData.debit)}</td>
							<td class="text-right">${formatCurrency(categoryData.credit)}</td>
						
						</tr>
					`);
				}
				balanceSheetBody.append(`</tbody>`);
			}
		});
	
		// Add a totals row at the bottom of the balance sheet
		balanceSheetBody.append(`
			<tr class="table-warning">
				<td><strong>Total</strong></td>
				<td class="text-right"><strong>${formatCurrency(totals.debit)}</strong></td>
				<td class="text-right"><strong>${formatCurrency(totals.credit)}</strong></td>
			
			</tr>
		`);
	}
	
	
	function formatCurrency(value) {
		return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
	}
	
	function escapeId(id) {
		return id.replace(/[^a-zA-Z0-9]/g, '-');
	}
	

    // Function to toggle visibility of category rows based on checkbox state
    function toggleCategoryRows(checked) {
        if (checked) {
            $('.category-row').show();  // Show all category rows
        } else {
            $('.category-row').hide();  // Hide all category rows
        }
    }

    // Helper function to escape special characters in IDs
    function escapeId(id) {
        return id.replace(/[&\/\\#,+()$~%.'":*?<>{}\s]/g, '_');
    }

    // Function to format number as currency
    function formatCurrency(amount) {
        return amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
};
