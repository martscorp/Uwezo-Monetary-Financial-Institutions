frappe.pages['daily-transaction'].on_page_load = function(wrapper) {
    var page = frappe.ui.make_app_page({
        parent: wrapper,
        title: 'Customer Balances',
        single_column: true
    });
      
        
        
            
                       
            
                    localStorage.clear();
                    
                
                var newRowHTML = `
                <tr>
                <th>Type</th> 
                <th>Client</th> 
                <th>Amount</th> 
                <th>Fees</th> 
                <th>Buy</th> 
                <th>Date</th> 
                </tr>
                `;
                
                
                
    frappe.call({
        method: 'frappe.client.get',
        args: {
            doctype: 'Company',
            filters: {
                // Add any filters you need
            },
            fields: ['org_name', 'email', 'phone_number', 'logo', 'address']
        },
        callback: function (data) {
            if (!data.exc) {
                var record = data.message;
    
                var company_name = record.company_name;
                var address = record.address_summary;
                var phone_no = record.phone_no;
                var imggg = record.company_logo;
                var email = record.email;
    
                $("#ccname").html(company_name);
                $("#ccnameftr").html(company_name);
                $("#ccname2").html(address);
                $("#ccname3").html(phone_no);
                $("#ccname4").html(email);
                $("#ccname5").attr("src", imggg);
            } else {
                // Handle the error
                console.error(data.exc);
            }
        }
    });
                
                
                
                    var container = $('<div class="report">').appendTo(page.body);
                
                    
                    // Add the HTML structure you provided
                    var htmlData = `
                
                
                    <div class="date-filters">
                    <div class="filter">
                      <label for="fromDate">From Date</label>
                      <input type="date" id="fromDateFilter" name="fromDate" value="${getCurrentDate()}" class="date-input">
                    </div>
                    <div class="filter">
                      <label for="toDate">To Date</label>
                      <input type="date" id="toDateFilter" name="toDate" value="${getCurrentDate()}" class="date-input">
                    </div>
                    <div class="filter">
                      <label for="dateFilter">Account Types</label>
                      <select id="dateFilter" name="dateFilter" class="date-input" >
                    
                      </select>
                    </div>
                    <button  id="btn3" onclick="addDemoDataToTable()" class="apply-button">Load Data</button>
                    <button onclick="printReport()" id="btn1" class="apply-button button3">Print</button>
                    <button onclick="exporttoexecl()"  id="btn2" class="apply-button button2">Export</button>
                  </div>
                  
                <hr>
                
                <div class="report" id="bana">
                <div class="header">
                  <div class="logo">
                  
                        <img src="" id="ccname5" alt=" Logo">
                    </div>
                    <!-- Company Name -->
                
                </div>
                
                
                
                <div class="account-details row" style="margin-top: ">
                `;
                
                
                
                
                htmlData+=`
                
                    <div class="account-summary col-6">
                        <h4 id="ccname"><span id="ccnameftr"></span> Financials</h4>
                        <p><b>Address:</b> <span id="ccname2"></span></p>
                        <p><b>Contact:</b> <span id="ccname3"></span></p>
                        <p><b>Email:</b> <span id="ccname4"></span></p>
                    </div>
                
                
                
                <div class="account-info2 col-6 d-none">
                        
                        <p><b>Account Name:</b> <span class="monrr" id="clientmane"></span></p>
                        <p><b></b> <span class="monrr" id="clientloc"></span></p>
                        <p><b>Account Type:</b> <span class="monrr" id="clientacctype"></span></p>
                        <p><b>Account No:</b> <span class="monrr" id="clientaccnumber" ></span></p>
                        <p><b>Session:</b> <span class="monrr" id="daterage1"></span> - <span class="monrr" id="daterage2"></span></p>
                </div>
                
                     <div class="account-info2 col-6 ">
                        <p><b>Generated By:</b> <span class="monrr">${frappe.session.user}</span></p>
                        <p><b>Report Type:</b> <span class="monrr">System Generated</span></p>
                        <p><b>Rows:</b> [<span class="monrr" id="rowcout">0</span>]</p>
                        <p><b>Session:</b> <span class="monrr" id="daterage12"></span> - <span class="monrr" id="daterage22"></span></p>
                </div>
                
                
                </div>
            
                <h3 class="tttt">Customer Balances Report </h3>
                
                <table class="balance-sheet-table col-12" id="myTable">
                <thead>
           <tr>
    <th style="white-space: nowrap;">ID</th>
    <th style="white-space: nowrap;">Portfolio</th>
    <th style="white-space: nowrap;">Client</th>
    <th style="white-space: nowrap;">Mobile</th>
    <th style="white-space: nowrap;">Account Number</th>
    <th style="white-space: nowrap;">Account Type</th>
    <th style="white-space: nowrap;">Last Transaction Date</th>
    <th style="white-space: nowrap;">Balance</th>
</tr>

                </thead>
                <tbody id="myTable2">
                <!-- Data rows will be added here -->
                </tbody>
                </table>
                <br>
                <h4><u>Summary Table</u></h4>
                        <table class="summary-table col-12" id="summaryTableg">
                    <thead>
                        <tr>
                            <th>Account Type</th>
                            <th>No. of Customers</th>
                            <th>Total Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Business Acc</td>
                            <td></td>
                            <td>0</td>
                        </tr>
                        <tr>
                            <td>Unsecured Loan</td>
                            <td>0</td>
                            <td>0</td>
                        </tr>
                        <tr>
                            <td>Staff Loan</td>
                            <td>0</td>
                            <td>0</td>
                        </tr>
                        <tr>
                            <td><b>Total</b></td>
                            <td><b>0</b></td>
                            <td><b>0</b></td>
                        </tr>
                    </tbody>
                </table>	
                <div class="footer" id="footer">
                
        
                    <hr>    
                    <p>&copy; 2025 <span id="ccnameftr"></span> Uwezo Microfinace All rights reserved.</p>
                
                
                </div>
                </div>
                
                <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.4/xlsx.full.min.js"></script>
                
                `;
                
                     container.html(htmlData);
                 
                
                    // Add the CSS styles
                    var style = `
                    body {
                        font-family: Arial, sans-serif;
                        margin: 0;
                        padding: 0;
                    }
                
                    /* Add your preferred styling here */
                .date-filters {
                  display: flex;
                  flex-wrap: wrap;
                  justify-content: space-between;
                }
                
                .filter {
                  width: 100%;
                  max-width: 150px;
                  margin-bottom: 10px;
                }
                
                label {
                  display: block;
                  font-weight: bold;
                  margin-bottom: 5px;
                }
                
                .date-input {
                  width: 100%;
                  padding: 5px;
                  border: 1px solid #ccc;
                  border-radius: 5px;
                }
                
                .apply-button {
                  background-color: #007bff;
                  color: #fff;
                  padding: 10px 10px;
                  border: none;
                  border-radius: 5px;
                  height:50%;
                  width:10%;
                  cursor: pointer;
                  margin-right: 2%;
                  margin-top: 3%;
                }
                
                
                  
                
                .button3 {
                  background-color: #333;
                }
                
                .button2 {
                  background-color: #ff9900;
                }
                
                /* Responsive styles */
                @media (min-width: 768px) {
                  .filter {
                    width: calc(33.33% - 10px);
                    margin-right: 5px;
                  }
                }
                
                
                    /* Style for the report container */
                    .report {
                        width: 800px;
                        margin: 0 auto;
                        position: relative;
                    }
                
                    /* Style for the header */
                    .header {
                        text-align: left;
                        margin-top: 10px;
                    }
                
                    /* Style for the logo */
                    .logo {
                        text-align: left;
                        margin-top: 20px;
                    }
                
                    .logo img {
                        width: 10%;
                    }
                
                    /* Style for company details */
                    .company-details {
                        text-align: left;
                        margin-top: 10px;
                    }
                
                    .company-details p {
                        margin: 5px 0;
                    }
                
                    /* Style for the balance sheet table */
                    .balance-sheet-table {
                        width: 100%;
                        border-collapse: collapse;
                        margin-top: 10px;
                    }
                
                    .balance-sheet-table th,
                    .balance-sheet-table td {
                        padding: 4px;
                        text-align: left;
                        border-bottom: 1px solid #ddd;
                    }
                
                    .balance-sheet-table th {
                        background-color: #f2f2f2;
                        font-weight: bold;
                    }
                
                    /* Style for the account details container */
                    .account-details {
                        display: flex;
                        justify-content: space-between;
                        margin-top: 10px;
                    }
                
                    /* Style for account information column */
                    .account-info {
                        flex: 1;
                    }
                
                    /* Style for account summary column */
                    .account-summary {
                        flex: 1;
                        text-align: left;
                    }
                
                      /* Style for account summary column */
                    .account-info2 {
                    
                        text-align: right;
                    }
                
                    /* Style for the footer */
                    .footer {
                        text-align: center;
                        position: relative;
                        bottom: 0;
                        left: 0;
                        right: 0;
                        margin-top: 20px;
                    }
                    .monrr{
                        color: teal;
                        text-decoration: underline;
                        font-weight: bold;
                    }
                
                    body{
                        font-family: calibri;
                    }
                    p{
                        margin: 0%;
                        margin-top: 2%;
                    }
                
                    .tttt{
                text-align: center;
                text-decoration: underline;
                    }
                    .d-none{
                        display: none;
                    }
                    `;
                
                
                
                
                    var styleElement = $('<style>').text(style);
                    $('head').append(styleElement);
                
                     var container = $('<div class="report">').appendTo(page.body);
                 
                     var styleElement = $('<style>').text(style);
                     $('head').append(styleElement);
                
                     document.getElementById("btn1").addEventListener("click", function() {
                        printReport();
                        localStorage.clear();
                    });
                 
                    document.getElementById("btn2").addEventListener("click", function() {
                        exportToExcel();
                        localStorage.clear();
                    });
                 
                
                        document.getElementById("btn3").addEventListener("click", function() {
                            addDemoDataToTable();
                            localStorage.clear();
                    });
                
                    
                
                    function printReport() {
                        var printContents = document.getElementById("bana").innerHTML;
                        var originalContents = document.body.innerHTML;
                
                        document.body.innerHTML = printContents;
                        window.print();
                        document.body.innerHTML = originalContents;
                    }
                
                var newRowHTML2="";
                
                    frappe.db.get_list('Saving Product', {
                        fields: ['product_name','name'],
                        filters: {
                        
                        }
                    }).then(records => {
                        newRowHTML2 += `
                        <option value="All">All</option>
                    `;
                        records.forEach(record => {
                            const full_name = record.product_name;
                            const id_autoincremet = record.name;
                
                            newRowHTML2 += `
                                <option value="${id_autoincremet}">${full_name}</option>
                            `;
                        });
                
                        var selectElement = document.getElementById("dateFilter");
                        selectElement.innerHTML = newRowHTML2;
                
                    });
                    
                    function get_savings_accountDetaisl(account_number) {
        
        
                        var filters = {
                            name: account_number
                        };
                    
                        frappe.db.get_list('Savings Account', {
                            fields: ['client_name','total_withdrawals_derived','external_number','external_number'],
                            filters: filters
                        }).then(records => {
                            records.forEach(record => {
                                const firtst_name2 = record.client_name;
                                const account_type = record.total_withdrawals_derived;
                                const location = record.external_number;
                                const idd = record.name;
                                $("#clientmane").text(firtst_name2);
                                $("#clientloc").text(location);
                                $("#clientacctype").text(account_type);
                                $("#clientaccnumber").text(idd);
                                
                        
                            });
                    
                            get_client_balance(account_number);
                        });
                        
                    }
                
                
                    function get_client_balance(account_number) {
            
                        var filters = {
                            name: account_number
                        };
                        frappe.db.get_list('Savings Account', {
                            fields: ['balance_derived'],
                            filters: filters
                        }).then(records => {
                            records.forEach(record => {
                                const blanc = record.balance_derived;
                                $("#client_balnce").text(blanc.toLocaleString());
                                $("#client_withdraw").text(blanc.toLocaleString());
                            
                            });
                    
                    
                        });
                        
                    }
                
  function addDemoDataToTable() {
    const $myTable2 = $("#myTable2");
    const $rowCount = $("#rowcout");

    const clientname = $("#dateFilter").val();      // Client filter
    const clientname2 = $("#dateFilter2").val();    // Branch filter
    const fromDate = $("#fromDateFilter").val();
    const toDate = $("#toDateFilter").val();

    $("#daterage12").text(fromDate);
    $("#daterage22").text(toDate);

    // Build filters
    let filters = {};

    // if (clientname !== "All" && clientname) {
    //     filters.client = clientname;
    // }

    if (clientname2 !== "All" && clientname2) {
        filters.branch = clientname2;
    }

    // ---- Fetch all Savings Accounts using pagination ----
    let allRecords = [];
    let start = 0;
    const pageSize = 500; // fetch 500 records per call to avoid overload

    function fetchNextBatch() {
        return frappe.db.get_list('Savings Account', {
            fields: [
                'name', 'client', 'client_name',
                'balance_derived', 'account_number', 'saving_product_name',
                'overdraft_derived', 'branch'
            ],
            filters: filters,
            limit_start: start,
            limit_page_length: pageSize
        }).then(records => {
            if (records.length === 0) return allRecords;

            allRecords = allRecords.concat(records);
            start += pageSize;
            return fetchNextBatch(); // recursively fetch next page
        });
    }

    fetchNextBatch().then(records => {
        let newRows = [];
        let promises = [];

        records.forEach(rec => {

            // Fetch Client
            let p = frappe.db.get_doc('Client', rec.client).then(clientDoc => {
                const lastTransaction = rec.overdraft_derived || 0;
                const balanceDisplay = (rec.balance_derived || 0).toLocaleString();

                // Fetch Employee for Portfolio
                if (!clientDoc.staff_id) {
                    newRows.push(`
                        <tr>
                            <td style="white-space:nowrap;">${rec.name}</td>
                            <td style="white-space:nowrap;"></td>
                            <td style="white-space:nowrap;">${clientDoc.full_name || rec.client_name}</td>
                            <td style="white-space:nowrap;">${clientDoc.mobile || ""}</td>
                            <td style="white-space:nowrap;">${rec.account_number || ""}</td>
                            <td style="white-space:nowrap;">${rec.saving_product_name || ""}</td>
                            <td style="white-space:nowrap;">${lastTransaction}</td>
                            <td style="white-space:nowrap;">${balanceDisplay}</td>
                        </tr>
                    `);
                    return;
                }

                return frappe.db.get_doc('Employee', clientDoc.staff_id)
                    .then(emp => {
                        const portfolioName = emp.full_name || '';
                        newRows.push(`
                            <tr>
                                <td style="white-space:nowrap;">${rec.name}</td>
                                <td style="white-space:nowrap;">${portfolioName}</td>
                                <td style="white-space:nowrap;">${clientDoc.full_name || rec.client_name}</td>
                                <td style="white-space:nowrap;">${clientDoc.mobile || ""}</td>
                                <td style="white-space:nowrap;">${rec.account_number || ""}</td>
                                <td style="white-space:nowrap;">${rec.saving_product_name || ""}</td>
                                <td style="white-space:nowrap;">${lastTransaction}</td>
                                <td style="white-space:nowrap;">${balanceDisplay}</td>
                            </tr>
                        `);
                    })
                    .catch(() => {
                        // fallback if employee not found
                        newRows.push(`
                            <tr>
                                <td style="white-space:nowrap;">${rec.name}</td>
                                <td style="white-space:nowrap;"></td>
                                <td style="white-space:nowrap;">${clientDoc.full_name || rec.client_name}</td>
                                <td style="white-space:nowrap;">${clientDoc.mobile || ""}</td>
                                <td style="white-space:nowrap;">${rec.account_number || ""}</td>
                                <td style="white-space:nowrap;">${rec.saving_product_name || ""}</td>
                                <td style="white-space:nowrap;">${lastTransaction}</td>
                                <td style="white-space:nowrap;">${balanceDisplay}</td>
                            </tr>
                        `);
                    });
            }).catch(() => {
                // fallback if client not found
                const lastTransaction = rec.overdraft_derived || 0;
                const balanceDisplay = (rec.balance_derived || 0).toLocaleString();
                newRows.push(`
                    <tr>
                        <td style="white-space:nowrap;">${rec.name}</td>
                        <td style="white-space:nowrap;"></td>
                        <td style="white-space:nowrap;">${rec.client_name || ""}</td>
                        <td style="white-space:nowrap;"></td>
                        <td style="white-space:nowrap;">${rec.account_number || ""}</td>
                        <td style="white-space:nowrap;">${rec.saving_product_name || ""}</td>
                        <td style="white-space:nowrap;">${lastTransaction}</td>
                        <td style="white-space:nowrap;">${balanceDisplay}</td>
                    </tr>
                `);
            });

            promises.push(p);
        });

        Promise.all(promises).then(() => {
            $myTable2.html(newRows.join(""));
            $rowCount.text(records.length);
        });
    });
}

                                    
                    function exportToExcel() {
                    
                        var table = document.getElementById("myTable");
                        var wb = XLSX.utils.table_to_book(table, { sheet: "Sheet1" });
                        XLSX.writeFile(wb, "financial_report.xlsx");
                    }
                
                    function getCurrentDate() {
                        
                        var currentDate = new Date();
                        var year = currentDate.getFullYear();
                        var month = String(currentDate.getMonth() + 1).padStart(2, '0');
                        var day = String(currentDate.getDate()).padStart(2, '0');
                        return `${year}-${month}-${day}`;
                    }
                
                     var accordionItems = document.querySelectorAll('.accordion-item');
                     accordionItems.forEach(function(item) {
                         var button = item.querySelector('.accordion-button');
                         var content = item.querySelector('.accordion-content');
                 
                         button.addEventListener('click', function() {
                             if (content.style.display === 'block') {
                                 content.style.display = 'none';
                             } else {
                                 content.style.display = 'block';
                             }
                         });
                     });
                    
                }
                