

frappe.pages['cancel-transactions'].on_page_load = function(wrapper) {
    var page = frappe.ui.make_app_page({
        parent: wrapper,
        title: 'Canceled Transactions',
        single_column: true
    });

    localStorage.clear();

    var container = $('<div class="report">').appendTo(page.body);

    var htmlData = `
    <div class="date-filters">
        <div class="filter">
            <label for="fromDate">From Date</label>
            <input type="date" id="fromDateFilter" name="fromDate" value="${getCurrentDate()}" class="date-input">
        </div>
        <div class="filter">
            <label for="toDate">To Date</label>
            <input type="date" id="toDateFilter" name="toDate" value="${getCurrentDate()}" class="date-input">
        </div>
        <button id="btnLoad" class="apply-button">Load Data</button>
        <button id="btnPrint" class="apply-button button3">Print</button>
        <button id="btnExport" class="apply-button button2">Export</button>
    </div>
    <hr>
    <div class="report" id="reportContainer">
        <h3 class="report-title">Canceled Transactions</h3>
        <table class="report-table" id="reportTable">
            <thead>
                <tr>
                    <th>Date</th> 
                    <th>Description</th> 
                    <th>Account</th> 
                    <th>Debit</th> 
                    <th>Credit</th> 
                    <th>Balance</th> 
                </tr>
            </thead>
            <tbody id="reportTableBody"></tbody>
            <tfoot>
                <tr>
                    <th colspan="3">Total</th>
                    <th id="totalDebit">0.00</th>
                    <th id="totalCredit">0.00</th>
                    <th id="totalBalance">0.00</th>
                </tr>
            </tfoot>
        </table>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.4/xlsx.full.min.js"></script>
    `;

    container.html(htmlData);

    var style = `
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }
    .date-filters {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
    }
    .filter {
        width: 100%;
        max-width: 150px;
        margin-bottom: 10px;
    }
    label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
    }
    .date-input {
        width: 100%;
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    .apply-button {
        background-color: #007bff;
        color: #fff;
        padding: 10px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        margin-right: 2%;
        margin-top: 3%;
    }
    .button3 {
        background-color: #333;
    }
    .button2 {
        background-color: #ff9900;
    }
    .report {
        width: 800px;
        margin: 0 auto;
        position: relative;
    }
    .report-title {
        text-align: center;
        text-decoration: underline;
    }
    .report-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
    }
    .report-table th, .report-table td {
        padding: 4px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    .report-table th {
        background-color: #f2f2f2;
        font-weight: bold;
    }
    `;

    var styleElement = $('<style>').text(style);
    $('head').append(styleElement);

    document.getElementById("btnLoad").addEventListener("click", function() {
        loadCanceledTransactions();
        localStorage.clear();
    });

    document.getElementById("btnPrint").addEventListener("click", function() {
        printReport();
        localStorage.clear();
    });

    document.getElementById("btnExport").addEventListener("click", function() {
        exportToExcel();
        localStorage.clear();
    });

    function printReport() {
        var printContents = document.getElementById("reportContainer").innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
        location.reload();
    }

    function exportToExcel() {
        var wb = XLSX.utils.table_to_book(document.getElementById('reportTable'), { sheet: "Sheet JS" });
        var wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });
        saveAs(new Blob([s2ab(wbout)], { type: "application/octet-stream" }), 'canceled_transactions.xlsx');
    }

    function s2ab(s) {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i < s.length; i++) view[i] = s.charCodeAt(i) & 0xFF;
        return buf;
    }

    function loadCanceledTransactions() {
        var fromDate = document.getElementById('fromDateFilter').value;
        var toDate = document.getElementById('toDateFilter').value;

        var tableBody = document.getElementById('reportTableBody');
        tableBody.innerHTML = '';

        frappe.call({
            method: 'frappe.client.get_list',
            args: {
                doctype: 'GL Entry',
                filters: [
                    ['posting_date', '>=', fromDate],
                    ['posting_date', '<=', toDate],
                    ['is_cancelled', '=', 1]
                ],
                fields: ['posting_date', 'voucher_type', 'voucher_no', 'account', 'debit', 'credit']
            },
            callback: function(data) {
                if (!data.exc) {
                    var records = data.message;
                    var runningBalance = 0;
                    var totalDebit = 0;
                    var totalCredit = 0;

                    for (var i = 0; i < records.length; i++) {
                        var record = records[i];
                        var debit = parseFloat(record.debit) || 0;
                        var credit = parseFloat(record.credit) || 0;
                        runningBalance += (debit - credit);
                        totalDebit += debit;
                        totalCredit += credit;

                        var row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${record.posting_date}</td>
                            <td>${record.voucher_type} ${record.voucher_no}</td>
                            <td>${record.account}</td>
                            <td>${debit.toFixed(2)}</td>
                            <td>${credit.toFixed(2)}</td>
                            <td>${runningBalance.toFixed(2)}</td>
                        `;
                        tableBody.appendChild(row);
                    }

                    document.getElementById('totalDebit').innerHTML = totalDebit.toFixed(2);
                    document.getElementById('totalCredit').innerHTML = totalCredit.toFixed(2);
                    document.getElementById('totalBalance').innerHTML = runningBalance.toFixed(2);
                } else {
                    console.error(data.exc);
                }
            }
        });
    }

    function getCurrentDate() {
        var currentDate = new Date();
        var year = currentDate.getFullYear();
        var month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
        var day = currentDate.getDate().toString().padStart(2, '0');
        return year + '-' + month + '-' + day;
    }
};



