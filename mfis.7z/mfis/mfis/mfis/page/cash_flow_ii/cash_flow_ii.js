frappe.pages['cash-flow-ii'].on_page_load = function(wrapper) {
    var page = frappe.ui.make_app_page({
        parent: wrapper,
        title: 'Cash Flow II',
        single_column: true
    });

	
	page.main.html(`
        <div id="filters" style="margin: auto!important;" class="m-2 container offset-4">
            <div class="col-2">
                <div class="col-md-auto ">
                    <select id="financialYear" class="form-control">
                        <!-- Financial years will be dynamically loaded here -->
                    </select>
                </div>
				<div class="col-md-auto ">
							<select id="financialYear2" class="form-control">
									<option value="All">All</option>
								<option value="10">Kikuubo</option>
								<option value="20" >Mbarara</option>
							</select>
						</div>

                <div class="col-md-auto mt-1">
                    <button class="btn btn-primary w-100" id="loadDataButton">Load Data</button>
                </div>
                <div class="col-md-auto mt-1">
                    <button class="btn btn-primary w-100">Print Report</button>
                </div>
                <div class="col-md-auto mt-1">
                    <label><input type="checkbox" id="toggleCategories" checked> Show Categories</label>
                </div>
            </div>
        </div>

        <div class="container" style="border: 1px solid #ccc; padding: 5px; border-radius: 5px; display: flex; justify-content: space-between; width: 70%; margin: auto; ">
            <div id="balanceSheet" style="width: 50%;  display:none; border-right: 2px solid blue;">
                <div id="letterhead" style="text-align: center; margin-bottom: 20px;">
                    <!-- Company details will be dynamically loaded here -->
                </div>

                <h4 class="text-center">Balance Sheet as at <span id="currentDate"></span></h4>

                <div id="balanceSheetContent">
                    <table id="balanceSheetTable" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Account</th>
                                <th class="text-right">Balance</th>
                            </tr>
                        </thead>
                        <tbody id="balanceSheetBody"></tbody>
                    </table>
                </div>
            </div>

          <div style="width:100%; margin: 0 auto;">
            <h3 style="text-align: center;">UWEZO FINANCIAL SERVICES LTD</h3>
            <p style="text-align: center;">BRN: 80020001854419</p>
            <p style="text-align: center;">TIN: 1015351135</p>
            <h4 style="text-align: center;">STATEMENT OF CASHFLOW AS AT <span id="cashFlowDate"></span></h4>

            <table class="table table-bordered">
                <thead>
                    <tr style="background-color: #a3bfc2;">
                        <th>Notes</th>
                        <th>${getTodayFormatted()}</th>
                        <th>${getYesterdayFormatted()}</th>
                    </tr>
                </thead>
                <tbody id="cashFlowBody">
                    <tr class="category-row" style="background-color: #a3bfc2;">
                        <td><strong>Cash flows from operating activities</strong></td>
                        <td></td>
                        <td>-</td>
                    </tr>
                    <tr><td>Profit before tax</td><td><span id="retainedEarningsText"></span></td><td>-</td></tr>
                    <tr class="category-row" style="background-color: #a3bfc2;">
                        <td><strong>Adjustment for:</strong></td>
                        <td></td>
                        <td>-</td>
                    </tr>
                    <tr><td>Depreciation</td><td>0</td><td>-</td></tr>
                    <tr><td>Deferred tax</td><td>0</td><td>-</td></tr>
                    <tr><td>Loss/gain on disposal of PPE</td><td></td><td>-</td></tr>
                    <tr class="category-row" style="background-color: #a3bfc2;">
                        <td><strong>Cash flows from operating activities before changes in operating assets and liabilities</strong></td>
                        <td><span id="retainedEarningsText2"></span></td>
                        <td>-</td>
                    </tr>
                    <tr class="category-row" style="background-color: #a3bfc2;">
                        <td><strong>Changes in operating assets and liabilities</strong></td>
                        <td></td>
                        <td>-</td>
                    </tr>
                    <tr><td>Increase/decrease in trade and other receivables</td><td><span id="totalreceivables"></span></td><td>-</td></tr>
                    <tr><td>Increase/decrease in trade and other payables</td><td><span id="totalliabilil"></span></td><td>-</td></tr>
                    <tr><td>Income tax paid</td><td></td><td>-</td></tr>
                    <tr><td><strong>Net cash from/(used in) operating activities</strong></td><td><span id="netcashher"></span></td><td>-</td></tr>
                    <tr class="category-row" style="background-color: #a3bfc2;">
                        <td><strong>Cash flows from investing activities</strong></td>
                        <td></td>
                        <td>-</td>
                    </tr>
                    <tr><td>Purchase of property and equipment</td><td></td><td>-</td></tr>
                    <tr><td>Proceeds from disposal of assets</td><td></td><td>-</td></tr>
                    <tr><td><strong>Net cash used in investing activities</strong></td><td></td><td>-</td></tr>
                    <tr class="category-row" style="background-color: #a3bfc2;">
                        <td><strong>Cash flows from financing activities</strong></td>
                        <td></td>
                        <td>-</td>
                    </tr>
                    <tr><td>Share capital</td><td><span id="sharedcapital"></span></td><td>-</td></tr>
                    <tr><td>Drawings by Shareholders</td><td>0</td><td>-</td></tr>
                    <tr><td>Long term loan</td><td>0</td><td>-</td></tr>
                    <tr><td><strong>Net cash used in financing activities</strong></td><td><span id="sharedcapital2"></span></td><td>-</td></tr>
                    <tr><td><strong>Net increase/(decrease) in cash and cash equivalents</strong></td><td><span id="sharedcapital3"></span></td><td>-</td></tr>
                    <tr><td>Cash and cash equivalents at beginning of the quarter</td><td></td><td>-</td></tr>
                    <tr><td><strong>Cash and cash equivalents at end of the quarter</strong></td><td><span id="sharedcapital4"></span></td><td>-</td></tr>
                </tbody>
            </table>
        </div>
        </div>
    `);

    // Load financial years into dropdown and set the current year
    loadFinancialYears();

    const todayFormatted = getTodayFormatted();
    document.getElementById('currentDate').textContent = todayFormatted;
    document.getElementById('cashFlowDate').textContent = todayFormatted;

    // Event listener for Load Data button
    $('#loadDataButton').on('click', function() {
        fetchBalanceSheetData();
    });

    // Event listener for the checkbox
    $('#toggleCategories').on('change', function() {
        let isChecked = $(this).is(':checked');
        toggleCategoryRows(isChecked);
    });

 // Function to get today's date formatted as per requirement
    function getTodayFormatted() {
        const today = new Date();
        return today.toLocaleDateString('en-GB');
    }

    // Function to get yesterday's date formatted as per requirement
    function getYesterdayFormatted() {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        return yesterday.toLocaleDateString('en-GB');
    }

   

    // Function to fetch balance sheet data
  
    // Function to toggle visibility of category rows based on checkbox
    function toggleCategoryRows(show) {
        const categoryRows = document.querySelectorAll('.category-row');
        categoryRows.forEach(row => {
            row.style.display = show ? '' : 'none';
        });
    }



			// Load financial years into dropdown and set the current year
			loadFinancialYears();
			const today = new Date();
			const formattedDate = today.toLocaleDateString(undefined, {
				year: 'numeric',
				month: 'numeric',
				day: 'numeric'
			});
		
			// Insert today's date into the span
			document.getElementById('currentDate').textContent = formattedDate;

	// Event listener for Load Data button
	$('#loadDataButton').on('click', function() {
		fetchBalanceSheetData();
	});

	// Event listener for the checkbox
	$('#toggleCategories').on('change', function() {
		let isChecked = $(this).is(':checked');
		toggleCategoryRows(isChecked);
	});

	// Function to fetch company details and logo based on user
	function fetchCompanyDetails() {
		frappe.call({
			method: 'frappe.client.get_value',
			args: {
				doctype: 'Employee',
				filters: {
					user: frappe.session.user
				},
				fieldname: 'company'
			},
			callback: function(response) {
				if (response.message && response.message.company) {
					const companyName = response.message.company;
					if (response.message && response.message.branch) {
						const companyName2 = response.message.branch;
						let financialYearSelect = $('#financialYear2');
						financialYearSelect.empty();
						financialYearSelect.append('<option value="">Select Branch</option>');
						financialYearSelect.append(new Option(companyName2, companyName2)).val(companyName2);
						financialYearSelect.val(companyName2);
					} 
					loadCompanyDetails(companyName);
				} else {
					frappe.call({
						method: 'frappe.client.get_list',
						args: {
							doctype: 'Company',
							fields: ['name'],
							limit: 1
						},
						callback: function(companyResponse) {
							if (companyResponse.message && companyResponse.message.length > 0) {
								const defaultCompanyName = companyResponse.message[0].name;
								loadCompanyDetails(defaultCompanyName);
							} else {
								frappe.msgprint(__('No company details found.'));
							}
						},
						error: function(xhr, status, error) {
							console.error('Error fetching default company details:', error);
							frappe.msgprint(__('An error occurred while fetching default company details: ' + error));
						}
					});
				}
			},
			error: function(xhr, status, error) {
				console.error('Error fetching user company details:', error);
				frappe.msgprint(__('An error occurred while fetching user company details: ' + error));
			}
		});
	}

	// Function to load company details and display in letterhead
	function loadCompanyDetails(companyName) {
		frappe.call({
			method: 'frappe.client.get',
			args: {
				doctype: 'Company',
				name: companyName
			},
			callback: function(response) {
				if (response.message) {
					let company = response.message;
					let letterhead = $('#letterhead');
					let logoHTML = company.company_logo ? `<img src="${company.company_logo}" alt="Company Logo" style="max-width: 100px; height: auto;">` : '';
					let companyDetailsHTML = `
						${logoHTML}
						<h3>${company.name}</h3>
						<h4>${company.address || ''}</h4>
						<h4>BRN: ${company.fax || ''}</h4>
						<h4>TIN: ${company.website || ''}</h4>
					`;
					letterhead.html(companyDetailsHTML);
				} else {
					frappe.msgprint(__('No company details found.'));
				}
			},
			error: function(xhr, status, error) {
				console.error('Error fetching company details:', error);
				frappe.msgprint(__('An error occurred while fetching company details: ' + error));
			}
		});
	}

	// Function to load financial years into dropdown
	function loadFinancialYears() {
		frappe.call({
			method: 'frappe.client.get_list',
			args: {
				doctype: 'Fiscal Year',
				fields: ['name', 'year_start_date', 'year_end_date'],
				limit_page_length: 100
			},
			callback: function(response) {
				let financialYearSelect = $('#financialYear');
				financialYearSelect.empty();
				financialYearSelect.append('<option value="">Select Financial Year</option>');

				let currentYear = new Date().getFullYear();  // Get the current year
				let foundCurrentYear = false;

				if (response.message) {
					response.message.forEach(year => {
						let option = `<option value="${year.name}" data-start="${year.year_start_date}" data-end="${year.year_end_date}">${year.name}</option>`;
						financialYearSelect.append(option);

						// Set the current year as selected
						if (year.name.includes(currentYear)) {
							foundCurrentYear = true;
							financialYearSelect.val(year.name);
						}
					});

					// If current year found, trigger the load data button
					if (foundCurrentYear) {
						$('#loadDataButton').click();
					}
				} else {
					frappe.msgprint(__('No financial years found.'));
				}
			},
			error: function(xhr, status, error) {
				console.error('Error fetching financial years:', error);
				frappe.msgprint(__('An error occurred while fetching financial years: ' + error));
			}
		});
	}

	// Function to fetch data from Saving Transaction doctype
	function fetchBalanceSheetData() {
		let selectedYear = $('#financialYear').val();

		if (!selectedYear) {
			frappe.msgprint(__('Please select a financial year.'));
			return;
		}

		let selectedOption = $('#financialYear option:selected');
		let startDate = selectedOption.data('start');
		let endDat     // Fetching Saving Transactions using Frappe call
        let branch = $('#financialYear2').val();
        if (branch == 'All') {
		// Fetching Saving Transactions using Frappe call
		frappe.call({
			method: 'frappe.client.get_list',
			args: {
				doctype: 'General Ledger II',
				filters: {
					posting_date: ['between', [startDate, endDate]],
					flagged:0
				},
				fields: ['account', 'debit', 'credit', 'posting_date', 'transaction_type_name', 'category', 'main_parent', 'sub_parent'],
				limit_page_length: 200
			},
			callback: function(response) {
				if (response.message) {
					processBalanceSheetData(response.message);
				} else {
					frappe.msgprint(__('No data found for the selected financial year.'));
				}
			},
			error: function(xhr, status, error) {
				console.error('Error fetching balance sheet data:', error);
				frappe.msgprint(__('An error occurred while fetching balance sheet data: ' + error));
			}
		});

	}else{
		frappe.call({
			method: 'frappe.client.get_list',
			args: {
				doctype: 'General Ledger II',
				filters: {
					posting_date: ['between', [startDate, endDate]],
					flagged:0,
					branch: $('#financialYear2').val()
				},
				fields: ['account', 'debit', 'credit', 'posting_date', 'transaction_type_name', 'category', 'main_parent', 'sub_parent'],
				limit_page_length: 200
			},
			callback: function(response) {
				if (response.message) {
					processBalanceSheetData(response.message);
				} else {
					frappe.msgprint(__('No data found for the selected financial year.'));
				}
			},
			error: function(xhr, status, error) {
				console.error('Error fetching balance sheet data:', error);
				frappe.msgprint(__('An error occurred while fetching balance sheet data: ' + error));
			}
		});
	}
	}

    function processBalanceSheetData(data) {
		let balanceSheetBody = $('#balanceSheetBody');
		balanceSheetBody.empty();
	
		let aggregatedData = {
			'Assets': { subCategories: {}, totals: { balance: 0 } },
			'Liabilities': { subCategories: {}, totals: { balance: 0 } },
			'Equity': { subCategories: {}, totals: { balance: 0 } }
		};
	
		let totalIncome = 0;
		let totalExpenses = 0;
	
		// Aggregate data by main_parent, sub_parent, and category
		data.forEach(entry => {
			let mainCategory = entry.main_parent || 'Other';
			let subCategory = entry.sub_parent || 'Other';
			let category = entry.category || 'Other';
			let debit = parseFloat(entry.debit || 0);
			let credit = parseFloat(entry.credit || 0);
			let balance = 0;
	
			// Determine balance based on category type
			if (mainCategory === 'Assets') {
				balance = debit - credit;
			} else if (mainCategory === 'Liabilities') {
				balance = credit - debit;
			} else if (mainCategory === 'Equity') {
				balance = credit - debit;
			} else if (mainCategory === 'Income') {
				totalIncome += credit - debit;
			} else if (mainCategory === 'Expenses') {
				totalExpenses += debit - credit;
			}
	
			// Ignore Income and Expenses for now, only process Assets, Liabilities, and Equity
			if (['Assets', 'Liabilities', 'Equity'].includes(mainCategory)) {
				if (!aggregatedData[mainCategory].subCategories[subCategory]) {
					aggregatedData[mainCategory].subCategories[subCategory] = { categories: {}, totals: { balance: 0 } };
				}
	
				if (!aggregatedData[mainCategory].subCategories[subCategory].categories[category]) {
					aggregatedData[mainCategory].subCategories[subCategory].categories[category] = { balance: 0 };
				}
	
				// Aggregate the amounts
				aggregatedData[mainCategory].subCategories[subCategory].categories[category].balance += balance;
	
				// Update subcategory totals (for later calculation, but not display)
				aggregatedData[mainCategory].subCategories[subCategory].totals.balance += balance;
	
				// Update main category totals
				aggregatedData[mainCategory].totals.balance += balance;
			}
		});
	
		// Calculate retained earnings (Total Income - Total Expenses)
		let retainedEarnings = totalIncome - totalExpenses;
		document.getElementById("retainedEarningsText").textContent =  parseInt(retainedEarnings).toLocaleString();
		document.getElementById("retainedEarningsText2").textContent =  parseInt(retainedEarnings).toLocaleString();
		aggregatedData['Equity'].totals.balance += retainedEarnings;
	
		// Define the order in which to display the main categories
		let categoryOrder = ['Assets', 'Liabilities', 'Equity'];
	
		// Render aggregated data in the specified order without intermediate totals
		categoryOrder.forEach(mainCategory => {
			let mainCategoryData = aggregatedData[mainCategory];
	
			balanceSheetBody.append(`
				<tr class="table-primary">
					<td><strong>${mainCategory}</strong></td>
					<td></td> <!-- No balance shown for the main category here -->
				</tr>
			`);
	
			for (let subCategory in mainCategoryData.subCategories) {
				let subCategoryData = mainCategoryData.subCategories[subCategory];
				let subCategoryId = 'subCategory-' + escapeId(subCategory);
	
				balanceSheetBody.append(`
					<tr class="table-secondary" style="cursor: pointer;" id="row-${subCategoryId}">
						<td><strong>${subCategory}</strong></td>
						<td></td> <!-- No balance shown for the subcategory -->
					</tr>
				`);
	
				// Add category rows with unique IDs, initially hidden
				balanceSheetBody.append(`<tbody id="${subCategoryId}" class="d-none">`);
				for (let category in subCategoryData.categories) {
					let categoryData = subCategoryData.categories[category];
	
					balanceSheetBody.append(`
						<tr class="category-row">
							<td>${category}</td>
							<td class="text-right">${formatCurrency(categoryData.balance)}</td>
						</tr>
					`);
				}
				balanceSheetBody.append(`</tbody>`);
			}
	
			// Add Retained Earnings under Equity but before Total Equity
			if (mainCategory === 'Equity') {
				balanceSheetBody.append(`
					<tr class="category-row">
						<td>Retained Earnings</td>
						<td class="text-right"><strong>${formatCurrency(retainedEarnings)}</strong></td>
					</tr>
				`);
			}
	
			// Add totals row for each main category (underlined)
			balanceSheetBody.append(`
				<tr class="table-warning">
					<td><strong>Total ${mainCategory}</strong></td>
					<td class="text-right" style="text-decoration: underline;"><strong>${formatCurrency(mainCategoryData.totals.balance)}</strong></td>
				</tr>
			`);
		});
	
		// Add a final total row for Liabilities + Equity
		let totalLiabilitiesEquity = aggregatedData['Liabilities'].totals.balance + aggregatedData['Equity'].totals.balance;
		
		document.getElementById("totalliabilil").textContent =  parseInt(aggregatedData['Liabilities'].totals.balance ).toLocaleString();

		var netcash =0;                     
 $.ajax({
	url: `${window.location.origin}/api/method/mfis.clients.get_receivablescashflow`,
	type: 'GET',
	dataType: 'json',
	success: function(response) {
		var data = response.message;
		if (data) {

			var oldamount = 0;
			var newamount = oldamount - parseInt(data);
			 netcash = aggregatedData['Liabilities'].totals.balance  + newamount + retainedEarnings;

			document.getElementById("totalreceivables").textContent =  parseInt(newamount).toLocaleString();
			document.getElementById("netcashher").textContent =  parseInt(netcash).toLocaleString();
		} else {
			console.error('Empty response data.');
		}
	},
	error: function(xhr, status, error) {
		console.error('Error fetching data:', error);
	}
});


var current_user = frappe.session.user;
// Fetch the Employee document linked to the current user
frappe.db.get_value('Employee', { 'user': current_user }, 'name', function(r) {
	if (r && r.name) {
		// Load the full Employee document
		frappe.model.with_doc('Employee', r.name, function() {
			var employee_doc = frappe.model.get_doc('Employee', r.name);
			var current_user2 = employee_doc.branch;

			$.ajax({
				url: `${window.location.origin}/api/method/mfis.clients.get_sharedcapital?br=`+ current_user2 +` `,
				type: 'GET',
				dataType: 'json',
				success: function(response) {
					var data = response.message;
					if (data) {
			
					
						var newamount = parseInt(data);
						
			
						document.getElementById("sharedcapital").textContent =  parseInt(newamount).toLocaleString();
						document.getElementById("sharedcapital2").textContent =  parseInt(newamount).toLocaleString();
						document.getElementById("sharedcapital3").textContent =  parseInt(netcash+newamount).toLocaleString();
						document.getElementById("sharedcapital4").textContent =  parseInt(netcash+newamount).toLocaleString();
					} else {
						console.error('Empty response data.');
					}
				},
				error: function(xhr, status, error) {
					console.error('Error fetching data:', error);
				}
			});

		});
	}else{
		
		$.ajax({
			url: `${window.location.origin}/api/method/mfis.clients.get_sharedcapital?br=10`,
			type: 'GET',
			dataType: 'json',
			success: function(response) {
				var data = response.message;
				if (data) {
		
				
					var newamount = parseInt(data);
					
		
					document.getElementById("sharedcapital").textContent =  parseInt(newamount).toLocaleString();
					document.getElementById("sharedcapital2").textContent =  parseInt(newamount).toLocaleString();
					document.getElementById("sharedcapital3").textContent =  parseInt(netcash+newamount).toLocaleString();
					document.getElementById("sharedcapital4").textContent =  parseInt(netcash+newamount).toLocaleString();
				} else {
					console.error('Empty response data.');
				}
			},
			error: function(xhr, status, error) {
				console.error('Error fetching data:', error);
			}
		});
	}
});






		balanceSheetBody.append(`
			<tr class="table-success">
				<td><strong>Total Liabilities + Equity</strong></td>
				<td class="text-right" style="text-decoration: underline;"><strong>${formatCurrency(totalLiabilitiesEquity)}</strong></td>
			</tr>
		`);
	}
	
	// Helper functions
	function formatCurrency(value) {
		return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value);
	}
	
	function escapeId(id) {
		return id.replace(/[^a-zA-Z0-9]/g, '-');
	}
	
	function toggleCategoryRows(checked) {
		if (checked) {
			$('.category-row').show();  // Show all category rows
		} else {
			$('.category-row').hide();  // Hide all category rows
		}
	}


	// Function to format number as currency
	function formatCurrency(amount) {
		return amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
	}
};
