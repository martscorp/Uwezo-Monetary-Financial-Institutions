frappe.pages['interest-on-credit-'].on_page_load = function(wrapper) {
	var page = frappe.ui.make_app_page({
		parent: wrapper,
		title: 'Interest On Credit',
		single_column: true
	});
}