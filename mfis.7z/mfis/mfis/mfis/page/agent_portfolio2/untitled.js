

        $.ajax({
    url: '',
    type: 'GET',
    dataType: 'json',
    success: function(response) {
        var data = response.message;
        if (data) {
            // Clear existing rows
    
        }
    },
    error: function(xhr, status, error) {
        console.error('Error fetching data:', error);
    }
});
