frappe.pages['net-interest-margin-'].on_page_load = function(wrapper) {
	var page = frappe.ui.make_app_page({
		parent: wrapper,
		title: 'Net Interest Margin Report',
		single_column: true
	});
}