frappe.pages['daily-loan-deposit-1'].on_page_load = function(wrapper) {
	var page = frappe.ui.make_app_page({
		parent: wrapper,
		title: 'Daily Loan Deposit',
		single_column: true
	});
}