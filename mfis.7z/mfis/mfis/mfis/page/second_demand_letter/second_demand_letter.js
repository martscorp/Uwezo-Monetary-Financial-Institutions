frappe.pages['second-demand-letter'].on_page_load = function(wrapper) {
	var page = frappe.ui.make_app_page({
		parent: wrapper,
		title: 'Second Demand Letter',
		single_column: true
	});

	
		var container = $('<div class="demand-letter-container">').appendTo(page.body);
	
		// Function to generate a unique reference number
		function generateRefNumber() {
			return Math.floor(Math.random() * (9999 - 1000 + 1)) + 1000;
		}
	
		// Function to fetch data from URL parameters
		function fetchDemandLetterDetails() {
			var urlParams = new URLSearchParams(window.location.search);
			var borrowerName = urlParams.get('name') || "";
			var borrowerPhoneNumber = urlParams.get('phoneNumber') || "";
			var businessAddress = urlParams.get('businessAddress') || "";
			var loanAmount = urlParams.get('principalAmount') || "";
			var firstDemandDate = urlParams.get('firstDemandDate') || ""; // Assuming you pass the first demand date in the URL params
	
			var currentDate = new Date().toLocaleDateString('en-US');
			var refNumber = generateRefNumber(); // Generate a unique reference number
	
			// Generate the HTML for the demand letter 2
			var htmlData = `
				<script>
					function pprint() {
						// Immediately-invoked function expression (IIFE) to handle printing
						(function() {
							var printContents = document.querySelector('.demand-letter-inner');
							if (printContents) {
								var originalContents = document.body.innerHTML;
								document.body.innerHTML = printContents.innerHTML;
								window.print();
								document.body.innerHTML = originalContents;
							} else {
								console.error('Error: Element with class "demand-letter-inner" not found.');
							}
						})();
					}
				</script>
				<style>
					.demand-letter-container {
						font-family: Arial, sans-serif;
						background-color: transparent;
						margin: 20px;
						padding: 20px;
					}
					.demand-letter {
						border: 0px solid #ccc;
						padding: 2px;
					}
					.logo {
						text-align: center;
						margin-bottom: 20px;
					}
					.logo img {
						max-width: 200px;
						height: auto;
					}
					.print-button {
						text-align: right;
						margin-top: 20px;
					}
					.print-button button {
						padding: 10px 20px;
						background-color: #007bff;
						color: #fff;
						border: none;
						cursor: pointer;
						font-size: 14px;
					}
					.demand-letter-inner {
						border: 1px solid #ccc;
						padding: 20px;
						margin-top: 20px;
					}
					.signature-block {
						text-align: center;
						margin-top: 20px;
						padding-top: 10px;
					}
					.signature-block p {
						margin: 5px 0;
					}
					.signature-block .signature-line {
						border-top: 1px dotted #000;
						width: 60%;
						margin: 0 auto;
					}
					@media print {
						.print-button {
							display: none;
						}
					}
				</style>
	
				<div class="demand-letter-container">
					<div class="demand-letter">
						<div class="print-button">
							<button onclick="pprint()">Print Demand Letter</button>
						</div>
						<div class="demand-letter-inner">
							<div class="logo">
								<img src="/private/files/logo-white-uwezo.webp" style="width:20%;" alt="Uwezo Microfinance Logo">
							</div>
							<h2 style="text-align: center; font-weight: bold;">Uwezo Microfinace</h2>
							<h3 style="text-align: center; font-weight: bold;">Demand Letter for Outstanding Loan Payment Guaranteed By you</h3>
	
							<div class="letter-header">
								<p><strong>Date:</strong> ${currentDate}</p>
								<p><strong>Ref No:</strong> ${refNumber}</p>
							</div>
							<div class="recipient-details">
								<h4><strong>${borrowerName}</strong></h4>
								<p><strong>Work Address:</strong> ${businessAddress}</p>
								<p><strong>Mobile Contact:</strong> ${borrowerPhoneNumber}</p>
							</div>
							<div class="letter-body">
								<h4>Dear ${borrowerName.split(' ')[0]},</h4>
								<h4><strong>RE: DEMAND LETTER FOR OUTSTANDING LOAN PAYMENT GUARANTEED BY YOU</strong></h4>
								<p>We are writing to follow up on our previous communication dated ${firstDemandDate} regarding the overdue loan payment guaranteed by you for ${borrowerName}. As of today, the outstanding balance of UGX ${loanAmount} remains unpaid.</p>
								<p>As a guarantor, it is imperative that you take immediate action to resolve this matter. We request that you settle the outstanding amount within seven (7) days from the date of this letter. Failure to do so will result in the forwarding of this account to our legal team for further action, which may include legal proceedings to recover the debt.</p>
								<p>To avoid these consequences, please ensure the payment is made by the seventh day from the day you receive this notice. If the payment has already been made, please notify us immediately to update our records. Should you have any questions or require assistance, you may contact us through [Office Phone Number] and [Risk & Collections Manager Phone Number].</p>
								<p>We hope to resolve this matter amicably and look forward to your prompt response.</p>
							</div>
							<div class="signature-block">
								<p>Sincerely,</p>
								<p><strong>___________________________</strong></p>
								<p>Risk and Collections Manager</p>
								<p>Uwezo Microfinace</p>
							</div>
						</div>
					</div>
				</div>
			`;
	
			return htmlData;
		}
	
		// Function to render the demand letter on page load
		function renderDemandLetter() {
			var htmlContent = fetchDemandLetterDetails();
			container.html(htmlContent);
		}
	
		// Initial render of the demand letter
		renderDemandLetter();
	};
	