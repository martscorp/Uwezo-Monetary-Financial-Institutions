frappe.pages['loan-closure-due-dat-1'].on_page_load = function(wrapper) {
	var page = frappe.ui.make_app_page({
		parent: wrapper,
		title: 'Loan Closure Due Date',
		single_column: true
	});
}