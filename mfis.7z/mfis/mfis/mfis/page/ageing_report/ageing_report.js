frappe.pages['ageing-report'].on_page_load = function(wrapper) {
    var page = frappe.ui.make_app_page({
        parent: wrapper,
        title: 'Ageing Report',
        single_column: true
    });
  
                                        localStorage.clear();
                                        
                                    
                                    var newRowHTML = `
                                    <tr>
                                    <th>Type</th> 
                                    <th>Client</th> 
                                    <th>Amount</th> 
                                    <th>Fees</th> 
                                    <th>Buy</th> 
                                    <th>Date</th> 
                                    </tr>
                                    `;
                                    
                                    
                                    
                        frappe.call({
                            method: 'frappe.client.get',
                            args: {
                                doctype: 'Company',
                                filters: {
                                    // Add any filters you need
                                },
                                fields: ['org_name', 'email', 'phone_number', 'logo', 'address']
                            },
                            callback: function (data) {
                                if (!data.exc) {
                                    var record = data.message;
                        
                                    var company_name = record.company_name;
                                    var address = record.address_summary;
                                    var phone_no = record.phone_no;
                                    var imggg = record.company_logo;
                                    var email = record.email;
                        
                                    $("#ccname").html(company_name);
                                    $("#ccnameftr").html(company_name);
                                    $("#ccname2").html(address);
                                    $("#ccname3").html(phone_no);
                                    $("#ccname4").html(email);
                                    $("#ccname5").attr("src", imggg);
                                } else {
                                    // Handle the error
                                    console.error(data.exc);
                                }
                            }
                        });
                                    
                                    
                                    
                                        var container = $('<div class="report">').appendTo(page.body);
                                    
                                        
                                        // Add the HTML structure you provided
                                        var htmlData = `
                                    
                                    
                                        <div class="date-filters">
                                        <div class="filter d-block">
                                          <label for="fromDate">From Date</label>
                                          <input type="date" id="fromDateFilter" name="fromDate" value="${getCurrentDate()}" class="date-input">
                                        </div>
                                        <div class="filter d-block">
                                          <label for="toDate">To Date</label>
                                          <input type="date" id="toDateFilter" name="toDate" value="${getCurrentDate()}" class="date-input">
                                        </div>
                                        <div class="filter">
                                          <label for="dateFilter">Teller/Agent</label>
                                          <select id="dateFilter" name="dateFilter" class="date-input" >
                                        
                                          </select>
                                        </div>
                                        <button  id="btn3" onclick="addDemoDataToTable()" class="apply-button">Load Data</button>
                                        <button onclick="printReport()" id="btn1" class="apply-button button3">Print</button>
                                        <button onclick="exporttoexecl()"  id="btn2" class="apply-button button2">Export</button>
                                      </div>
                                      
                                    <hr>
                                    
                                    <div class="report" id="bana">
                                    <div class="header">
                                      <div class="logo">
                                      
                                            <img src="" id="ccname5" alt=" Logo">
                                        </div>
                                        <!-- Company Name -->
                                    
                                    </div>
                                    
                                    
                                    
                                    <div class="account-details row" style="margin-top: ">
                                    `;
                                    
                                    
                                    
                                    
                                    htmlData+=`
                                    
                                        <div class="account-summary col-6">
                                            <h4 id="ccname"><span id="ccnameftr"></span> Financials</h4>
                                            <p><b>Address:</b> <span id="ccname2"></span></p>
                                            <p><b>Contact:</b> <span id="ccname3"></span></p>
                                            <p><b>Email:</b> <span id="ccname4"></span></p>
                                        </div>
                                    
                                    
                                    
                                    <div class="account-info2 col-6 d-none">
                                            
                                            <p><b>Account Name:</b> <span class="monrr" id="clientmane"></span></p>
                                            <p><b></b> <span class="monrr" id="clientloc"></span></p>
                                            <p><b>Account Type:</b> <span class="monrr" id="clientacctype"></span></p>
                                            <p><b>Account No:</b> <span class="monrr" id="clientaccnumber" ></span></p>
                                            <p><b>Session:</b> <span class="monrr" id="daterage1"></span> - <span class="monrr" id="daterage2"></span></p>
                                    </div>
                                    
                                         <div class="account-info2 col-6 ">
                                            <p><b>Generated By:</b> <span class="monrr">${frappe.session.user}</span></p>
                                            <p><b>Report Type:</b> <span class="monrr">System Generated</span></p>
                                            <p><b>Rows:</b> [<span class="monrr" id="rowcout">0</span>]</p>
                                            <p><b>Session:</b> <span class="monrr" id="daterage12"></span> - <span class="monrr" id="daterage22"></span></p>
                                    </div>
                                    
                                    
                                    </div>
                                
                                    <h3 class="tttt">Ageing Report</h3>
                                    
                                    <table class="balance-sheet-table col-12" id="myTable">
                                          <tr>
                                        <th>ID</th>
                                        
                                        <th>Portfolio</th>
                                        <th>Loan.Type</th>
                                        <th>Loan.No.</th>
                                        <th>Loan.Title</th>
                                        <th>Loan.cycle</th>
                                        <th>Disbursed.Amount</th>
                                        <th>P..Due.&.Not.paid</th>
                                        
                                        <th>I..in.Arrears</th>
                                        <th>Total.Unpaid.Amount</th>
                                        <th>Installment.Unpaid</th>
                                        <th>Days.In.Arreas</th>
                                    </tr>
                                    </thead>
                                    <tbody id="myTable2">
                                    <!-- Data rows will be added here -->
                                    </tbody>
                                    </table>
                                    <br>
                                    <h4><u>Summary Table</u></h4>
                                            <table class="summary-table col-12" id="summaryTableg">
                                        <thead>
                                            <tr>
                                                <th>Account Type</th>
                                                <th>No. of Customers</th>
                                                <th>Total Amount</th>
                                            
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Business Acc</td>
                                                <td></td>
                                                <td>0</td>
                                            
                                            </tr>
                                            <tr>
                                                <td>Unsecured Loan</td>
                                                <td>0</td>
                                                <td>0</td>
                                            
                                            </tr>
                                            <tr>
                                                <td>Staff Loan</td>
                                                <td>0</td>
                                                <td>0</td>
                                            
                                            </tr>
                                            <tr>
                                                <td><b>Total</b></td>
                                                <td><b>0</b></td>
                                                <td><b>0</b></td>
                                            
                                            </tr>
                                        </tbody>
                                    </table>	
                                    <div class="footer" id="footer">
                                    
                            
                                        <hr>    
                                        <p>&copy; 2025 <span id="ccnameftr"></span> Uwezo Microfinace All rights reserved.</p>
                                    
                                    
                                    </div>
                                    </div>
                                    
                                    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.4/xlsx.full.min.js"></script>
                                    
                                    `;
                                    
                                         container.html(htmlData);
                                     
                                    
                                        // Add the CSS styles
                                        var style = `
                                        body {
                                            font-family: Arial, sans-serif;
                                            margin: 0;
                                            padding: 0;
                                        }
                                    
                                        /* Add your preferred styling here */
                                    .date-filters {
                                      display: flex;
                                      flex-wrap: wrap;
                                      justify-content: space-between;
                                    }
                                    
                                    .filter {
                                      width: 100%;
                                      max-width: 150px;
                                      margin-bottom: 10px;
                                    }
                                    
                                    label {
                                      display: block;
                                      font-weight: bold;
                                      margin-bottom: 5px;
                                    }
                                    
                                    .date-input {
                                      width: 100%;
                                      padding: 5px;
                                      border: 1px solid #ccc;
                                      border-radius: 5px;
                                    }
                                    
                                    .apply-button {
                                      background-color: #007bff;
                                      color: #fff;
                                      padding: 10px 10px;
                                      border: none;
                                      border-radius: 5px;
                                      height:50%;
                                      width:10%;
                                      cursor: pointer;
                                      margin-right: 2%;
                                      margin-top: 3%;
                                    }
                                    
                                    
                                      
                                    
                                    .button3 {
                                      background-color: #333;
                                    }
                                    
                                    .button2 {
                                      background-color: #ff9900;
                                    }
                                    
                                    /* Responsive styles */
                                    @media (min-width: 768px) {
                                      .filter {
                                        width: calc(33.33% - 10px);
                                        margin-right: 5px;
                                      }
                                    }
                                    
                                    
                                        /* Style for the report container */
                                        .report {
                                            width: 800px;
                                            margin: 0 auto;
                                            position: relative;
                                        }
                                    
                                        /* Style for the header */
                                        .header {
                                            text-align: left;
                                            margin-top: 10px;
                                        }
                                    
                                        /* Style for the logo */
                                        .logo {
                                            text-align: left;
                                            margin-top: 20px;
                                        }
                                    
                                        .logo img {
                                            width: 10%;
                                        }
                                    
                                        /* Style for company details */
                                        .company-details {
                                            text-align: left;
                                            margin-top: 10px;
                                        }
                                    
                                        .company-details p {
                                            margin: 5px 0;
                                        }
                                    
                                        /* Style for the balance sheet table */
                                        .balance-sheet-table {
                                            width: 100%;
                                            border-collapse: collapse;
                                            margin-top: 10px;
                                        }
                                    
                                        .balance-sheet-table th,
                                        .balance-sheet-table td {
                                            padding: 4px;
                                            text-align: left;
                                            border-bottom: 1px solid #ddd;
                                        }
                                    
                                        .balance-sheet-table th {
                                            background-color: #f2f2f2;
                                            font-weight: bold;
                                        }
                                    
                                        /* Style for the account details container */
                                        .account-details {
                                            display: flex;
                                            justify-content: space-between;
                                            margin-top: 10px;
                                        }
                                    
                                        /* Style for account information column */
                                        .account-info {
                                            flex: 1;
                                        }
                                    
                                        /* Style for account summary column */
                                        .account-summary {
                                            flex: 1;
                                            text-align: left;
                                        }
                                    
                                          /* Style for account summary column */
                                        .account-info2 {
                                        
                                            text-align: right;
                                        }
                                    
                                        /* Style for the footer */
                                        .footer {
                                            text-align: center;
                                            position: relative;
                                            bottom: 0;
                                            left: 0;
                                            right: 0;
                                            margin-top: 20px;
                                        }
                                        .monrr{
                                            color: teal;
                                            text-decoration: underline;
                                            font-weight: bold;
                                        }
                                    
                                        body{
                                            font-family: calibri;
                                        }
                                        p{
                                            margin: 0%;
                                            margin-top: 2%;
                                        }
                                    
                                        .tttt{
                                    text-align: center;
                                    text-decoration: underline;
                                        }
                                        .d-none{
                                            display: none;
                                        }
                                        `;
                                    
                                    
                                    
                                    
                                        var styleElement = $('<style>').text(style);
                                        $('head').append(styleElement);
                                    
                                         var container = $('<div class="report">').appendTo(page.body);
                                     
                                         var styleElement = $('<style>').text(style);
                                         $('head').append(styleElement);
                                    
                                         document.getElementById("btn1").addEventListener("click", function() {
                                            printReport();
                                            localStorage.clear();
                                        });
                                     
                                        document.getElementById("btn2").addEventListener("click", function() {
                                            exportToExcel();
                                            localStorage.clear();
                                        });
                                     
                                    
                                            document.getElementById("btn3").addEventListener("click", function() {
                                                addDemoDataToTable();
                                                localStorage.clear();
                                        });
                                    
                                        
                                    
                                        function printReport() {
                                            var printContents = document.getElementById("bana").innerHTML;
                                            var originalContents = document.body.innerHTML;
                                    
                                            document.body.innerHTML = printContents;
                                            window.print();
                                            document.body.innerHTML = originalContents;
                                        }
                                    
                                    var newRowHTML2="";
                                    
                                    frappe.db.get_list('Employee', {
                                        fields: ['user','full_name'],
                                        filters: {
                                        
                                        }
                                    }).then(records => {
                                        newRowHTML2 += `
                                                <option value="All">All</option>
                                            `;
                                        records.forEach(record => {
                                            const full_name = record.user;
                                            const id_autoincremet = record.full_name;
                                
                                            newRowHTML2 += `
                                                <option value="${full_name}">${id_autoincremet}</option>
                                            `;
                                        });
                                
                                        var selectElement = document.getElementById("dateFilter");
                                        selectElement.innerHTML = newRowHTML2;
                                
                                    });
                                        
                                        function get_savings_accountDetaisl(account_number) {
                            
                            
                                            var filters = {
                                                name: account_number
                                            };
                                        
                                            frappe.db.get_list('Savings Account', {
                                                fields: ['client_name','total_withdrawals_derived','external_number','external_number'],
                                                filters: filters
                                            }).then(records => {
                                                records.forEach(record => {
                                                    const firtst_name2 = record.client_name;
                                                    const account_type = record.total_withdrawals_derived;
                                                    const location = record.external_number;
                                                    const idd = record.name;
                                                    $("#clientmane").text(firtst_name2);
                                                    $("#clientloc").text(location);
                                                    $("#clientacctype").text(account_type);
                                                    $("#clientaccnumber").text(idd);
                                                    
                                            
                                                });
                                        
                                                get_client_balance(account_number);
                                            });
                                            
                                        }
                                    
                                    
                                        function get_client_balance(account_number) {
                                
                                            var filters = {
                                                name: account_number
                                            };
                                            frappe.db.get_list('Savings Account', {
                                                fields: ['balance_derived'],
                                                filters: filters
                                            }).then(records => {
                                                records.forEach(record => {
                                                    const blanc = record.balance_derived;
                                                    $("#client_balnce").text(blanc.toLocaleString());
                                                    $("#client_withdraw").text(blanc.toLocaleString());
                                                
                                                });
                                        
                                        
                                            });
                                            
                                        }
                                    
                                        async function addDemoDataToTable() {
                                            let newRowHTML = "";
                                            const table = document.getElementById("myTable");
                                            const clientname = $("#dateFilter").val();
                                            const fromDate = $("#fromDateFilter").val();
                                            const toDate = $("#toDateFilter").val();
                                            get_savings_accountDetaisl(clientname);
                                            $("#daterage12").text(fromDate);
                                            $("#daterage22").text(toDate);
                                        
                                            let filters = clientname === "All" ? {} : { loan_portfolio: clientname };
                                        
                                            try {
                                                const records = await frappe.db.get_list('Loan Application Plus', {
                                                    fields: ['name', 'client_name', 'mobile_contacts', 'account_number', 'loan_type', 'loan_portfolio', 'creation', 'loan_interest', 'principal', 'loan_tenure', 'grace_period_on_disbursment'],
                                                    filters: filters
                                                });
                                        
                                                let rowCount = 0;
                                                let totalAmount = 0;
                                                let totalOutstanding = 0;
                                                let totalArrears = 0;
                                                let totalPrincipal = 0;
                                                let totalDaysInArrears = 0;  // To keep track of the total Days.In.Arrears
                                        
                                                for (const [index, record] of records.entries()) {
                                                    const { name: id, client_name, mobile_contacts: mobile, account_number, loan_portfolio, principal: amount, loan_interest, loan_tenure } = record;
                                                    const createdOn = new Date(record.creation).toLocaleDateString();
                                        
                                                    const dailyRate = loan_interest / 100 / 30;
                                                    const to_int = dailyRate * amount * loan_tenure;
                                                    const dayinterest = to_int / loan_tenure;
                                        
                                                    // Fetch account type name
                                                    const loanProducts = await frappe.db.get_list('Loan Product', {
                                                        fields: ['product_name'],
                                                        filters: { name: record.loan_type },
                                                        limit: 1
                                                    });
                                                    const accounttype = loanProducts.length > 0 ? loanProducts[0].product_name : "Unknown";
                                        
                                                    // Fetch outstanding loan data
                                                    const loanData = await fetch(`/api/method/mfis.clients.getcurrentloandata?loan=${id}`)
                                                        .then(response => response.json())
                                                        .catch(error => {
                                                            console.error("Error fetching loan data:", error);
                                                            return null;
                                                        });
                                                    const outstanding = loanData?.message?.outstanding || 0;
                                                    const principal = loanData?.message?.principal || 0;
                                        
                                                    // Fetch arrears data
                                                    const arrearsData = await fetch(`/api/method/mfis.clients.get_arrears?loan_id=${id}`)
                                                        .then(response => response.json())
                                                        .catch(error => {
                                                            console.error("Error fetching arrears data:", error);
                                                            return { message: 0 };
                                                        });
                                                    const arrears = arrearsData?.message || 0;
                                        
                                                    // Calculate days with no credit
                                                    let noOfDaysWithNoCredit = 0;
                                                    let lastTransDate = null;
                                        
                                                    const loanRepayments = await frappe.db.get_list('Loan Repayment', {
                                                        fields: ['created_on'],
                                                        filters: { loan: id },
                                                        order_by: 'created_on desc',
                                                        limit: 1
                                                    });
                                        
                                                    const savingsTransfers = await frappe.db.get_list('Savings To Loan Transfer', {
                                                        fields: ['posting_date'],
                                                        filters: { loan: id },
                                                        order_by: 'posting_date desc',
                                                        limit: 1
                                                    });
                                        
                                                    if (loanRepayments.length > 0 && savingsTransfers.length > 0) {
                                                        lastTransDate = new Date(
                                                            Math.max(new Date(loanRepayments[0].created_on), new Date(savingsTransfers[0].posting_date))
                                                        );
                                                    } else if (loanRepayments.length > 0) {
                                                        lastTransDate = new Date(loanRepayments[0].created_on);
                                                    } else if (savingsTransfers.length > 0) {
                                                        lastTransDate = new Date(savingsTransfers[0].posting_date);
                                                    }
                                        
                                                    if (lastTransDate instanceof Date && !isNaN(lastTransDate)) {
                                                        const currentDate = new Date();
                                                        const timeDiff = currentDate - lastTransDate;
                                                        noOfDaysWithNoCredit = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
                                                    } else {
                                                        lastTransDate = "No_Transactions";
                                                        noOfDaysWithNoCredit = "N/A";
                                                    }
                                        
                                                    // Calculate Days.In.Arrears
                                                    const daysInArrears = noOfDaysWithNoCredit !== "N/A" ? noOfDaysWithNoCredit * dayinterest : "N/A";
                                                    totalDaysInArrears += daysInArrears !== "N/A" ? daysInArrears : 0;
                                        
                                                    // Update totals
                                                    totalAmount += amount;
                                                    totalOutstanding += outstanding;
                                                    totalArrears += arrears;
                                                    totalPrincipal += principal;
                                        
                                                    // Generate HTML row
                                                    newRowHTML += `
                                                        <tr>
                                                            <td>${index + 1}</td> <!-- Row Number -->
                                                            <td>${id}</td>
                                                            <td>${loan_portfolio}</td>
                                                            <td>${accounttype.replace(/\s+/g, '.')}</td>
                                                            <td>${account_number}</td>
                                                            <td>${client_name.replace(/\s+/g, '.')}</td>
                                                            <td>${amount.toLocaleString()}</td>
                                                            <td>${(amount - principal).toLocaleString()}</td> <!-- Outstanding Amount -->
                                                            <td>${arrears.toLocaleString()}</td> <!-- Arrears -->
                                                            <td>${outstanding.toLocaleString()}</td> <!-- Outstanding -->
                                                            <td>${noOfDaysWithNoCredit}</td> <!-- Days with No Credit -->
                                                            <td>${daysInArrears !== "N/A" ? daysInArrears.toLocaleString() : "N/A"}</td> <!-- Days.In.Arrears -->
                                                        </tr>
                                                    `;
                                        
                                                    rowCount += 1;
                                                    $("#rowcout").text(rowCount.toLocaleString());
                                                }
                                        
                                                // Append totals row
                                                newRowHTML += `
                                                    <tr>
                                                        <td colspan="6"><strong>Total</strong></td>
                                                        <td><strong>${totalAmount.toLocaleString()}</strong></td>
                                                        <td><strong>${(totalAmount - totalPrincipal).toLocaleString()}</strong></td> <!-- Total Outstanding Amount -->
                                                        <td><strong>${totalArrears.toLocaleString()}</strong></td> <!-- Total Arrears -->
                                                        <td><strong>${totalOutstanding.toLocaleString()}</strong></td> <!-- Total Outstanding -->
                                                        <td></td> <!-- Empty cell for Days with No Credit column in totals row -->
                                                        <td><strong>${totalDaysInArrears.toLocaleString()}</strong></td> <!-- Total Days.In.Arrears -->
                                                    </tr>
                                                `;
                                        
                                                $("#myTable2").html(newRowHTML); // Update the table with all rows including totals
                                        
                                            } catch (error) {
                                                console.error("Error in addDemoDataToTable:", error);
                                            }
                                        }
                                        
                                        
                                    
                                    
                                        function exportToExcel() {
                                        
                                            var table = document.getElementById("myTable");
                                            var wb = XLSX.utils.table_to_book(table, { sheet: "Sheet1" });
                                            XLSX.writeFile(wb, "financial_report.xlsx");
                                        }
                                    
                                        function getCurrentDate() {
                                            
                                            var currentDate = new Date();
                                            var year = currentDate.getFullYear();
                                            var month = String(currentDate.getMonth() + 1).padStart(2, '0');
                                            var day = String(currentDate.getDate()).padStart(2, '0');
                                            return `${year}-${month}-${day}`;
                                        }
                                    
                                         var accordionItems = document.querySelectorAll('.accordion-item');
                                         accordionItems.forEach(function(item) {
                                             var button = item.querySelector('.accordion-button');
                                             var content = item.querySelector('.accordion-content');
                                     
                                             button.addEventListener('click', function() {
                                                 if (content.style.display === 'block') {
                                                     content.style.display = 'none';
                                                 } else {
                                                     content.style.display = 'block';
                                                 }
                                             });
                                         });
                                        
                                    }
                                    