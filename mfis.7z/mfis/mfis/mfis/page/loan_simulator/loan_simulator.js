frappe.pages['loan-simulator'].on_page_load = function(wrapper) {
    var page = frappe.ui.make_app_page({
        parent: wrapper,
        title: 'Loan Simulator',
        single_column: true
    });

    page.main.html(`
        <section class="content">
            <div class="container">
                <div style="display: flex; justify-content: center; margin-bottom: 20px;">
                    <button class="btn btn-primary btn-icon mx-1" type="button" onclick="goBack()">
                        <i class="zmdi zmdi-arrow-left"></i> Go Back
                    </button>
                    <button class="btn btn-primary btn-icon mx-1" type="button" onclick="printdiv()">
                        <i class="zmdi zmdi-print"></i> Print
                    </button>
                    <a class="btn btn-primary btn-icon mx-1 text-light" href="calender.php" target="_blank">
                        <i class="zmdi zmdi-calendar"></i> Calendar
                    </a>
                </div>
                <div id="loan-simulator-content"></div>
            </div>
        </section>
    `);

    window.printdiv = function() {
        var divContents = document.querySelector("#loan-simulator-content").innerHTML;
        var printCSS = '<style>@media print {.boxx:last-child { page-break-after: avoid; }}</style>';
        var html = '<html><head><title>Print</title>' + printCSS + '</head><body>' + divContents + '</body><style>.boxx{font-family:calibri;font-size:14px;margin:25%;padding:2%;margin-top:0px;padding-top:0px;background:#fff!important;}h1{font-size:2.5em;}b{color:#ff7600;font-size:15px;}h1,h4{text-align:center;}</style></html>';
        var printWindow = window.open('', '', 'height=800,width=900');

        printWindow.document.write(html);
        printWindow.document.close();

        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };

    window.goBack = function() {
        window.history.back();
    };

    function getQueryParam(name) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(name);
    }

    // Retrieve parameters from URL
    var loan_date = getQueryParam('loanApprovalDate');
  
    var loan_amount = parseFloat(getQueryParam('principalAmount'));
    var loan_interest = parseFloat(getQueryParam('interestRate'));
    var loan_term = parseInt(getQueryParam('loanPeriod'));
    var grace_period = parseInt(getQueryParam('grace_period_on_disbursment')) || 0;
    var compulsory_saving_percentage = parseFloat(getQueryParam('compulsorySavingPercentage')) || 0;
    var repayment_type = getQueryParam('payment_intervals') || 'Days'; // Default to 'Days'
    var refNo = getQueryParam('refNo')|| 0; // Reference number for Loan Application Plus


frappe.call({
    method: "mfis.clients.get_loan_disbursement_date",
    args: { ref_no: refNo },
    callback: function (r) {
        if (r.message) {
            if (r.message.error) {
                frappe.msgprint({
                    title: "Not Found",
                    message: r.message.error,
                    indicator: "red"
                });
            } else {
                const loan_date = r.message.disbursement_date;
                frappe.msgprint({
                    title: "Loan Disbursement Info",
                    message: `
                        <b>Loan Reference:</b> ${refNo}<br>
                        <b>Disbursement Record:</b> ${r.message.disbursement_name}<br>
                        <b>Disbursement Date:</b> ${loan_date}
                    `,
                    indicator: "green"
                });

                // Optionally, set to a field on the form
                // frm.set_value("disbursement_date", loan_date);
            }
        }
    }
});


    // Check if parameters are missing
    if (!loan_date || isNaN(loan_amount) || isNaN(loan_interest) || isNaN(loan_term)) {
        // Prompt user for loan details if not available in URL
        frappe.prompt([
            { fieldtype: 'Date', label: 'Loan Approval Date', fieldname: 'loanApprovalDate', reqd: true },
            { fieldtype: 'Currency', label: 'Principal Amount', fieldname: 'principalAmount', reqd: true },
            { fieldtype: 'Float', label: 'Interest Rate (%)', fieldname: 'interestRate', reqd: true },
            { fieldtype: 'Int', label: 'Loan Period (Days)', fieldname: 'loanPeriod', reqd: true },
            { fieldtype: 'Select', fieldname: 'repaymentType', label: 'Repayment Type', options: 'Days\nWeeks\nMonths\nYears', default: repayment_type },
            { fieldtype: 'Int', label: 'Grace Period (Days)', fieldname: 'gracePeriod', reqd: false },
            { fieldtype: 'Float', label: 'Compulsory Saving (%)', fieldname: 'compulsorySavingPercentage', reqd: false }
        ], 
        function(values) {
            loan_date = values.loanApprovalDate;
            loan_amount = parseFloat(values.principalAmount);
            loan_interest = parseFloat(values.interestRate);
            loan_term = parseInt(values.loanPeriod);
            grace_period = parseInt(values.gracePeriod) || 0;
            compulsory_saving_percentage = parseFloat(values.compulsorySavingPercentage) || 0;
            repayment_type = values.repaymentType || 'Days';

            fetchSkippedDaysAndGenerateSchedule();
        }, 
        'Enter Loan Details', 
        'Submit');
    } else {
        // If parameters are available, generate loan schedule directly
        fetchSkippedDaysAndGenerateSchedule();
    }

    function fetchSkippedDaysAndGenerateSchedule() {
        frappe.call({
            method: 'frappe.client.get',
            args: {
                doctype: 'Loan Application Plus',
                name: refNo
            },
            callback: function(response) {
                if (response.message) {
                    var calendarSettings = response.message['calendar_settings']; // Assuming this is the field pointing to Calendar Settings

                    // Fetch No Working Days2 from each Calendar Settings record
                    if (calendarSettings && calendarSettings.length > 0) {
              

                        Promise.all(calendarSettings).then(function(results) {
                            var allNoWorkingDays2 = results.flat();

                            var skipped_days = allNoWorkingDays2.map(record => record.day);
                            var skipped_dates = allNoWorkingDays2.map(record => record.date);

                            // Generate the loan schedule with the fetched data
                            generateLoanSchedule(skipped_days, skipped_dates);
                        });
                    } else {
                        console.error('No Calendar Settings records found.');
                    }
                } else {
                    console.error('No data received from server.');
                }
            },
            error: function(err) {
                console.error('Error fetching Loan Application Plus record:', err);
            }
        });
    }

    

    function formatDateToWord(dateString) {
        var date = new Date(dateString);
        var dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        var monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    
        var dayName = dayNames[date.getDay()];
        var day = date.getDate();
        var monthName = monthNames[date.getMonth()];
        var year = date.getFullYear();
    
        // Add ordinal suffix
        var ordinalSuffix;
        if (day >= 1 && day <= 3 || day >= 21 && day <= 23) {
            ordinalSuffix = 'st';
        } else if (day >= 4 && day <= 20 || day >= 24 && day <= 30) {
            ordinalSuffix = 'th';
        } else if (day === 31) {
            ordinalSuffix = 'st';
        }
    
        return `${dayName} ${day}${ordinalSuffix} ${monthName} ${year}`;
    }

    function generateLoanSchedule(skipped_days, skipped_dates) {
        var loanTimestamp = new Date(loan_date).getTime();
        var interest_rate_per_day = (loan_interest / 100) / 30;
        var daily_interest = loan_amount * interest_rate_per_day;

        // Normalize skipped_dates to "YYYY-MM-DD" format
        var normalizedSkippedDates = skipped_dates.map(date => {
            var d = new Date(date);
            return d.toISOString().split('T')[0]; // "YYYY-MM-DD" format
        });

        var repayment_dates = [];
        var last_date = "";
        var grace_period_interest = 0;
        var accumulated_interest = 0;

        if (repayment_type === "Days") {
            var actual_repayment_days = loan_term - grace_period;

            for (var i = 0; i < grace_period; i++) {
                grace_period_interest += daily_interest;
            }

            for (var i = grace_period; i < loan_term; i++) {
                var repayment_date = new Date(loanTimestamp + i * 24 * 60 * 60 * 1000);
                var formatted_date = repayment_date.toISOString().split('T')[0]; // "YYYY-MM-DD" format

                if (normalizedSkippedDates.includes(formatted_date) || skipped_days.includes(repayment_date.toLocaleString('en-US', { weekday: 'long' }))) {
                    accumulated_interest += daily_interest;
                    continue;
                }

                repayment_dates.push({
                    date: formatDateToWord(repayment_date), // Format the date here
                    accumulated_interest: accumulated_interest,
                    isMondayAfterSkippedSunday: repayment_date.getDay() === 1 && skipped_days.includes('Sunday')
                });

                last_date = formatDateToWord(repayment_date);
                accumulated_interest = 0;
            }

            var total_interest = ((loan_term - grace_period) * daily_interest) + grace_period_interest;
            var constant_due_amount = (loan_amount + total_interest) / repayment_dates.length;

            var tableContent = `
                <div class="boxx">
                    <h4 class="mt-2">Payment Schedule (Simulator)</h4>
                    <h6>Interest: <b>${loan_interest}%</b></h6>
                    <h6>Loan Term: <b>${loan_term} Days</b> (s) <span class="text-success">Start: ${loan_date}</span> - <span class="text-danger">End: ${last_date}</span></h6>
                    <h6>Grace Period: <b>${grace_period}</b> Days</h6>
                    <h6>Compulsory Saving: <b>${compulsory_saving_percentage}%</b></h6>
                    <h6>Amount: <b>${loan_amount.toFixed(2)}</b></h6>
                    <h6>Amount To Repay: <b class="text-success mt-2">${(total_interest + loan_amount).toFixed(2)}</b></h6>
                    <table class="table table-bordered table-hover dataTable js-exportable">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Date</th>
                                <th>Principal</th>
                                <th>Full Interest</th>
                                <th>Interest</th>
                                <th>Collection Fees</th>
                                <th>Total Due</th>
                                <th>Principal Balance</th>
                            </tr>
                        </thead>
                        <tbody>
            `;

            var totalPrincipal = 0;
            var totalInterest = 0;
            var totalSavings = 0;
            var totalDue = 0;
            var totalBalance = loan_amount;

            for (var i = 0; i < repayment_dates.length; i++) {
                var interest = daily_interest + repayment_dates[i].accumulated_interest;

                if (i === 0) {
                    interest += grace_period_interest;
                }

                var principal = constant_due_amount - interest;
                var savings = compulsory_saving_percentage;
                var balance = totalBalance - principal;

                tableContent += `
                    <tr>
                        <td>${i + 1}</td>
                        <td>${repayment_dates[i].date}</td>
                        <td>${principal.toFixed(2)}</td>
                        <td>${interest.toFixed(2)}</td>
                        <td>${savings}%</td>
                     
                        <td>${constant_due_amount.toFixed(2)}</td>
                        <td>${Math.max(balance, 0).toFixed(2)}</td>
                    </tr>
                `;

                totalPrincipal += principal;
                totalInterest += interest;
                totalSavings += savings;
                totalDue += constant_due_amount;

                totalBalance = balance;
            }

            tableContent += `
                        </tbody>
                        <tfoot>
                            <tr class="bg-dark text-light">
                                <td colspan="2">Total Payments (Installments)</td>
                                <td>${totalPrincipal.toFixed(2)}</td>
                                <td>${totalInterest.toFixed(2)}</td>
                                <td>${totalSavings.toFixed(2)}</td>
                                <td>${totalDue.toFixed(2)}</td>
                                <td>${Math.max(totalBalance, 0).toFixed(2)}</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            `;

            page.main.find('#loan-simulator-content').html(tableContent);

        } else if (repayment_type === "Weeks") {
            var actual_repayment_weeks = Math.ceil(loan_term / 7);

            for (var i = 0; i < actual_repayment_weeks; i++) {
                var repayment_date = new Date(loanTimestamp + i * 7 * 24 * 60 * 60 * 1000);
                var formatted_date = repayment_date.toISOString().split('T')[0]; // "YYYY-MM-DD" format

                if (normalizedSkippedDates.includes(formatted_date) || skipped_days.includes(repayment_date.toLocaleString('en-US', { weekday: 'long' }))) {
                    accumulated_interest += daily_interest * 7;
                    continue;
                }

                repayment_dates.push({
                    date: formatDateToWord(repayment_date),
                    accumulated_interest: accumulated_interest,
                    isMondayAfterSkippedSunday: repayment_date.getDay() === 1 && skipped_days.includes('Sunday')
                });

                last_date = formatDateToWord(repayment_date);
                accumulated_interest = 0;
            }

            var total_interest = (actual_repayment_weeks * 7 * daily_interest) + grace_period_interest;
            var constant_due_amount = (loan_amount + total_interest) / repayment_dates.length;

            var tableContent = `
                <div class="boxx">
                    <h4 class="mt-2">Payment Schedule (Simulator)</h4>
                    <h6>Interest: <b>${loan_interest}%</b></h6>
                    <h6>Loan Term: <b>${actual_repayment_weeks} Weeks</b> (s) <span class="text-success">Start: ${loan_date}</span> - <span class="text-danger">End: ${last_date}</span></h6>
                    <h6>Grace Period: <b>${grace_period}</b> Days</h6>
                    <h6>Compulsory Saving: <b>${compulsory_saving_percentage}%</b></h6>
                    <h6>Amount: <b>${loan_amount.toFixed(2)}</b></h6>
                    <h6>Amount To Repay: <b class="text-success mt-2">${(total_interest + loan_amount).toFixed(2)}</b></h6>
                    <table class="table table-bordered table-hover dataTable js-exportable">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Date</th>
                                <th>Principal</th>
                                <th>Interest</th>
                                <th>Interest (%)</th>
                                <th>Collection Fees</th>
                                <th>Total Due</th>
                                <th>Principal Balance</th>
                            </tr>
                        </thead>
                        <tbody>
            `;

            var totalPrincipal = 0;
            var totalInterest = 0;
            var totalSavings = 0;
            var totalDue = 0;
            var totalBalance = loan_amount;

            for (var i = 0; i < repayment_dates.length; i++) {
                var interest = (daily_interest * 7) + repayment_dates[i].accumulated_interest;

                if (i === 0) {
                    interest += grace_period_interest;
                }

                var principal = constant_due_amount - interest;
                var savings = compulsory_saving_percentage;
                var balance = totalBalance - principal;

                tableContent += `
                    <tr>
                        <td>${i + 1}</td>
                        <td>${repayment_dates[i].date}</td>
                        <td>${principal.toFixed(2)}</td>
                        <td>${interest.toFixed(2)}</td>
                        <td>${savings}%</td>
                        <td>${constant_due_amount.toFixed(2)}</td>
                        <td>${Math.max(balance, 0).toFixed(2)}</td>
                    </tr>
                `;

                totalPrincipal += principal;
                totalInterest += interest;
                totalSavings += savings;
                totalDue += constant_due_amount;

                totalBalance = balance;
            }

            tableContent += `
                        </tbody>
                        <tfoot>
                            <tr class="bg-dark text-light">
                                <td colspan="2">Total Payments (Installments)</td>
                                <td>${totalPrincipal.toFixed(2)}</td>
                                <td>${totalInterest.toFixed(2)}</td>
                                <td>${totalSavings.toFixed(2)}</td>
                                <td>${totalSavings.toFixed(2)}</td>
                                <td>${totalDue.toFixed(2)}</td>
                                <td>${Math.max(totalBalance, 0).toFixed(2)}</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            `;

            page.main.find('#loan-simulator-content').html(tableContent);

        } else if (repayment_type === "Months") {
            var actual_repayment_months = Math.ceil(loan_term / 30);

            for (var i = 0; i < actual_repayment_months; i++) {
                var repayment_date = new Date(loanTimestamp + i * 30 * 24 * 60 * 60 * 1000);
                var formatted_date = repayment_date.toISOString().split('T')[0]; // "YYYY-MM-DD" format

                if (normalizedSkippedDates.includes(formatted_date) || skipped_days.includes(repayment_date.toLocaleString('en-US', { weekday: 'long' }))) {
                    accumulated_interest += daily_interest * 30;
                    continue;
                }

                repayment_dates.push({
                    date: formatDateToWord(repayment_date),
                    accumulated_interest: accumulated_interest,
                    isMondayAfterSkippedSunday: repayment_date.getDay() === 1 && skipped_days.includes('Sunday')
                });

                last_date = formatDateToWord(repayment_date);
                accumulated_interest = 0;
            }

            var total_interest = (actual_repayment_months * 30 * daily_interest) + grace_period_interest;
            var constant_due_amount = (loan_amount + total_interest) / repayment_dates.length;

            var tableContent = `
                <div class="boxx">
                    <h4 class="mt-2">Payment Schedule (Simulator)</h4>
                    <h6>Interest: <b>${loan_interest}%</b></h6>
                    <h6>Loan Term: <b>${actual_repayment_months} Months</b> (s) <span class="text-success">Start: ${loan_date}</span> - <span class="text-danger">End: ${last_date}</span></h6>
                    <h6>Grace Period: <b>${grace_period}</b> Days</h6>
                    <h6>Compulsory Saving: <b>${compulsory_saving_percentage}%</b></h6>
                    <h6>Amount: <b>${loan_amount.toFixed(2)}</b></h6>
                    <h6>Amount To Repay: <b class="text-success mt-2">${(total_interest + loan_amount).toFixed(2)}</b></h6>
                    <table class="table table-bordered table-hover dataTable js-exportable">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Date</th>
                                <th>Principal</th>
                                <th>Interest</th>
                                    <th>Interest (%)</th>
                                <th>Collection Fees</th>
                                <th>Total Due</th>
                                <th>Principal Balance</th>
                            </tr>
                        </thead>
                        <tbody>
            `;

            var totalPrincipal = 0;
            var totalInterest = 0;
            var totalSavings = 0;
            var totalDue = 0;
            var totalBalance = loan_amount;

            for (var i = 0; i < repayment_dates.length; i++) {
                var interest = (daily_interest * 30) + repayment_dates[i].accumulated_interest;

                if (i === 0) {
                    interest += grace_period_interest;
                }

                var principal = constant_due_amount - interest;
                var savings = compulsory_saving_percentage;
                var balance = totalBalance - principal;

                tableContent += `
                    <tr>
                        <td>${i + 1}</td>
                        <td>${repayment_dates[i].date}</td>
                        <td>${principal.toFixed(2)}</td>
                        <td>${interest.toFixed(2)}</td>
                        <td>${savings.toFixed(2)}</td>
                        <td>${savings.toFixed(2)}</td>
                        <td>${constant_due_amount.toFixed(2)}</td>
                        <td>${Math.max(balance, 0).toFixed(2)}</td>
                    </tr>
                `;

                totalPrincipal += principal;
                totalInterest += interest;
                totalSavings += savings;
                totalDue += constant_due_amount;

                totalBalance = balance;
            }

            tableContent += `
                        </tbody>
                        <tfoot>
                            <tr class="bg-dark text-light">
                                <td colspan="2">Total Payments (Installments)</td>
                                <td>${totalPrincipal.toFixed(2)}</td>
                                <td>${totalInterest.toFixed(2)}</td>
                                <td>${totalSavings.toFixed(2)}</td>
                                <td>${totalDue.toFixed(2)}</td>
                                <td>${Math.max(totalBalance, 0).toFixed(2)}</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            `;

            page.main.find('#loan-simulator-content').html(tableContent);

        } else if (repayment_type === "Years") {
            var actual_repayment_years = Math.ceil(loan_term / 365);

            for (var i = 0; i < actual_repayment_years; i++) {
                var repayment_date = new Date(loanTimestamp + i * 365 * 24 * 60 * 60 * 1000);
                var formatted_date = repayment_date.toISOString().split('T')[0]; // "YYYY-MM-DD" format

                if (normalizedSkippedDates.includes(formatted_date) || skipped_days.includes(repayment_date.toLocaleString('en-US', { weekday: 'long' }))) {
                    accumulated_interest += daily_interest * 365;
                    continue;
                }

                repayment_dates.push({
                    date: formatDateToWord(repayment_date),
                    accumulated_interest: accumulated_interest,
                    isMondayAfterSkippedSunday: repayment_date.getDay() === 1 && skipped_days.includes('Sunday')
                });

                last_date = formatDateToWord(repayment_date);
                accumulated_interest = 0;
            }

            var total_interest = (actual_repayment_years * 365 * daily_interest) + grace_period_interest;
            var constant_due_amount = (loan_amount + total_interest) / repayment_dates.length;

            var tableContent = `
                <div class="boxx">
                    <h4 class="mt-2">Payment Schedule (Simulator)</h4>
                    <h6>Interest: <b>${loan_interest}%</b></h6>
                    <h6>Loan Term: <b>${actual_repayment_years} Years</b> (s) <span class="text-success">Start: ${loan_date}</span> - <span class="text-danger">End: ${last_date}</span></h6>
                    <h6>Grace Period: <b>${grace_period}</b> Days</h6>
                    <h6>Compulsory Saving: <b>${compulsory_saving_percentage}%</b></h6>
                    <h6>Amount: <b>${loan_amount.toFixed(2)}</b></h6>
                    <h6>Amount To Repay: <b class="text-success mt-2">${(total_interest + loan_amount).toFixed(2)}</b></h6>
                    <table class="table table-bordered table-hover dataTable js-exportable">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Date</th>
                                <th>Principal</th>
                                <th>Interest</th>
                                <th>Interest (%)</th>
                                <th>Collection Fees</th>
                                <th>Total Due</th>
                                <th>Principal Balance</th>
                            </tr>
                        </thead>
                        <tbody>
            `;

            var totalPrincipal = 0;
            var totalInterest = 0;
            var totalSavings = 0;
            var totalDue = 0;
            var totalBalance = loan_amount;

            for (var i = 0; i < repayment_dates.length; i++) {
                var interest = (daily_interest * 365) + repayment_dates[i].accumulated_interest;

                if (i === 0) {
                    interest += grace_period_interest;
                }

                var principal = constant_due_amount - interest;
                var savings = compulsory_saving_percentage;
                var balance = totalBalance - principal;

                tableContent += `
                    <tr>
                        <td>${i + 1}</td>
                        <td>${repayment_dates[i].date}</td>
                        <td>${principal.toFixed(2)}</td>
                        <td>${interest.toFixed(2)}</td>
                        <td>${savings.toFixed(2)}</td>
                        <td>${savings.toFixed(2)}</td>
                        <td>${constant_due_amount.toFixed(2)}</td>
                        <td>${Math.max(balance, 0).toFixed(2)}</td>
                    </tr>
                `;

                totalPrincipal += principal;
                totalInterest += interest;
                totalSavings += savings;
                totalDue += constant_due_amount;

                totalBalance = balance;
            }

            tableContent += `
                        </tbody>
                        <tfoot>
                            <tr class="bg-dark text-light">
                                <td colspan="2">Total Payments (Installments)</td>
                                <td>${totalPrincipal.toFixed(2)}</td>
                                <td>${totalInterest.toFixed(2)}</td>
                                <td>${totalSavings.toFixed(2)}</td>
                                <td>${totalDue.toFixed(2)}</td>
                                <td>${Math.max(totalBalance, 0).toFixed(2)}</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            `;

            page.main.find('#loan-simulator-content').html(tableContent);

        } else {
            console.error('Unknown repayment type.');
        }
    }
    

};
