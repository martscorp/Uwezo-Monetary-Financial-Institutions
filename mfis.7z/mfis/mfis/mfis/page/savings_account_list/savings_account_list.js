frappe.pages['savings-account-list'].on_page_load = function(wrapper) {
	var page = frappe.ui.make_app_page({
		parent: wrapper,
		title: 'Savings Account Listings',
		single_column: true
	});
}