# Copyright (c) 2025, Abbey and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document

class fix_numbers(Document):
	pass
