// Copyright (c) 2025, Abbey and contributors
// For license information, please see license.txt

frappe.ui.form.on('Security_deposit', {
	// refresh: function(frm) {

	// }
});
