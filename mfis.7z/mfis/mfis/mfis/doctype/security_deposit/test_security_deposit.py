# Copyright (c) 2025, Abbey and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestSecurity_deposit(FrappeTestCase):
	pass
