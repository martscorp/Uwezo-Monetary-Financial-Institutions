frappe.ui.form.on('Joint Accounts', {
    refresh: function(frm) {

   // Add a custom button to calculate the total amount if not already added
   if (!frm.custom_buttons || !frm.custom_buttons['Generate Total']) {
    frm.add_custom_button(__('Generate Joint Account Name'), function() {
        calculate_total_amount(frm);
    });
}

        if (frm.doc.first_name !== '') {
                   
            frm.add_custom_button('Create New Savings Account', () => {
                frappe.new_doc("Savings Account",
                    {
                        "client_type": "Joint Accounts",
                        "client": frm.doc.name,
                    })
            }, 'Open Savings Account')
                   }else{


        frm.cscript.signing_mandate = function(doc) {
         
            var signing_mandate = doc.signing_mandate;
            if(signing_mandate=="Others Please Specify"){
                frm.toggle_display("sgnams", true);
            }else{
                frm.toggle_display("sgnams", false);
            }
            

        }

        // Set query filter for the client_type field
        frm.set_query("client_type", function () {
            return {
                "filters": [
                    ["name", "IN", ['Client', 'Joint Accounts', 'Guarantors_', 'Account Agent']]
                ]
            };
        });

        if (frm.doc.first_name ) {
            $('.primary-action').show();
        }else{
            $('.primary-action').hide();
            if (frm.doc.joint_account_members && frm.doc.joint_account_members.length > 0) {
                // Access the first row and set the value of the 'charge' column
              
                // Refresh the field to reflect the change
                frm.doc.joint_account_members[0].transaction_message  = 1

                frm.refresh_field('joint_account_members');
            }
        }

        // Hide the primary action button initially
       

     

        // Add a custom button to generate a signing mandate
     


            // Check if there are rows in the table

                   }


            
        
    },
    onload: function(frm) {
        var current_user = frappe.session.user;
        
        frappe.db.get_value('Employee', { 'user': current_user }, 'branch')
            .then(r => {
                if (r.message && r.message.branch) {
                    let user_branch = r.message.branch;
    
                    frm.set_value('branch', user_branch);
                    frm.set_df_property('branch', 'read_only', 1);
    
                    // Set filters for normal link fields
                    ['staff_id', 'accountagent'].forEach(field => {
                        frm.set_query(field, () => ({ filters: { 'branch': user_branch } }));
                    });
    
                    // Handle dynamic link (client) inside joint_account_members table
                    frm.fields_dict['joint_account_members'].grid.get_field('client').get_query = function(doc, cdt, cdn) {
                        let row = locals[cdt][cdn];  // Get the current row
                        if (!row.cltype) {
                            frappe.msgprint(__('Please select Cltype first.'));
                            return { filters: {} };
                        }
                        return {
                            doctype: row.cltype,  // Dynamic doctype from cltype
                            filters: { 'branch': user_branch }
                        };
                    };
                }
            });
    }
    
    
});

// Function to calculate the total amount and concatenate client names
function calculate_total_amount(frm) {
    let concatenated_names = '';

    // Function to process API response and concatenate names
    function process_api_response(data) {
        if (data && data.length) {
            data.forEach((transaction, index) => {
                if (index > 0) {
                    concatenated_names += ',';
                }
                concatenated_names += transaction.first_name + " ";
            });
        } else {
            console.error('Empty response data.');
        }
    }

    // Get the first three entries from joint_account_members
    const joint_account_members = frm.doc.joint_account_members.slice(0, 3);
    let ajax_calls = [];

    joint_account_members.forEach(function(row) {
        let ajax_call = $.ajax({
            url: `${window.location.origin}/api/method/mfis.clients.search_client_api_name?keyword=${row.client}`,
            type: 'GET',
            dataType: 'json'
        }).done(function(response) {
            process_api_response(response.message);
        }).fail(function(xhr, status, error) {
            console.error('Error fetching data:', error);
        });

        ajax_calls.push(ajax_call);
    });

    // Once all AJAX calls are complete
    $.when.apply($, ajax_calls).then(function() {
        if (concatenated_names.length > 0) {
            // Show the primary action button
            $('.primary-action').show();

            // Limit the length of concatenated_names to 30 characters
            let truncated_names = concatenated_names.substring(0, 27);

            // Add ellipsis if the original string is longer than the truncated version
            if (concatenated_names.length > truncated_names.length) {
                truncated_names += '...';
            }

           frm.fields_dict.first_name.$input.focus();
            // Set the truncated names to the 'first_name' field (or another appropriate field)
            frm.set_value('first_name', truncated_names);
            frm.set_value('full_name', truncated_names);
        } else {
            frappe.msgprint(__('No Clients Selected to generate Joint account Name'));
        }
    });
}

// Function to generate a signing mandate
function generate_signing_mandate(frm) {
    // Get the truncated names from the form
    let truncated_names = frm.doc.first_name;

    if (truncated_names) {
        frappe.call({
            method: `mfis.clients.generate_signing_mandate`, // Update this path
            args: {
                truncated_names: truncated_names
            },
            callback: function(response) {
                if (response.message) {
                    // Show the generated mandate (customize as needed)
                    frappe.msgprint(response.message);
                } else {
                    frappe.msgprint(__('Failed to generate signing mandate.'));
                }
            }
        });
    } else {
        frappe.msgprint(__('No names available to generate signing mandate.'));
    }
}
