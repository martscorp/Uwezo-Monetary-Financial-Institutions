from frappe.model.document import Document
import random

import frappe
import requests
import mfis.savings.doctype.savings_charges.savings_charges as savings_charges
import urllib.parse
from datetime import datetime
import mfis.savings.doctype.saving_transaction.saving_transaction as saving_transaction

from frappe.utils import now, get_date_str, today, cint, getdate

from frappe.query_builder.functions import _sum
class JointAccounts(Document):

	def after_insert(self):
		clients_array = []
		joint_accounts = frappe.get_all('Joint Accounts', filters={'name': self.name}, fields=['name'])

		# Initializing a list to hold all mobile numbers
		mobile_numbers = []

		# Fetching members of joint accounts
		for joint_account in joint_accounts:
			members = frappe.get_all(
				'Joint Account Members',
				filters={'parent': joint_account['name'], 'transaction_message': 1},
				fields=['cltype', 'client']  # Fetching both clienttype and client
			)

			# Collecting member details
			for member in members:
				clienttype = member['cltype']
				client = member['client']

				# Fetching the mobile number of the member
				phone_number = get_phone_number(clienttype, "mobile", filters={"name": client})

				# If a mobile number is found, add it to the list
				if phone_number:
					mobile_numbers.append(phone_number)

		# Concatenating the mobile numbers with a comma separator if more than one number exists
		if len(mobile_numbers) == 1:
			numberscollected = mobile_numbers[0]  # No comma needed if only one number
		else:
			numberscollected = ",".join(mobile_numbers)

	
		self.mobile = numberscollected
		self.save()


def get_phone_number(table, column, filters):
    query = f"SELECT {column} FROM `tab{table}` WHERE name = %s"
    result = frappe.db.sql(query, filters['name'], as_dict=True)
    if result and result[0].get(column):
        return result[0][column]
    else:
        frappe.throw(f"Client with name {filters['name']} not found")