// Copyright (c) 2024, Abbey and contributors
// For license information, please see license.txt

frappe.ui.form.on('Group Account', {
    refresh: function(frm) {

        frm.add_custom_button('Generate Account Numbers', function() {
            console.log('Button clicked'); // Debugging log
            // Call the function to assign random account numbers
            frm.set_value("full_name", frm.doc.first_name);
            frm.events.assign_account_numbers(frm);
        });

        if (frm.doc.first_name !== '') {
                   
            frm.add_custom_button('Create New Savings Account', () => {
                frappe.new_doc("Savings Account",
                    {
                        "client_type": "Group Account",
                        "client": frm.doc.name,
                    })
            }, 'Open Savings Account')
                   }else{

   // Add custom button to generate account numbers


// Debugging log to confirm button is added
console.log('Custom button added');

                   }

    

     
    },

    onload: function(frm) {


        if (frm.doc.first_name == '') {

        frm.events.autopopulate_child_table(frm);

        // Check if there are rows in the joint_account_members table
        if (frm.doc.joint_account_members && frm.doc.joint_account_members.length > 0) {
            // Access the first row and set the value of the 'charge' and 'transaction_message' columns
           
            frm.doc.joint_account_members[0].transaction_message = 1;

            // Refresh the field to reflect the changes
            frm.refresh_field('joint_account_members');
        }}



        var current_user = frappe.session.user;
        
        frappe.db.get_value('Employee', { 'user': current_user }, 'branch')
            .then(r => {
                if (r.message && r.message.branch) {
                    let user_branch = r.message.branch;
    
                    frm.set_value('branch', user_branch);
                    frm.set_df_property('branch', 'read_only', 1);
    
                    // Set filters for normal link fields
                    ['staff_id', 'accountagent'].forEach(field => {
                        frm.set_query(field, () => ({ filters: { 'branch': user_branch } }));
                    });
    
                    // Handle dynamic link (client) inside joint_account_members table
                    frm.fields_dict['joint_account_members'].grid.get_field('client').get_query = function(doc, cdt, cdn) {
                        let row = locals[cdt][cdn];  // Get the current row
                        if (!row.cltype) {
                            frappe.msgprint(__('Please select Cltype first.'));
                            return { filters: {} };
                        }
                        return {
                            doctype: row.cltype,  // Dynamic doctype from cltype
                            filters: { 'branch': user_branch }
                        };
                    };

                      // Handle dynamic link (client) inside joint_account_members table
                      frm.fields_dict['authorized_signatories'].grid.get_field('nd_signatory').get_query = function(doc, cdt, cdn) {
                        let row = locals[cdt][cdn];  // Get the current row
                      
                        return {
                            doctype: row.nd_signatory,  // Dynamic doctype from cltype
                            filters: { 'branch': user_branch }
                        };
                    };

                }
            });
            
    },

    autopopulate_child_table: function(frm) {
        // Sample denominations data
        const denominations = [
            "Name",
            "Designation",
            "Date Of Birth",
            "Nationality",
            "P.O.Box",
            "Mobile Phone",
            "Telephone",
            "Email",
            "Work-Stations",
            "Employer",
            "Address Residence",
            "Other Bankers",
            "Occupation"
        ];

        if (denominations.length > 0) {
            // Clear existing rows in the authorized_signatories table
            frm.clear_table('authorized_signatories');
            // Add rows to the child table
            denominations.forEach(function(denomination) {
                let row = frappe.model.add_child(frm.doc, 'authorized_signatories');
                row.position = denomination; // Set the position field to the denomination value
                // Initialize other fields as needed
            });
            // Refresh the form to reflect changes
            frm.refresh_field('authorized_signatories');
            console.log('Denominations inserted'); // Debugging log
        }
    },

    assign_account_numbers: function(frm) {
        // Check if there are rows in the joint_account_members table
        if (frm.doc.joint_account_members && frm.doc.joint_account_members.length > 0) {
            var cc = 0;
            // Assign random account numbers to each row in the joint_account_members table
            frm.doc.joint_account_members.forEach(function(member) {
                $.ajax({
                    url: `${window.location.origin}/api/method/mfis.clients.change_officer3?staff_id=${member.cltype}&account=${member.client}`,
                    type: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        var data = response.message;
                        member.client_name =  data;
                    },
                    error: function(xhr, status, error) {
                        console.error('Error fetching data:', error);
                    }
                });
cc+=1;
if(cc==1){
    member.accountsn = 14;
}else{
    member.accountsn  = 13;
}
                member.accountsn = generateRandomAccountNumber()+"-0"+cc;
            });
            // Refresh the field to reflect the changes
            frm.refresh_field('joint_account_members');
        }
    }
});

// Utility function to generate a random account number in the format Ac120002
function generateRandomAccountNumber() {
    const prefix = "Ac";
    const randomNumber = Math.floor(1000000 + Math.random() * 9000000); // Generates a 6-digit random number
    return prefix + randomNumber.toString();
}
