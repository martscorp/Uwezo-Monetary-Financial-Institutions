import frappe
from frappe.utils import cint, add_to_date, today
from mfis import get_default_cost_center
from mfis.import_transactions import clean_transactions


def get_import_settings():
    allow_import = frappe.db.get_single_value("Savings Settings", "allow_import")

    return cint(allow_import)


def delete_loans():
    frappe.db.delete("Loan")
    frappe.db.delete("Loan Transaction")
    frappe.db.delete("Loan Repayment")
    frappe.db.delete("Loan Disbursement")


def create(existing_loans=None):
    from mfis.data_import import create_connection, get_company
    allow_import = get_import_settings()

    if allow_import == 0:
        return

    if existing_loans is None:
        existing_loans = []
        old_loans = frappe.get_list("Loan", filters={
            "external_id": ["!=", None]
        },
                                    fields=["external_id"])

        if len(old_loans):
            for loan in old_loans:
                if loan.external_id:
                    existing_loans.append(loan.external_id)

    connection = create_connection()
    company = get_company()

    sql_query = """
    SELECT loan.id as external_id, loan.loan_type_id as loan_product, loan_type.code as type_code, loan.loan_type_name as product_name,
    loan.company_id as branch, loan.borrower_id as client, loan.borrower_account as client_account, 
    loan.borrower_name as client_name, loan.disbursed_on as expected_disbursement_date, loan.loan_term as loan_term,
    loan.amount_borrowed as principal, loan.interest_rate as interest_rate, loan.loan_ref as external_number
    FROM fgy_loans as loan
    LEFT JOIN fgy_loan_types as loan_type on loan_type.id = loan.loan_type_id
    WHERE loan.is_disbursed = 1
    and loan.status in ('unpaid', 'partial')
    # and loan.loan_type_id not in (12)
    """

    if len(existing_loans):
        result_string = '(' + ', '.join(existing_loans) + ')'
        sql_query += f" and loan.id not in {result_string}"

    sql_query += """
                ORDER BY
                loan.created_at DESC
                LIMIT 1"""

    mycursor = connection.cursor(dictionary=True)

    mycursor.execute(sql_query)

    data = mycursor.fetchall()

    frappe.cache().set_value("loans", data)

    loans = frappe.cache().get_value("loans")

    branches = {
        1: "10",
        2: "20",
    }

    if len(loans):
        for loan in loans:
            print(f"{loan['loan_product']} {loan['product_name']}")

            loan["applied_amount"] = loan["principal"]

            loan["expected_first_payment"] = add_to_date(loan["expected_disbursement_date"], days=1)

            # loan["loan_product"] = clean_transactions(loan.get("loan_product"), loan_products)
            loan_product = frappe.db.get_value("Loan Product", {"code": int(loan["type_code"])})

            # if loan["loan_product"] is None:
            #     existing_loans.append(str(loan["external_id"]))
            #     continue
            #
            # loan["loan_product"] = frappe.db.get_value("Loan Product", {"product_name": str(loan["loan_product"])},
            #                                            "name")

            if loan_product is None:
                continue

            loan["loan_product"] = loan_product
            loan["company"] = company

            if loan["loan_product"] is None:
                existing_loans.append(str(loan["external_id"]))
                continue

            loan["branch"] = clean_transactions(loan.get("branch"), branches)

            if loan["client_account"]:
                if not frappe.db.exists("Savings Account", loan["client_account"]):
                    loan["client_account"] = frappe.db.get_value("Savings Account", {"client": loan["client"]}, "name")

                    if loan["client_account"] is None:
                        existing_loans.append(str(loan["external_id"]))
                        print(f"client account missing {loan['client_account']} - {loan['client']}")
                        continue

            loan["doctype"] = "Loan"
            loan["is_import"] = 1
            loan["auto_disburse"] = 1

            try:
                new_loan = frappe.get_doc(loan)
                new_loan.insert(ignore_permissions=True, ignore_if_duplicate=True, ignore_links=True)
                new_loan.submit()
                frappe.db.commit()
                # import_transactions(loan=new_loan.name)
            except Exception as e:
                frappe.log_error(title="Loan import error", message=frappe.get_traceback())
                continue

            existing_loans.append(str(loan["external_id"]))

        try:
            frappe.db.commit()
        except Exception as e:
            frappe.log_error(title="Loan import error", message=frappe.get_traceback())

        frappe.cache().set_value("loans", [])
        create(existing_loans)


def get_loan_products():
    from mfis.data_import import create_connection, get_company
    connection = create_connection()

    sql_query = """
    SELECT id, name
    FROM fgy_loan_types
    where deleted_at is null
    """

    mycursor = connection.cursor(dictionary=True)

    mycursor.execute(sql_query)

    data = mycursor.fetchall()

    if len(data):
        for row in data:
            print(row)

    connection.close()


def import_loan_transactions():
    allow_import = get_import_settings()

    if allow_import == 0:
        return

    loans = frappe.db.get_all("Loan", fields=['name'], order_by="expected_disbursement_date")

    for loan in loans:
        import_transactions(loan=loan.name)


@frappe.whitelist()
def import_transactions(existing_transactions=None, loan=None):
    from mfis.data_import import create_connection, get_company
    allow_import = get_import_settings()

    if allow_import == 0:
        return
    if existing_transactions is None:
        existing_transactions = []
        old_trasactions = frappe.get_list("Loan Repayment", filters={
            "external_id": ["!=", None]
        },
                                          fields=["external_id"])

        if len(old_trasactions):
            for transaction in old_trasactions:
                if transaction.external_id:
                    existing_transactions.append(transaction.external_id)

    sql_query = """
    SELECT trans.id as external_id, loan.loan_ref as loan, loan.id as loan_id,
     trans.company_id as branch, trans.amount as amount, 
     trans.paid_at as created_on, trans.description as description
    FROM fgy_transactions as trans
    LEFT JOIN fgy_loans as loan on trans.account_id = loan.id
    WHERE trans.account_type_id != 1
    and loan.deleted_at is null
    and trans.deleted_at is null
    and loan.is_disbursed = 1
    and loan.status in ('unpaid', 'partial')
    and trans.type = 'deposit'
    """

    if len(existing_transactions):
        result_string = '(' + ', '.join(existing_transactions) + ')'
        sql_query += f"and trans.id not in {result_string}"

    if loan:
        sql_query += f"and loan.loan_ref = %(loan)s"

    sql_query += " LIMIT 1000"

    connection = create_connection()

    mycursor = connection.cursor(dictionary=True)

    mycursor.execute(sql_query, {"loan": loan})

    data = mycursor.fetchall()

    frappe.cache().set_value("loan_transactions", data)

    connection.close()

    data = frappe.cache().get_value("loan_transactions")

    branches = {
        1: "10",
        2: "20",
    }

    # frappe.db.delete("Loan Repayment")
    # frappe.db.delete("Loan Transaction", {"transaction_type": 11})

    if len(data):
        for row in data:
            row["branch"] = clean_transactions(row["branch"], branches)

            # row["transaction_type"] = 11
            row["is_import"] = 1
            row["payment_method"] = "Cash"
            # row["status"] = "Approved"
            # row["credit"] = row["amount"]

            if not frappe.db.exists("Loan", row["loan"]):
                loan = frappe.db.get_value("Loan", {"external_id": row["loan_id"]}, "name")

                if loan is None:
                    existing_transactions.append(row["external_id"])
                    print(f"missing loan {row['loan']} ")
                    continue

                row["loan"] = loan

            row["doctype"] = "Loan Repayment"

            try:
                new_loan = frappe.get_doc(row)
                new_loan.insert(ignore_links=True, ignore_permissions=True)

                new_loan.submit()
                frappe.db.commit()
            except Exception as e:
                frappe.log_error(title="Error importing loan transactions", message=frappe.get_traceback())
                continue
            print("___done____")
            existing_transactions.append(str(row["external_id"]))

        frappe.cache().set_value("loan_transactions", [])
        import_transactions(existing_transactions)


def test_recursive():
    sql_query = """
    WITH RECURSIVE numbers AS (
        SELECT 0 as n
        UNION 
        SELECT n + 10
        FROM numbers where n < 200
    )

    SELECT * from numbers
    """

    data = frappe.db.sql(sql_query, as_dict=True)

    print(data)


def create_opening_journals():
    # frappe.db.delete("GL Entry")
    # frappe.db.delete("Journal Entry")
    # frappe.db.delete("Journal Entry Account")
    companies = frappe.get_all("Company", fields=["name"])

    for company in companies:
        loan_products = frappe.get_all("Loan Product",
                                       filters={"company": company.name},
                                       fields=["name", "product_name"])

        branches = frappe.get_list("Branch", filters={"company": company.name},
                                   fields=["name", "default_opening_balances"])
        if len(loan_products):
            for product in loan_products:
                for branch in branches:
                    sql_query = """
                    SELECT 
                        COALESCE(SUM(loan.principal_disbursed_derived), 0) AS total_principal, 
                        COALESCE(SUM(loan.interest_disbursed), 0) AS total_interest_disbursed
                    FROM 
                        tabLoan as loan
                    WHERE 
                        loan_product = %(loan_product)s
                        and loan.branch  = %(branch)s
                    """

                    results = frappe.db.sql(sql_query,
                                            {"loan_product": product.name, "branch": branch.name},
                                            as_dict=True)

                    if float(results[0].total_interest_disbursed) == 0 or float(results[0].total_principal) == 0:
                        continue

                    make_jv(branch, company, product, results)


def make_jv(branch, company, loan_product, results):
    journal_entry = frappe.new_doc("Journal Entry")
    journal_entry.title = f"{loan_product.product_name} Opening Entry Loans"
    journal_entry.voucher_type = "Journal Entry"
    journal_entry.branch = branch.name
    journal_entry.company = company.name
    journal_entry.posting_date = today()

    # cost_center = get_default_cost_center(branch=branch)

    cost_center = frappe.get_cached_value("Branch", branch.name, "cost_center")

    product_accounts = frappe.db.get_value("Loan Product Accounts",
                                           {"parent": loan_product.name, "branch": branch.name},
                                           ["interest_outstanding", "income_from_interest",
                                            "principal_outstanding", "loan_account"], as_dict=True)

    if product_accounts is None:
        return

    if product_accounts:
        interest_outstanding_acc = product_accounts.get("interest_outstanding")
        income_from_interest_acc = product_accounts.get("income_from_interest")
        principal_outstanding_acc = product_accounts.get("principal_outstanding")
        loan_account = product_accounts.get("loan_account")

        print(f"Interest outstanding: {product_accounts} \n")

        if interest_outstanding_acc and income_from_interest_acc and principal_outstanding_acc and loan_account:
            # journal_entry.append("accounts", {
            #     "account": interest_outstanding_acc,
            #     "debit": results[0].total_interest_disbursed,
            #     "debit_in_account_currency": results[0].total_interest_disbursed,
            #     "cost_center": cost_center,
            #     "against_account": income_from_interest_acc
            # })
            #
            # journal_entry.append("accounts", {
            #     "account": income_from_interest_acc,
            #     "credit": results[0].total_interest_disbursed,
            #     "credit_in_account_currency": results[0].total_interest_disbursed,
            #     "cost_center": cost_center,
            #     "against_account": interest_outstanding_acc
            # })

            journal_entry.append("accounts", {
                "account": principal_outstanding_acc,
                "debit": results[0].total_principal,
                "debit_in_account_currency": results[0].total_principal,
                "cost_center": cost_center,
                "against_account": branch.get('default_opening_balances')
            })

            journal_entry.append("accounts", {
                "account": branch.get('default_opening_balances'),
                "credit": results[0].total_principal,
                "credit_in_account_currency": results[0].total_principal,
                "cost_center": cost_center,
                "against_account": principal_outstanding_acc
            })

            # journal_entry.append("accounts", {
            #     "account": branch.get('default_opening_balances'),
            #     "credit": results[0].total_principal,
            #     "credit_in_account_currency": results[0].total_principal,
            #     "cost_center": cost_center,
            #     "against_account": loan_account
            # })
            #
            # journal_entry.append("accounts", {
            #     "account": loan_account,
            #     "debit": results[0].total_principal,
            #     "debit_in_account_currency": results[0].total_principal,
            #     "cost_center": cost_center,
            #     "against_account": branch.get('default_opening_balances')
            # })

            journal_entry.insert(ignore_permissions=True)
            journal_entry.submit()
            frappe.db.commit()
        else:
            frappe.log_error("Accounts not found", f"Branch: {branch} product: {loan_product}")


def create_payments_transactions():
    allow_import = get_import_settings()

    if allow_import == 0:
        return
    companies = frappe.get_all("Company", fields=["name"])

    for company in companies:
        loan_products = frappe.get_all("Loan Product",
                                       filters={"company": company.name},
                                       fields=["name", "product_name"])

        branches = frappe.get_list("Branch", filters={"company": company.name},
                                   fields=["name", "default_opening_balances"])
        if len(loan_products):
            for product in loan_products:
                for branch in branches:
                    sql_query = """
                    SELECT COALESCE(SUM(transactions.interest_repaid_derived + transactions.interest_recovered), 0) as interest,
                    COALESCE(SUM(transactions.principal_repaid_derived + transactions.principal_recovered), 0) as principal
                    FROM `tabLoan Transaction` as transactions
                    LEFT JOIN `tabLoan` as loan on loan.name = transactions.loan
                    WHERE loan.loan_product = %(loan_product)s
                    and loan.branch  = %(branch)s
                    """

                    results = frappe.db.sql(sql_query, {"loan_product": product.name, "branch": branch.name},
                                            as_dict=True)

                    if results[0].interest == 0 or results[0].principal == 0:
                        continue

                    print(results)
                    create_payments_jv(branch, company, product, results)


def create_payments_jv(branch, company, product, results):
    journal_entry = frappe.new_doc("Journal Entry")
    journal_entry.title = f"Loan repayments {product.product_name} Opening Journal"
    journal_entry.voucher_type = "Journal Entry"
    journal_entry.branch = branch.name
    journal_entry.company = company.name
    journal_entry.posting_date = today()

    cost_center = frappe.get_cached_value("Branch", branch.name, "cost_center")

    product_accounts = frappe.db.get_value("Loan Product Accounts",
                                           {"parent": product.name, "branch": branch.name},
                                           ["interest_outstanding", "principal_outstanding", "income_from_interest"],
                                           as_dict=True)

    if product_accounts is None:
        return

    if product_accounts:
        interest_outstanding_acc = product_accounts.get("income_from_interest")
        principal_outstanding_acc = product_accounts.get("principal_outstanding")

        if interest_outstanding_acc and principal_outstanding_acc:
            journal_entry.append("accounts", {
                "account": interest_outstanding_acc,
                "credit": results[0].interest,
                "credit_in_account_currency": results[0].interest,
                "cost_center": cost_center,
                "against_account": branch.get('default_opening_balances')
            })

            journal_entry.append("accounts", {
                "account": principal_outstanding_acc,
                "credit": results[0].principal,
                "credit_in_account_currency": results[0].principal,
                "cost_center": cost_center,
                "against_account": branch.get('default_opening_balances')
            })

            journal_entry.append("accounts", {
                "account": branch.get('default_opening_balances'),
                "debit": results[0].principal,
                "debit_in_account_currency": results[0].principal,
                "cost_center": cost_center,
            })

            journal_entry.append("accounts", {
                "account": branch.get('default_opening_balances'),
                "debit": results[0].interest,
                "debit_in_account_currency": results[0].interest,
                "cost_center": cost_center,
            })

            journal_entry.insert(ignore_permissions=True)
            journal_entry.submit()
        else:
            frappe.log_error("Accounts not found", f"Branch: {branch.name} product: {product.product_name}")
