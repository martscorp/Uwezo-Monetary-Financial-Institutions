import frappe

@frappe.whitelist(allow_guest=True)
def list():
    branches = []

    data = frappe.db.get_list("Branch", fields=["name", "branch_name"])

    if data:
        branches = data

    return branches