import frappe


@frappe.whitelist(allow_guest=True, methods=["GET"])
def salutations():
    titles = []

    query = frappe.db.get_list("Salutation",
                               fields=["name"])

    if query:
        titles = query

    return titles

@frappe.whitelist(allow_guest=True, methods=["GET"])
def countries():
    countries_results = []

    query = frappe.db.get_list("Country")

    if query:
        countries_results = query

    return countries_results\

@frappe.whitelist(allow_guest=True, methods=["GET"])
def professions():
    professions_results = []

    query = frappe.db.get_list("Professions")

    if query:
        professions_results = query

    return professions_results
