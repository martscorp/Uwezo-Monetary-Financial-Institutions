import frappe
from frappe import auth


@frappe.whitelist(allow_guest=True)
def login(username, password):
    try:
        login_manager = auth.LoginManager()
        login_manager.authenticate(user=username, pwd=password)
        login_manager.post_login()
    except frappe.exceptions.AuthenticationError:
        frappe.local.response['message'] = {
            "success_key": 0,
            "message": "Invalid details"
        }

    api_secret = generate_key(username)

    user = frappe.get_doc("User", username)

    frappe.local.response["message"] = {
        "success_key": 1,
        "message": "Login success",
        "sid": frappe.session.sid,
        "api_key": user.api_key,
        "secret_key": api_secret,
        "session": frappe.session
    }


def generate_key(user):
    user_details = frappe.get_doc("User", user)

    api_secret = frappe.generate_hash(length=15)

    if not user_details.api_key:
        api_key = frappe.generate_hash(length=15)
        user_details.api_key = api_key
    else:
        api_key = user_details.api_key

    user_details.api_secret = api_secret
    user_details.flags.ignore_permissions = True
    user_details.save()

    return api_secret


@frappe.whitelist(allow_guest=True)
def get_company_details():
    # company = frappe.db.get_singles_dict("Company")

    company = frappe.get_all("Company", fields=["name", "company_name", "abbr", "default_currency", "country", "company_logo", "phone_no", "email", "website"])

    company = company[0]

    frappe.local.response["message"] = company
