import frappe

def execute(filters=None):
    
    """
    Main function to execute the report generation.
    Returns the columns, data, chart, summary, and report summary.
    """
    if not filters or not hasattr(filters, 'account'):
        frappe.throw(_("Account filter is mandatory"))

    columns = get_columns()
    data = get_data(filters)
    report_summary = get_report_summary(data)

    return columns, data, None, None, report_summary
     
def get_data(filters=None):
    """
    Fetch transaction data from the database, categorize transactions,
    and calculate running balances.
    """
    conditions, query_filters = build_conditions(filters)

    query = f"""
    SELECT 
        t1.creation AS posting_date, 
        t1.description,
        t1.amount,
        t2.suba,
        t1.transaction_type_name,
        t1.name AS transaction_id
    FROM `tabSaving Transaction` t1
    LEFT JOIN `tabDeposit` t2 ON t2.name = t1.deposit
    WHERE t1.account = %(account)s
      AND t1.flagged = 0
      {conditions}
    ORDER BY t1.creation
    """

    transactions = frappe.db.sql(query, query_filters, as_dict=True)

    if not transactions:
        return []

    # Process transactions
    balance = 0
    total_credit = 0
    total_debit = 0

    for transaction in transactions:
        description = transaction.get("description")
        transaction_type_name = transaction.get("transaction_type_name")

        if description is not None:
            description = description.lower()
        else:
            description = ""
        amount = transaction.get("amount", 0)


            # frappe.throw(str(transaction_type_name))

        # Ensure correct amount for "account opening"
        if "account opening" == description:
            balance +=0  
            amount = abs(amount) 

            # Classify transaction
            classification = classify_transaction(description, amount)
            transaction.update(classification)

            # Update totals
            total_credit += classification["credit"]
            total_debit += classification["debit"]

            # Compute running balance
           
            transaction["balance"] = balance

        elif "account opening2" == description:
            balance -= abs(amount)  
            amount = abs(amount) 

            # Classify transaction
            classification = classify_transaction(description, amount)
            transaction.update(classification)

            # Update totals
            total_credit += classification["credit"]
            total_debit += classification["debit"]

            # Compute running balance
           
            transaction["balance"] = balance

        else:
            if "security deposit" in description:
                if transaction_type_name == "deposit":
                    description = "d" + description
                    transaction["description"] = "D-" + transaction["description"]
                else:
                    description = "w" + description
                    transaction["description"] = "W-" + transaction["description"]
            # Classify transaction
            classification = classify_transaction(description, amount)
            transaction.update(classification)

            # Update totals
            total_credit += classification["credit"]
            total_debit += classification["debit"]

            # Compute running balance
            balance += classification["credit"] - classification["debit"]
            transaction["balance"] = balance 
            
            


    # Add total row
    total_row = {
        "posting_date": "Total",
        "description": None,
        "credit": total_credit,
        "debit": total_debit,
        "balance": balance,
        "transaction_id": ""
    }
    transactions.append(total_row)

    return transactions

def build_conditions(filters):
    """
    Build SQL conditions based on the filters provided.
    """
    conditions = []
    query_filters = {
        "account": filters.account,
        "account2": filters.get("account2"),
        
        "from_date": filters.get("from_date"), 
        "to_date": filters.get("to_date"),
    }

    if filters.from_date:
        conditions.append("t1.creation >= %(from_date)s")
    if filters.to_date:
        conditions.append("t1.creation <= %(to_date)s")
    if filters.account2:
        conditions.append("t2.suba = %(account2)s")

    condition_str = " AND ".join(conditions)
    if condition_str:
        condition_str = " AND " + condition_str

    return condition_str, query_filters
def classify_transaction(description, amount):
    """
    Classify a transaction based on its description and assign credit/debit values.
    """
    amount = round(amount)

    # Define classification rules (order matters: specific first, general later)
    rules = [
        ("deposit fees", {"credit": 0, "debit": amount}),  
        ("account opening3", {"credit": 0, "debit": amount}),  
        ("account opening2", {"credit": amount, "debit": 0}),  # Already made negative in get_data
        ("account opening", {"credit": amount, "debit": amount}),
        ("opening balance", {"credit": amount, "debit": 0}),
        ("monthly ", {"credit": 0, "debit": amount}),
        ("withdraw", {"credit": 0, "debit": amount}),
        ("withdraw fees", {"credit": 0, "debit": amount}),
        ("withdraw penalty", {"credit": 0, "debit": amount}),
        ("transfer from", {"credit": amount, "debit": 0}),
        ("transfer to", {"credit": 0, "debit": amount}),
     
        ("cash collateral", {"credit": 0, "debit": amount}),
        ("charge", {"credit": 0, "debit": amount}),
        ("loan security", {"credit": amount, "debit": 0}),
        ("loan closure", {"credit": 0, "debit": amount}),
        ("to sacco contribution", {"credit": amount, "debit": 0}),
        ("sacco contribution", {"credit": 0, "debit": amount}),
        ("dsecurity", {"credit": amount, "debit": 0}),
        ("wsecurity", {"credit": 0, "debit": amount}),
        ("security", {"credit": 0, "debit": amount}),
        ("approval", {"credit": 0, "debit": amount}),
        ("fees payment", {"credit": 0, "debit": amount}),
        ("disbursement", {"credit": amount, "debit": 0}),
        ("loan application fee", {"credit": 0, "debit": amount}),
        ("loan charge ", {"credit": 0, "debit": amount}),
        ("loan insurance", {"credit": 0, "debit": amount}),
        ("refund of loan insurance", {"credit": amount, "debit": 0}),
        ("loan repayment", {"credit": 0, "debit": amount}),
        ("deposit", {"credit": amount, "debit": 0}),
        ("reconciliation", {"credit": 0, "debit": amount}),  # General rule for "deposit"
    ]

    # Match the description against rules
    for keyword, result in rules:
        if keyword in description:
            return result

    # Default classification (credit if amount > 0, otherwise debit)
    return {"credit": max(amount, 0), "debit": max(-amount, 0)}

def get_columns():
    """
    Define the columns for the report.
    """
    return [
    {"fieldname": "posting_date", "fieldtype": "Datetime", "label": "Date", "width": 100},
    {"fieldname": "transaction_id", "label": "Transaction ID", "fieldtype": "Data", "width": 150},
    {"fieldname": "description", "fieldtype": "Data", "label": "Description", "width": 150},
    {"fieldname": "debit", "label": "Debit", "fieldtype": "Float", "width": 200},
    {"fieldname": "credit", "label": "Credit", "fieldtype": "Float", "width": 200},
    {"fieldname": "balance", "label": "Balance", "fieldtype": "Float", "width": 200},
    ]


def get_report_summary(data):
    """
    Generate the report summary with total credit and debit values.
    """
    total_credit = sum(row.get("credit", 0) for row in data if row.get("posting_date") != "Total")
    total_debit = sum(row.get("debit", 0) for row in data if row.get("posting_date") != "Total")
    return [
        {
            "value": total_credit,
            "indicator": "Green",
            "label": "Total Credit",
            "datatype": "Currency",
            "currency": "UGX"
        },
        {
            "value": total_debit,
            "indicator": "Red",
            "label": "Total Debit",
            "datatype": "Currency",
            "currency": "UGX"
        }
    ]
