// Copyright (c) 2023, Abbey and contributors
// For license information, please see license.txt
/* eslint-disable */

frappe.query_reports["Account Statement"] = {
	"filters": [
		{
			"fieldname": "branch",
			"label": __("Branch"),
			"fieldtype": "Link",
			"options": "Branch",
			"default": frappe.defaults.get_user_default("Branch"),
			"reqd": 1
		},
		// {
		//    "fieldname": "client",
		//    "fieldtype": "MultiSelectList",
		//    "label": "Client",
		//    "reqd": 1,
		//    "options": "Client",
		//    get_data: function(txt) {
		// 		return frappe.db.get_link_options('Client', txt, {
		// 			branch: frappe.query_report.get_filter_value("branch")
		// 		});
		// 	}
		// },
		{
			"fieldname": "account",
			"fieldtype": "Link",
			"label": "Account",
			"reqd": 1,
			"options": "Savings Account",
			// get_query: function(txt) {
			 // 	return frappe.db.get_link_options('Savings Account', txt, {
			 // 		client: ['in', [frappe.query_report.get_filter_value("client")]]
			 // 	});
			 // }
		   }
		   ,{
		   "fieldname": "account2",
		   "fieldtype": "Link",
		   "label": "Sub-Account",
		   "reqd": 0,
		    "options": "Group Account Members",
		//    get_query: function(txt) {
		// 		return frappe.db.get_link_options('Savings Account', txt, {
		// 			client: ['in', [frappe.query_report.get_filter_value("client")]]
		// 		});
		// 	}
	  	},
		{
			"fieldname":"from_date",
			"label": __("From Date"),
			"fieldtype": "Datetime",
			"default": frappe.datetime.add_months(frappe.datetime.get_today(), -12),
			"reqd": 1,
			"width": "60px"
		},
		{
			"fieldname":"to_date",
			"label": __("To Date"),
			"fieldtype": "Datetime",
			"default": frappe.datetime.get_today(),
			"reqd": 1,
			"width": "60px"
		}
	],
	onload: function (report){
		const views_menu = report.page.add_custom_button_group(__('Custom'));

		console.log(report.get_menu_items())
		report.page.add_action_item("Print New", function (){
			var filters = report.get_values();

			var data = report.data

			console.log(data)
		})

		report.page.add_custom_menu_item(views_menu, __("Print"), function() {
			var filters = report.get_values();

			var data = report.data

			console.log(data)
			// frappe.set_route('query-report', 'Balance Sheet', {branch: filters.company});
		});
	}
};


// cur_frm.fields_dict['client'].get_query = function(doc) {
// 	return {
// 		filters: {
// 			branch: frappe.query_report.get_filter_value("branch")
// 		}
// 	}
// }

