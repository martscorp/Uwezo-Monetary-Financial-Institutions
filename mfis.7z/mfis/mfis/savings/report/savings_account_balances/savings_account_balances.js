// Copyright (c) 2023, Abbey and contributors
// For license information, please see license.txt
/* eslint-disable */

frappe.query_reports["Savings Account Balances"] = {
	"filters": [
		  {
		   "fieldname": "saving_product",
		   "fieldtype": "Link",
		   "label": "Product",
		   "mandatory": 0,
		   "options": "Saving Product",
		  },
		  {
		   "fieldname": "branch",
			"label": __("Branch"),
			"fieldtype": "Link",
			"options": "Branch",
			"default": frappe.defaults.get_user_default("Branch"),
		  },
		  {
		   "fieldname": "balance",
			"label": __("Balance"),
			"fieldtype": "Float",
			"default": 0,
		  },
		  {
		   "fieldname": "operations",
			"label": __("Is"),
			"fieldtype": "Select",
			"default": ">",
			"options": [">", ">=", "=", "<="],
		  },
		  // {
			// "fieldname":"from_date",
			// "label": __("From Date"),
			// "fieldtype": "Date",
			// "default": frappe.datetime.add_months(frappe.datetime.get_today(), -3),
			// "reqd": 1,
			// "width": "60px"
		  // },
		  // {
			// "fieldname":"to_date",
			// "label": __("To Date"),
			// "fieldtype": "Date",
			// "default": frappe.datetime.get_today(),
			// "reqd": 1,
			// "width": "60px"
		  // },
	]
};
