# Copyright (c) 2023, Abbey and contributors
# For license information, please see license.txt

import frappe


def execute(filters=None):
    columns, data = [], []

    columns = get_columns()

    data, total = get_data(filters)

    summary = get_summary(total)

    return columns, data, None, None, summary


def get_data(filters):
    query_filters = {
        "branch": filters.branch,
        "saving_product": filters.saving_product,
        "balance": filters.balance,
        "operations": filters.operations
    }

    conditions = ""

    if filters.branch:
        conditions += " AND branch = %(branch)s"

    if filters.saving_product:
        conditions += " AND saving_product = %(saving_product)s"

    if filters.balance and filters.operations:
        conditions += """AND balance_derived {operation} {balance}
                        """.format(operation=filters.operations, balance=filters.balance)

    accounts = frappe.db.sql(
        """select name, client, balance_derived as balance, branch, client_name, 
        total_deposits_derived as deposit, total_withdrawals_derived as withdraw, status
        FROM 
        `tabSavings Account`
        WHERE 
            status = "Active"
            {conditions}
        GROUP BY 
            branch, client
        ORDER BY 
            branch, balance
        """.format(conditions=conditions),
        query_filters,
        as_dict=True
    )

    total = 0

    if not accounts:
        return None, total

    for account in accounts:
        total += account.get('balance')

    return accounts, total


def get_columns():
    return [
        {
            "fieldname": "branch",
            "label": "Branch",
            "fieldtype": "Link",
            "options": "Branch",
            "width": 100
        },
        {
            "fieldname": "name",
            "label": "Account",
            "fieldtype": "Link",
            "options": "Savings Account",
            "width": 100
        },
        {
            "fieldname": "client",
            "label": "Client",
            "fieldtype": "Link",
            "options": "Client",
            "width": 100
        },
        {
            "fieldname": "client_name",
            "label": "Client Name",
            "fieldtype": "Data",
            "width": 100
        },
        {
            "fieldname": "currency",
            "label": "Currency",
            "fieldtype": "Link",
            "options": "Currency",
            "hidden": 1,
        },
        {
            "fieldname": "deposit",
            "label": "Deposits",
            "fieldtype": "Currency",
            "options": "currency",
            "width": 150,
        },
        {
            "fieldname": "withdraw",
            "label": "Withdraw",
            "fieldtype": "Currency",
            "options": "currency",
            "width": 150,
        },
        {
            "fieldname": "balance",
            "label": "Balance",
            "fieldtype": "Currency",
            "options": "currency",
            "width": 150,
        },
    ]


def get_summary(total=0):
    return [{
        "value": total,
        "indicator": "Green",
        "label": "Total Balance",
        "datatype": "Currency",
        "currency": "UGX"
    }]
