# Copyright (c) 2024, Abbey and contributors
# For license information, please see license.txt

import frappe
from frappe.utils import cint


def execute(filters=None):

    columns = get_columns()
    data = get_data(filters)

    return columns, data


def get_columns():
    return [
        {
            "fieldname": "client_name",
            "fieldtype": "Data",
            "label": "Client",
            "width": 150
        },
        {
            "fieldname": "account",
            "fieldtype": "Link",
            "label": "Account",
            "options": "Savings Account",
            "width": 150
        },
        {
            "fieldname": "agent",
            "fieldtype": "Data",
            "label": "Agent",
            "width": 200
        },
        {
            "fieldname": "balance",
            "fieldtype": "Currency",
            "label": "Balance",
            "width": 150
        },
        {
            "fieldname": "active_loans",
            "fieldtype": "Int",
            "label": "Active Loans",
            "width": 150
        },
        {
            "fieldname": "last_transaction",
            "fieldtype": "Data",
            "label": "Last Transacted",
            "width": 150
        },
        {
            "fieldname": "currency",
            "label": "Currency",
            "fieldtype": "Link",
            "options": "Currency",
            "hidden": 1,
        },
    ]


def get_data(filters=None):
    conditions = ""

    if cint(filters.include_unassigned) == 1:
        conditions += " AND portfolio.account IS NULL"
    else:
        conditions += " AND portfolio.account IS NOT NULL"

    if filters.agent:
        conditions += " AND account.staff_id = %(agent)s"

    query_filters = {
        "branch": filters.branch,
        "agent": filters.agent,
        "include_unassigned": filters.include_unassigned
    }

    query = """
    WITH transactions as (
        SELECT account, SUM(credit - debit) as balance,     
        timestampdiff(DAY, transaction.posting_date, CURRENT_TIMESTAMP) as last_transaction
        FROM `tabSaving Transaction` as transaction
        WHERE transaction.docstatus = 1
        and transaction.is_cancelled = 0
        GROUP BY account
    ),
    loans as (
        SELECT loan.client_account, COUNT(*) as active_loans
        FROM `tabLoan Application Plus` as loan
        WHERE loan.docstatus = 1
        AND loan.status = 'Active'
        GROUP BY loan.client_account
    )
    SELECT account.name as account, account.client_name, agent.full_name as agent, COALESCE(balance, 0) as balance,
    CONCAT(last_transaction, ' days ago') as last_transaction, COALESCE(loan.active_loans, 0) as active_loans
    FROM `tabSavings Account` as account
    LEFT JOIN `tabSaving Portifolio` as portfolio on portfolio.account = account.name
    LEFT JOIN `tabEmployee` as agent on agent.name = account.staff_id
    LEFT JOIN transactions as transaction on transaction.account = account.name
    LEFT JOIN loans as loan on loan.client_account = account.name
    WHERE account.branch = %(branch)s
    {conditions}
    """.format(conditions=conditions)

    data = frappe.db.sql(query, query_filters, as_dict=1)

    print(data)
    if len(data) == 0:
        data = []

    return data
