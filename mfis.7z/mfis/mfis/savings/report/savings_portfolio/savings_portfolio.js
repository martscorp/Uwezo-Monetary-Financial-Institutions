// Copyright (c) 2024, Abbey and contributors
// For license information, please see license.txt
/* eslint-disable */

frappe.query_reports["Savings Portfolio"] = {
	"filters": [
		{
			"fieldname": "Company",
			"label": __("Company"),
			"fieldtype": "Link",
			"options": "Company",
			"default": frappe.defaults.get_user_default("Company"),
			"reqd": 1
		},
		{
			"fieldname": "branch",
			"label": __("Branch"),
			"fieldtype": "Link",
			"options": "Branch",
			"default": frappe.defaults.get_user_default("Branch"),
			"reqd": 1,
			get_query: function(txt) {
				return {
					filters: {
						"company": frappe.query_report.get_filter_value("Company")
					}
				}
			}
		},
		{
			"fieldname": "agent",
			"label": __("Agent"),
			"fieldtype": "Link",
			"options": "Employee",
			get_query: function (txt){
				return {
					// query: "mfis.controllers.queries.employee_query",
					filters: {
						"roles": ["in", ["Relationship Officer", "Sales Officer"]],
						"company": frappe.query_report.get_filter_value("Company"),
						// "branches.branch": ["in", [frappe.query_report.get_filter_value("branch")]]
					}
				}
			}
		},
		{
            "fieldname": "include_unassigned",
            "fieldtype": "Check",
            "label": "Include Unassigned",
			"default": 0
        },
	]
};
