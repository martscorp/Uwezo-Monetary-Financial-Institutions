# Copyright (c) 2023, Abbey and contributors
# For license information, please see license.txt

import frappe


def execute(filters=None):
    columns, data = [], []

    data, transactions_total = get_data(filters)

    columns = get_columns()

    report_summary = get_report_summary(transactions_total)

    return columns, data, None, None, report_summary


def get_data(filters):
    additional_conditions = ""

    if filters.savings_officer:
        additional_conditions += """ and savings_officer in (%(savings_officer)s, '') """

    if filters.transaction_type:
        additional_conditions += "and transaction_type = %(transaction_type)s"

    if filters.account:
        additional_conditions += "and account = %(account)s"

    additional_conditions += "and posting_date >= %(from_date)s"

    additional_conditions += "and posting_date <= %(to_date)s"

    query_filters = {
        "branch": filters.branch,
        "savings_officer": filters.savings_officer,
        "transaction_type": filters.transaction_type,
        "from_date": filters.from_date,
        "to_date": filters.to_date,
        "account": filters.account
    }
    # branch, savings_officer, transaction_type

    transactions = frappe.db.sql(
        """select branch,posting_date,sum(amount) as amount,sum(fees_total) as fees,savings_officer,transaction_type,transaction_type_name
                    from 
                        `tabSaving Transaction`
                    where
                        is_cancelled = 0
                        AND 
                        is_parent = 1
                        AND 
                        branch = %(branch)s
                        {additional_conditions}
                    group by 
                        account
                    order by 
                        branch, posting_date""".format(additional_conditions=additional_conditions),
        query_filters,
        as_dict=True
    )

    transactions_total = get_transactions_totals(transactions)

    if not transactions:
        return None, transactions_total

    return transactions, transactions_total


def get_transactions_totals(transactions):
    transactions_total = {
        "deposit": 0,
        "withdraw": 0,
        "fees": 0,
        "charge_trans": 0,
        "balance": 0
    }
    for transaction in transactions:
        transaction_type = transaction.get('transaction_type_name')

        if transaction_type == 'Deposit':
            transactions_total['deposit'] += transaction.get('amount', 0)
            transactions_total['balance'] += transactions_total['deposit']

        if transaction_type == 'Withdraw':
            transactions_total['withdraw'] += transaction.get('amount', 0)
            transactions_total['balance'] -= transactions_total['withdraw']

        if transaction_type not in ['Deposit', 'Withdraw']:
            transactions_total['charge_trans'] += transaction.get('charge_trans', 0)
            transactions_total['balance'] += transactions_total['charge_trans']
    return transactions_total


def get_columns():
    return [
        {
            "fieldname": "posting_date",
            "label": "Date",
            "fieldtype": "Date",
            "width": 100,
        },
        {
            "fieldname": "savings_officer",
            "label": "Officer",
            "fieldtype": "Link",
            "options": "User",
            "width": 100,
        },
        {
            "fieldname": "branch",
            "label": "Branch",
            "fieldtype": "Link",
            "options": "Branch",
            "width": 120,
        },
        {
            "fieldname": "transaction_type_name",
            "label": "Type",
            "fieldtype": "Data",
            "width": 100,
        },
        {
            "fieldname": "currency",
            "label": "Currency",
            "fieldtype": "Link",
            "options": "Currency",
            "hidden": 1,
        },
        {
            "fieldname": "amount",
            "label": "Amount",
            "fieldtype": "Currency",
            "options": "currency",
            "width": 150,
        },
        {
            "fieldname": "fees_total",
            "label": "Fees",
            "fieldtype": "Currency",
            "options": "currency",
            "width": 150,
        },

    ]


def get_report_summary(transactions_total=None):
    if transactions_total is None:
        transactions_total = {}
    return [
        {
            "value": transactions_total.get('deposit', 0),
            "indicator": "Green",
            "label": "Total Deposit",
            "datatype": "Currency",
            "currency": "UGX"
        },
        {
            "value": transactions_total.get('withdraw', 0),
            "indicator": "Red",
            "label": "Total Withdraws",
            "datatype": "Currency",
            "currency": "UGX"
        },
        {
            "value": transactions_total.get('charge_trans', 0),
            "indicator": "Green",
            "label": "Charges",
            "datatype": "Currency",
            "currency": "UGX"
        },
        {
            "value": transactions_total.get('balance', 0),
            "indicator": "Green",
            "label": "Cash",
            "datatype": "Currency",
            "currency": "UGX"
        },
    ]
