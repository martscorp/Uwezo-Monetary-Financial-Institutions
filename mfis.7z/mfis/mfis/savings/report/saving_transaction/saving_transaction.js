// Copyright (c) 2023, Abbey and contributors
// For license information, please see license.txt
/* eslint-disable */

frappe.query_reports["Saving Transaction"] = {
	"filters": [
		{
			"fieldname": "branch",
			"label": __("Branch"),
			"fieldtype": "Link",
			"options": "Branch",
			"default": frappe.defaults.get_user_default("Branch"),
			"reqd": 1
		},
		{
		   "fieldname": "savings_officer",
		   "fieldtype": "MultiSelectList",
		   "label": "Officer",
		   "options": "Employee",
			get_data: function(txt) {
				return frappe.db.get_link_options('Employee', txt, {
					branch: frappe.query_report.get_filter_value("branch")
				});
			}
		},
		{
		   "fieldname": "transaction_type",
		   "fieldtype": "Link",
		   "label": "Type",
		   "mandatory": 0,
		   "options": "Saving Transaction Type",
		   "wildcard_filter": 0
		},
		{
		   "fieldname": "account",
		   "fieldtype": "Link",
		   "label": "Account",
		   "mandatory": 0,
		   "options": "Savings Account"
		},
		{
			"fieldname":"from_date",
			"label": __("From Date"),
			"fieldtype": "Date",
			"default": frappe.datetime.add_months(frappe.datetime.get_today(), -1),
			"reqd": 1,
			"width": "60px"
		},
		{
			"fieldname":"to_date",
			"label": __("To Date"),
			"fieldtype": "Date",
			"default": frappe.datetime.get_today(),
			"reqd": 1,
			"width": "60px"
		},

	]
};
