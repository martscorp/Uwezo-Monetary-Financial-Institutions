# Copyright (c) 2023, Abbey and contributors
# For license information, please see license.txt
import frappe


# import frappe


def execute(filters=None):

	columns = get_columns()

	data = get_data(filters)

	return columns, data

def get_data(filters=None):
	conditions = ""

	if filters.savings_officer:
		conditions += """ and transactions.savings_officer in (%(savings_officer)s, '') """

	query_filters = {
		"branch": filters.branch,
		"savings_officer": filters.savings_officer,
	}

	data = frappe.db.sql("""
	SELECT transactions.account as account_number, 
	MAX(transactions.posting_date) AS last_transaction_date,
	DATEDIFF(CURDATE(), MAX(transactions.posting_date)) AS days_since_last_credit,
	transactions.client_name as account_name, 
	employee.full_name as sales_office
	FROM `tabSaving Transaction` as transactions
	LEFT JOIN `tabSavings Account` as account on account.name = transactions.account
	LEFT JOIN `tabEmployee` as employee on employee.name = transactions.savings_officer
	where transactions.credit > 0
	and transactions.account_branch = %(branch)s
	GROUP BY transactions.account
	""".format(conditions=conditions), query_filters, as_dict=True)

	if not data:
		return None

	return data

def get_columns():
	return [
		{
			"fieldname": "account_number",
			"label": "Account",
			"fieldtype": "Link",
			"options": "Savings Account",
			"width": 150,
		},
		{
			"fieldname": "account_name",
			"label": "Account Name",
			"fieldtype": "Data",
			"width": 200,
		},
		{
			"fieldname": "last_transaction_date",
			"label": "Last Date",
			"fieldtype": "Date",
			"width": 120,
		},
		{
			"fieldname": "days_since_last_credit",
			"label": "Days",
			"fieldtype": "Int",
			"width": 100,
		},

	]
