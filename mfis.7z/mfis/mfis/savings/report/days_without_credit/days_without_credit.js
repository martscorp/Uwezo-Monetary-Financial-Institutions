// Copyright (c) 2023, Abbey and contributors
// For license information, please see license.txt
/* eslint-disable */

frappe.query_reports["Days without Credit"] = {
	"filters": [
		{
			"fieldname": "branch",
			"label": __("Branch"),
			"fieldtype": "Link",
			"options": "Branch",
			"default": frappe.defaults.get_user_default("Branch"),
			"reqd": 1
		},
	]
};
