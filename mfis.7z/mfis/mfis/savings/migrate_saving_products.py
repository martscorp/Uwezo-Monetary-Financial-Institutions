import frappe
from mfis.data_import import create_connection


def execute():
    companies = frappe.get_list("Company")

    connection = create_connection()

    mycursor = connection.cursor(dictionary=True)

    sql_query = """
    SELECT * from fgy_accounts_types 
    where company_id = 1
    """
    mycursor.execute(sql_query)

    data = mycursor.fetchall()

    connection.close()

    for company in companies:
        for product in data:
            if frappe.db.exists("Saving Product", {"code": product.get("code")}):
                continue
            create_saving_product(product, company)


def create_saving_product(product, company):
    doc = frappe.new_doc("Saving Product")
    product_name = product.get('name')
    doc.product_name = str(product_name).title()
    doc.company = company.name
    short_name = frappe.utils.get_abbr(product_name, 4)
    doc.short_name = str(short_name).upper()
    doc.code = product.get("code")
    doc.description = product_name
    doc.external_number = product.get('id')
    doc.insert(ignore_links=True, ignore_mandatory=True, ignore_permissions=True, ignore_if_duplicate=True)
    frappe.db.commit()