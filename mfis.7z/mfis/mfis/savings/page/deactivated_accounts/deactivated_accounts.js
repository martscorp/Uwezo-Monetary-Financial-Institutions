frappe.pages['deactivated_accounts'].on_page_load = function(wrapper) { 
    var page = frappe.ui.make_app_page({
        parent: wrapper,
        title: 'Deactivated Savings Accounts',
        single_column: true
    });

    // Green theme header
    $(frappe.render_template(`
        <div id="savings-container" style="margin-top: 20px;">

            <!-- Company Header -->
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 15px; border-bottom: 3px solid #28a745; padding-bottom: 10px;">
                <div style="display: flex; align-items: center;">
                    <img src="/files/uwezo_logo.png" alt="Uwezo Logo" style="height: 60px; margin-right: 15px;">
                    <div>
                        <h3 style="margin: 0; color: #28a745; font-weight: 700;">UWEZO MICROFINANCE</h3>
                        <p style="margin: 0; font-size: 13px; color: #555;">Plot 12 Kampala Road, Kampala, Uganda<br>
                        Tel: +256 700 123456 | Email: info@uwezomicrofinance.com</p>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div>
                    <button id="printBtn" class="btn btn-sm btn-success" style="margin-right: 10px;">
                        <i class="fa fa-print"></i> Print
                    </button>
                    <button id="exportExcelBtn" class="btn btn-sm btn-success">
                        <i class="fa fa-file-excel"></i> Export to Excel
                    </button>
                </div>
            </div>

            <!-- Table Header -->
            <div style="background: #eaf6ea; padding: 10px 15px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 10px;">
                <h4 style="margin: 0; font-weight: 600; color: #28a745;">Deactivated Savings Accounts</h4>
                <p style="margin: 3px 0 0 0; font-size: 13px; color: #777;">List of customers with deactivated savings accounts.</p>
            </div>

            <!-- Table -->
            <div style="border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <table id="savingsTable" class="table table-bordered" style="width: 100%; font-size: 13px; border-collapse: collapse;">
                    <thead style="background: #28a745; color: white; text-align: center; white-space: nowrap;">
                        <tr>
                            <th>No</th>
                            <th>Last Served By</th>
                            <th>Customer Name</th>
                            <th>Account Number</th>
                            <th>Balance</th>
                            <th>Last Deposit Date</th>
                			<th>Contact</th>
                            <th>Account Status</th>
                        </tr>
                    </thead>
                    <tbody id="savings-table-body">
                        <tr><td colspan="9" style="text-align:center;">Loading accounts...</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    `)).appendTo(page.body);

	const today = frappe.datetime.now_date();
	const ninetyDaysAgo =  frappe.datetime.add_days(frappe.datetime.now_datetime(), -90);

    frappe.call({
        method: 'frappe.client.get_list',
        args: {
            doctype: 'Savings Account',
            fields: ['name', 'total_deposits_derived', 'client_name', 'account_number', 'balance_derived', 'overdraft_derived',  'phone_number', 'status'],
            filters: {
                overdraft_derived: ['<=', ninetyDaysAgo]
            },
			order_by: 'overdraft_derived desc',  

            limit_page_length: 0
        },
        callback: function (r) {
            const tbody = $('#savings-table-body');
            tbody.empty();

            if (!r.message || r.message.length === 0) {
                tbody.append(`<tr><td colspan="9" style="text-align:center;">No deactivated accounts found.</td></tr>`);
                return;
            }

            r.message.forEach((acc, index) => {
				if (acc.overdraft_derived){

					
 					tbody.append(`
                    <tr style="white-space: nowrap;">
                        <td style="text-align:center;">${index + 1}</td>
                        <td>${acc.total_deposits_derived || ''}</td>
                        <td style="max-width: 150px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" >${acc.client_name || ''}</td>
                        <td>${acc.name || ''}</td>
                        <td style="text-align:right;">${acc.balance_derived ? Number(acc.balance_derived).toLocaleString() : '--'}</td>
                        <td>${acc.overdraft_derived || ''}</td>
             <td style="max-width: 150px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${acc.phone_number || ''}</td>
                        <td style="font-weight:600; color:red;">${acc.status || ''}</td>
                    </tr>
                `);
				}
               
            });
        }
    });

    // Print functionality
    $(document).on('click', '#printBtn', function () {
        const tableContents = document.getElementById('savingsTable').outerHTML;
        const win = window.open('', '', 'height=800,width=1200');
        win.document.write(`
            <html>
                <head>
                    <title>Deactivated Savings Accounts - Uwezo Microfinance</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 2px; }
                        h3 { text-align: center; color: #28a745; margin-bottom: 10px; }
                        p { text-align: center; font-size: 13px; color: #555; margin-top: 0; }
                        table { width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 10px; }
                        th, td { border: 1px solid #ccc; padding: 6px; text-align: right; }
                        th { background: #28a745; color: white; text-align: center; }
                        td:first-child, th:first-child { text-align: center; }
                    </style>
                </head>
                <body>
                    <h3>UWEZO MICROFINANCE</h3>
                    <p>Deactivated Savings Accounts<br>Plot 12 Kampala Road, Kampala | Tel: +256 700 123456</p>
                    ${tableContents}
                </body>
            </html>
        `);
        win.document.close();
        win.print();
    });

    // Export to Excel
    $(document).on('click', '#exportExcelBtn', function () {
        const table = document.getElementById('savingsTable');
        let csv = [];
        for (let i = 0; i < table.rows.length; i++) {
            let row = [], cols = table.rows[i].querySelectorAll('td, th');
            for (let j = 0; j < cols.length; j++) {
                row.push('"' + cols[j].innerText.replace(/,/g, '') + '"');
            }
            csv.push(row.join(","));
        }
        downloadCSV(csv.join("\n"), 'uwezo_deactivated_savings_accounts.csv');
    });

    function downloadCSV(csv, filename) {
        let csvFile = new Blob([csv], { type: "text/csv" });
        let downloadLink = document.createElement("a");
        downloadLink.download = filename;
        downloadLink.href = window.URL.createObjectURL(csvFile);
        downloadLink.style.display = "none";
        document.body.appendChild(downloadLink);
        downloadLink.click();
    }
};
