import frappe
from frappe.desk.page.setup_wizard.setup_wizard import make_records
from mfis.data_import import create_connection


def execute():
    saving_charges = [
        {
            "charge_name": "Deposit fees",
            "amount": 200,
            "charge_time_type": "Deposit",
            "charge_calculation_type": "Flat"
        },
        {
            "charge_name": "Account Opening Fees",
            "amount": 20000,
            "charge_time_type": "Account Creation",
            "charge_calculation_type": "Flat"
        },
        {
            "charge_name": "Bank Statement Charge",
            "amount": 5000,
            "charge_time_type": "Specific Due date",
            "charge_calculation_type": "Flat"
        },
        {
            "charge_name": "Monthly Charges",
            "amount": 200,
            "charge_time_type": "Monthly",
            "charge_calculation_type": "Flat"
        },
        {
            "charge_name": "Passbook Charge",
            "amount": 35000,
            "charge_time_type": "Specific Due date",
            "charge_calculation_type": "Flat"
        },
        {
            "charge_name": "Withdraw Charges",
            "amount": 0,
            "charge_time_type": "Withdraw",
            "charge_calculation_type": "Flat"
        },
        {
            "charge_name": "Withdraw Penalty",
            "amount": 0,
            "charge_time_type": "Withdraw",
            "charge_calculation_type": "Flat"
        }
    ]

    for charge in saving_charges:
        charge_time_type = frappe.db.get_value("Charge Time Type",
                                               filters={"charge_type_name": charge.get("charge_time_type")},
                                               fieldname="name")

        if charge_time_type is None:
            continue
        charge.update({
            "doctype": "Charge",
            "charge_applies_to": "Savings",
            "active": 1,
            "charge_time_type": charge_time_type
        })

    make_records(saving_charges)


def import_loan_charge():
    charges = [
        {
            "charge_name": "Loan Application fees",
            "amount": 20000,
            "charge_time_type": "Loan Application",
            "charge_calculation_type": "Flat"
        },
        {
            "charge_name": "Security Deposit",
            "amount": 25,
            "charge_time_type": "Disbursement",
            "charge_calculation_type": "Percentage"
        },
        {
            "charge_name": "Loan Insurance",
            "amount": 1,
            "charge_time_type": "Loan Approval",
            "charge_calculation_type": "Percentage"
        },
    ]

    for charge in charges:
        charge_time_type = frappe.db.get_value("Charge Time Type",
                                               filters={"charge_type_name": charge.get("charge_time_type"),
                                                        "type": "Loan"},
                                               fieldname="name")

        if charge_time_type is None:
            continue

        charge.update({
            "doctype": "Charge",
            "charge_applies_to": "Loan",
            "active": 1,
            "charge_time_type": charge_time_type
        })

    make_records(charges)
