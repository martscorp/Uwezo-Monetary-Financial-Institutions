// Copyright (c) 2022, Abbey and contributors
// For license information, please see license.txt
frappe.provide("mfis.saving_product_accounts");
frappe.provide("mfis.saving_charge_account");

frappe.ui.form.on('Saving Product', {
	refresh: function(frm) {
        mfis.saving_product_accounts.setup_queries(frm)
        mfis.saving_charge_account.setup_queries(frm)
	},
    onload: function (frm){
        frm.set_query("interest_compounding_period_type", function (){
            return {
                "filters" : [
                    ["period_name", "IN", ['Monthly', 'Daily']]
                ]
            }
        })


        
        var current_user = frappe.session.user;
        
        frappe.db.get_value('Employee', { 'user': current_user }, 'branch')
            .then(r => {
                if (r.message && r.message.branch) {
                    let user_branch = r.message.branch;
    
                    frm.set_value('branch', user_branch);
                    frm.set_df_property('branch', 'read_only', 1);
    
                    // Set filters for normal link fields
                    ['depositfees', 'withdrawfee', 'acc', 'acc2', 'customer_balance_account', 'deposit_fees_receivable', 'monthly_fees_account'
                        , 'monthly_fees_receivable', 'penalty_charges', 'penalty_account', 'accountagent', 'accountagent', 'accountagent'
                    ].forEach(field => {
                        frm.set_query(field, () => ({ filters: { 'branch': user_branch } }));
                    });
    
                    // Handle dynamic link (client) inside joint_account_members table
                    frm.fields_dict['product_charges'].grid.get_field('charge').get_query = function(doc, cdt, cdn) {
                        let row = locals[cdt][cdn];  // Get the current row
                        row.branch = user_branch;
                        
                        return {
                            doctype: row.charge,  // Dynamic doctype from cltype
                            filters: { 'branch': user_branch }
                        };
                    };

                    frm.fields_dict['product_charges'].grid.get_field('branch').get_query = function(doc, cdt, cdn) {
                        let row = locals[cdt][cdn];  // Get the current row
                       
                        
                        return {
                            doctype: row.branch,  // Dynamic doctype from cltype
                            filters: { 'branch_code': user_branch }
                        };
                    };

                }
            });
    }
});


mfis.saving_product_accounts.setup_queries = function (frm){
    $.each([
        ["overdraw_account", {"root_type": "Asset", "account_type": "Receivable"}],
        ["portfolio_account", {"root_type": "Liability"}],
        ["inter_branch_account", {"root_type": "Asset"}],
    ], function (i, v){
        mfis.saving_product_accounts.set_custom_query(frm, v)
    })
}

mfis.saving_charge_account.setup_queries = function (frm){
    $.each([
        ["income_account", {"root_type": "Income"}],
        ["accounts_receivable", {"root_type": "Asset", "account_type": "Receivable"}],
        // ["inter_branch_account", {"root_type": "Asset"}],
    ], function (i, v){
        mfis.saving_charge_account.set_custom_query(frm, v)
    })
}

mfis.saving_charge_account.set_custom_query = function(frm, v) {
	var filters = {
		"is_group": 0
	};

	for (var key in v[1]) {
		filters[key] = v[1][key];
	}

    frm.fields_dict["product_charges"].grid.get_field(v[0]).get_query = function(doc, cdt, cdn) {
			var d = locals[cdt][cdn];

            filters["company"] = frm.doc.company
			return {
				filters: filters
			}
    }
}




mfis.saving_product_accounts.set_custom_query = function(frm, v) {
	var filters = {
		"is_group": 0
	};

	for (var key in v[1]) {
		filters[key] = v[1][key];
	}

    frm.fields_dict["branch_accounts"].grid.get_field(v[0]).get_query = function(doc, cdt, cdn) {
			var d = locals[cdt][cdn];

            filters["company"] = frm.doc.company
			return {
				filters: filters
			}
    }
}

