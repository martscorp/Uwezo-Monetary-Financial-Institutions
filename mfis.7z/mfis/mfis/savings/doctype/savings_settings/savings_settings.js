// Copyright (c) 2023, Abbey and contributors
// For license information, please see license.txt
frappe.provide("mfis.savings_settings");
frappe.ui.form.on('Savings Settings', {
	refresh: function(frm) {
        mfis.savings_settings.setup_queries(frm)
	},
});

mfis.savings_settings.setup_queries = function (frm){
    $.each([
        ["interest_expense_account", {"is_group": 0}],
        ["provision_for_interests_account", {"is_group": 0}],
    ], function (i, v){
        mfis.savings_settings.set_custom_query(frm, v)
    })
}


mfis.savings_settings.set_custom_query = function(frm, v) {
	var filters = {};

	for (var key in v[1]) {
		filters[key] = v[1][key];
	}

    frm.fields_dict["interest_accounts"].grid.get_field(v[0]).get_query = function(doc, cdt, cdn) {
			var d = locals[cdt][cdn];

            filters["branch"] = d.branch
			return {
				filters: filters
			}
    }
}


