# Copyright (c) 2023, Abbey and contributors
# For license information, please see license.txt

import os

from frappe.utils import cint, cstr, flt, getdate
from frappe.utils.csvutils import UnicodeWriter
from frappe.utils.xlsxutils import (
    read_xls_file_from_attached_file,
    read_xlsx_file_from_attached_file,
)

import csv
import json
import re

import frappe
import openpyxl
from frappe import _
from frappe.core.doctype.data_import.data_import import DataImport
from frappe.core.doctype.data_import.importer import Importer, ImportFile
from frappe.utils.background_jobs import enqueue
from frappe.utils.xlsxutils import ILLEGAL_CHARACTERS_RE, handle_html
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

INVALID_VALUES = ("", None)


class SavingTransactionImporter(DataImport):
    def __init__(self, *args, **kwargs):
        super(SavingTransactionImporter, self).__init__(*args, **kwargs)

    def start_import(self):
        preview = frappe.get_doc("Saving Transaction Importer", self.name).get_preview_from_template(
            self.import_file, self.google_sheets_url
        )

        if "Account" not in json.dumps(preview["columns"]):
            frappe.throw(_("Please add the Account column"))

        from frappe.core.page.background_jobs.background_jobs import get_info
        from frappe.utils.scheduler import is_scheduler_inactive

        if is_scheduler_inactive() and not frappe.flags.in_test:
            frappe.throw(_("Scheduler is inactive. Cannot import data."), title=_("Scheduler Inactive"))

        enqueued_jobs = [d.get("job_name") for d in get_info()]

        if self.name not in enqueued_jobs:
            enqueue(
                start_import,
                queue="default",
                timeout=6000,
                event="data_import",
                job_name=self.name,
                data_import=self.name,
                branch=self.branch,
                import_file_path=self.import_file,
                google_sheets_url=self.google_sheets_url,
                template_options=self.template_options,
                transaction_type=self.transaction_type,
                transaction_type_name=None,
                charge=None,
                now=frappe.conf.developer_mode or frappe.flags.in_test,
            )
            return True

        return False


@frappe.whitelist()
def get_preview_from_template(data_import, import_file=None, google_sheets_url=None):
    return frappe.get_doc("Saving Transaction Importer", data_import).get_preview_from_template(
        import_file, google_sheets_url
    )


@frappe.whitelist()
def form_start_import(data_import):
    return frappe.get_doc("Saving Transaction Importer", data_import).start_import()


@frappe.whitelist()
def download_errored_template(data_import_name):
    data_import = frappe.get_doc("Saving Transaction Importer", data_import_name)
    data_import.export_errored_rows()


def parse_data_from_template(raw_data):
    data = []
    account_loc = None
    for i, row in enumerate(raw_data):
        if all(v in INVALID_VALUES for v in row):
            # empty row
            continue

        if row == "Account":
            account_loc = i

        data.append(row)

    for row in data[1:]:
        if account_loc:
            account = row[account_loc]
            if frappe.db.exists("Savings Account", account) is None:
                if frappe.db.exists("Savings Account", {
                    "external_id": account
                }):
                    account = frappe.db.get_value("Savings Account", filters={
                        "external_id": account
                    }, fieldname="name")

                row[account_loc] = account

    return data


def add_other_details(data, branch, transaction_type, transaction_type_name, charge=None):
    account_loc, branch_loc, charge_loc = None, None, None
    # data[0].append("Branch")
    if charge is not None:
        data[0].append("Charge")
    if "Account" not in data[0]:
        data[0].append("Account")
    else:
        for loc, header in enumerate(data[0]):
            if header == "Account":
                account_loc = loc

    # for row in data[1:]:
    #     if account_loc:
    #         account = row[account_loc]
    #         if frappe.db.exists("Savings Account", account) is None:
    #             if frappe.db.exists("Savings Account", {
    #                 "external_id": account
    #             }):
    #                 account = frappe.db.get_value("Savings Account", filters={
    #                     "external_id": account
    #                 }, fieldname="name")
	#
    #             row[account_loc] = account


def start_import(data_import, branch, import_file_path, google_sheets_url, template_options, transaction_type=None,
                 transaction_type_name=None, charge=None):
    data_import = frappe.get_doc("Saving Transaction Importer", data_import)
    file = import_file_path if import_file_path else google_sheets_url

    import_file = ImportFile("Saving Transaction", file=file, import_type="Insert New Records")

    data = parse_data_from_template(import_file.raw_data)

    if import_file_path:
        add_other_details(data, branch, transaction_type, transaction_type_name, charge)
        write_files(import_file, data)

    try:
        i = Importer(data_import.reference_doctype, data_import=data_import)
        i.import_data()
    except Exception:
        frappe.db.rollback()
        data_import.db_set("status", "Error")
        data_import.log_error("Saving Transaction Importer failed")
    finally:
        frappe.flags.in_import = False

    frappe.publish_realtime("data_import_refresh", {"data_import": data_import.name})


def write_files(import_file, data):
    full_file_path = import_file.file_doc.get_full_path()
    parts = import_file.file_doc.get_extension()
    extension = parts[1]
    extension = extension.lstrip(".")

    if extension == "csv":
        with open(full_file_path, "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerows(data)
    elif extension == "xlsx" or "xls":
        write_xlsx(data, "trans", file_path=full_file_path)


def write_xlsx(data, sheet_name, wb=None, column_widths=None, file_path=None):
    # from xlsx utils with changes
    column_widths = column_widths or []
    if wb is None:
        wb = openpyxl.Workbook(write_only=True)

    ws = wb.create_sheet(sheet_name, 0)

    for i, column_width in enumerate(column_widths):
        if column_width:
            ws.column_dimensions[get_column_letter(i + 1)].width = column_width

    row1 = ws.row_dimensions[1]
    row1.font = Font(name="Calibri", bold=True)

    for row in data:
        clean_row = []
        for item in row:
            if isinstance(item, str) and (sheet_name not in ["Data Import Template", "Data Export"]):
                value = handle_html(item)
            else:
                value = item

            if isinstance(item, str) and next(ILLEGAL_CHARACTERS_RE.finditer(value), None):
                # Remove illegal characters from the string
                value = re.sub(ILLEGAL_CHARACTERS_RE, "", value)

            clean_row.append(value)

        ws.append(clean_row)

    wb.save(file_path)
    return True
