# Copyright (c) 2023, Abbey and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document


class SavingChargeAccounts(Document):

    def validate(self):
        self.validate_rule()

    def validate_rule(self):
        if self.is_new():
            filters = {
                "branch": self.branch,
                "product_type": self.product_type,
                "product": self.product,
                "charge": self.charge or None
            }

            if self.charge is None:
                filters.pop("charge")
                filters["loan_charge"] = self.loan_charge

            exists = frappe.db.exists("Saving Charge Accounts", filters)

            if exists:
                frappe.throw("Rule already exists")

    def on_change(self):
        create_accounting_rules(self)

# Rules adjustment
def create_accounting_rules(doc, method=None):
    default_cash_account = frappe.get_value('Branch', doc.branch, 'default_cash_account')

    if default_cash_account is None:
        frappe.throw("Please add default cash account")

    if doc.product_type == "Saving Product":
        portfolio_account = frappe.db.get_value("Saving Product Accounts", {
            "saving_product": doc.product,
            "branch": doc.branch
        }, fieldname='portfolio_account')

        if portfolio_account is None:
            portfolio_account = frappe.get_value('Branch', doc.branch, 'default_saving_portfolio_account')

        if portfolio_account is None:
            frappe.throw(f'Please enter portfolio account for saving product')

        savings_charges(doc, portfolio_account)

    if doc.product_type == "Loan Product":
        saving_products = frappe.db.get_list("Saving Product", fields=["name"])

        for saving_product in saving_products:
            portfolio_account = frappe.db.get_value("Saving Product Accounts", {
                "saving_product": saving_product.name,
                "branch": doc.branch
            }, fieldname='portfolio_account')

            if portfolio_account is None:
                portfolio_account = frappe.get_value('Branch', doc.branch, 'default_saving_portfolio_account')

            if portfolio_account is None:
                continue

            doc.flags.saving_product = saving_product.name

            savings_charges(doc, portfolio_account)


def savings_charges(doc, portfolio_account):
    if doc.income_account:
        deposit_type = frappe.db.get_value("Saving Transaction Type", {"alias_name": "apply_charge"})

        deposit_accounts = [
            {
                "account": portfolio_account,
                "entry_type": "debit",
                "is_user_account": 0
            },
            {
                "account": doc.income_account,
                "entry_type": "credit",
                "is_user_account": 0
            }
        ]
        update_or_create_rule(deposit_type, doc, deposit_accounts)
    if doc.accounts_receivable:
        withdraw_type = frappe.db.get_value("Saving Transaction Type", {"alias_name": "apply_charge"})

        withdraw_accounts = [
            {
                "account": doc.accounts_receivable,
                "entry_type": "debit",
                "is_user_account": 0
            },
            {
                "account": doc.income_account,
                "entry_type": "credit",
                "is_user_account": 0
            }
        ]

        update_or_create_rule(withdraw_type, doc, withdraw_accounts, True)


def update_or_create_rule(transaction_type, doc, deposit_accounts,
                          is_overdraft=False):
    deposit_rules = {
        "doctype": "Accounting Rule",
        "branch": doc.branch,
        "disabled": 0,
        "transaction_type_of": "Saving Transaction Type",
        "transaction_type": transaction_type,
        "is_overdraft": is_overdraft,
        "saving_charge": doc.charge or None,
        "loan_charge": doc.loan_charge or None
    }

    if doc.product_type == "Saving Product":
        deposit_rules["saving_product"] = doc.product or None

    if doc.product_type == "Loan Product":
        deposit_rules["loan_product"] = doc.product
        deposit_rules["saving_product"] = doc.flags.saving_product

    exists = frappe.db.exists(deposit_rules)

    if exists:
        deposit_rule = frappe.get_doc("Accounting Rule", exists)
        deposit_rule.accounts = []
        for acc in deposit_accounts:
            deposit_rule.append("accounts", acc)

        deposit_rule.save()

    else:
        deposit_rule = frappe.get_doc(deposit_rules)
        deposit_rule.accounts = []
        for acc in deposit_accounts:
            deposit_rule.append("accounts", acc)

        deposit_rule.save()
