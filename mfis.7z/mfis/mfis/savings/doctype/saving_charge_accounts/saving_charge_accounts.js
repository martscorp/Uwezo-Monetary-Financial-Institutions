// Copyright (c) 2023, Abbey and contributors
// For license information, please see license.txt

frappe.ui.form.on('Saving Charge Accounts', {
	refresh: function(frm) {
        frm.set_query('income_account', function(doc) {
			return {
				filters: {
					"is_group": 0,
					"branch": doc.branch,
                    "root_type": "Income",
                    "account_type": "Income Account"
				}
			};
		});
        frm.set_query('accounts_receivable', function(doc) {
			return {
				filters: {
					"is_group": 0,
					"branch": doc.branch,
                    "root_type": "Asset",
                    "account_type": "Receivable"
				}
			};
		});
		frm.set_query('charge', function(doc) {
			return {
				filters: {
                    "savings_product": doc.product
				}
			};
		});
		frm.set_query('loan_charge', function(doc) {
			return {
				filters: {
                    "loan_product": doc.product
				}
			};
		});
	}
});
