# Copyright (c) 2023, Abbey and contributors
# For license information, please see license.txt
import frappe
# import frappe
from frappe.model.document import Document


class PortfolioTransfer(Document):
    def validate(self):
        if self.portfolio_from == self.portfolio_to:
            frappe.throw("Please select different officers")

    def on_submit(self):
        update_portfolio(self)


def update_portfolio(doc):
    accounts = frappe.db.sql("""
    SELECT transfers.account
    FROM `tabAccounts Transfer` as transfers
    where transfers.parent = %(transfer)s
    """, {"transfer": doc.name}, as_dict=True)

    if accounts is None:
        frappe.throw(f'Please select accounts to transfer')

    if accounts:
        for account in accounts:
            employee = frappe.get_doc("Employee", doc.portfolio_to)

            if employee:
                employee.append("clients", {
                    "account": account.account
                })

            employee.save(ignore_permissions=True)

            frappe.db.set_value("Savings Account", account.account, "staff_id", doc.portfolio_to)

            frappe.db.delete("Saving Portifolio", {
                "parent": doc.portfolio_from,
                "parentfield": "clients",
                "parenttype": "Employee",
                "account": account.account
            })

