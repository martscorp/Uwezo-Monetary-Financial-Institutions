// Copyright (c) 2023, Abbey and contributors
// For license information, please see license.txt

frappe.ui.form.on('Portfolio Transfer', {
	refresh: function(frm) {

	},
    portfolio_from: function (frm){
        if(frm.accounts_editor){
			frm.accounts_editor.hide_editor()
		}
        let selected_attributes = {}

        var accounts_area = $("<div>").appendTo(frm.fields_dict.from_html.wrapper);

        if(!frm.accounts_editor){

            frm.accounts_editor = new frappe.AccountEditor(frm, accounts_area, frm.doc.portfolio_from, selected_attributes)
        }
        else
        {
            frm.accounts_editor.show();
        }
    }
});
