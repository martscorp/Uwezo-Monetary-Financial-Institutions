# Copyright (c) 2022, Abbey and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document
import frappe

class SavingTransactionType(Document):
	pass


def get_saving_transaction_type(transaction_type, by_alias = False):

	if by_alias is True:
		transaction_type = get_saving_transaction_type_alias(transaction_type)

	transaction_type = frappe.get_doc("Saving Transaction Type", transaction_type)

	print(transaction_type)

	return transaction_type

def get_saving_transaction_type_alias(alias = None, ignore_errors=True):
	if alias is None:
		frappe.throw("Please provide alias")

	transaction_type = frappe.db.get_value("Saving Transaction Type", {"alias_name": alias})

	return transaction_type
