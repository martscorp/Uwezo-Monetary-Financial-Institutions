// Copyright (c) 2024, Abbey and contributors
// For license information, please see license.txt

frappe.ui.form.on('Savings Cycle Repayments', {
	// refresh: function(frm) {

	// }
});
