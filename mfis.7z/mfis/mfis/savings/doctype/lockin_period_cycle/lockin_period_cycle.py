# Copyright (c) 2023, Abbey and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document
from frappe.utils import cint


class LockinPeriodCycle(Document):

    def autoname(self):
        cycles_count = frappe.db.count("Lockin Period Cycle", {
            'saving_account': self.saving_account,
            'docstatus': 1
        })

        self.name = f'{self.saving_account}-{int(cycles_count) + 1}'

    def validate(self):
        self.validate_start_date()
        self.validate_end_date()
        self.validate_duplicate()

    def validate_duplicate(self):
        cycle_exists = frappe.db.exists("Lockin Period Cycle",
                                        {'saving_account': self.saving_account, 'docstatus': 1, 'active': 1})
        if cycle_exists:
            frappe.throw("Account is already fixed")

    def validate_start_date(self):
        if self.start_date is None:
            self.start_date = frappe.utils.today()

    def validate_end_date(self):
        start_date = self.start_date

        end_date = None

        frequency_type = self.frequency_type

        frequency = int(self.frequency)

        if frequency < 0:
            frequency = abs(frequency)

        if frequency_type == 'Days':
            end_date = frappe.utils.add_days(start_date, frequency)

        if frequency_type == 'Weeks':
            days = 7 * frequency
            end_date = frappe.utils.add_days(start_date, days)

        if frequency_type == 'Months':
            end_date = frappe.utils.add_months(start_date, frequency)

        if frequency_type == 'Years':
            end_date = frappe.utils.add_years(start_date, frequency)

        self.end_date = end_date

    def on_submit(self):
        update_account(self)


def update_account(self):
    frappe.db.set_value("Savings Account", self.saving_account, 'is_fixed', 1)


def fix_account(doc, method=None):
    old_doc = doc.get_doc_before_save()

    savings_account = doc

    cycle_exists = frappe.db.exists("Lockin Period Cycle",
                                    {'saving_account': savings_account.name, 'docstatus': 1, 'active': 1})

    if cycle_exists:
        return

    else:

        if old_doc and savings_account.status == "Active" and old_doc.status in ["Pending", "Approved"]:
            frequency_type, frequency = frappe.db.get_value("Saving Product", savings_account.saving_product,
                                                            ["lockin_period_frequency_type", "lockin_period_frequency"])

            if frequency > 0:
                lockin_period_cycle = frappe.get_doc({
                    "doctype": "Lockin Period Cycle",
                    "saving_account": savings_account.name,
                    "frequency_type": frequency_type,
                    "frequency": frequency,
                    "start_date": frappe.utils.today()
                })

                lockin_period_cycle.save()
                lockin_period_cycle.submit()

                frappe.db.set_value("Savings Account", savings_account.name, "is_fixed", 1)
