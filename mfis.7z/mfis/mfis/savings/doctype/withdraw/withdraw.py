# Copyright (c) 2023, Abbey and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document
from frappe.utils import cint, flt, nowdate
from datetime import datetime
from mfis.clients import send_message_to_clients_opening,generate_savings_report_last
from mfis.savings.doctype.apply_charge.apply_charge import validate_company
from mfis.savings.doctype.saving_transaction.saving_transaction import create_withdraw_transaction
from mfis.savings.doctype.savings_account.savings_account import get_required_signatories
from mfis.savings.doctype.saving_transaction.saving_transaction import create_deposit_transaction,validate_accounting_period
from datetime import datetime, timedelta
import requests
import random 
import urllib.parse
from frappe.utils import nowdate
from frappe.utils.background_jobs import enqueue
from frappe import _  # Importing translation function


class Withdraw(Document):
    def validate(self):
        validate_company(self)

    my_var = 0


    def before_submit(self):
        savings_account = frappe.get_doc("Savings Account", self.account)
            
        # Get the current logged-in user
        current_user = frappe.session.user
        
        # Get the employee record for the current user
        employee = frappe.get_doc('Employee', {'user': current_user})

        from_date = "2019-01-01"
        to_date = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")  # tomorrow

        # Call the function and store the result
        report_last = generate_savings_report_last(account=savings_account.name, from_date=from_date, to_date=to_date, account2="NULL", ag=employee.full_name)

        # Balance:{AccountNumber}.
        # Access returned values
        last_balance = report_last["last_balance"]
        self.my_var = last_balance
        last_date = report_last["last_date"]
     

        
        # Retrieve roles from the employee record
        user_roles = employee.roles if employee else []
        
        # Get the withdrawal amount from the document
        amount = float(self.amount) if self.amount else 0
        
        # Default to not hiding the button
        hide_button = False

        # Conditions for hiding the button
        is_supervisor_or_branch_supervisor = 'Branch Supervisor' in user_roles or 'Supervisor' in user_roles 
        is_accountant = 'Assistant Accountant' in user_roles
        is_branch_manager = 'Branch Manager' in user_roles

        if amount <= 2500000 and is_supervisor_or_branch_supervisor:
            hide_button = True
        elif 2500000 > amount <= 5000000 and is_accountant:
            hide_button = True
        elif amount >= 5000000 and is_branch_manager:
            hide_button = True



    def on_submit(self):
        from mfis.clients import get_total_outstanding, close_cycle_renew
        # validate_accounting_period(self)
        create_gl_entry2(self)
        # get_total_outstanding(self.account)
        balancer=0
        try:
            savings_account = frappe.get_doc("Savings Account", self.account)
            balancer = savings_account.balance_derived
        except frappe.DoesNotExistError:
            frappe.throw(f"Savings Account '{self.account}' does not exist.")
        
      
        savings_freeze_reason = savings_account.savings_freeze_reason
        savings_freeze_amount = savings_account.savings_amount_frozen
        loan_freeze_reason = savings_account.loan_freeze_reason
        loan_freeze_amount = savings_account.frozen_amount
        
        # Adjust balance to account for frozen amounts
        adjusted_balance = balancer - (savings_freeze_amount + loan_freeze_amount)
        # if self.amount <= adjusted_balance:
        val = int(self.my_var)
        if self.amount <= val:
            create_withdraw_transaction(self)
            # get_total_outstanding(self.account)
            if savings_account.is_fixed:
                
                create_savings_transactions(self)
                close_cycle_renew(self.account)
         


            send_otp2(savings_account, self.posting_date, savings_account.client_type, self.amount, self.owner, val)
            
        else:
            frappe.db.set_value("Withdraw", self.name, "docstatus", "0")
            frappe.db.set_value("Withdraw", self.name, "status", "Reviewed")
            frappe.db.set_value("Withdraw", self.name, "workflow_state", "Reviewed")
            frappe.db.commit()
            error_message = f"""
                <p><strong>Insufficient balance on account.</strong></p>
                <p><strong>Savings Freeze Reason:</strong> <span style="color: red;">{savings_freeze_reason}</span></p>
                <p><strong>Savings Freeze Amount:</strong>{savings_freeze_amount:,}</p>
                <p><strong>Loan Freeze Reason:</strong> <span style="color: red;">{loan_freeze_reason}</span></p>
                <p><strong>Loan Freeze Amount:</strong> {loan_freeze_amount:,}</p>
                <p><strong>Total frozen:</strong> <span style="color: darkorange;">{loan_freeze_amount + savings_freeze_amount:,}</span></p>
                <p><strong>Withdrawable Amount:</strong> <span style="color: green;">{adjusted_balance:,}</span></p>
            """

            # Display the error message
            frappe.throw(error_message, title='Account Balance Issue')


    def after_save(self):
            from mfis.clients import get_total_outstanding, close_cycle_renew

            # Retrieve the total outstanding amount
            get_total_outstanding(self.account)
            
            # Fetch the savings account document
            savings_account = frappe.get_doc("Savings Account", self.account)
            
            # Calculate the effective balance
            balancer = savings_account.balance_derived - savings_account.frozen_amount
            
            # Check if the withdrawal amount exceeds the available balance
            if self.amount > balancer:
                # Reset the document status to draft if the balance is insufficient
                self.db_set('docstatus', 0)
                
                # Provide a clear and informative error message
                frappe.throw(
                    _(
                        "Insufficient balance on account.\n"
                        "Frozen Amount: {0}\n"
                        "Available Balance: {1}\n"
                        "Requested Amount: {2}"
                    ).format(
                        savings_account.frozen_amount,
                        balancer,
                        self.amount
                    )
                )


    def on_cancel(self):
        self.ignore_linked_doctypes = (
            "Saving Transaction",
        )
        cancel_transaction(self)

def get_amount_disbursed(doc, amount_org):
    for row in doc.charge_sheet:
        if row.min <= amount_org <= row.max:
            return row.charges
    return 0  # or raise exception / return None

def create_gl_entry2(doc):
    self = doc 
    current_user = frappe.session.user
    coa_account = frappe.db.get_value('Employee', {'user': doc.user}, 'coa_account')

    coa_account_name = frappe.get_doc(
                        "Account", {"name": coa_account}
                    )

    balance_on_account = frappe.get_doc(
                        "Savings Account", {"name": doc.account}
                    )
    Saving_Product = frappe.get_doc(
                        "Saving Product", {"name": balance_on_account.saving_product}
                    )
    saving_transactionr = frappe.get_doc({'parent_transaction': self.name, 'doctype': 'General Ledger II','account': coa_account,'label_for_report': coa_account_name,'transaction_type': 1,'transaction_type_name': "Withdraw",'posting_date': datetime.now().date(),'company': doc.company,'branch': doc.branch, 'amount': doc.amount,'credit': doc.amount,'debit': 0, 'main_parent': "Assets",'sub_parent': "Cash & Cash Equivalents",'category': coa_account_name
                    })
    saving_transactionr.insert()
    saving_transactionr.submit()
   
    coa_account_name2 = frappe.get_doc(
                            "Account", {"name": Saving_Product.customer_balance_account}
                        )
    saving_transactionr2 = frappe.get_doc({'parent_transaction': self.name, 'doctype': 'General Ledger II','account': coa_account_name2,'label_for_report': coa_account_name2,'transaction_type': 1,'transaction_type_name': "Withdraw",'posting_date': datetime.now().date(),'company': doc.company,'branch': doc.branch, 'amount': doc.amount,'credit': 0,'debit': doc.amount, 'main_parent': "Liabilities",'sub_parent': "Balances On Customer Account",'category': coa_account_name2
                    })
    saving_transactionr2.insert()
    saving_transactionr2.submit()
    
    amount_disbursed = get_amount_disbursed(Saving_Product, doc.amount)

    if amount_disbursed > 0:
        savings_account = frappe.get_doc(
            "Account", {"name": Saving_Product.withdrawfee}
        )
        account_name = savings_account.name

      
        coa_account_name3 = frappe.get_doc(
            "Account", {"name": Saving_Product.withdrawfee}
        )

        saving_transactionr = frappe.get_doc({
            'parent_transaction': self.name,
            'doctype': 'General Ledger II',
            'account': account_name,
            'label_for_report': coa_account_name3,
            'transaction_type': 5,
            'transaction_type_name': "withdraw Charges",
            'posting_date': datetime.now().date(),
            'company': doc.company,
            'branch': doc.branch,
            'amount': amount_disbursed,
            'credit': amount_disbursed,
            'debit': 0,
            'main_parent': "Income",
            'sub_parent': "Income",
            'category': coa_account_name3
        })
        saving_transactionr.insert()
        saving_transactionr.submit()

        coa_account_name2 = frappe.get_doc(
            "Account", {"name": Saving_Product.customer_balance_account}
        )
        saving_transactionr2 = frappe.get_doc({
            'parent_transaction': self.name,
            'doctype': 'General Ledger II',
            'account': Saving_Product.customer_balance_account,
            'label_for_report': coa_account_name2,
            'transaction_type': 5,
            'transaction_type_name': "withdraw Charges",
            'posting_date': datetime.now().date(),
            'company': doc.company,
            'branch': doc.branch,
            'amount': amount_disbursed,
            'credit': 0,
            'debit': amount_disbursed,
            'main_parent': "Liabilities",
            'sub_parent': "Balances On Customer Account",
            'category': coa_account_name2
        })
        saving_transactionr2.insert()
        saving_transactionr2.submit()

        date = nowdate()
        transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": "Withdraw Charges"})

        saving_transaction = frappe.get_doc({
            'doctype': 'Saving Transaction',
            'account': doc.account,
            'transaction_type': transaction_type,
            'posting_date': date,
            'branch': doc.branch,
            'withdraw': doc.name,
            'amount': amount_disbursed,
            'debit': amount_disbursed,
            'client_account': doc.account,  # Ensure this field exists in the Saving Transaction doctype
            'reference': doc.name,
            'description': "Withdraw Fees",
            'is_parent': 1,
            'allow_charges': 0
        })
        saving_transaction.insert()
        saving_transaction.submit()


def create_savings_transactions(doc, method=None):
    savings_account = frappe.get_doc("Savings Account", {"name": doc.account})
    saving_product = frappe.get_doc("Saving Product", {"name": savings_account.saving_product})
    penalty_account = saving_product.penalty_account
    charge = frappe.get_doc("Charge", {"name": saving_product.penalty_charges})
    date = nowdate()
    amount_disbursed = charge.amount
    coa_account_name3 = frappe.get_doc(
                        "Account", {"name": penalty_account}
                    )
    
    saving_transactionr = frappe.get_doc({'parent_transaction': doc.name, 'doctype': 'General Ledger II','account': penalty_account,'label_for_report': coa_account_name3,'transaction_type': 1,'transaction_type_name': "withdraw",'posting_date': datetime.now().date(),'company': doc.company,'branch': doc.branch, 'amount': amount_disbursed,'credit': amount_disbursed,'debit': 0, 'main_parent': "Income",'sub_parent': "Income",'category': coa_account_name3
    })
    saving_transactionr.insert()
    saving_transactionr.submit()

    coa_account_name2 = frappe.get_doc(
                                            "Account", {"name": saving_product.customer_balance_account}
                                        )
    saving_transactionr2 = frappe.get_doc({'parent_transaction': doc.name, 'doctype': 'General Ledger II','account': saving_product.customer_balance_account,'label_for_report': coa_account_name2,'transaction_type': 1,'transaction_type_name': "withdraw",'posting_date': datetime.now().date(),'company': doc.company,'branch': doc.branch, 'amount': amount_disbursed,'credit': 0,'debit': amount_disbursed, 'main_parent': "Liabilities",'sub_parent': "Balances On Customer Account",'category': coa_account_name2
                                    })
    saving_transactionr2.insert()
    saving_transactionr2.submit()

    enqueue(
            method=savings_transaction(date, charge.charge_name, doc, amount_disbursed),
            queue='long',
            timeout=300,
            now=False,
            job_name=None,
            event=None,
            is_async=True
        )

def savings_transaction(date, chname, doc, amount, trans_type="1"):
    transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": trans_type})
    try:
        saving_transaction = frappe.get_doc({
            'doctype': 'Saving Transaction',
            'account': doc.account,
            'user': doc.user,
            'transaction_type': transaction_type,
            'posting_date': date,
            'branch': doc.branch,
            'amount': amount,
            'debit': amount,
            'client_account': doc.account,  # Ensure this field exists in the Saving Transaction doctype
            'reference': doc.account,
            'description': f'{chname} Charged',
            'is_parent': 1,
            'allow_charges': 0
        })

        saving_transaction.insert()
        saving_transaction.submit()
        saving_id = saving_transaction.name

        frappe.db.sql("""
            UPDATE `tabWithdraw`
            SET savings_id = %s
            WHERE name = %s
        """, (str(saving_id), doc.name))

    except Exception as e:
        frappe.log_error(f"Error in savings_transaction: {e}")


def get_phone_number(table, column, namer):
    query = f"SELECT {column} FROM `tab{table}` WHERE name = %s"
    result = frappe.db.sql(query, (namer,), as_dict=True)
    
    if not result:
        frappe.throw(f"Client with name {namer} not found in table {table}.")
    
    return result[0][column]


def send_otp2(account, posting_date, typer, amounter, agent, val):
    savings_account2 = frappe.get_doc("Savings Account", {"name": account.name})
    typer = savings_account2.client_type
    

    if savings_account2.client_type == "Client":
        phone_number = get_phone_number("Client", "mobile", savings_account2.client)
        client_name = get_phone_number("Client", "full_name", savings_account2.client)
    elif savings_account2.client_type == "Group Account":
        phone_number = get_phone_number("Group Account", "mobile",  savings_account2.client)
        client_name = get_phone_number("Group Account", "full_name", savings_account2.client)
    elif savings_account2.client_type == "Joint Accounts":
        phone_number = get_phone_number("Joint Accounts", "mobile",  savings_account2.client)
        client_name = get_phone_number("Joint Accounts", "full_name", savings_account2.client)
       

    send_sms_notification(client_name, account.saving_product_name, account.name, phone_number, posting_date, amounter, agent, val)
 
def send_sms_notification(client_name, account, account2,  phone_number, posting_date, amounter, agent, val):
    user = frappe.session.user
    ID = frappe.db.get_value('Employee', {'user': user}, 'name')
    bal = get_phone_number("Savings Account", "balance_derived", account2)
    posting_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    balancer = "{:,}".format(val-amounter)

    try:
        # Prepare the SMS message content
        # message = (

        #     f"Withdraw  UGX {amounter:,.0f} with Agent.{ID}.Account {account2} Bal.{bal:,.0f}  Date: {posting_date}"
        # )
        message = (

            f"Withdraw  UGX {amounter:,.0f} with Agent.{ID}.Account {account2}. Bal {balancer} Date: {posting_date} Thnks 4 Choosing Uwezo"
        )

        phone_number_clean = urllib.parse.quote(phone_number.replace("-", ""))
        message_encoded = urllib.parse.quote(message)
        send_message_to_clients_opening(
            recipients=phone_number_clean,
            message=message
        )
        # url = f"https://mortarbulksms.online/apisend_uwezo.php?number={phone_number_clean}&name={message_encoded}"
        
        # headers = {
        #     'Content-Type': 'application/json',
        #     'Accept': 'application/json',
        #     'Authorization': 'Bearer 68o3IgTdNwAvm0BBGDVeklrdUoJKXDIzRWRpYzRVIP5MKr4CPkpfZJAjc38He1lDtDTGXIJy6BwLkO8x'
        # }

        # # Send the GET request to the SMS API
        # response = requests.get(url, headers=headers)
        # response.raise_for_status()  # Raise an HTTPError for bad responses

    except requests.exceptions.RequestException as e:
        # Handle specific exceptions from the requests library
        frappe.throw(f"Error sending SMS: {e}")
    except Exception as error:
        # Handle any other unexpected errors
        frappe.throw(f"An unexpected error occurred: {error}")



def send_otp(numbers_string, namaa, amounter, agent, dater,account):
    bal = get_phone_number("Savings Account", "balance_derived", filters={"name": account})
    try:
        otp = random.randint(100000, 999999)
        message = (
            f"Withdraw of UGX {amounter:,.0f} with Agent ID: {agent}. Bal UGX {bal:,.0f}. TID: --- Date: {dater}"
        )

        url = f"https://mortarbulksms.online/apisend_uwezo.php?number={urllib.parse.quote(numbers_string)}&name={urllib.parse.quote(message)}"
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': 'Bearer 68o3IgTdNwAvm0BBGDVeklrdUoJKXDIzRWRpYzRVIP5MKr4CPkpfZJAjc38He1lDtDTGXIJy6BwLkO8x'
        }

        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an exception for HTTP errors

        response_data = response.json()

        return {
            'otp': response_data.get('otp'),
            'message': response_data.get('message')
        }
    except Exception as error:
        dat = ""


def validate_signatories(self):
    if self.client_type == "Group" and self.signatories:
        required_no = get_required_signatories(self.account)

        signatories = frappe.db.count("Withdraw Representative", {
            "parent": self.name,
            "signed": 1
        })

        if cint(required_no) != cint(signatories):
            frappe.throw(f'Please attach required signatories ({required_no})')


def cancel_transaction(doc, method=None):
    conditions = {
        'withdraw': doc.name,
        # 'docstatus': 1
    }
    transaction = frappe.db.exists("Saving Transaction", conditions)

    if transaction:
        frappe.db.set_value("Saving Transaction", doc.transaction, {
            "is_cancelled": 1,
            "status": "Cancelled"
        })
