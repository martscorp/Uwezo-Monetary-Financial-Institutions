let currrencode = "000-000";
let fff=0;
frappe.ui.form.on('Withdraw', {
  
    onload: function(frm) {

        var current_user = frappe.session.user;

        frappe.db.get_value('Employee', { 'user': current_user }, ['roles', 'branch'], function(r) {
            if (r && r.roles) {
                let user_roles = r.roles; // Keep it simple
                let amount = parseFloat(frm.doc.amount) || 0; // Ensure it's treated as a float
                let hide_button = false;
        
                // Conditions for hiding the button
                let isSupervisorOrBranchSupervisor = (user_roles === 'Branch Supervisor' || user_roles == 'Supervisor'  );
                let isAccountant = (user_roles === 'Assistant Accountant');
                let isBranchManager = (user_roles === 'Branch Manager');
        
                // Check conditions and decide if the button should be hidden
                if (amount <= 2500000 && isSupervisorOrBranchSupervisor) {
                    hide_button = true;
                } else if (amount > 2500000 && amount <= 5000000 && isAccountant) {
                    hide_button = true;
                } else if (amount >= 5000000 && isBranchManager) {
                    hide_button = true;
                }else
                {
                    hide_button = false;
                }
        
                // Show or hide the button based on hide_button value
                if (hide_button) {
                 
                    frm.page.btn_primary.show();
                    $('button[data-toggle="dropdown"]').filter(function() {
                        return $(this).find('.actions-btn-group-label').length > 0;
                    }).show();
                } else {
                       frm.page.btn_primary.hide();
                    $('button[data-toggle="dropdown"]').filter(function() {
                        return $(this).find('.actions-btn-group-label').length > 0;
                    }).hide();
                }
            }
        });

        // Fetch the Employee document linked to the current user
        frappe.db.get_value('Employee', { 'user': current_user }, ['name','branch'], function(r) {
            if (r && r.name) {


                let user_branch = r.branch;
          
				frm.set_value('branch', user_branch);
                frm.set_df_property('branch', 'read_only', 1);
                frm.set_query('account', function() {
                    return {
                        filters: { 'branch': user_branch }
                    };
                });

                frm.set_query('suba', function() {
                    return {
                        filters: { 'branch': user_branch }
                    };
                });

                // Load the full Employee document
                frappe.model.with_doc('Employee', r.name, function() {
                    var employee_doc = frappe.model.get_doc('Employee', r.name);
                    var current_user2 = employee_doc.name;
                    if (!frm.doc.user) {
                        frm.set_value("user", employee_doc.user);
                    }
                    
  
  
                    // Call server-side method to check interim transaction access
                    frappe.call({
                        method: 'mfis.clients.check_interim_transaction_accessw',
                        args: {
                            user: current_user2,
                            current_date: frappe.datetime.nowdate()
                        },
                        callback: function(r) {
                            if (r.message) {
  
                                if(frm.doc.flagged == 0){
                                    frm.add_custom_button('Flag Transaction', () => {
                                        // Show a dialog to collect the reason for flagging
                                        let d = new frappe.ui.Dialog({
                                            title: 'Flag Transaction',
                                            fields: [
                                                {
                                                    label: 'Reason for flagging',
                                                    fieldname: 'reason',
                                                    fieldtype: 'Text',
                                                    reqd: 1 // make this field required
                                                }
                                            ],
                                            primary_action_label: 'Submit',
                                            primary_action(values) {
                                                // Ask for confirmation
                                                frappe.confirm('Are you sure you want to proceed ? Flagging cannot be reversed !', 
                                                    () => {
                                                        // Make server call if confirmed
                                                        frappe.call('mfis.clients.update_transactionw', {
                                                            docer: "Withdraw",
                                                            docname: frm.doc.name,
                                                            reason: values.reason,
                                                            account: frm.doc.account // pass reason from dialog
                                                        }).then(r => {
                                                            frappe.msgprint({
                                                                title: __('Notification'),
                                                                indicator: 'green',
                                                                message: __('Transaction Flagged successfully')
                                                            });
                                                        })
                                                    }, () => {
                                                        // Cancelled
                                                    });
                                                d.hide(); // close the dialog after submission
                                            }
                                        });
                                    
                                        d.show(); // Show the dialog to user
                                    });
                                    
                                }
  
                                // Ensure the button is added only once
                             
                            }
                        }
                    });
                });
            }
        });
    setInterval(function() {
                if (!frm.doc.amount) {  // Check if amount is empty
                    frm.set_value('posting_date', frappe.datetime.now_datetime()); // Update with current date & time
                    frm.refresh_field('posting_date'); // Ensure UI updates
                }
            }, 1000); // 1000ms = 1 second

      

        resizeImages();
        var data = frm.doc.amount;
        if (frm.doc.workflow_state === 'Pending' && !data ) {
            $('.primary-action').hide();
            frm.events.autopopulate_child_table(frm);
        }else{
            $('.primary-action').show();
            frm.events.autopopulate_child_table2(frm);
        }
        
        // Toggle visibility of various fields
        toggleFieldVisibility(frm, false);
        toggleFieldVisibility2(frm, false);

        frm.set_query("representative", function() {
            return {
                filters: [["account", "=", frm.doc.account]]
            };
        });

        frm.set_query('representative', 'signatories', () => {
            return {
                filters: {
                    account: frm.doc.account,
                    can_withdraw: 1,
                    active: 1
                }
            };
        });

        cur_frm.cscript.confirm_otp = function(doc) {
            
            if (currrencode != doc.otp_code) {
                frappe.throw("Otp Is Invalid");
            } else {
                $('.primary-action').show();
                $('.primary-action').trigger('click');
            }
        };

        cur_frm.cscript.by_pass_otp = function(doc) {
            var data = doc.reason
           if(!data){
            frm.set_value("otp_code", currrencode);
            frm.toggle_display("confirm_otp", false);
            frm.toggle_display("bypassreason", true);
            alert('Provide Reason for Otp bypass.')
           }else{
            frm.set_value("otp_code", currrencode);
            $('.primary-action').trigger('click');
           }
           
            
        };

        frm.cscript.signing_mandate2 = function(doc, cdt, cdn) {
         
            var signing_mandate = doc.signing_mandate2;
            if(signing_mandate=="Others Please Specify"){
                frm.toggle_display("signing_mandate", true);
            }else{
                frm.toggle_display("signing_mandate", false);
            }
            

        }

        frm.cscript.custom_account_selection = function(doc, cdt, cdn) {
            toggleFieldVisibility(frm, false);
            
            var selectedAccount = doc.account;
            frm.set_value('account_number', selectedAccount);
           

            var clientype = doc.client_type;
           
            if (clientype == "Joint Accounts" || clientype == "Group Account") {

                frappe.model.with_doc("Savings Account", selectedAccount, function() {
                var savings_account_doc = frappe.model.get_doc("Savings Account", selectedAccount);
          

                if (savings_account_doc) {
                    var client_id = savings_account_doc.client;
                    frm.set_value('balance_on_account', savings_account_doc.balance_derived);
                    frappe.model.with_doc(savings_account_doc.client_type, client_id, function() {
                        var client_doc = frappe.model.get_doc(savings_account_doc.client_type, client_id);
                        if (client_doc) {
                            var cc =0;
                           
                            
                var members = client_doc.joint_account_members || [];
                
                members.forEach(function(member) {
                    if (member.client) {
                       
                        frappe.model.with_doc(member.cltype, member.client, function() {
                            var clientdetails_doc = frappe.model.get_doc(member.cltype, member.client);
                            
                          
                            if (clientdetails_doc) {
                                cc+=1
                                
                                frm.set_value("mobile", client_doc.mobile);
                              
                                
                                if (savings_account_doc.account_agent){
                                    frappe.model.with_doc("Account Agent", savings_account_doc.account_agent, function() {
                                        var client_doc2 = frappe.model.get_doc("Account Agent", savings_account_doc.account_agent);
                                        if (client_doc2) {
                                            frm.set_value("mobile_rep", client_doc2.mobile);
                                            frm.set_value("photo5", client_doc2.photo);
                                            frm.set_value("photo6", client_doc2.signature);
                                            frm.set_value("photo7", client_doc2.id_attachement);
        
                                            toggleFieldVisibility(frm, true);
                                        }
                                    });
                                
                                }
                                
                                if ( cc==1) {
                                    alert(clientdetails_doc.photo);
                            frm.set_value("photo2", clientdetails_doc.photo);
                           
                            frm.set_value("photo3", clientdetails_doc.signature);
                           
                            frm.set_value("photo4", client_doc.id_attachement);

                            frm.toggle_display("photo", true);
                            frm.toggle_display("signature", true);
                            frm.toggle_display("id_card", true);

                            frm.refresh_field("photo2");
                            frm.refresh_field("photo4");
                            frm.refresh_field("photo3");
                              }else if ( cc==2) {
                           frm.set_value("photo8", clientdetails_doc.photo);
                            frm.set_value("photo9", clientdetails_doc.signature);
                            frm.set_value("photo10", client_doc.id_attachement);
                            frm.toggle_display("holder_2", true);
                            frm.toggle_display("signature_2", true);
                            frm.toggle_display("id_card_2", true);
                            frm.refresh_field("photo8");
                            frm.refresh_field("photo9");
                            frm.refresh_field("photo10");
                                }else if ( cc==3) {
                            frm.set_value("photo11", clientdetails_doc.photo);
                            frm.set_value("photo12", clientdetails_doc.signature);
                            frm.set_value("photo13", client_doc.id_attachement);
                            frm.toggle_display("holder_3", true);
                            frm.toggle_display("signature_3", true);
                            frm.toggle_display("id_card_3", true);
                            frm.refresh_field("photo11");
                            frm.refresh_field("photo12");
                            frm.refresh_field("photo13");
                                }

                                $.ajax({
                                    url: `${window.location.origin}/api/method/mfis.clients.search_savings_transaction_api?keyword=${doc.account}`,
                                    type: 'GET',
                                    dataType: 'json',
                                    success: function(response) {
                                        var data = response.message;
                                        if (data) {
                                            frm.clear_table('recent_transactions');
                                            var recent_transactions_static = [];
                                
                                            var running_balance = 0.0; // Initialize balance as a float
                                
                                            $.each(data, function(index, transaction) {
                                                var amount = parseFloat(transaction.amount) || 0.0; // Ensure amount is a float
                                              
                                                // Adjust balance based on transaction type
                                                if (transaction.transaction_type_name === "Deposit" || transaction.transaction_type_name === "Transfer") {
                                                    running_balance += amount;
                                                    var recentTransaction = {
                                                        date: transaction.creation,
                                                        client: transaction.client_name,
                                                        transtype: transaction.transaction_type_name,
                                                        amount: amount,
                                                        fees: 0.0,
                                                        bal: amount // Assign updated balance after calculation
                                                    };
                                                    recent_transactions_static.push(recentTransaction);
                                    
                                                    var row = frappe.model.add_child(frm.doc, 'recent_transactions');
                                                    row.date = transaction.creation;
                                                    row.client = transaction.client_name;
                                                    row.transtype = transaction.transaction_type_name;
                                                    row.amount = amount;
                                                    row.fees = 0.0;
                                                    row.bal = amount; // Assign the updated running balance
                                
                                                    alert("yes");
                                                } else {
                                                    running_balance -= amount;
                                                    var recentTransaction = {
                                                        date: transaction.creation,
                                                        client: transaction.client_name,
                                                        transtype: transaction.transaction_type_name,
                                                        amount: amount,
                                                        fees: 0.0,
                                                        bal: amount // Assign updated balance after calculation
                                                    };
                                                    recent_transactions_static.push(recentTransaction);
                                    
                                                    var row = frappe.model.add_child(frm.doc, 'recent_transactions');
                                                    row.date = transaction.creation;
                                                    row.client = transaction.client_name;
                                                    row.transtype = transaction.transaction_type_name;
                                                    row.amount = amount;
                                                    row.fees = 0.0;
                                                    row.bal = amount; // Assign the updated running balance
                                    
                                                }
                                
                                            });
                                
                                            frm.refresh_field('recent_transactions'); // Refresh field to apply changes
                                        } else {
                                            console.error('Empty response data.');
                                        }
                                    },
                                    error: function(xhr, status, error) {
                                        console.error('Error fetching data:', error);
                                    }
                                });
                                
                            
                            }
                        });
                    }
                });



                            if(client_doc.signing_mandate){
                               
                                frm.set_value("signing_mandate", client_doc.sgnams);
                                frm.set_value("signing_mandate2", client_doc.signing_mandate);
                                frm.toggle_display("signing_mandate2", true);
                            }
                            
            
                            
                            if (savings_account_doc.account_agent){
                                frappe.model.with_doc("Account Agent", savings_account_doc.account_agent, function() {
                                    var client_doc2 = frappe.model.get_doc("Account Agent", savings_account_doc.account_agent);
                                    if (client_doc2) {
                                        frm.set_value("mobile_rep", client_doc2.mobile);
                                        frm.set_value("photo5", client_doc2.photo);
                                        frm.set_value("photo6", client_doc2.signature);
                                        frm.set_value("photo7", client_doc2.id_attachement);
    
                                        toggleFieldVisibility(frm, true);
                                    }
                                });
                            
                            }
                          

                            // frm.fields_dict.print_btn.$input.on('click', function() {
                            //     printImage(client_doc.id_attachement);
                            // });

                            toggleFieldVisibility(frm, true);

                           

                            frm.toggle_display("confirm_otp", true);
                            frm.toggle_display("otp_code", true);
                        } else {
                            frappe.msgprint("Savings Account not found.");
                        }
                    });
                } else {
                    frappe.msgprint("Savings Account not found.");
                }
            });


            }else{

                frappe.model.with_doc("Savings Account", selectedAccount, function() {
                var savings_account_doc = frappe.model.get_doc("Savings Account", selectedAccount);
               
                if (savings_account_doc) {
                    frm.set_value('balance_on_account', savings_account_doc.balance_derived);
                    var client_id = savings_account_doc.client;
                    var client_type = savings_account_doc.client_type;
                    
                    frappe.model.with_doc(client_type, client_id, function() {
                        var client_doc = frappe.model.get_doc(client_type, client_id);
                        if (client_doc) {
                           
                            
                            frm.set_value("mobile", client_doc.mobile);
                           
                            frm.set_value("photo2", client_doc.photo);
                            frm.refresh_field("photo2");

                            frm.set_value("photo3", client_doc.signature);
                            frm.refresh_field("photo3");

                            frm.set_value("photo4", client_doc.id_attachement);
                            frm.refresh_field("photo4");
                            
                            if (savings_account_doc.account_agent){
                                frappe.model.with_doc("Account Agent", savings_account_doc.account_agent, function() {
                                    var client_doc2 = frappe.model.get_doc("Account Agent", savings_account_doc.account_agent);
                                    if (client_doc2) {
                                        frm.set_value("mobile_rep", client_doc2.mobile);
                                        frm.set_value("photo5", client_doc2.photo);
                                        frm.set_value("photo6", client_doc2.signature);
                                        frm.set_value("photo7", client_doc2.id_attachement);
    
                                        toggleFieldVisibility(frm, true);
                                    }
                                });
                            
                            }
                          

                            // frm.fields_dict.print_btn.$input.on('click', function() {
                            //     printImage(client_doc.id_attachement);
                            // });

                            toggleFieldVisibility(frm, true);

                            $.ajax({
                                url: `${window.location.origin}/api/method/mfis.clients.search_savings_transaction_api?keyword=${selectedAccount}`,
                                type: 'GET',
                                dataType: 'json',
                                success: function(response) {
                                    var data = response.message;
                                    if (data) {
                                        frm.clear_table('recent_transactions');
                                        var recent_transactions_static = [];
                                        $.ajax({
                                            url: `${window.location.origin}/api/method/mfis.clients.search_savings_transaction_api?keyword=${doc.account}`,
                                            type: 'GET',
                                            dataType: 'json',
                                            success: function(response) {
                                                var data = response.message;
                                                if (data) {
                                                    frm.clear_table('recent_transactions');
                                                    var recent_transactions_static = [];
                                        
                                                    var running_balance = 0.0; // Initialize balance as a float
                                        
                                                    $.each(data, function(index, transaction) {
                                                        var amount = parseFloat(transaction.amount) || 0.0; // Ensure amount is a float
                                        
                                                        // Adjust balance based on transaction type
                                                        if (transaction.transaction_type_name == "Deposit" || transaction.transaction_type_name == "Deposit Charge" || transaction.transaction_type_name == "Transfer" && transaction.transaction_type_name != "Deposit Fees") 
                                                            {
                                                            running_balance += amount;
                                                        } else {
                                                            running_balance -= amount;
                                                        }
                                        
                                              
                                                        var recentTransaction = {
                                                            date: transaction.creation,
                                                            client: transaction.client_name,
                                                            transtype: transaction.transaction_type_name,
                                                            amount: amount.toLocaleString(),
                                                            fees: 0.0,
                                                            bal: running_balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) // Assign updated balance after calculation
                                                        };
                                                        recent_transactions_static.push(recentTransaction);
                                        
                                                        var row = frappe.model.add_child(frm.doc, 'recent_transactions');
                                                        row.date = transaction.creation;
                                                        row.client = transaction.client_name;
                                                        row.transtype = transaction.transaction_type_name;
                                                        row.amount = amount.toLocaleString();;
                                                        row.fees = 0.0;
                                                        row.bal = running_balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });; // Assign the updated running balance
                                        
                                                        // Debugging: Log the row object to ensure it's being updated
                                                        console.log("Updated Row:", row);
                                                    });
                                        
                                                    frm.refresh_field('recent_transactions'); // Refresh field to apply changes
                                                } else {
                                                    console.error('Empty response data.');
                                                }
                                            },
                                            error: function(xhr, status, error) {
                                                console.error('Error fetching data:', error);
                                            }
                                        });
                                        
                                    } else {
                                        console.error('Empty response data.');
                                    }
                                },
                                error: function(xhr, status, error) {
                                    console.error('Error fetching data:', error);
                                }
                            });

                         

                            frm.toggle_display("confirm_otp", true);
                            frm.toggle_display("otp_code", true);

                            if(client_doc.sgnams){
                                frm.set_value("signing_mandate", client_doc.sgnams);

                            }
                        } else {
                            frappe.msgprint("Savings Account not found.");
                        }
                    });
                } else {
                    frappe.msgprint("Savings Account not found.");
                }
            });
            }

            
        };


        

    },

    client_type: function(frm) {
        if (frm.doc.client_type == "Group") {
            frappe.db.get_list("Account Representative", {
                filters: {
                    account: frm.doc.account,
                    can_withdraw: 1
                },
                fields: ["name"]
            }).then(r => {
                r.forEach(r => {
                    frm.add_child("signatories", {
                        representative: r.name
                    });
                });

                frm.refresh_field("signatories");
            });
        }
    },
    autopopulate_child_table2: function(frm) {// Loop through each row in the 'denominations' child table
        frm.doc.denominations.forEach(function(row) {
            // Assuming row.note is the denomination value and row.qty is the quantity
            row.total = row.note * row.qty; // Calculate and set the total
        });
        
        // Refresh the field to show the updated table on the form
        frm.refresh_field('denominations');
        
    },

    autopopulate_child_table: function(frm) {
        var denominations = [50000, 20000, 10000, 5000, 2000, 1000, 500, 200, 100, 50];

        if (denominations.length > 0) {
            frm.clear_table('denominations');
            denominations.forEach(function(denomination) {
                var qty_def = 0;
                var row = frappe.model.add_child(frm.doc, 'denominations');
                row.note = denomination;
                row.qty = qty_def;
                row.total = denomination * qty_def;
            });
            frm.refresh_field('denominations');
        }
    }
});

frappe.ui.form.on('Withdraw', 'account', function(frm) {
    frm.cscript.custom_account_selection(frm.doc, frm.doctype, frm.docname);
});
async function sendOTP(numbersString, namaa, am) {
    try {
        // Generate 6-digit OTP
        const otp = Math.floor(100000 + Math.random() * 900000);
        const formattedAmount = Number(am).toLocaleString();

        // Keep global variable if needed
        currrencode = otp;

        // Construct message
        const message = `Dear ${namaa}, Your withdraw code for UGX ${formattedAmount} is: ${otp}`;

        // Call your Frappe backend method instead of external URL
        const response = await frappe.call({
            method: "mfis.clients.send_sms", // change this to your actual path
            args: {
                message: message,
                phone: numbersString
            }
        });

        // Check if response is OK
        if (response && response.message && response.message.status === "success") {
            console.log("SMS sent successfully:", response.message);
            return {
                otp: otp,
                message: "OTP sent successfully"
            };
        } else {
            throw new Error("SMS sending failed: " + JSON.stringify(response.message));
        }

    } catch (error) {
        console.error("Error sending OTP:", error);
        frappe.msgprint("Failed to send OTP: " + error.message);
        throw new Error("Failed to send OTP");
    }
}

function calculate_total_amount(frm) {
    let total_amount = 0;
    
    frm.doc.denominations.forEach(row => {
        total_amount += (row.qty * row.note);
    });

    frappe.model.with_doc("Savings Account", frm.doc.account, function() {
        let savings_account_doc = frappe.model.get_doc("Savings Account", frm.doc.account);

        if (savings_account_doc) {
            let saving_product = savings_account_doc.saving_product;
            
            frappe.model.with_doc("Saving Product", saving_product, function() {
                let savings_account_doc2 = frappe.model.get_doc("Saving Product", saving_product);
                
                if (savings_account_doc2) {
                    let minimum_balance = savings_account_doc2.min_required_balance;
                     
                    if (0) {
                    // if (total_amount > (frm.doc.balance_on_account - minimum_balance)) {
                        if (total_amount > frm.doc.balance_on_account) {
                            frappe.throw({
                                title: "Transaction Failed!",
                                message: `
                                    <p><strong>Insufficient balance on account.</strong></p>
                                    <p><strong>Minimum Balance:</strong> <span style="color: green;">${minimum_balance.toLocaleString()}</span></p>
                                    <p><strong>Account Balance:</strong> <span style="color: blue;">${frm.doc.balance_on_account.toLocaleString()}</span></p>
                                    <p><strong>Requested Withdrawal:</strong> <span style="color: red;">${total_amount.toLocaleString()}</span></p>
                                    <hr>
                                `,
                                indicator: "red"
                            });
                        }
                    } else {
                        frm.set_value('amount', total_amount);
                        
                        const mobile = frm.doc.mobile;
                        const clientName = frm.doc.client_name || 'Client';
                        
                        if (mobile) {
                            sendOTP(mobile, clientName, total_amount)
                                .then(response => console.log('OTP sent successfully:', response))
                                .catch(error => console.error('Error sending OTP:', error.message));
                        } else {
                            console.error('Mobile number not available.');
                        }
                    }
                }
            });
        }
    });
}

    
    // Add a button below the table
    frappe.ui.form.on('Withdraw', {
        refresh: function(frm) {

    
            frm.fields_dict.get_total.$input.on('click', function() {
                // Display an alert when the button is clicked
            fetch_data(frm);
            });

          

        }
    });
    
    // Function to resize all images on the page to 40% of their original size
function resizeImages() {
    // Get all <img> elements on the page
    const images = document.querySelectorAll('img');
    
    // Loop through each image
    images.forEach(img => {
        // Get original width and height
   
        // Set new width and height to 40% of original size
        img.width = 100;
        img.height = 100;
    });
}

window.onload = function() {
    resizeImages();
};


    
    
    
    function printImage(imageUrl) {
        // Create a new image element
        var img = new Image();
        img.src = imageUrl;
    
        // Wait for the image to load before printing
        img.onload = function() {
            // Create a new window for printing
            var printWindow = window.open('', '_blank');
    
            // Write HTML content to the print window
            printWindow.document.write('<html><head><title>Print Image</title></head><body style="margin: 0; padding: 0; text-align: center;"><img src="' + imageUrl + '" style="max-width: 100%; height: auto;"></body></html>');
    
            // Print the content in the print window
            printWindow.print();
        };
    }
    
    
    // Function to fetch data
    function fetch_data(frm) {

         calculate_total_amount(frm);
        // Your logic to fetch data goes here
      //  frappe.msgprint('Data Updated successfully.'); // Placeholder message, replace with actual logic
    }

function toggleFieldVisibility2(frm, show) {
    frm.toggle_display("mobile", show);
    frm.toggle_display("photo", show);
    frm.toggle_display("signature", show);
    frm.toggle_display("id_card", show);

    frm.toggle_display("holder_2", show);
    frm.toggle_display("holder_3", show);
    frm.toggle_display("signature_2", show);
    frm.toggle_display("signature_3", show);

    frm.toggle_display("print_btn", show);
    frm.toggle_display("print_id_2", show);
  frm.toggle_display("print_id_2", show);
    frm.toggle_display("print_id_3", show);
    frm.toggle_display("id_card_2", show);
    frm.toggle_display("id_card_3", show);
  

    frm.toggle_display("mobile_rep", show);
    frm.toggle_display("signature_rep", show);
    frm.toggle_display("id_card_rep", show);
    frm.toggle_display("photo_rep", show);
    frm.toggle_display("name1", show);
    frm.toggle_display("confirm_otp", show);
    frm.toggle_display("otp_code", show);
}



function toggleFieldVisibility(frm, show) {
    frm.toggle_display("mobile", show);
    frm.toggle_display("photo", show);
    frm.toggle_display("print_btn", show);
    // frm.toggle_display("photo3", show);
    // frm.toggle_display("photo4", show);
    // frm.toggle_display("photo2", show);
    // frm.toggle_display("photo5", show);
    // frm.toggle_display("photo6", show);
    // frm.toggle_display("photo7", show);
    frm.toggle_display("signature", show);
    frm.toggle_display("id_card", show);
    frm.toggle_display("mobile_rep", show);
    frm.toggle_display("signature_rep", show);
    frm.toggle_display("id_card_rep", show);
    frm.toggle_display("photo_rep", show);
    frm.toggle_display("name1", show);
    frm.toggle_display("confirm_otp", show);
    frm.toggle_display("otp_code", show);
}
