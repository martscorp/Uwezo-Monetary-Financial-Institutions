// Copyright (c) 2023, Abbey and contributors
// For license information, please see license.txt

frappe.ui.form.on('Apply Charge', {
    charge: function (frm) {
        // Define the charge document based on the charge type
        var charge_doc = 'Savings Charges';

        if (frm.doc.charge_type == 'Loan') {
            charge_doc = 'Loan Charge';
        }

        // Show a loading spinner while fetching data
        frm.set_df_property('amount', 'read_only', 0); // Allow editing temporarily to set the spinner

        // Fetch the charge details from the relevant document
        frappe.db.get_value(charge_doc, frm.doc.charge, ['name', 'amount'])
            .then(r => {
                let values = r.message;

                if (values && values.amount) {
                    let amount = values.amount;

                    // Set the amount field and make it read-only
                    frm.set_value({
                        amount: amount
                    });

                    frm.set_df_property('amount', 'read_only', 1);
                } else {
                    // Handle the case where no amount is found
                    frappe.msgprint(__('No amount found for this charge.'));
                }
            })
            .catch(error => {
                // Handle any error during the API call
                console.error(error);
                frappe.msgprint(__('An error occurred while fetching the charge details.'));
            })
            .finally(() => {
                // Hide the loading spinner once the request is complete
                frm.set_df_property('amount', 'read_only', 1);
            });
    },

    onload: function (frm) {
        // Get the current user and fetch their branch info
        var current_user = frappe.session.user;
        frappe.db.get_value('Employee', { 'user': current_user }, ['branch', 'name'], function (r) {
            if (r && r.branch) {
                let user_branch = r.branch;

                // Set the branch fields and make them read-only
                frm.set_value('branch', user_branch);
                frm.set_df_property('branch', 'read_only', 1);

                frm.set_value('account_branch', user_branch);
                frm.set_df_property('account_branch', 'read_only', 1);

                // Set filters for the 'account' field to show only accounts from the user's branch
                frm.set_query('account', function () {
                    return {
                        filters: { 'branch': user_branch }
                    };
                });

                // Set query for 'charge' field to show only active flat charges for the user's branch
                frm.set_query("charge", function () {
                    return {
                        "filters": [
                            ["charge_calculation_type", "=", 'Flat'],
                            ["active", "=", 1],
                            ["branch", "=", user_branch]
                        ]
                    };
                });
            } else {
                // Handle the case where the employee branch is not found
                frappe.msgprint(__('Could not determine branch for the current user.'));
            }
        });
    }
});
