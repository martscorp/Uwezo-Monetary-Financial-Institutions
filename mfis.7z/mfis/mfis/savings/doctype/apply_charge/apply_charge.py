# Copyright (c) 2023, Abbey and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document
from mfis.savings.doctype.saving_transaction.saving_transaction import create_apply_charge_transaction
from mfis.savings.doctype.saving_transaction.saving_transaction import create_deposit_transaction,validate_accounting_period


class ApplyCharge(Document):
    def validate(self):
        validate_company(self)

    def on_submit(self):
        validate_accounting_period(self)
        frappe.throw(str("fghgffhfgh"))
        create_apply_charge_transaction(self)

    def on_cancel(self):
        cancel_transaction(self)


# self.ignore_linked_doctypes = (
#     "Saving Transaction"
# )


def cancel_transaction(doc, method=None):
    conditions = {
        'apply_charge': doc.name,
        'docstatus': 1
    }
    transaction = frappe.db.exists("Saving Transaction", conditions)

    if transaction:
        transaction = frappe.get_doc("Saving Transaction", conditions)
        transaction.cancel()


def validate_company(doc, method=None):
    company = doc.get('company', None)

    if company is None:
        company = frappe.get_cached_value("Branch", doc.get('account_branch'), "company")

        if company is None:
            frappe.throw("Company is required")
    doc.company = company
