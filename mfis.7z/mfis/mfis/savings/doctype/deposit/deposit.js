// Copyright (c) 2023, Abbey and contributors
// For license information, please see license.txt

frappe.ui.form.on('Deposit', {
	refresh: function(frm) {
    frm.toggle_display("suba", false);
      // Get the current user
      var current_user = frappe.session.user;

      // Fetch the Employee document linked to the current user
      frappe.db.get_value('Employee', { 'user': current_user }, 'name', function(r) {
          if (r && r.name) {
              // Load the full Employee document
              frappe.model.with_doc('Employee', r.name, function() {
                  var employee_doc = frappe.model.get_doc('Employee', r.name);
                  var current_user2 = employee_doc.name;


                  // Call server-side method to check interim transaction access
                  frappe.call({
                      method: 'mfis.clients.check_interim_transaction_access',
                      args: {
                          user: current_user2,
                          current_date: frappe.datetime.nowdate()
                      },
                      callback: function(r) {
                          if (r.message) {

                            if(frm.doc.flagged == 0){
                                frm.add_custom_button('Flag Transaction', () => {
                                    // Show a dialog to collect the reason for flagging
                                    let d = new frappe.ui.Dialog({
                                        title: 'Flag Transaction',
                                        fields: [
                                            {
                                                label: 'Reason for flagging',
                                                fieldname: 'reason',
                                                fieldtype: 'Text',
                                                reqd: 1 // make this field required
                                            }
                                        ],
                                        primary_action_label: 'Submit',
                                        primary_action(values) {
                                            // Ask for confirmation
                                            frappe.confirm('Are you sure you want to proceed? Flagging cannot be reversed !', 
                                                () => {
                                                    // Make server call if confirmed
                                                    frappe.call('mfis.clients.update_transaction', {
                                                        docer: "Deposit",
                                                        docname: frm.doc.name,
                                                        reason: values.reason,
                                                        account: frm.doc.account
                                                        
                                                    }).then(r => {
                                                        frappe.msgprint({
                                                            title: __('Notification'),
                                                            indicator: 'green',
                                                            message: __('Transaction Flagged successfully')
                                                        });
                                                    })
                                                }, () => {
                                                    // Cancelled
                                                });
                                            d.hide(); // close the dialog after submission
                                        }
                                    });
                                
                                    d.show(); // Show the dialog to user
                                });
                                
                            }

                              // Ensure the button is added only once
                             
                          }
                      }
                  });
              });
          }
      });

	},onload: function(frm) {

       
        var current_user = frappe.session.user;
		frappe.db.get_value('Employee', { 'user': current_user }, ['branch','name'], function(r) {
            if (r && r.branch) {
                let user_branch = r.branch;

                frm.set_value('account_branch', user_branch);
                frm.set_df_property('account_branch', 'read_only', 1);
          
				frm.set_value('branch', user_branch);
                frm.set_df_property('branch', 'read_only', 1);
                frm.set_query('account', function() {
                    return {
                        filters: { 'branch': user_branch }
                    };
                });

             

            } });

            setInterval(function() {
                if (!frm.doc.amount) {  // Check if amount is empty
                    frm.set_value('posting_date', frappe.datetime.now_datetime()); // Update with current date & time
                    frm.refresh_field('posting_date'); // Ensure UI updates
                }
            }, 1000); // 1000ms = 1 second


        var data = frm.doc.amount;
        
if (frm.doc.docstatus == 0 && !data ) {
$('.primary-action').hide();
 frm.events.autopopulate_child_table(frm);
 
}else{
    $('.primary-action').show();
    frm.events.autopopulate_child_table2(frm);
}


},


account: function(frm) { 
    if (frm.doc.account) {
        frappe.model.with_doc("Savings Account", frm.doc.account, function() {
            var savings_account_doc = frappe.model.get_doc("Savings Account", frm.doc.account);
            if (savings_account_doc) {
                var client_type = savings_account_doc.client_type;
                var client = savings_account_doc.client;
                frm.set_value('acccnumber', savings_account_doc.name);
                
                if (client_type == "Group Account") {
                    frm.toggle_display("suba", true);

                    // Step 1: Fetch Group Account Members from Group Account
                    frappe.call({
                        method: 'frappe.client.get',
                        args: {
                            doctype: client_type,
                            name: client
                        },
                        callback: function(res) {
                            if (res.message) {
                             
                                let group_account_name = res.message.name;
                                let members = res.message.joint_account_members; // Extract group members

                                let options = ['']; // Start with an empty option
                                $.each(members || [], function(i, row) {
                                    options.push(row.name);  // Extract 'account' field
                                });

                                frm.set_df_property('suba', 'options', options.join('\n'));  // Populate select field
                                frm.refresh_field('suba');
                            }
                        }
                    });
                } else {
                    frm.toggle_display("suba", false);
                }
            }
        });
    }
}
,
    autopopulate_child_table: function(frm) {
        // Sample denominations data
        var denominations = [
            50000,
            20000,
            10000,
            5000,
            2000,
            1000,
            500,
            200,
            100,
            50
        ];

        if (denominations.length > 0) {
            // Clear existing rows
            frm.clear_table('denominations');
            // Add rows to child table
            denominations.forEach(function(denomination) {
                var qty_def = 0; 
                var row = frappe.model.add_child(frm.doc, 'denominations');
                row.note = denomination; // Add denomination to row
                row.qty = qty_def; // Initialize quantity to 1
                row.total = (denomination * qty_def);
                // Set other fields as needed
            });
            // Refresh the form
            frm.refresh_field('denominations');
            //calculate_total_amount(frm);
        }
    },autopopulate_child_table2: function(frm) {// Loop through each row in the 'denominations' child table
        frm.doc.denominations.forEach(function(row) {
            // Assuming row.note is the denomination value and row.qty is the quantity
            row.total = row.note * row.qty; // Calculate and set the total
        });
        
        // Refresh the field to show the updated table on the form
        frm.refresh_field('denominations');
        
    }

});



    function calculate_total_amount(frm) {
    var total_amount = 0;
    frm.doc.denominations.forEach(function(row) {
        total_amount += (row.qty*row.note);
    });
    frm.set_value('amount', total_amount);
         $('.primary-action').show();
    
}

// Add a button below the table
frappe.ui.form.on('Deposit', {
    refresh: function(frm) {

        frm.fields_dict.get_total.$input.on('click', function() {
            // Display an alert when the button is clicked
        fetch_data(frm);
        });

        // frm.add_custom_button(__('Generate Total'), function() {
        //     // Call a function to fetch data
        //     fetch_data(frm);
        // });
    }
});

// Function to fetch data
function fetch_data(frm) {
     calculate_total_amount(frm);
    // Your logic to fetch data goes here
  //  frappe.msgprint('Data Updated successfully.'); // Placeholder message, replace with actual logic
}