import frappe
import random
import urllib.parse
import requests
from datetime import datetime
from frappe.utils import cint, flt, nowdate
from frappe.model.document import Document
from mfis.clients import send_message_to_clients_opening
from mfis.clients import get_total_outstanding, getcurrent_cycle_running
from mfis.savings.doctype.apply_charge.apply_charge import validate_company
from mfis.savings.doctype.saving_transaction.saving_transaction import (
    create_deposit_transaction,
    validate_accounting_periodd,
)
import datetime
from datetime import timedelta

class Deposit(Document):
    def validate(self):
        validate_company(self)
 
    def on_submit(self):
        
        validate_accounting_periodd(self)
        savings_account = frappe.get_doc("Savings Account", {"name": self.account})
        databd = str(savings_account.client)
        transaction_id = create_deposit_transaction(self)
        create_gl_entry(self,self.amount,transaction_id)
       
        if savings_account.is_fixed:
            getcurrent_cycle_running(self.account)
            
        # get_total_outstanding(self.account)
        # send_otp2(savings_account, self.posting_date, savings_account.client_type, self.amount, self.owner)

    def on_cancel(self):
        self.ignore_linked_doctypes = ("Saving Transaction",)
        # cancel_transaction(self)

    def on_change(self):
        on_flagging(self)


def update_paid_and_amount(docname, amount):
    # Make sure to pass the correct parameters to format the SQL query
    frappe.db.sql("""
    UPDATE `tabGeneral Ledger II` 
    SET credit = credit + %s
    WHERE name = %s
""", (amount, docname))

    # Commit the changes to the database
    frappe.db.commit()
def create_gl_entry(doc, amounter, transaction_id):
    current_user = frappe.session.user
    savings_account_id = doc.account
    coa_account = frappe.db.get_value('Employee', {'user': current_user}, 'coa_account')

    coa_account_name = frappe.get_doc("Account", {"name": coa_account})
    savings_accounter = frappe.get_doc("Savings Account", {"name": doc.account})
    balance_on_account = savings_accounter.balance_derived

    if balance_on_account < 0:
        Saving_Product = frappe.get_doc("Saving Product", {"name": savings_accounter.saving_product})
   
        account_receivable = frappe.get_list("General Ledger II", 
            filters={
                "savings_account": doc.account,
                "transaction_type_name": "accountrecivable"
            },
            fields=["name", "debit", "credit", "transaction_type_name", "rcpayment1"]

        )

        deposit_fees_receivable = frappe.get_list("General Ledger II", 
            filters={
                "savings_account": doc.account,
                "transaction_type_name": "depositreceivable"
            },
            fields=["name", "debit", "credit", "transaction_type_name", "rcpayment1"]
        )

        monthly_receivable = frappe.get_list("General Ledger II", 
            filters={
                "savings_account": doc.account,
                "transaction_type_name": "monthlyfessrecivable"
            },
            fields=["name", "debit", "credit", "transaction_type_name", "rcpayment1"]

        )

        remaining_amount = amounter
        current_user = frappe.session.user
        coa_account = frappe.db.get_value('Employee', {'user': current_user}, 'coa_account')
        coa_account_name = frappe.get_doc(
                            "Account", {"name": coa_account}
                        )
        saving_transactionr2 = frappe.get_doc({
                            'parent_transaction': transaction_id, 
                            'doctype': 'General Ledger II',
                            'account': coa_account_name,
                            'label_for_report': coa_account_name,
                            'transaction_type': 1,
                            'transaction_type_name': "Deposit",
                            'posting_date': datetime.now(),
                            'company': doc.company,
                            'branch': doc.branch,
                            'amount': amounter,
                            'credit': 0,
                            'debit':amounter,
                            'main_parent': "Assets",
                            'sub_parent': "Cash & Cash Equivalents",
                            'category': coa_account_name,
                            'savings_account': savings_account_id
                            })
        saving_transactionr2.insert()
        saving_transactionr2.submit()       

        for records in [account_receivable, deposit_fees_receivable, monthly_receivable]:
            for record in records:
                debit = record['debit']
                credit = record['credit']
                record_name = record['name']
                record_type = record['transaction_type_name']
                rcpayment1 = record['rcpayment1']

                if record_type == "accountrecivable":
           
                    
                    if remaining_amount <= 0:
                        break

                    if rcpayment1 < debit:
                        amount_to_adjust = min(remaining_amount, debit - rcpayment1)
                        
                        frappe.db.sql("""
                            UPDATE `tabGeneral Ledger II` 
                            SET rcpayment1 = rcpayment1 + %s
                            WHERE name = %s
                        """, (amount_to_adjust, record_name))
                        frappe.db.commit()

                        savings_account3 = frappe.get_doc("Account", {"name": Saving_Product.acc2})
                        account_name2 = savings_account3.name


                        current_user = frappe.session.user
                        coa_account = frappe.db.get_value('Employee', {'user': current_user}, 'coa_account')
                        coa_account_name = frappe.get_doc(
                                            "Account", {"name": coa_account}
                                        )

                        transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": "Deposit Charge"})
                        saving_transactionr = frappe.get_doc({
                            'doctype': 'General Ledger II',
                            'parent_transaction': transaction_id, 
                            'account': account_name2,
                            'label_for_report': account_name2,
                            'transaction_type': 1,
                            'transaction_type_name': "Receiveble Payment",
                            'posting_date': datetime.now().date(),
                            'company': doc.company,
                            'branch': doc.branch,
                            'amount': amount_to_adjust,
                            'credit': amount_to_adjust,
                            'debit': 0,
                            'main_parent': "Assets",
                            'sub_parent': "Debtors & Receivables",
                            'category': account_name2,
                            'savings_account': savings_account_id
                        })
                        saving_transactionr.insert()
                        saving_transactionr.submit()



                        remaining_amount -= amount_to_adjust

                elif record_type == "depositreceivable":
                    

                    if remaining_amount <= 0:
                        break

                    if rcpayment1 < debit:
                        amount_to_adjust = min(remaining_amount, debit - rcpayment1)
                        
                        frappe.db.sql("""
                            UPDATE `tabGeneral Ledger II` 
                            SET rcpayment1 = rcpayment1 + %s
                            WHERE name = %s
                        """, (amount_to_adjust, record_name))
                        frappe.db.commit()

                        savings_account3 = frappe.get_doc("Account", {"name": Saving_Product.deposit_fees_receivable})
                        account_name2 = savings_account3


                        current_user = frappe.session.user
                        coa_account = frappe.db.get_value('Employee', {'user': current_user}, 'coa_account')
                        coa_account_name = frappe.get_doc(
                                            "Account", {"name": coa_account}
                                        )
                        remaining_amount -= amount_to_adjust
                        transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": "Deposit Charge"})
                        saving_transactionr = frappe.get_doc({
                            'doctype': 'General Ledger II',
                            'parent_transaction': transaction_id, 
                            'account': account_name2,
                            'label_for_report': account_name2,
                            'transaction_type': 1,
                            'transaction_type_name': "Deposit Fees Receiveble Payment",
                            'posting_date': datetime.now().date(),
                            'company': doc.company,
                            'branch': doc.branch,
                            'amount': amount_to_adjust,
                            'credit': amount_to_adjust,
                            'debit': 0,
                            'main_parent': "Assets",
                            'sub_parent': "Debtors & Receivables",
                            'category': account_name2,
                            'savings_account': savings_account_id
                        })
                        saving_transactionr.insert()
                        saving_transactionr.submit()
                        coa_account_name2 = frappe.get_doc(
                            "Account", {"name": Saving_Product.customer_balance_account}
                        )
                        remaining_amount -= amount_to_adjust
                        if remaining_amount < 1 :
                            saving_transactionr2 = frappe.get_doc({
                            'parent_transaction': transaction_id, 
                            'doctype': 'General Ledger II',
                            'account': coa_account_name2,
                            'label_for_report': coa_account_name2,
                            'transaction_type': 1,
                            'transaction_type_name': "Deposit",
                            'posting_date': datetime.now().date(),
                            'company': doc.company,
                            'branch': doc.branch,
                            'amount': amount_to_adjust,
                            'credit': 0,
                            'debit':amount_to_adjust,
                            'main_parent': "Liabilities",
                            'sub_parent': "Balances On Customer Account",
                            'category': coa_account_name2,
                            'savings_account': savings_account_id
                            })
                            saving_transactionr2.insert()
                            saving_transactionr2.submit()
                        else:
                            deposit_fees_data = Saving_Product.get("product_charges")
                            for fee in deposit_fees_data:
                                charge_name = fee.get("charge")
                                coa_account_name = frappe.get_doc("Charge", {"name": charge_name})

                                if fee.get("branch") == doc.branch and  "Deposit Fees" in coa_account_name.charge_name:
                                    savings_account = frappe.get_doc("Account", {"name": coa_account_name.account})
                                    account_name = savings_account.name

                                    charge_nal = frappe.get_doc("Charge", {"name": charge_name})
                                    coa_account_name3 = frappe.get_doc("Account", {"name": Saving_Product.depositfees})
                                    date = nowdate()

                                    saving_transactionr2 = frappe.get_doc({
                                    'parent_transaction': transaction_id, 
                                    'doctype': 'General Ledger II',
                                    'account': coa_account_name2,
                                    'label_for_report': coa_account_name3,
                                    'transaction_type': 1,
                                    'transaction_type_name': "Deposit Fees",
                                    'posting_date': datetime.now().date(),
                                    'company': doc.company,
                                    'branch': doc.branch,
                                    'amount': amount_to_adjust,
                                    'credit': amount_to_adjust,
                                    'debit':0,
                                    'main_parent': "Income",
                                    'sub_parent': "Income",
                                    'category': coa_account_name3,
                                    'savings_account': savings_account_id
                                    })
                                    saving_transactionr2.insert()
                                    saving_transactionr2.submit()
                            


              
                       

                else:
                    if remaining_amount <= 0:
                        break

                    if credit < debit:
                        amount_to_adjust = min(remaining_amount, debit - credit)
                       
                        frappe.db.sql("""
                            UPDATE `tabGeneral Ledger II` 
                            SET credit = credit + %s
                            WHERE name = %s
                        """, (amount_to_adjust, record_name))
                        frappe.db.commit()


                        current_user = frappe.session.user
                        coa_account = frappe.db.get_value('Employee', {'user': current_user}, 'coa_account')
                        coa_account_name = frappe.get_doc(
                                            "Account", {"name": coa_account}
                                        )


                        remaining_amount -= amount_to_adjust

        if remaining_amount > 0:
            deposit_fees_data = Saving_Product.get("product_charges")
            for fee in deposit_fees_data:
                charge_name = fee.get("charge")
                coa_account_name = frappe.get_doc("Charge", {"name": charge_name})

                if fee.get("branch") == doc.branch and  "Deposit Fees" in coa_account_name.charge_name:
                    savings_account = frappe.get_doc("Account", {"name": coa_account_name.account})
                    account_name = savings_account.name

                    charge_nal = frappe.get_doc("Charge", {"name": charge_name})
                    coa_account_name3 = frappe.get_doc("Account", {"name": Saving_Product.depositfees})
                    date = nowdate()

                    transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": "Deposit Charge"})
                    saving_transaction = frappe.get_doc({
                                'doctype': 'Saving Transaction',
                                'account': doc.account,
                                 
                                'transaction_type': transaction_type,
                                'transaction_type_name':"Deposit Fees",
                                 'user': doc.owner,
                                'posting_date': date,
                                'branch': doc.branch,
                                'deposit': transaction_id,
                                'amount': charge_nal.amount,
                                'debit': charge_nal.amount,
                                'client_account': doc.account,  # Ensure this field exists in the Saving Transaction doctype
                                'reference': doc.name,
                                'description': "Deposit Fees",
                                'is_parent': 1,
                                'allow_charges': 0
                            })
                    saving_transaction.insert()
                    saving_transaction.submit()
                    
                    transaction_id_after = saving_transaction.name


                    coa_account_name4 = frappe.get_doc("Account", {"name": Saving_Product.deposit_fees_receivable})
                

                    # saving_transactionr2 = frappe.get_doc({
                    #     'parent_transaction': transaction_id_after,
                    #     'doctype': 'General Ledger II',
                    #     'account': account_name,
                    #     'label_for_report': coa_account_name4,
                    #     'transaction_type': 1,
                    #     'transaction_type_name': "depositreceivable",
                    #     'posting_date': datetime.now().date(),
                    #     'company': doc.company,
                    #     'branch': doc.branch,
                    #     'amount': charge_nal.amount,
                    #     'credit': 0,
                    #     'debit': charge_nal.amount,
                    #     'main_parent': "Assets",
                    #     'sub_parent': "Debtors & Receivables",
                    #     'category': coa_account_name4,
                    #     'savings_account': savings_account_id
                    # })
                    # saving_transactionr2.insert()
                    # saving_transactionr2.submit()

                    saving_transactionr = frappe.get_doc({
                        
                        'parent_transaction': transaction_id_after,
                        'doctype': 'General Ledger II',
                        'account': account_name,
                        'label_for_report': coa_account_name3,
                        'transaction_type': 1,
                        'transaction_type_name': "Deposit fees",
                        'posting_date': datetime.now().date(),
                        'company': doc.company,
                        'branch': doc.branch,
                        'amount': charge_nal.amount,
                        'credit': charge_nal.amount,
                        'debit': 0,
                        'main_parent': "Income",
                        'sub_parent': "Income",
                        'category': coa_account_name3,
                        'savings_account': savings_account_id
                    })
                    saving_transactionr.insert()
                    saving_transactionr.submit()
                    remaining_amount -= charge_nal.amount
         
            create_customer_balance_entry2(doc, remaining_amount, savings_account_id)
        else:
                
            deposit_fees_data = Saving_Product.get("product_charges")
            for fee in deposit_fees_data:
                charge_name = fee.get("charge")
                coa_account_name = frappe.get_doc("Charge", {"name": charge_name})

                if fee.get("branch") == doc.branch and  "Deposit Fees" in coa_account_name.charge_name:
                    savings_account = frappe.get_doc("Account", {"name": coa_account_name.account})
                    account_name = savings_account.name

                    charge_nal = frappe.get_doc("Charge", {"name": charge_name})
                    coa_account_name3 = frappe.get_doc("Account", {"name": Saving_Product.depositfees})
                    date = nowdate()

                    transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": "Deposit Charge"})
                    saving_transaction = frappe.get_doc({
                                'doctype': 'Saving Transaction',
                                'account': doc.account,
                                'transaction_type': transaction_type,
                                  'transaction_type_name':"Deposit Fees",
                                 'user': doc.owner,
                                'posting_date': date,
                                'branch': doc.branch,
                                'deposit': transaction_id,
                                'amount': charge_nal.amount,
                                'debit': charge_nal.amount,
                                'client_account': doc.account,  # Ensure this field exists in the Saving Transaction doctype
                                'reference': doc.name,
                                'description': "Deposit Fees",
                                'is_parent': 1,
                                'allow_charges': 0
                            })
                    saving_transaction.insert()
                    saving_transaction.submit()
                    transaction_id_after = saving_transaction.name


                    coa_account_name4 = frappe.get_doc("Account", {"name": Saving_Product.deposit_fees_receivable})
                

                    saving_transactionr2 = frappe.get_doc({
                        'parent_transaction': transaction_id_after,
                        'doctype': 'General Ledger II',
                        'account': account_name,
                        'label_for_report': coa_account_name4,
                        'transaction_type': 1,
                        'transaction_type_name': "depositreceivable",
                        'posting_date': datetime.now().date(),
                        'company': doc.company,
                        'branch': doc.branch,
                        'amount': charge_nal.amount,
                        'credit': 0,
                        'debit': charge_nal.amount,
                        'main_parent': "Assets",
                        'sub_parent': "Debtors & Receivables",
                        'category': coa_account_name4,
                        'savings_account': savings_account_id
                    })
                    saving_transactionr2.insert()
                    saving_transactionr2.submit()

                    saving_transactionr = frappe.get_doc({
                        
                        'parent_transaction': transaction_id_after,
                        'doctype': 'General Ledger II',
                        'account': account_name,
                        'label_for_report': coa_account_name3,
                        'transaction_type': 1,
                        'transaction_type_name': "Deposit fees",
                        'posting_date': datetime.now().date(),
                        'company': doc.company,
                        'branch': doc.branch,
                        'amount': charge_nal.amount,
                        'credit': charge_nal.amount,
                        'debit': 0,
                        'main_parent': "Income",
                        'sub_parent': "Income",
                        'category': coa_account_name3,
                        'savings_account': savings_account_id
                    })
                    saving_transactionr.insert()
                    saving_transactionr.submit()

                    

                    # Update or create entry for Deposit Fees Receivable
                    update_or_create_entry(
                        Saving_Product.deposit_fees_receivable,
                        doc,
                        charge_nal.amount,
                        savings_account_id,
                        "depositreceivable"
                    )

    else:
        current_user = frappe.session.user
        savings_account_id = doc.account
        coa_account = frappe.db.get_value('Employee', {'user': current_user}, 'coa_account')
        coa_account_name = frappe.get_doc("Account", {"name": coa_account})
        Saving_Product = frappe.get_doc("Saving Product", {"name": savings_accounter.saving_product})


        saving_transactionr = frappe.get_doc({
            'parent_transaction': transaction_id, 'doctype': 'General Ledger II',
            'account': coa_account_name,
            'label_for_report': coa_account_name,
            'transaction_type': 1,
            'transaction_type_name': "Deposit",
            'posting_date': datetime.now().date(),
            'company': doc.company,
            'branch': doc.branch,
            'amount': doc.amount,
            'credit': 0,
            'debit': doc.amount,
            'main_parent': "Assets",
            'sub_parent': "Cash & Cash Equivalents",
            'category': coa_account_name,
            'savings_account': savings_account_id
        })
        saving_transactionr.insert()
        saving_transactionr.submit()

        coa_account_name2 = frappe.get_doc(
                            "Account", {"name": Saving_Product.customer_balance_account}
                        )

 
        saving_transactionr2 = frappe.get_doc({
            'parent_transaction': transaction_id, 'doctype': 'General Ledger II',
            'account': coa_account_name2,
            'label_for_report': coa_account_name2.name,
            'transaction_type': 1,
            'transaction_type_name': "Deposit",
            'posting_date': datetime.now().date(),
            'company': doc.company,
            'branch': doc.branch,
            'amount': doc.amount,
            'credit':  doc.amount,
            'debit': 0,
            'main_parent': "Liabilities",
            'sub_parent': "Balances On Customer Account",
            'category': coa_account_name2,
            'savings_account': savings_account_id
        })
        saving_transactionr2.insert()
        saving_transactionr2.submit()

        deposit_fees_data = Saving_Product.get("product_charges")
        for fee in deposit_fees_data:
            charge_name = fee.get("charge")
            coa_account_name = frappe.get_doc("Charge", {"name": charge_name})

            if fee.get("branch") == doc.branch and "Deposit Fees" in coa_account_name.charge_name:
                savings_account = frappe.get_doc("Account", {"name": coa_account_name.account})
                account_name = savings_account.name
                date = nowdate()
                charge_nal = frappe.get_doc("Charge", {"name": charge_name})
                coa_account_name3 = frappe.get_doc("Account", {"name": Saving_Product.depositfees})
                transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": "Deposit Charge"})
                saving_transaction = frappe.get_doc({
                            'doctype': 'Saving Transaction',
                            'account': doc.account,
                            'transaction_type': "Deposit fees",
                              'transaction_type_name':"Deposit Fees",
                                 'user': doc.owner,
                            'posting_date': date,
                            'deposit': transaction_id,
                            'branch': doc.branch,
                            'amount': charge_nal.amount,
                            'debit': charge_nal.amount,
                            'client_account': doc.account,  # Ensure this field exists in the Saving Transaction doctype
                            'reference': doc.name,
                            'description': "Deposit Fees",
                            'is_parent': 1,
                            'allow_charges': 0
                        })
                saving_transaction.insert()
                saving_transaction.submit()



                current_user = frappe.session.user
                coa_account = frappe.db.get_value('Employee', {'user': current_user}, 'coa_account')
                coa_account_name = frappe.get_doc(
                                    "Account", {"name": Saving_Product.customer_balance_account}
                                )
                transaction_id_after = saving_transaction.name
                saving_transactionr2 = frappe.get_doc({
                    'parent_transaction': transaction_id_after,
                     'doctype': 'General Ledger II',
                    'account': coa_account_name,
                    'label_for_report': coa_account_name,
                    'transaction_type': 1,
                    'transaction_type_name': "Deposit Fees",
                    'posting_date': datetime.now().date(),
                    'company': doc.company,
                    'branch': doc.branch,
                    'amount': charge_nal.amount,
                    'credit': 0,
                    'debit': charge_nal.amount,
                    'main_parent': "Liabilities",
                    'sub_parent': "Balances On Customer Account",
                    'category': coa_account_name,
                    'savings_account': savings_account_id
                    })
                saving_transactionr2.insert()
                saving_transactionr2.submit()


               

                saving_transactionr = frappe.get_doc({
                    'parent_transaction': transaction_id_after, 'doctype': 'General Ledger II',
                    'account': account_name,
                    'label_for_report': coa_account_name3,
                    'transaction_type': 1,
                    'transaction_type_name': "Deposit fees",
                    'posting_date': datetime.now().date(),
                    'company': doc.company,
                    'branch': doc.branch,
                    'amount': charge_nal.amount,
                    'credit': charge_nal.amount,
                    'debit': 0,
                    'main_parent': "Income",
                    'sub_parent': "Income",
                    'category': coa_account_name3,
                    'savings_account': savings_account_id
                })
                saving_transactionr.insert()
                saving_transactionr.submit()

               


def update_or_create_entry(account, doc, amount, savings_account_id, transaction_type_name):

    existing_entry = frappe.get_list("General Ledger II", 
        filters={
            'account': account,
            'transaction_type_name': transaction_type_name,
            'savings_account': savings_account_id,
        },
        fields=["name", "debit", "credit"]
    )

    if existing_entry:
        for entry in existing_entry:
            debit = entry['debit']
            credit = entry['credit']
            record_name = entry['name']

            if credit < debit:
                amount_to_adjust = min(amount, debit - credit)
                # Update existing record
                frappe.db.sql("""
                    UPDATE `tabGeneral Ledger II` 
                    SET credit = credit + %s
                    WHERE name = %s
                """, (amount_to_adjust, record_name))
                frappe.db.commit()
                amount -= amount_to_adjust

                if amount <= 0:
                    break

        if amount > 0:
            # Create a new entry for the remaining amount
            create_customer_balance_entry(doc, amount, savings_account_id)

    else:
        # Create a new entry if no existing entry found
        create_customer_balance_entry(doc, amount, savings_account_id)

def create_customer_balance_entry(doc, amount, savings_account_id):
    # Implement this function to create a new entry for customer balance
    # Example:
    savacccc = frappe.get_doc("Savings Account", {"name": doc.account})
    coa_accountw = frappe.get_doc("Saving Product", {"name": savacccc.saving_product})
    coa_account = frappe.get_doc("Account", {"name": coa_accountw.customer_balance_account})  # Replace with actual account
    # saving_transactionr = frappe.get_doc({
    #     'parent_transaction': doc.name, 'doctype': 'General Ledger II',
    #     'account': coa_account.name,
    #     'label_for_report': coa_account,
    #     'transaction_type': 1,
    #     'transaction_type_name': "Customer Balance",
    #     'posting_date': datetime.now().date(),
    #     'company': doc.company,
    #     'branch': doc.branch,
    #     'amount': amount,
    #     'credit': amount,
    #     'debit': 0,
    #     'main_parent': "Liabilities",
    #     'sub_parent': "Balances On Customer Account",
    #     'category': coa_account.name,
    #     'savings_account': savings_account_id
    # })
    # saving_transactionr.insert()
    # saving_transactionr.submit()

    # current_user = frappe.session.user
    # coa_account = frappe.db.get_value('Employee', {'user': current_user}, 'coa_account')
    # coa_account_name = frappe.get_doc(
    #                     "Account", {"name": coa_account}
    #                 )

    # saving_transactionr2 = frappe.get_doc({
    #     'parent_transaction': doc.name, 'doctype': 'General Ledger II',
    #     'account': coa_account_name.name,
    #     'label_for_report': coa_account,
    #     'transaction_type': 1,
    #     'transaction_type_name': "Customer Balance",
    #     'posting_date': datetime.now().date(),
    #     'company': doc.company,
    #     'branch': doc.branch,
    #     'amount': amount,
    #     'credit': 0,
    #     'debit': amount,
    #     'main_parent': "Assets",
    #     'sub_parent': "Cash & Cash Equivalents",
    #     'category': coa_account_name.name,
    #     'savings_account': savings_account_id
    # })
    # saving_transactionr2.insert()
    # saving_transactionr2.submit()


def create_customer_balance_entry2(doc, amount, savings_account_id):
    # Implement this function to create a new entry for customer balance
    # Example:
    savacccc = frappe.get_doc("Savings Account", {"name": doc.account})
    Saving_Product = frappe.get_doc("Saving Product", {"name": savacccc.saving_product})
    coa_account_name2 = frappe.get_doc(
                            "Account", {"name": Saving_Product.customer_balance_account}
                        )
 # Replace with actual account
    saving_transactionr = frappe.get_doc({
        'parent_transaction': doc.name, 'doctype': 'General Ledger II',
        'account': coa_account_name2,
        'label_for_report': coa_account_name2,
        'transaction_type': 1,
        'transaction_type_name': "Customer Balance",
        'posting_date': datetime.now().date(),
        'company': doc.company,
        'branch': doc.branch,
        'amount': amount,
        'credit': amount,
        'debit': 0,
        'main_parent': "Liabilities",
        'sub_parent': "Balances On Customer Account",
        'category': coa_account_name2,
        'savings_account': savings_account_id
    })
    saving_transactionr.insert()
    saving_transactionr.submit()

    current_user = frappe.session.user
    coa_account = frappe.db.get_value('Employee', {'user': current_user}, 'coa_account')
    coa_account_name = frappe.get_doc(
                        "Account", {"name": coa_account}
                    )



def get_phone_number(table, column, namer):
    query = f"SELECT {column} FROM `tab{table}` WHERE name = %s"
    result = frappe.db.sql(query, (namer,), as_dict=True)
    
    if not result:
        frappe.throw(f"Client with name {namer} not found in table {table}.")
    
    return result[0][column]


def send_otp2(account, posting_date, typer, amounter, agent):
    savings_account2 = frappe.get_doc("Savings Account", {"name": account.name})
    typer = savings_account2.client_type
    

    if savings_account2.client_type == "Client":
        phone_number = get_phone_number("Client", "mobile", savings_account2.client)
        client_name = get_phone_number("Client", "full_name", savings_account2.client)
    elif savings_account2.client_type == "Group Account":
        phone_number = get_phone_number("Group Account", "mobile",  savings_account2.client)
        client_name = get_phone_number("Group Account", "full_name", savings_account2.client)
    elif savings_account2.client_type == "Joint Accounts":
        phone_number = get_phone_number("Joint Accounts", "mobile",  savings_account2.client)
        client_name = get_phone_number("Joint Accounts", "full_name", savings_account2.client)
       

    send_sms_notification(client_name, account.saving_product_name, account.name, phone_number, posting_date, amounter, agent)
 
def send_sms_notification(client_name, account, account2,  phone_number, posting_date, amounter, agent):
    user = frappe.session.user
    ID = frappe.db.get_value('Employee', {'user': user}, 'name')
    ID2 = frappe.db.get_value('Employee', {'user': user}, 'full_name')
    bal = get_phone_number("Savings Account", "balance_derived", account2)
    posting_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')



    try:
        # Prepare the SMS message content
        # message = (
        #     f"Deposit  UGX {amounter:,.0f} with Agent.{ID}.Account {account2} Bal.{bal:,.0f}  Date: {posting_date}"
        # )
        
        from_date = "2019-01-01"
        to_date = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")  # tomorrow

        # Call the function and store the result
        report_last = generate_savings_report_last(account=account2, from_date=from_date, to_date=to_date, account2="NULL", ag=ID2)

        # Balance:{AccountNumber}.
        # Access returned values
        last_balance = report_last["last_balance"]
        last_balance_formatted = "{:,}".format(last_balance)
        last_date = report_last["last_date"]
        message = (
            f"Deposit  UGX {amounter:,.0f} with Agent.{ID}.Account {account2} .Balance {last_balance_formatted}. Date: {posting_date} Thnks 4 Choosing Uwezo"
        )

        # Prepare the URL for the SMS API request

        phone_number_clean = urllib.parse.quote(phone_number.replace("-", ""))
        message_encoded = urllib.parse.quote(message)
        send_message_to_clients_opening(
            recipients=phone_number_clean,
            message=message
        )
        # url = f"https://mortarbulksms.online/apisend_uwezo2.php?number={phone_number_clean}&name={message_encoded}"

        # # Set headers for the API request
        # headers = {
        #     'Content-Type': 'application/json',
        #     'Accept': 'application/json',
        #     'Authorization': 'Bearer 68o3IgTdNwAvm0BBGDVeklrdUoJKXDIzRWRpYzRVIP5MKr4CPkpfZJAjc38He1lDtDTGXIJy6BwLkO8x'
        # }

        # # Send the GET request to the SMS API
        # response = requests.get(url, headers=headers)
        # response.raise_for_status()  # Raise an HTTPError for bad responses
        

    except requests.exceptions.RequestException as e:
        # Handle specific exceptions from the requests library
        frappe.throw(f"Error sending SMS: {e}")
    except Exception as error:
        # Handle any other unexpected errors
        frappe.throw(f"An unexpected error occurred: {error}")



def flag_deposit(doc):
    doc.flagged = 1
    doc.save()
    frappe.db.commit()

def flag_deposit2(deposit_id):
    doc = frappe.get_doc("Deposit", deposit_id)
    doc.flagged = 1
    doc.save()
    frappe.db.commit()

def on_flagging(doc):
    if doc.flagged == 1:
        frappe.get_doc({
            'doctype': 'Account Hold',
            'account': doc.account,
            'reason': 'Flagged Deposit',
            'reference': doc.name
        }).insert()
        frappe.db.commit()
