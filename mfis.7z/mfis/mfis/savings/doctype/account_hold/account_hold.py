# Copyright (c) 2023, Abbey and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document

class AccountHold(Document):
	def on_change(self):
		update_available_balance(self)


@frappe.whitelist()
def unhold(doc, method=None):
	doc = frappe.get_doc("Account Hold", doc)

	if doc:
		doc.active = 0
		doc.save()

def update_available_balance(doc, method=None):
	from mfis.savings.doctype.savings_account.savings_account import calculate_available_balance

	available_balance = calculate_available_balance(doc.account)

	frappe.db.set_value("Savings Account", doc.account, {
		'available_balance_derived': available_balance
	})
