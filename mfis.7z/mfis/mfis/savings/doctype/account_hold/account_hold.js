// Copyright (c) 2023, Abbey and contributors
// For license information, please see license.txt

frappe.ui.form.on('Account Hold', {
	refresh: function(frm) {
        frm.set_value({
            "held_on": frappe.datetime.get_today()
        })

        frm.add_custom_button('Unhold', () => {
                frappe.confirm("Are you sure you want to proceed", () => {
                    frappe.call({
                        method: 'mfis.savings.doctype.account_hold.account_hold.unhold',
                        args: {
                            doc: frm.doc.name
                        },
                        freeze: true,
                        callback: (r) => {
                            frappe.msgprint("Account updated")
                        },
                        error: (e) => {
                            frappe.msgprint("Something went wrong")
                        }
                    })
                })
            })
	},
    account: function (frm){
        frappe.db.get_value("Savings Account", frm.doc.account, ["balance_derived"])
            .then(r => {
                let values = r.message;

                let amount = values.balance_derived

                frm.set_value({
                    "amount": amount
                })
            })
    }
});
