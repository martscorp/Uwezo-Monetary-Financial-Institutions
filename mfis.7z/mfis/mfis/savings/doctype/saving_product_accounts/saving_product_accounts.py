# Copyright (c) 2023, Abbey and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document
from mfis.savings.doctype.saving_transaction_type.saving_transaction_type import get_saving_transaction_type


class SavingProductAccounts(Document):

    def validate(self):
        self.validate_duplicate_branch()

    def validate_duplicate_branch(self):
        if self.is_new():
            exists = frappe.db.exists("Saving Product Accounts", {
                "branch": self.branch,
                "saving_product": self.saving_product
            })

            if exists:
                frappe.throw("Rule already exists")

    # def on_change(self):
    #     create_accounting_rules(self)


def create_accounting_rules(doc, method=None):
    default_cash_account = frappe.get_value('Branch', doc.branch, 'default_cash_account')

    if default_cash_account is None:
        frappe.throw("Please add default cash account")

    # deposit_accounting_rule
    if doc.portfolio_account:
        deposit_type = frappe.db.get_value("Saving Transaction Type", {"alias_name": "deposit"})

        deposit_accounts = [
            {
                "account": default_cash_account,
                "entry_type": "debit",
                "is_user_account": 1
            },
            {
                "account": doc.portfolio_account,
                "entry_type": "credit",
                "is_user_account": 0
            }
        ]
        update_or_create_rule(deposit_type, doc, deposit_accounts)

        withdraw_type = frappe.db.get_value("Saving Transaction Type", {"alias_name": "withdraw"})

        withdraw_accounts = [
            {
                "account": default_cash_account,
                "entry_type": "credit",
                "is_user_account": 1
            },
            {
                "account": doc.portfolio_account,
                "entry_type": "debit",
                "is_user_account": 0
            }
        ]

        update_or_create_rule(withdraw_type, doc, withdraw_accounts)

    if doc.overdraw_account:
        withdraw_type = frappe.db.get_value("Saving Transaction Type", {"alias_name": "withdraw"})

        withdraw_accounts = [
            {
                "account": default_cash_account,
                "entry_type": "credit",
                "is_user_account": 1
            },
            {
                "account": doc.overdraw_account,
                "entry_type": "debit",
                "is_user_account": 0
            }
        ]

        update_or_create_rule(withdraw_type, doc, withdraw_accounts, True)


def update_or_create_rule(transaction_type, doc, deposit_accounts, is_overdraft=False):
    deposit_rules = {
        "doctype": "Accounting Rule",
        "branch": doc.branch,
        "disabled": 0,
        "transaction_type_of": "Saving Transaction Type",
        "transaction_type": transaction_type,
        "saving_product": doc.saving_product,
        "saving_charge": None,
        "is_overdraft": is_overdraft
    }
    exists = frappe.db.exists(deposit_rules)

    if exists:
        deposit_rule = frappe.get_doc("Accounting Rule", exists)
        deposit_rule.accounts = []
        for acc in deposit_accounts:
            deposit_rule.append("accounts", acc)

        deposit_rule.save()

    else:
        deposit_rule = frappe.get_doc(deposit_rules)
        deposit_rule.accounts = []
        for acc in deposit_accounts:
            deposit_rule.append("accounts", acc)

        deposit_rule.save()
