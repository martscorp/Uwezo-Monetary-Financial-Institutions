// Copyright (c) 2023, Abbey and contributors
// For license information, please see license.txt
frappe.provide("mfis.saving_product_accounts");

// frappe.ui.form.on('Saving Product Accounts', {
// 	refresh: function(frm) {
//         frm.set_query('overdraw_account', function(doc) {
// 			return {
// 				filters: {
// 					"is_group": 0,
// 					"branch": doc.branch,
//                     "root_type": "Asset",
//                     "account_type": "Receivable"
// 				}
// 			};
// 		});
//         frm.set_query('portfolio_account', function(doc) {
// 			return {
// 				filters: {
// 					"is_group": 0,
// 					"branch": doc.branch,
//                     "root_type": "Liability",
//                     "account_type": "Payable"
// 				}
// 			};
// 		});
// 		frm.set_query('inter_branch_account', function(doc) {
// 			return {
// 				filters: {
// 					"is_group": 0,
// 					"branch": doc.branch,
//                     // "root_type": "Liability",
//                     // "account_type": "Payable"
// 				}
// 			};
// 		});
//
// 	}
// });

