# Copyright (c) 2022, Abbey and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document
from datetime import datetime
import mfis.savings.doctype.saving_transaction_type.saving_transaction_type as saving_transaction_types
from frappe.utils import cint, flt, getdate, get_date_str, update_progress_bar
from frappe.utils.background_jobs import enqueue
from mfis.accounts.general_ledger import make_reverse_gl_entries, ClosedAccountingPeriod
from mfis.savings.doctype.overdraft_account.overdraft_account import update_overdraft_balances
# import  mfis.savings.doctype.saving_transaction_type.saving_transaction_type.get_saving_transaction_type_alias as get_transaction_type

from mfis.savings.doctype.saving_transaction_type.saving_transaction_type import \
    get_saving_transaction_type_alias as get_transaction_type


class SavingTransaction(Document):
    def validate(self):
        self.validate_company()
        self.get_post_type()
        self.is_active_account()
        validate_pay_charge(self)
        validate_transfer_transaction(self)
        # validate_accounting_period(self)
        if self.is_import == 1:
            frappe.local.flags.ignore_accounting_periods = True

    def validate_company(self):
        company = self.get('company', None)

        if company is None:
            company = frappe.get_cached_value("Branch", self.get('branch'), "company")

            if company is None:
                frappe.throw("Company is required")
        self.company = company

    def autoname(self):
        if self.external_id:
            self.name = str(self.external_id)

    def before_save(self):
        self.status = 'Approved'
        self.savings_officer = frappe.session.user
        if self.is_import == 1:
            frappe.local.flags.ignore_accounting_periods = True
            frappe.local.flags.ignore_gl_entry = True

    def get_post_type(self):
        transaction_type = frappe.get_doc("Saving Transaction Type", self.transaction_type)


    # def before_submit(self):
    #     self.flags.ignore_permissions = True

    def on_submit(self):
        ff=0
        # self.flags.ignore_permissions = True
        # if self.is_import == 1:
        #     frappe.local.flags.ignore_accounting_periods = True
        #     frappe.local.flags.ignore_gl_entry = True

    def is_active_account(self):
        account = frappe.get_doc("Savings Account", self.account)
        if account:
            status = account.status
            if status not in ["Active", "Approved"]:
                ff=0
                # frappe.throw("Account not active")
        else:
            frappe.throw("Invalid account")

    def on_cancel(self):
        # super(SavingTransaction, self).on_cancel()

        self.make_gl_entries_on_cancel()

    def make_gl_entries_on_cancel(self):
        if frappe.db.sql(
                """select name from `tabGL Entry` where voucher_type=%s
                and voucher_no=%s""",
                (self.doctype, self.name),
        ):
            self.make_gl_entries()

    def make_gl_entries(self, gl_entries=None, from_repost=False):
        if self.docstatus == 2:
            make_reverse_gl_entries(voucher_type=self.doctype, voucher_no=self.name)

        self.ignore_linked_doctypes = (
            "GL Entry",
        )

    def on_change(self):
        if self.docstatus == 1:
            self.make_gl_entries_on_cancel()

    def before_cancel(self):
        cancel_charges(self)
        cancel_bank_transaction(self)
        delete_overdrafts(self)


def cancel_bank_transaction(doc):
    frappe.db.delete("Bank Transactions", {"saving_transaction": doc.name})


def delete_overdrafts(doc):
    frappe.db.delete("Overdraft Account", {"transaction": doc.name})


def update_charges(doc, method=None):
    if doc.is_parent == 1 and doc.allow_charges == 1 and doc.is_import == 0:

        # delete all charges
        frappe.db.delete("Saving Transaction", {'is_parent': 0, 'parent_transaction': doc.name})

        account = frappe.get_doc("Savings Account", doc.account)

        transaction_type = saving_transaction_types.get_saving_transaction_type(doc.transaction_type)

        import mfis.savings.doctype.savings_charges.savings_charges as savings_charges

        # fees, charges = savings_charges.get_charges(account.saving_product, transaction_type.type_name, doc.amount, 0,
        #                                             doc.branch)

        # if len(charges) > 0:
        #     for charge in charges:
        #         calculate_charge_fees(doc, charge)

        # doc.fees_total = fees

        # # frappe.throw(f"{doc.fees_total}")
        # frappe.db.set_value('Saving Transaction', doc.name, 'fees_total', fees)


def calculate_charge_fees(doc, savings_charge):
    make_charge_transaction(
        client_account=doc.account,
        date=doc.posting_date,
        branch=doc.branch,
        amount=savings_charge.get('amount'),
        charge=savings_charge.get('charge'),
        parent_transaction=doc.name,
        description=savings_charge.get('charge_name', 'Apply charge')
    )


def submit_charges(doc, method=None):
    if doc.is_parent == 1 and doc.is_import == 0:
        enqueue(
            method=_submit_charges(doc),
            queue="long",
            timeout=300,
            event=None,
            is_async=True,
            job_name=None,
            now=False,
        )


def _submit_charges(doc):
    children_transactions = frappe.db.get_list("Saving Transaction",
                                               filters={'is_parent': 0, 'parent_transaction': doc.name})
    if children_transactions:
        for child_transaction in children_transactions:
            doc = frappe.get_doc("Saving Transaction", child_transaction.name)
            doc.flags.ignore_permissions = True
            doc.submit()


def cancel_charges(doc, method=None):
    if doc.is_parent == 1:
        children_transactions = frappe.db.get_list("Saving Transaction",
                                                   filters={'is_parent': 0, 'parent_transaction': doc.name})

        if children_transactions:
            for child_transaction in children_transactions:
                frappe.db.set_value("Saving Transaction", child_transaction.name, {
                    "is_cancelled": 1,
                    "status": "Cancelled",
                })
                frappe.get_doc("Saving Transaction", child_transaction.name).cancel()


def update_client_balance(doc, method=None):
    if doc.is_import == 0:
        _update_client_balances(doc)
    # enqueue(
    #     method=_update_client_balances(doc),
    #     queue="long",
    #     timeout=300,
    #     event=None,
    #     is_async=True,
    #     job_name=None,
    #     now=False,
    # )


def _update_client_balances(doc):
    from frappe.query_builder.functions import _sum
    posting_date = doc.posting_date
    total_deposits_derived = _sum("Saving Transaction", "credit", filters={
        # "docstatus": 1,
        "account": doc.account,
        # "posting_date": ["<=", getdate(posting_date)],
        "is_cancelled": 0
    }) or 0

    total_withdrawals_derived = _sum("Saving Transaction", "debit", filters={
        # "docstatus": 1,
        "account": doc.account,
        # "posting_date": ["<=", getdate(posting_date)],
        "is_cancelled": 0
    }) or 0

    # update derived balance
    from mfis.savings.doctype.savings_account.savings_account import (calculate_account_balance,
                                                                      calculate_available_balance)
    balance = calculate_account_balance(doc.account)
    available_balance = calculate_available_balance(doc.account)

    frappe.db.set_value("Savings Account", doc.account, {
        'total_withdrawals_derived': total_withdrawals_derived,
        'total_deposits_derived': total_deposits_derived,
        'balance_derived': balance,
        'available_balance_derived': available_balance
    })

    # doc.reload()
    # doc.balance = balance
    frappe.db.set_value("Saving Transaction", doc.name, 'balance', balance)
    # doc.save()


def bulk_update_balances():
    accounts = frappe.db.get_list("Savings Account",
                                  filters={
                                      "status": "Active"
                                  },
                                  fields=["name", "balance_derived"],
                                  limit_page_length=7000
                                  )

    for index, account in enumerate(accounts, start=1):
        update_progress_bar("Updating account balances", index, len(accounts))
        balance = 0
        credits_derived = 0
        debits = 0

        transactions = frappe.db.get_list(
            "Saving Transaction",
            filters={
                "is_cancelled": 0,
                "account": account.name
            },
            fields=["amount", "credit", "debit", "name"],
            order_by='posting_date asc'
        )

        for transaction in transactions:
            credit = transaction["credit"]
            credits_derived += credit
            debit = transaction["debit"]
            debits += debit
            balance += credit - debit
            frappe.db.set_value("Saving Transaction", transaction["name"], {
                "balance": balance,
                "docstatus": 1
            })

        frappe.db.set_value("Savings Account", account.name, {
            "available_balance_derived": balance,
            "total_withdrawals_derived": debits,
            "balance_derived": balance,
            "total_deposits_derived": credits_derived,
            "updated_balance": '1'
        })


def update_last_transaction_date(doc, method=None):
    if doc.is_import == 0:
        # if saving_account:
        frappe.db.set_value("Savings Account", doc.account, {
            "last_transaction_date": doc.posting_date
        })


@frappe.whitelist()
def make_charge_transaction(charge_type="apply_charge", **kwargs):
    if charge_type not in ["apply_charge", "pay_charge"]:
        return

    # frappe.throw(f'{kwargs}')

    transaction_type = get_transaction_type(charge_type, True)

    if kwargs.get('charge_trans_type') is None:
        charge_trans_type = "Charges"
    else:
        charge_trans_type = kwargs.get('charge_trans_type')

    account_branch = frappe.get_value("Savings Account", kwargs.get("client_account"), "branch")

    is_parent = 1

    

    doc = frappe.get_doc({
        'doctype': 'Saving Transaction',
        'account': kwargs.get("client_account"),
        'transaction_type': transaction_type,
        'posting_date': kwargs.get("date"),
        'branch': kwargs.get("branch"),
        'amount': kwargs.get("amount"),
        'reference': kwargs.get("reference"),
        'charge': kwargs.get("charge"),
        'description': kwargs.get("description"),
        'is_parent': is_parent,
        'allow_charges': 0,
        'allow_overdraw': 1,
        'parent_transaction': kwargs.get("parent_transaction"),
        'charge_type': charge_trans_type,
        'loan': kwargs.get('loan', None),
        'loan_application': kwargs.get('loan_application', None),
        'account_branch': account_branch
    })

    doc.insert(ignore_permissions=True)
    doc.submit()

    if charge_type == "pay_charge":
        frappe.db.set_value("Saving Transaction", kwargs.get("parent_transaction"), "is_charge_paid", 1)


def validate_pay_charge(doc):
    transaction_type = get_transaction_type('pay_charge', True)
    if doc.transaction_type == transaction_type:
        parent_transaction = doc.parent_transaction

        if parent_transaction is None or "":
            frappe.throw("Please select charge being paid")

        transaction = frappe.get_doc("Saving Transaction", parent_transaction)

        if transaction is None:
            frappe.throw("Invalid Parent Transaction")

        appy_charge_type = get_transaction_type("apply_charge", True)

        parent_transactions_count = frappe.db.count("Saving Transaction", {"docstatus": "1",
                                                                           "parent_transaction": transaction.name,
                                                                           "transaction_type": appy_charge_type})

        if parent_transactions_count > 0:
            frappe.throw("Charge already paid")


def update_charge_payment(doc, method=None):
    transaction_type = get_transaction_type('pay_charge', True)

    if transaction_type == doc.transaction_type and doc.is_import == 0:
        if doc.parent_transaction is not None:
            frappe.db.set_value("Saving Transaction", doc.parent_transaction, "is_charge_paid", 1)


def check_account_balance_before_withdraw(doc, method=None):
    if doc.is_import == 0:
        transaction_types = frappe.db.get_list("Saving Transaction Type",
                                               filters=[
                                                   ['credit', '=', '0']
                                               ],
                                               pluck='name'
                                               )

        if doc.transaction_type in transaction_types:

            withdraw_type = get_transaction_type("withdraw", True)

            amount = doc.amount

            savings_account = frappe.get_doc("Savings Account", doc.account)
            balance_derived = savings_account.available_balance()

            # print(f'{balance_derived}')

            saving_product = savings_account.saving_product
            overdraft_derived = savings_account.overdraft_derived

            if doc.transaction_type == withdraw_type:
                amount = amount + doc.fees_total

            allow_overdraft, overdraft_limit, min_required_balance, enforce_min_required_balance = frappe.db.get_value(
                "Saving Product", saving_product,
                ['allow_overdraft', 'overdraft_limit', 'min_required_balance', 'enforce_min_required_balance'])

            


def update_overdraft(doc, method=None):
    from mfis.savings.doctype.savings_account.savings_account import update_overdraft as acc_update_overdraft

    if doc.is_import == 0:
        enqueue(
            method=acc_update_overdraft(doc.account),
            queue="long",
            timeout=300,
            event=None,
            is_async=True,
            job_name=None,
            now=False,
        )


def create_account_overdraft(doc, savings_account, new_overdraft):
    if doc.is_import == 0:
        enqueue(
            method=_create_account_overdraft(doc, new_overdraft, savings_account),
            queue="long",
            timeout=300,
            event=None,
            is_async=True,
            job_name=None,
            now=False,
        )


def _create_account_overdraft(doc, new_overdraft, savings_account):
    overdraft_doc = frappe.get_doc({
        "doctype": "Overdraft Account",
        "account": savings_account.name,
        "amount": new_overdraft,
        "posting_date": doc.posting_date,
        "transaction": doc.name,
        "total_due": new_overdraft
    })
    overdraft_doc.insert(ignore_permissions=True)
    doc.flags._overdraw = new_overdraft or 0


def save_transaction_overdraft(doc, method=None):
    if doc.is_import == 0:
        frappe.db.set_value("Saving Transaction", doc.name, 'overdraft', doc.flags._overdraw or 0)


def activate_account_on_first_deposit(doc, method=None):
    if doc.transaction_type_name == "Deposit" and doc.is_import == 0:
        enqueue(
            method=_activate_account_on_first_deposit(doc),
            queue="long",
            timeout=300,
            event=None,
            is_async=True,
            job_name=None,
            now=False,
        )


def _activate_account_on_first_deposit(doc):
    
    old_doc = doc.get_doc_before_save()
    savings_account_id = doc.name
    if old_doc and doc.status == "Approved" and old_doc.status in ["Pending"] and cint(doc.is_old_account) == 0:
        charge_time_type = [18, 2]
        savings_product = frappe.get_doc("Saving Product", {"name": doc.saving_product})

        for charge in savings_product.product_charges:

          if charge.charge == "CH-0120" and charge.branch == doc.branch:

            charge_value = charge.charge
          

            charge_nal = frappe.get_doc("Charge", {"name": charge_value})
            savings_account = frappe.get_doc("Account", {"name": charge_nal.account})
            account_name = savings_account.name
            amount = charge_nal.amount
            transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": 12})

            saving_transaction = frappe.get_doc({
                'doctype': 'Saving Transaction',
                'account': doc.name,
                'transaction_type': transaction_type,
                'posting_date':  datetime.now().date(),
                'branch': doc.branch,
                'amount': amount,
                'debit': amount,
                'client_account': doc.name,  # Ensure this field exists in the Saving Transaction doctype
                'reference': doc.name,
                'description': f'Account Opening',
                'is_parent': 1,
                'allow_charges': 0
            })

            saving_transaction.insert()
            saving_transaction.submit()

    
            saving_transactionr = frappe.get_doc({
                'doctype': 'General Ledger II',
                'account': charge.get('account'),
                'label_for_report': account_name,
                'transaction_type': transaction_type,
                'transaction_type_name': "Account Opening",
                'posting_date': datetime.now().date(),
                'company': doc.company,
                'branch': doc.branch,  # Ensure this field exists in the Saving Transaction doctype
                'amount': amount,
                'credit': 0,
                'debit': amount,  # Ensure this field exists in the Saving Transaction doctype
                'main_parent': "Assets",
                'sub_parent': "Debtors & Receivables",
                'category': account_name,
                'savings_account': savings_account_id
            })
            saving_transactionr.insert()
            saving_transactionr.submit()

            saving_transactionr2 = frappe.get_doc({
                'doctype': 'General Ledger II',
                'account': account_name,
                'label_for_report': account_name,
                'transaction_type': transaction_type,
                'transaction_type_name': "Account Opening",
                'posting_date': datetime.now().date(),
                'company': doc.company,
                'branch': doc.branch,  # Ensure this field exists in the Saving Transaction doctype
                'amount': amount,
                'credit': amount,
                'debit': 0,  # Ensure this field exists in the Saving Transaction doctype
                'main_parent': "Income",
                'sub_parent': "Income",
                'category': account_name,
                'savings_account': savings_account_id
            })
            saving_transactionr2.insert()
            saving_transactionr2.submit()


def handle_transfer_transactions(doc, method=None):
    enqueue(
        method=_handle_transfer(doc),
        queue="long",
        timeout=300,
        event=None,
        is_async=True,
        job_name=None,
        now=False,
    )


def _handle_transfer(doc):
    transfer_type = get_transaction_type("transfer", True)
    if doc.transaction_type == transfer_type:
        to_account = frappe.get_doc("Savings Account", doc.to_account)

        deposit_type = get_transaction_type("deposit", True)

        # frappe.throw(f'{to_account}')
        deposit = frappe.get_doc({
            'doctype': 'Saving Transaction',
            'account': doc.to_account,
            'transaction_type': deposit_type,
            'posting_date': doc.posting_date,
            'branch': doc.branch,
            'amount': doc.amount,
            'reference': f'account-transfer-{doc.account}-to-{doc.to_account}',
            'description': f'{doc.account} transfer to {doc.to_account}',
            'is_parent': 1,
            'allow_charges': 0,
            'allow_overdraw': 0,
            'parent_transaction': doc.name,
        })

        deposit.insert(ignore_permissions=True)
        deposit.submit()


def validate_transfer_transaction(doc):
    transaction_type = get_transaction_type("transfer", True)

    if doc.transaction_type == transaction_type:
        if doc.to_account is None:
            frappe.throw("Please enter to account")

        if doc.to_account == doc.account:
            frappe.throw("Both numbers cant be the same")

        to_account = frappe.get_doc("Savings Account", doc.to_account)

        if to_account is None:
            frappe.throw("Invalid account provided")

        if to_account.status not in ['Active', 'Approved']:
            frappe.throw("Account is not active yet")

import frappe
from frappe.utils import now

def create_deposit_transaction(doc, method=None):
    deposit_type = get_transaction_type("deposit", True)

    # Lock table so two inserts don't get same ID
    frappe.db.sql("LOCK TABLES `tabSaving Transaction` WRITE")

    # Get last numeric transaction ID
    last_id = frappe.db.sql("""
        SELECT CAST(name AS UNSIGNED)
        FROM `tabSaving Transaction`
        ORDER BY CAST(name AS UNSIGNED) DESC
        LIMIT 1
    """)
    next_id = (last_id[0][0] + 1) if last_id else 1

    # Insert new Saving Transaction directly
    frappe.db.sql("""
        INSERT INTO `tabSaving Transaction`
        (name, creation, modified, modified_by, owner, docstatus, account, transaction_type,transaction_type_name,
         posting_date, branch, amount, reference, description, is_parent, deposited_by, allow_charges,
         allow_overdraw, deposit, is_opening, account_branch)
        VALUES
        (%s, %s, %s, %s, %s, 1, %s, %s,%s,
         %s, %s, %s, %s, %s, 1, %s, %s,
         0, %s, %s, %s)
    """, (
        str(next_id), now(), now(), frappe.session.user, frappe.session.user,
        doc.account, deposit_type,"Deposit",
        doc.posting_date, doc.branch, doc.amount, f"deposit-{doc.name}",
        f"Deposit {doc.amount} by {doc.deposited_by}",
        doc.deposited_by, doc.allow_charges,
        doc.name, doc.is_opening, doc.account_branch
    ))

    # Unlock table
    frappe.db.sql("UNLOCK TABLES")

    # Update Deposit doc with transaction id
    frappe.db.sql("""
        UPDATE `tabDeposit`
        SET savings_id = %s, fees_total = 0
        WHERE name = %s
    """, (str(next_id), doc.name))

    return str(next_id)





def create_withdraw_transaction(doc, method=None):
    withdraw_type = get_transaction_type("withdraw", True)

    withdraw = frappe.get_doc({
        'doctype': 'Saving Transaction',
        'account': doc.account,
        'user': doc.user,
        'transaction_type': withdraw_type,
        'posting_date': doc.posting_date,
        'branch': doc.branch,
        'amount': doc.amount,
        'reference': "withdraw-{name}".format(name=doc.name),
        'description': "Withdraw {amount}".format(amount=doc.amount),
        'is_parent': 1,
        'allow_charges': doc.allow_charges,
        'allow_overdraw': 0,
        'is_representative': doc.is_representative,
        'representative': doc.representative or None,
        'withdraw': doc.name,
        'account_branch': doc.account_branch
    })

    withdraw.insert(ignore_permissions=True)
    withdraw.submit()

    doc.transaction = withdraw.name
    doc.fees_total = withdraw.fees_total
    doc.save()

    # create_new_cycle(doc)


def create_new_cycle(doc):
    account, is_fixed, saving_product = frappe.db.get_value("Savings Account", doc.account,
                                                            ["name", "is_fixed", "saving_product"])

    if cint(is_fixed) == 1:
        conditions = {'saving_account': account, 'docstatus': 1, 'active': 1}
        cycle_exists = frappe.db.exists("Lockin Period Cycle",
                                        conditions)

        if cycle_exists:
            cycle = frappe.db.get_value("Lockin Period Cycle", conditions, 'name')

            if cycle:

                frequency_type, frequency = frappe.db.get_value("Saving Product", saving_product,
                                                                ["lockin_period_frequency_type",
                                                                 "lockin_period_frequency"])

                if frequency > 0:
                    apply_penalty_for_fixed_withdraw(doc, saving_product)

                    frappe.db.set_value("Lockin Period Cycle", cycle, 'active', 0)

                    lockin_period_cycle = frappe.get_doc({
                        "doctype": "Lockin Period Cycle",
                        "saving_account": account,
                        "frequency_type": frequency_type,
                        "frequency": frequency,
                        "start_date": frappe.utils.today()
                    })

                    lockin_period_cycle.save()
                    lockin_period_cycle.submit()

                    frappe.db.set_value("Savings Account", account, "is_fixed", 1)


                else:
                    frappe.db.set_value("Savings Account", account, "is_fixed", 0)
                    frappe.db.set_value("Lockin Period Cycle", cycle, 'active', 0)


def apply_penalty_for_fixed_withdraw(doc, saving_product):
    conditions = {'saving_account': doc.account, 'docstatus': 1, 'active': 1}

    start_date, end_date = frappe.db.get_value("Lockin Period Cycle", conditions, ["start_date", "end_date"])

    # frappe.throw(frappe.utils.getdate(doc.posting_date))

    if frappe.utils.getdate(start_date) <= frappe.utils.getdate(doc.posting_date) <= frappe.utils.getdate(end_date):
        # transaction_type = saving_transaction_types.get_saving_transaction_type(doc.transaction_type)

        import mfis.savings.doctype.savings_charges.savings_charges as savings_charges

        # fees, charges = savings_charges.get_charges(saving_product=saving_product, charge_time_type_name="Withdraw",
        #                                             transaction_amount=doc.amount, is_penalty=1, branch=doc.branch)

        # if len(charges) > 0:
        #     for charge in charges:
        #         calculate_charge_fees(doc, charge)


def create_transfer_transaction(doc, method=None):
    transfer_type = get_transaction_type("transfer", True)

    transfer = frappe.get_doc({
        'doctype': 'Saving Transaction',
        'account': doc.account,
        'to_account': doc.to_account,
        'transaction_type': transfer_type,
        'posting_date': doc.posting_date,
        'branch': doc.branch,
        'amount': doc.amount,
        'reference': "transfer-{name}".format(name=doc.name),
        'description': f"Transfer {doc.amount} from {doc.account} to {doc.to_account}",
        'is_parent': 1,
        'allow_charges': 1,
        'allow_overdraw': 0,
        'transfer': doc.name,
        'account_branch': doc.account_branch
    })

    transfer.insert(ignore_permissions=True)
    transfer.submit()


def create_apply_charge_transaction(doc, method=None):
    transaction_type = get_transaction_type('apply_charge', True)

    charge_transaction = frappe.get_doc({
        'doctype': 'Saving Transaction',
        'account': doc.account,
        'transaction_type': transaction_type,
        'posting_date': doc.posting_date,
        'branch': doc.branch,
        'amount': doc.amount,
        'reference': f'apply-charge-{doc.name}',
        'charge': doc.charge,
        'description': f'Apply charge {doc.charge_name}: {doc.amount}',
        'is_parent': 1,
        'allow_charges': 0,
        'allow_overdraw': 1,
        'charge_type': doc.charge_type,
        'apply_charge': doc.name,
        'account_branch': doc.account_branch
        # 'loan': kwargs.get('loan', None),
        # 'loan_application': kwargs.get('loan_application', None)
    })

    charge_transaction.insert(ignore_permissions=True)
    charge_transaction.submit()
    savings_account_id = doc.account
    savings_charge = frappe.get_doc(doc.charge_type, {"name": doc.charge})
    charge = frappe.get_doc("Charge", {"name": savings_charge.charge})
    amount_disbursed = charge.amount
    coa_account_name3 = frappe.get_doc(
                        "Account", {"name": charge.account}
                    )
    
    saving_transactionr = frappe.get_doc({'doctype': 'General Ledger II','account': charge.account,'label_for_report': coa_account_name3,'transaction_type': 1,'transaction_type_name': "Apply Charge",'posting_date': datetime.now().date(),'company': doc.company,'branch': doc.branch, 'amount': amount_disbursed,'credit': amount_disbursed,'debit': 0, 'main_parent': "Income",'sub_parent': "Income",'category': coa_account_name3,'savings_account': savings_account_id
    })
    saving_transactionr.insert()
    saving_transactionr.submit()

    savings_accout = frappe.get_doc("Savings Account", {"name": doc.account})
    saving_product = frappe.get_doc("Saving Product", {"name": savings_accout.saving_product})
    coa_account_name2 = frappe.get_doc("Account", {"name": saving_product.customer_balance_account})
    saving_transactionr2 = frappe.get_doc({'doctype': 'General Ledger II','account': saving_product.customer_balance_account,'label_for_report': coa_account_name2,'transaction_type': 1,'transaction_type_name': "Apply Charge",'posting_date': datetime.now().date(),'company': doc.company,'branch': doc.branch, 'amount': amount_disbursed,'credit': 0,'debit': amount_disbursed, 'main_parent': "Liabilities",'sub_parent': "Balances On Customer Account",'category': coa_account_name2,'savings_account': savings_account_id
                                    })
    saving_transactionr2.insert()
    saving_transactionr2.submit()

    doc.transaction = charge_transaction.name
    doc.save()

def validate_accounting_period(doc, method=None):
    if not frappe.local.flags.ignore_accounting_periods:
        accounting_periods = frappe.db.sql(
            """ SELECT
                ap.name as name
            FROM
                `tabAccounting Period` ap, `tabClosed Document` cd
            WHERE
                ap.name = cd.parent
                AND ap.branch = %(branch)s
                AND ap.company = %(company)s
                AND cd.closed = 0
                AND cd.document_type = %(voucher_type)s
                AND %(date)s between ap.start_date and ap.end_date
                """,
            {
                "date": doc.posting_date,
                "branch": doc.branch,
                "voucher_type": "Saving Transaction",
                "company": doc.company
            },
            as_dict=1,
        )

        if not accounting_periods:
            frappe.throw(
                frappe._(
                    "You cannot create a transaction without an active session"
                ),
                ClosedAccountingPeriod,
            )

def validate_accounting_periodd(doc, method=None):
    if not frappe.local.flags.ignore_accounting_periods:
        accounting_periods = frappe.db.sql(
            """ SELECT
                ap.name as name
            FROM
                `tabAccounting Period` ap, `tabClosed Document` cd
            WHERE
                ap.name = cd.parent
                AND ap.branch = %(branch)s
                AND ap.company = %(company)s
                AND cd.closed = 0
                AND cd.document_type = %(voucher_type)s
                AND %(date)s between ap.start_date and ap.end_date
                """,
            {
                "date": doc.posting_date,
                "branch": doc.branch,
                "voucher_type": "Deposit",
                "company": doc.company
            },
            as_dict=1,
        )

        if not accounting_periods:
            frappe.throw(
                frappe._(
                    "You cannot create a transaction without an active session"
                ),
                ClosedAccountingPeriod,
            )

def validate_accounting_period2(doc, method=None):
    if not frappe.local.flags.ignore_accounting_periods:
        accounting_periods = frappe.db.sql(
            """ SELECT
                ap.name as name
            FROM
                `tabAccounting Period` ap, `tabClosed Document` cd
            WHERE
                ap.name = cd.parent
                AND ap.branch = %(branch)s
                AND ap.company = %(company)s
                AND cd.closed = 0
                AND cd.document_type = %(voucher_type)s
                AND %(date)s between ap.start_date and ap.end_date
                """,
            {
                "date": doc.created_on,
                "branch": doc.branch,
                "voucher_type": "Saving Transaction",
                "company": doc.company
            },
            as_dict=1,
        )

        if not accounting_periods:
            frappe.throw(
                frappe._(
                    "You cannot create a transaction without an active session"
                ),
                ClosedAccountingPeriod,
            )


def reverse_overdraft(doc, method):
    if doc.is_import == 0:
        transaction_types = frappe.db.get_list("Saving Transaction Type",
                                               filters=[
                                                   ['credit', '=', '1']
                                               ],
                                               pluck='name'
                                               )

        if doc.transaction_type in transaction_types:

            deposit_amount = doc.amount

            overdraft = frappe.db.get_value("Savings Account", doc.account, 'overdraft_derived')

            overdraft_recovered = 0

            if overdraft > 0:
                if deposit_amount < overdraft:
                    overdraft_recovered = deposit_amount

                if deposit_amount > overdraft:
                    overdraft_recovered = overdraft

                if deposit_amount == overdraft:
                    overdraft_recovered = overdraft

                doc.flags.overdraft_recovered = overdraft_recovered or 0


def save_overdraft_recovered(doc, method=None):
    if doc.is_import == 0:
        frappe.db.set_value("Saving Transaction", doc.name, {'overdraft_recovered': doc.flags.overdraft_recovered or 0})

        update_overdraft_balances(doc.account, flt(doc.flags.overdraft_recovered or 0), doc)


def create_banking_transaction(doc, method=None):
    if not frappe.local.flags.ignore_accounting_periods or doc.is_import == 0:
        if doc.transaction_type_name not in ["Deposit", "Withdraw", "Saving Transfer"]:
            return

        transaction_type = str(doc.transaction_type_name)

        cash_account = frappe.db.get_single_value("Banking Settings", "default_cash_account")

        if doc.transaction_type_name == "Deposit" and doc.loan is not None:

            transaction_type = "Withdraw"

            loan_product = frappe.db.get_value("Loan", doc.loan, "loan_product")

            loan_fund = frappe.db.get_value("Loan Product", loan_product, "fund")

            loan_fund_account = frappe.db.get_value("Loan Fund Account", {
                "branch": doc.branch,
                "parent": loan_fund
            }, "bank_account")

            if loan_fund is None:
                cash_account = frappe.db.get_single_value("Banking Settings", "default_loan_fund")

            if loan_fund:
                cash_account = loan_fund_account


        else:
            if frappe.db.exists("Employee", {"user": frappe.session.user}):
                cash_account = frappe.db.get_value("Employee", {"user": frappe.session.user}, "account")

                if cash_account is None:
                    frappe.throw("No account attached to user")

        if cash_account is None:
            frappe.throw("Please set default cash account")

        transaction = frappe.get_doc({
            "doctype": "Bank Transactions",
            "posting_date": doc.posting_date,
            "type": transaction_type,
            "amount": doc.amount,
            "created_by": frappe.session.user,
            "reference": doc.name,
            "account": cash_account,
            "branch": doc.branch,
            "saving_transaction": doc.name,
            "company": doc.get('company', None)
        })

        transaction.insert(ignore_permissions=True)
        transaction.submit()


def check_for_inter_branch(doc, method=None):
    if doc.is_import == 0:
        savings_branch = doc.account_branch or doc.branch

        transaction_branch = doc.branch

        if cint(savings_branch) != cint(transaction_branch):
            doc.is_inter_branch = 1


def submit_multiple():
    data = frappe.db.sql("""
    SELECT name 
    FROM `tabSaving Transaction`
    where docstatus = 0
    """, as_dict=True)

    if data:
        for item in data:
            doc = frappe.get_doc("Saving Transaction", item.name)
            doc.submit()
