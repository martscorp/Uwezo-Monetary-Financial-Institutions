// Copyright (c) 2022, Abbey and contributors
// For license information, please see license.txt

frappe.ui.form.on('Saving Transaction', {
	refresh: function(frm) {
	
		  // Get the current user
		  var current_user = frappe.session.user;
	
		  // Fetch the Employee document linked to the current user
		  frappe.db.get_value('Employee', { 'user': current_user }, 'name', function(r) {
			  if (r && r.name) {
				  // Load the full Employee document
				  frappe.model.with_doc('Employee', r.name, function() {
					  var employee_doc = frappe.model.get_doc('Employee', r.name);
					  var current_user2 = employee_doc.name;
	
	
					  // Call server-side method to check interim transaction access
					  frappe.call({
						  method: 'mfis.clients.check_interim_transaction_access',
						  args: {
							  user: current_user2,
							  current_date: frappe.datetime.nowdate()
						  },
						  callback: function(r) {
							  if (r.message) {
	
								if(frm.doc.flagged == 0){
									frm.add_custom_button('Flag Transaction', () => {
										// Show a dialog to collect the reason for flagging
										let d = new frappe.ui.Dialog({
											title: 'Flag Transaction',
											fields: [
												{
													label: 'Reason for flagging',
													fieldname: 'reason',
													fieldtype: 'Text',
													reqd: 1 // make this field required
												}
											],
											primary_action_label: 'Submit',
											primary_action(values) {
												// Ask for confirmation
												frappe.confirm('Are you sure you want to proceed? Flagging cannot be reversed !', 
													() => {
														// Make server call if confirmed
														frappe.call('mfis.clients.update_transaction_kl', {
															docer: "Saving Transaction",
															docname: frm.doc.name,
															reason: values.reason,
															account: frm.doc.account
															
														}).then(r => {
															frappe.msgprint({
																title: __('Notification'),
																indicator: 'green',
																message: __('Transaction Flagged successfully')
															});
														})
													}, () => {
														// Cancelled
													});
												d.hide(); // close the dialog after submission
											}
										});
									
										d.show(); // Show the dialog to user
									});
									
								}
	
								  // Ensure the button is added only once
								 
							  }
						  }
					  });
				  });
			  }
		  });
		// frm.page.btn_secondary.hide()
	}
});
