# Copyright (c) 2023, Abbey and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document
import mfis
from mfis.accounts.general_ledger import make_gl_entries


class OverdraftAccount(Document):
    def before_save(self):
        update_accounts(self)


def update_accounts(doc, method=None):
    if doc.reversal_account is None:
        if frappe.db.exists("Saving Product Accounts", {
            "parent": doc.saving_product,
            "branch": doc.branch
        }):
            doc.reversal_account = frappe.db.get_value("Saving Product Accounts",
                                                       {
                                                           "parent": doc.saving_product,
                                                           "branch": doc.branch
                                                       },
                                                       'portfolio_account')

    if doc.receivable_account is None:
        if frappe.db.exists("Saving Product Accounts", {
            "parent": doc.saving_product,
            "branch": doc.branch
        }
                            ):
            doc.receivable_account = frappe.db.get_value("Saving Product Accounts",
                                                         {
                                                             "parent": doc.saving_product,
                                                             "branch": doc.branch
                                                         },
                                                         "overdraw_account")

        if doc.transaction_type == 'Apply Charge':
            if frappe.db.exists("Saving Product Charge", {
                "parent": doc.saving_product,
                "charge": doc.charge,
                "branch": doc.branch
            }):
                doc.receivable_account = frappe.db.get_value("Saving Product Charge",
                                                             {
                                                                 "parent": doc.saving_product,
                                                                 "charge": doc.charge,
                                                                 "branch": doc.branch
                                                             },
                                                             "accounts_receivable")

                # frappe.throw(f'{doc.receivable_account}')


def get_account_overdrafts(account):
    data = frappe.db.sql(
        """
        SELECT 
            acc_overdrafts.account as saving_account,
            acc_overdrafts.name as name,
            acc_overdrafts.amount as amount,
            acc_overdrafts.amount_recovered as amount_recovered,
            acc_overdrafts.total_due as total_due,
            acc_overdrafts.receivable_account as receivable_account,
            acc_overdrafts.reversal_account
        FROM `tabOverdraft Account` as acc_overdrafts
        WHERE
            acc_overdrafts.account = %(saving_account)s
            and  acc_overdrafts.total_due > 0
        ORDER BY
            acc_overdrafts.posting_date ASC
        """,
        {
            "saving_account": account
        },
        as_dict=True
    )

    if data is None:
        data = []

    return data


def update_overdraft_balances(account, amount: float = 0, transaction=None):
    overdrafts = get_account_overdrafts(account)

    if overdrafts is None:
        return

    gl_entries = []

    branch = transaction.branch
    company = transaction.company
    cost_center = mfis.get_default_cost_center(company=transaction.company, branch=branch)

    for overdraft in overdrafts:
        if amount == 0:
            break

        if overdraft.total_due <= 0:
            continue

        amount_due = overdraft.amount - overdraft.amount_recovered

        amount_recovered = 0

        total_due = overdraft.total_due

        if amount >= amount_due:
            amount_recovered = amount_due
            amount -= amount_recovered
        else:
            amount_recovered = amount
            amount = 0

        total_due = total_due - amount_recovered

        amount_recovered_to = overdraft.amount_recovered + amount_recovered

        frappe.db.set_value("Overdraft Account", overdraft.name, {
            "total_due": total_due,
            "amount_recovered": amount_recovered_to
        })

        if overdraft.receivable_account is None or overdraft.receivable_account == "":
            continue

        if overdraft.reversal_account is None or overdraft.reversal_account == "":
            continue

        gl_entry_rec = frappe._dict({
            "party_type": "Savings Account",
            "party": overdraft.saving_account,
            "voucher_type": "Saving Transaction",
            "voucher_no": transaction.name,
            "cost_center": cost_center,
            "branch": branch,
            "account": overdraft.receivable_account,
            "posting_date": frappe.utils.today(),
            "transaction_date": frappe.utils.today(),
            "credit": amount_recovered,
            "company": company
        })

        gl_entries.append(gl_entry_rec)

        gl_entry_rev = frappe._dict({
            "party_type": "Savings Account",
            "party": overdraft.saving_account,
            "voucher_type": "Saving Transaction",
            "voucher_no": transaction.name,
            "cost_center": cost_center,
            "branch": branch,
            "account": overdraft.reversal_account,
            "posting_date": frappe.utils.today(),
            "transaction_date": frappe.utils.today(),
            "debit": amount_recovered,
            "company": company
        })

        gl_entries.append(gl_entry_rev)

    if len(gl_entries) > 1:
        make_gl_entries(
            gl_entries,
            merge_entries=False,
        )
