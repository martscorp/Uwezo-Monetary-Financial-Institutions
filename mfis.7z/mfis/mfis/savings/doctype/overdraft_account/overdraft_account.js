// Copyright (c) 2023, Abbey and contributors
// For license information, please see license.txt

frappe.ui.form.on('Overdraft Account', {
	// refresh: function(frm) {

	// }
});
