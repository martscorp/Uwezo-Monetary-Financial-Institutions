// Copyright (c) 2022, Abbey and contributors
// For license information, please see license.txt


frappe.ui.form.on('Savings Account', {
    saving_product: async function(frm) {
        // Fetch active savings accounts based on the newly selected saving_product
        let savings_accounts = await frappe.db.get_list('Savings Account', {
            fields: ["client", "saving_product", "status"],
            filters: {
                saving_product: frm.doc.saving_product, // Fetch based on selected saving product
                status: "Active" // Only active accounts
            }
        });

        // Extract client IDs from the filtered savings accounts
        let disbursed_loan_ids = savings_accounts.map(d => d.client);

        // Set client query to exclude clients with active savings accounts
        frm.set_query("client", function() {
            return {
                filters: [
                    ["Client", "docstatus", "=", 1],
                    ["Client", "name", "not in", disbursed_loan_ids]
                ]
            };
        });


        // Set saving_product query to exclude already used products
        frm.set_query("saving_product", function() {
            let active_products = savings_accounts.map(d => d.saving_product); // Extract active saving products
            return {
                filters: [
                    ["name", "not in", active_products] // Exclude already disbursed saving products
                ]
            };
        });
    },
    refresh: async function(frm) {

            if (frm.doc.status === 'Inactive') {
            frm.add_custom_button('Run Activation Charge', () => {
                frappe.confirm(
                    'Are you sure you want to activate this dormant account?',
                    () => {
                        frappe.call({
                            method: "mfis.clients.create_apply_charge_transaction",
                            args: {
                                savings_account_id: frm.doc.name
                            },
                            freeze: true,
                            freeze_message: "Activating account...",
                            callback: function(r) {
                                if (!r.exc) {
                                    frappe.msgprint('Dormant account has been reactivated successfully.');
                                    frm.reload_doc();
                                }
                            }
                        });
                    }
                );
            }, __("Activate Dormant Account"));
        }

        
        frm.cscript.saving_product = function(doc, cdt, cdn) {
            var saving_product = doc.saving_product;
            frappe.model.with_doc("Saving Product", saving_product, function() {
                var savings_account_doc = frappe.model.get_doc("Saving Product", saving_product);
                if (savings_account_doc) {
                    var is_fixed = savings_account_doc.is_fixed;
                    var is_fixed2 = savings_account_doc.is_fixed2;
                    frm.set_value("is_fixed", is_fixed);
                    frm.set_value("is_check", is_fixed2);
                }
            });
        };

   
        

        if (frm.doc.status == 'Active' || frm.doc.status == 'Approved') {
            frm.add_custom_button('Deposit', () => {
                frappe.new_doc("Deposit", {
                    "account": frm.doc.name,
                    "branch": frm.doc.branch,
                });
            }, 'Create');

            frm.add_custom_button('Withdraw', () => {
                frappe.new_doc("Withdraw", {
                    "account": frm.doc.name,
                    "branch": frm.doc.branch,
                });
            }, 'Create');

            frm.add_custom_button('Transfer', () => {
                frappe.new_doc("Transfer", {
                    "account": frm.doc.name,
                    "branch": frm.doc.branch,
                });
            }, 'Create');

            frm.add_custom_button('Hold Account', () => {
                frappe.new_doc("Account Hold", {
                    "account": frm.doc.name,
                    "amount": frm.doc.balance_derived
                });
            }, 'Manage');

            frm.add_custom_button(__('Freeze Money'), function() {
                process_guarantors(frm, true);
            });

            frm.add_custom_button(__('Unfreeze Money'), function() {
                process_guarantors(frm, false);
            });

            frm.add_custom_button("Fetch Transactions", () => {
                frappe.call({
                    method: "mfis.import_transactions.fetch_and_process_transactions",
                    args: {
                        account: frm.doc.external_id
                    },
                    freeze: true,
                    freeze_message: "Fetching transactions..."
                }).then(() => {
                    frappe.msgprint("Fetch completed");
                    frm.refresh();
                });
            }, 'Manage');

            frm.add_custom_button("Update Opening Balance", () => {
                frappe.call({
                    method: 'mfis.import_savings.update_opening_balance',
                    args: {
                        account: frm.doc.name
                    },
                    freeze: true,
                    freeze_message: "Updating balance"
                }).then(() => {
                    frappe.msgprint("Balance updated successfully");
                    frm.refresh();
                });
            }, 'Manage');
        }

        frm.add_custom_button('Apply Charge', () => {
            frappe.new_doc("Apply Charge", {
                "account": frm.doc.name,
                "branch": frm.doc.branch,
            });
        });

        frm.add_custom_button(__('Statement'), function() {
            frappe.route_options = {
                "branch": frm.doc.branch,
                "account": frm.doc.name
            };
            frappe.set_route("query-report", "Account Statement");
        }, __('View'));
    },

    onload: function (frm) {
        
    
        frm.set_query("client_type", function () {
            return {
                "filters": [
                    ["name", "IN", ["Client", "Joint Accounts",  "Group Account"]]
                ]
            };
        });

var current_user = frappe.session.user;

frappe.db.get_value('Employee', { 'user': current_user }, ["branch", "roles"], function(r) {
    if (r && r.branch) {
        let user_branch = r.branch;

        // Check if the user has the role 'Assistant Accountant'
        if (r.roles && r.roles.includes("Assistant Accountant")) {
      
            return;
        } else {
            // Set branch value and make it read-only
            frm.set_value('branch', user_branch);
            frm.set_df_property('branch', 'read_only', 1);

            // Set queries for link fields filtered by branch
            frm.set_query('client', function() {
                return {
                    filters: {
                        branch: user_branch,
                        docstatus: 1
                    }
                };
            });

            frm.set_query('account_agent', function() {
                return {
                    filters: { branch: user_branch }
                };
            });

            frm.set_query('saving_product', function() {
                return {
                    filters: { branch: user_branch }
                };
            });

            frm.set_query('staff_id', function() {
                return {
                    filters: { branch: user_branch }
                };
            });
        }
    }
});





    }
    
        ,

    client_type: function (frm) {
        var is_joint_account = 0;
        if (frm.doc.client_type == "Group") {
            is_joint_account = 1;
        }
    }
});
async function process_guarantors(frm, freeze) {
    try {
        // Define the fields for the prompt
        let fields = [
            {
                label: 'Amount to Freeze',
                fieldname: 'amount',
                fieldtype: 'Currency',
                default: freeze ? (frm.doc.savings_amount_frozen || 0) : frm.doc.savings_amount_frozen,
                reqd: true
            }
        ];

        if (freeze) {
            fields.push({
                label: 'Reason for Freezing',
                fieldname: 'reason',
                fieldtype: 'Small Text',
                default: frm.doc.savings_freeze_reason || '',
                reqd: true
            });
        }

        // Show the prompt to get the amount and reason
        frappe.prompt(fields, async (values) => {
            try {
                // Call the server-side method to update the fields
                var bal = frm.doc.savings_amount_frozen - values.amount;
                var rr = frm.doc.savings_freeze_reason;
                if(bal<=0){
                    bal = 0;
                    rr = "";
                }
                let response = await frappe.call({
                    method: 'mfis.clients.update_transaction2', // Adjust path according to your app and method name
                    args: {
                        docer: "Savings Account",
                        docname: frm.doc.name,
                        amount: freeze ? values.amount : bal, // Assuming current date is to be used
                        reason: freeze ? values.reason : rr
                    }
                });

                if (!response.exc) {
                    frappe.msgprint(__('Transaction updated successfully.'));
                    frm.reload_doc(); // Reload the document to reflect changes
                } else {
                    frappe.msgprint(__('Error updating transaction: ' + (response.exc.message || 'Unknown error.')));
                }
            } catch (err) {
                frappe.msgprint(__('An error occurred while updating the transaction.'));
                console.error('Error updating transaction:', err);
            }
        }, freeze ? __('Freeze Amount') : __('Unfreeze Amount'), __('Submit'));

    } catch (err) {
        frappe.msgprint(__('An error occurred while initializing the process.'));
        console.error('Error initializing process_guarantors:', err);
    }
}

