import frappe
from frappe.utils import nowdate
from frappe.utils.background_jobs import enqueue
from mfis.clients import get_total_outstanding,close_cycle_renew2,close_cycle_renew
from frappe.utils import now_datetime, add_days
import calendar
from datetime import datetime, timedelta
from datetime import date
def fixed_account_closure(): 
    today = datetime.now().date()
    summary_details = "No savings accounts processed."

    # Fetch all savings accounts with their associated saving product
    savings_accounts = frappe.get_list("Savings Account", fields=["name", "saving_product"])

    for account in savings_accounts:
        try:
            # Retrieve the associated saving product document
            savings_product = frappe.get_doc("Saving Product", account.saving_product)
            
            # Skip if the saving product is not fixed
            if not savings_product.is_fixed:
                continue
            
            # Check if it's a vision account and set the duration accordingly
            if savings_product.is_vision_account:
                duration_months = 6
                double_interest_month = 6  # Double the 6th month interest
            else:
                duration_months = 12
                double_interest_month = 12  # Double the 12th month interest
            
            # Adjust the monthly rate based on the duration
            annual_rate = savings_product.interest_rate / 100  # Convert percentage to decimal
            monthly_rate = annual_rate / 12  # Monthly interest rate always based on 12 months
            minimum_savings_per_month = savings_product.minimum_savings_per_month or 250000
            minimum_annual_savings = savings_product.minimum_annual_savings or 3000000
            
            # For vision accounts, adjust minimum annual savings accordingly
            if savings_product.is_vision_account:
                minimum_annual_savings = minimum_savings_per_month * duration_months
            
            # Retrieve the active savings cycle for the account
            active_cycle = frappe.get_list(
                "Savings Cycle",
                filters={
                    "savings_account": account.name,
                    "status": "Running"
                },
                fields=["name", "start_date", "stop_date"]
            )
            
            if not active_cycle:
                continue
            
            cycle_doc = frappe.get_doc("Savings Cycle", active_cycle[0].name)
            
            # Skip if the stop_date of the active cycle is not today
            if cycle_doc.stop_date and cycle_doc.stop_date.date() != today:
                continue

            total_interest = 0
            total_interest_before_last_month = 0
            is_disqualified = False
            total_annual_savings = 0
            month_details = []
            
            # Get the start month and year from the cycle's start date
            start_month = cycle_doc.start_date.month
            start_year = cycle_doc.start_date.year

            for month_index in range(duration_months):
                # Calculate the current month and year
                current_month = (start_month + month_index - 1) % 12 + 1
                current_year = start_year + (start_month + month_index - 1) // 12

                # Numerical month label
                month_label = str(month_index + 1)

                start_of_month = datetime(current_year, current_month, 1)
                end_of_month = (start_of_month.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)

                # Get the balance for the end of the current month
                end_of_month_balance_str = cycle_doc.get(month_label) or '0'
                end_of_month_balance = float(end_of_month_balance_str)  # Convert to float
                
                # Fetch deposit transactions within the start and end dates of the current month
                deposits = frappe.get_all(
                    "Deposit",
                    filters={
                        "account": account.name,
                        "posting_date": ["between", [start_of_month, end_of_month]]
                    },
                    fields=["amount"]
                )
                
                # Calculate total deposits for the current month
                total_deposits = sum(d.amount for d in deposits)
                meets_minimum_savings = end_of_month_balance >= minimum_savings_per_month
                
                # Calculate interest for the month
                if not meets_minimum_savings:
                    interest_for_month = 0
                    month_details.append(f"Month {month_label}:\n"
                                         f"End-of-Month Balance: {end_of_month_balance:.2f}\n"
                                         f"Deposits: {total_deposits:.2f}\n"
                                         f"Meets Minimum Savings: {'No'} "
                                         f"({end_of_month_balance:.2f} < {minimum_savings_per_month:.2f})\n"
                                         f"Interest: 0.00\n"
                                         f"Total Annual Savings: {total_annual_savings:.2f}\n")
                    is_disqualified = True  # Mark as disqualified if minimum savings are not met
                else:
                    interest_for_month = monthly_rate * end_of_month_balance
                    month_details.append(f"Month {month_label}:\n"
                                         f"End-of-Month Balance: {end_of_month_balance:.2f}\n"
                                         f"Deposits: {total_deposits:.2f}\n"
                                         f"Meets Minimum Savings: {'Yes'} "
                                         f"({end_of_month_balance:.2f} >= {minimum_savings_per_month:.2f})\n"
                                         f"Interest: {end_of_month_balance:.2f} * {monthly_rate:.4f} = {interest_for_month:.2f}\n"
                                         f"Total Annual Savings: {total_annual_savings + end_of_month_balance:.2f}\n")
                
                # Add to total annual savings
                total_annual_savings += end_of_month_balance
                
                if month_index + 1 == double_interest_month:  # Double interest for 6th or 12th month
                    total_interest += 2 * interest_for_month
                    month_details.append(f"Month {month_label} (Interest Doubled):\n"
                                         f"Interest for {month_label}th Month (Doubled): {interest_for_month:.2f} * 2 = {2 * interest_for_month:.2f}\n")
                else:
                    total_interest_before_last_month += interest_for_month
                    total_interest += interest_for_month
            
            # Check for disqualification and adjust total interest if necessary
            if is_disqualified or total_annual_savings < minimum_annual_savings:
                total_interest = 0
                qualification_summary = f"Check Qualifications:\nIs Disqualified: Yes (Some months have savings less than {minimum_savings_per_month} or total savings do not meet the required amount for {duration_months} months)"
            else:
                qualification_summary = f"Check Qualifications:\nIs Disqualified: No (All months have savings greater than {minimum_savings_per_month}, and total savings meet the required amount for {duration_months} months)\n" \
                                        f"Total Savings: {total_annual_savings:.2f} (exceeds the minimum requirement)"
            
            # Compile the final summary details
            interest_summary = f"Total Interest Calculation:\n" \
                               f"Interest for First {duration_months - 1} Months: {total_interest_before_last_month:.2f}\n" \
                               f"Last Month Interest (or bonus if applicable): {total_interest - total_interest_before_last_month:.2f}\n" \
                               f"Total Interest Collected: {total_interest:.2f}"
            
            summary_details = "\n".join(month_details) + "\n\n" + qualification_summary + "\n\n" + interest_summary
            
            # Log the generated summary for debugging
            frappe.log_error(summary_details, "Generated Summary Details")
            
            # Update the cycle document with the calculated interest and savings
            cycle_doc.total_interest_collected = total_interest
            cycle_doc.total_annual_savings = total_annual_savings
            cycle_doc.summary = summary_details
            
            # Save the updated cycle document
            cycle_doc.save()

            # Call the function to handle cycle closure
            close_cycle_renew2(account.name)

        except Exception as e:
            frappe.log_error(f"Error processing account {account.name}: {e}", "Fixed Account Closure Error")
        
        from mfis.clients import get_total_outstanding, getcurrent_cycle_running
        get_total_outstanding(account)


@frappe.whitelist(allow_guest=True)
def process_charges():
    from mfis.clients import get_total_outstanding, getcurrent_cycle_running
    # Import functions at the top of the file
    # savings_accounts = frappe.get_list("Savings Account", fields=["name", "saving_product"])  # Adjust fields if necessary
    savings_accounts = frappe.get_list("Savings Account", fields=["name", "saving_product"], filters={"status": ["!=", "Inactive"]})

    for account in savings_accounts:
        # Retrieve the associated saving product document
        savings_product = frappe.get_doc("Saving Product", account.saving_product)
        
        # Check if there have been any transactions in the last 90 days, excluding monthly charges
        last_90_days = add_days(now_datetime(), -90)
        transactions = frappe.get_all("Saving Transaction", filters={
            "account": account.name,
            "posting_date": [">=", last_90_days],
            "transaction_type": ["!=", 12]  # Exclude monthly fees
        })
        
        # If the product has monthly fees, create savings transactions
        if savings_product.monthly_fees > 0:
            create_savings_transactions(account, savings_product)
            
        
        # Check if the saving product is fixed
        if savings_product.is_fixed:
            # Get the current month name
            current_month = calendar.month_name[datetime.now().month].lower()
            
            # Calculate the total outstanding balance using the function
            result = get_total_outstanding(account.name)
            total_outstanding = 0
            
            # Ensure the result is correctly extracted
            if isinstance(result, dict) and "message" in result:
                total_outstanding = result["message"]
            else:
                total_outstanding = result
            
            # Attempt to retrieve an existing cycle record
            existing_cycle = frappe.get_all("Savings Cycle", filters={"savings_account": account.name}, limit=1)
            
            if existing_cycle:
                # If the cycle exists, load the document
                cycle_doc = frappe.get_doc("Savings Cycle", existing_cycle[0].name)
                
                # Set the value for the current month field
                cycle_doc.set(current_month, total_outstanding)
                
                # Ensure status is set to "Running"
                if cycle_doc.status != "Running":
                    cycle_doc.status = "Running"
                
                # Save the cycle document
                cycle_doc.save()

        # Deactivate account if no non-monthly charge transactions in the last 90 days
        if not transactions:
            frappe.db.set_value("Savings Account", account.name, "status", "Inactive")
            frappe.db.set_value("Savings Account", account.name, "workflow_state", "Inactive")
            frappe.db.commit()
            frappe.logger().info(f"Savings Account {account.name} deactivated due to inactivity.")

        from mfis.clients import get_total_outstanding, getcurrent_cycle_running
        get_total_outstanding(account.name)

def get_vault_intrestpaid(br, current_date):
    loan_doc = frappe.get_doc("Loan Application Plus", br)
    loan_product = frappe.get_doc("Loan Product", loan_doc.loan_type)
    accounter = frappe.get_doc("Account", loan_product.loan_interest_account)

    # Execute the SQL query to fetch the sum of debits and credits from the General Ledger II table
    data = frappe.db.sql("""
        SELECT 
            COALESCE(SUM(debit), 0) as total_debit, 
            COALESCE(SUM(credit), 0) as total_credit
        FROM `tabGeneral Ledger II`
        WHERE category = %(system_vault)s 
          AND flagged = 0
        AND loan = %(current_date)s
        LIMIT 1
    """, {
        "system_vault": accounter.name,
        "current_date": br
    }, as_dict=True)
    
    total_debit = data[0]["total_debit"] if data else 0
    total_credit = data[0]["total_credit"] if data else 0
    
    total_balance = total_credit
    return total_balance


def process_loan_repayments():
    from datetime import date
    from frappe import log_error
    try:
        # Ensure mfis module is available
        from mfis.clients import create_journal_entry_for_account, get_daily_interest
    except ImportError as e:
        log_error(f"Error importing mfis module: {str(e)}")
        return

    # Get today's date (currently unused, but retained for potential use)
    current_date = date.today()
    if current_date.weekday() == 6 or current_date.weekday() == 0:
        # It's Saturday or Sunday, do not run
        frappe.logger().info("Skipping loan repayment processing on weekend.")
        return

   
    try:
        active_loans = frappe.get_all("Loan Application Plus", filters={"workflow_state": "Activate Loan"}, fields=["name"])
        for loan in active_loans:
            try:
               
                loan_doc = frappe.get_doc("Loan Application Plus", loan.name)
                loan_product = frappe.get_doc("Loan Product", loan_doc.loan_type)
                grace_period = loan_doc.grace_period_on_disbursment
                loan_term = loan_doc.loan_type
                loan_disbursement_date = None

                try:
                    disbursement_list = frappe.get_all(
                        "Loan Disbursement",
                        filters={"loan": loan.name},
                        fields=["disbursement_date"]
                    )
                    
                    if disbursement_list:
                        loan_disbursement_date = disbursement_list[0]["disbursement_date"]
                except Exception as e:
                    print(f"Error processing loan {loan.name}: {str(e)}")

                 
    
                payment_intervals =  loan_doc.payment_intervals
               
                if payment_intervals == "Days":
                    if  grace_period > 0 :
                        if isinstance(loan_disbursement_date, str):
                            loan_disbursement_date = datetime.strptime(loan_disbursement_date, "%Y-%m-%d").date()
                        elif isinstance(loan_disbursement_date, datetime):
                            loan_disbursement_date = loan_disbursement_date.date()

                        if loan_disbursement_date:
                            future_date = loan_disbursement_date + timedelta(days=grace_period)
                            if datetime.today().date() >= future_date  :
                                ff = 0
                            else:
                                print(f"Skipped loan {loan.name} due to grace period")
                                continue
                    current_date = datetime.today() - timedelta(days=1)
                    current_date = current_date.replace(hour=23, minute=0, second=0, microsecond=0)
                    loan_interstpaid = get_vault_intrestpaid(loan.name,current_date)
                    annual_interest_rate = loan_doc.loan_interest+loan_doc.collection_fees


                    unpaiddamount = ((annual_interest_rate / 100) / 30) * loan_doc.approved_principle
                    

                     

                    if loan_interstpaid >= unpaiddamount:
                        unpaiddamount = 0
                        print("skipped")
                    else:
                        unpaiddamount = unpaiddamount - loan_interstpaid
                        
                   
                    print(unpaiddamount)
                    
                    
                    if current_date.weekday() == 6:  # Tuesday 00
                        unpaiddamount *= 2

                    if 1:
                        

                        # Get transaction type ID for 'Repayment'
                        transaction_type = frappe.db.get_value("Loan Transaction Type", {"type_name": "Arreas"})
                        if not transaction_type:
                            print("Transaction type 'Repayment' not found.")
                            

                        # # Load the Loan Repayment document
                        # if not doc.get('name'):
                        #     print("Loan Repayment name not provided.")
                            

                    
                        # Create new Loan Transaction2
                        transaction = frappe.get_doc({
                            'doctype': 'Loan Transaction2',
                            'loan': loan_doc.name,
                            'transaction_type': transaction_type,
                            'created_by': "Administrator",
                            'branch': loan_doc.branch,
                            'amount': unpaiddamount,
                            'credit': unpaiddamount,
                            'reference': f'{loan_doc.name}-repayment - (Bank)',
                            'description': f'{loan_doc.name} repayment - (Bank)',
                            'created_on': current_date,  # Fixed date format
                            'status': 'Approved',
                            'payment_method':  "Cash",  # fallback to "Bank"
                            'loan_repayment': loan_doc.name
                        })

                    
                        # Save and submit the transaction
                        transaction.flags.ignore_permissions = True
                        transaction.insert(ignore_permissions=True)
                        transaction.submit()

                        if transaction.created_on:
                            frappe.db.set_value(
                                "Loan Transaction2",
                                transaction.name,
                                "creation",
                                transaction.created_on
                            )
                            frappe.db.commit()

                        


                        # Create journal entry for interest receivables (debit)
                        create_journal_entry_for_account(
                            account_name=loan_product.interest_receivables_account,
                            amount=unpaiddamount,
                            debit=True,
                            transaction_type_name="Arrears Posting",
                            company=loan_doc.company,
                            branch=loan_doc.branch,
                            loan= loan_doc.name
                        )

                        # Create journal entry for loan interest (credit)
                        create_journal_entry_for_account(
                            account_name=loan_product.loan_interest_account,
                            amount=unpaiddamount,
                            debit=False,
                            transaction_type_name="Arrears Posting",
                            company=loan_doc.company,
                            branch=loan_doc.branch,
                            loan= loan_doc.name,
                            isincome=1,
                            isar=1
                        )
                elif payment_intervals == "Weeks":
                    unpaiddamount = get_daily_interest(loan_doc.name)
                    if not loan_disbursement_date:
                        frappe.throw("Disbursement date not found.")

                    yesterday = datetime.today() + timedelta(days=7)

                    if yesterday < loan_disbursement_date:
                        continue

                    # Handle case where unpaiddamount might be None
                    if unpaiddamount is None:
                        log_error(f"Unpaid amount for loan {loan.name} is None.")
                        continue  # Skip to the next loan
            

                    if unpaiddamount > 0:
                        

                        # Get transaction type ID for 'Repayment'
                        transaction_type = frappe.db.get_value("Loan Transaction Type", {"type_name": "Arreas"})
                        if not transaction_type:
                            print("Transaction type 'Repayment' not found.")
                            

                        # # Load the Loan Repayment document
                        # if not doc.get('name'):
                        #     print("Loan Repayment name not provided.")
                            

                    
                        # Create new Loan Transaction2
                        transaction = frappe.get_doc({
                            'doctype': 'Loan Transaction2',
                            'loan': loan_doc.name,
                            'transaction_type': transaction_type,
                            'created_by': "Administrator",
                            'branch': loan_doc.branch,
                            'amount': unpaiddamount,
                            'credit': unpaiddamount,
                            'reference': f'{loan_doc.name}-repayment - (Bank)',
                            'description': f'{loan_doc.name} repayment - (Bank)',
                            'created_on': yesterday,  # Fixed date format
                            'status': 'Approved',
                            'payment_method':  "Cash",  # fallback to "Bank"
                            'loan_repayment': loan_doc.name
                        })

                    
                        # Save and submit the transaction
                        transaction.flags.ignore_permissions = True
                        transaction.insert(ignore_permissions=True)
                        transaction.submit()

                        
                        # Create journal entry for interest receivables (debit)
                        create_journal_entry_for_account(
                            account_name=loan_product.interest_receivables_account,
                            amount=unpaiddamount,
                            debit=True,
                            transaction_type_name="Arrears Posting",
                            company=loan_doc.company,
                            branch=loan_doc.branch,
                            loan= loan_doc.name
                        )

                        # Create journal entry for loan interest (credit)
                        create_journal_entry_for_account(
                            account_name=loan_product.loan_interest_account,
                            amount=unpaiddamount,
                            debit=False,
                            transaction_type_name="Arrears Posting",
                            company=loan_doc.company,
                            branch=loan_doc.branch,
                            loan= loan_doc.name,
                            isincome=1,
                            isar=1
                        )
                elif payment_intervals == "Months":
                    
                    yesterday = loan_disbursement_date + timedelta(days=30)
                    today = datetime.today()
                    if today >= yesterday:
                        
                            continue

                    unpaiddamount = get_daily_interest(loan_doc.name)

                    if not loan_disbursement_date:
                        frappe.throw("Disbursement date not found.")

                    # Calculate the difference in days
                    days_diff = (datetime.today().date() - loan_disbursement_date).days

                    # Check if it's divisible by 30
                    if days_diff % 30 == 0:
                        ff=0
                    else:
                        continue

                    # Handle case where unpaiddamount might be None
                    if unpaiddamount is None:
                        log_error(f"Unpaid amount for loan {loan.name} is None.")
                        continue  # Skip to the next loan
                    
             

                    if unpaiddamount > 0:
                        

                        # Get transaction type ID for 'Repayment'
                        transaction_type = frappe.db.get_value("Loan Transaction Type", {"type_name": "Arreas"})
                        if not transaction_type:
                            print("Transaction type 'Repayment' not found.")
                            

                        # # Load the Loan Repayment document
                        # if not doc.get('name'):
                        #     print("Loan Repayment name not provided.")
                            

                    
                        # Create new Loan Transaction2
                        transaction = frappe.get_doc({
                            'doctype': 'Loan Transaction2',
                            'loan': loan_doc.name,
                            'transaction_type': transaction_type,
                            'created_by': "Administrator",
                            'branch': loan_doc.branch,
                            'amount': unpaiddamount,
                            'credit': unpaiddamount,
                            'reference': f'{loan_doc.name}-repayment - (Bank)',
                            'description': f'{loan_doc.name} repayment - (Bank)',
                            'created_on': yesterday,  # Fixed date format
                            'status': 'Approved',
                            'payment_method':  "Cash",  # fallback to "Bank"
                            'loan_repayment': loan_doc.name
                        })

                    
                        # Save and submit the transaction
                        transaction.flags.ignore_permissions = True
                        transaction.insert(ignore_permissions=True)
                        transaction.submit()
                     

                        
                        # Create journal entry for interest receivables (debit)
                        create_journal_entry_for_account(
                            account_name=loan_product.interest_receivables_account,
                            amount=unpaiddamount,
                            debit=True,
                            transaction_type_name="Arrears Posting",
                            company=loan_doc.company,
                            branch=loan_doc.branch,
                            loan= loan_doc.name
                        )

                        # Create journal entry for loan interest (credit)
                        create_journal_entry_for_account(
                            account_name=loan_product.loan_interest_account,
                            amount=unpaiddamount,
                            debit=False,
                            transaction_type_name="Arrears Posting",
                            company=loan_doc.company,
                            branch=loan_doc.branch,
                            loan= loan_doc.name,
                            isincome=1,
                            isar=1
                        )
            except Exception as e:
                print(f"Error processing loan {loan.name}: {str(e)}")
    except Exception as e:
        log_error(f"Error fetching active loans: {str(e)}")


            


        
            
def process_charges2():
    frappe.log_error("Error in process_charges")

def create_savings_transactions(account, savings_product):
    date = nowdate()
    savings_account_id = account.name
    account_name = account.name

    amount_disbursed = savings_product.monthly_fees
    
    account2 = frappe.get_doc("Savings Account", account_name)
    monthly_fees_receivable = savings_product.monthly_fees_receivable
    monthly_fees_receivablen = frappe.get_doc("Account", {"name": monthly_fees_receivable})
    coa_account_name3 = frappe.get_doc("Account", {"name": savings_product.monthly_fees_account})
 
 
   
    transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": "Deposit Charge"})
    saving_transaction = frappe.get_doc({
                            'doctype': 'Saving Transaction',
                            'account': account.name,
                            'transaction_type': transaction_type,
                            'posting_date': date,
                            'branch': savings_product.branch,
                            
                            'amount': savings_product.monthly_fees,
                            'debit': savings_product.monthly_fees,
                            'client_account': account.name,  # Ensure this field exists in the Saving Transaction doctype
                            'reference': account.name,
                            'description': "Monthly Charges",
                            'is_parent': 1,
                            'allow_charges': 0
                        })
    saving_transaction.insert()
    saving_transaction.submit()

   
    if account2.balance_derived < savings_product.monthly_fees:
        required_amount = abs(account2.balance_derived - savings_product.monthly_fees)
        balance = account2.balance_derived
        balance_left = savings_product.monthly_fees - balance

        if balance > 0:
            existing_entry = frappe.get_list("General Ledger II", filters={
                'account': monthly_fees_receivable,
                'transaction_type_name': "monthlyfessrecivable",
                'savings_account': savings_account_id
            }, fields=["name", "credit", "debit"])

            if existing_entry:
                frappe.db.sql("""
                    UPDATE `tabGeneral Ledger II` 
                    SET credit = credit + %s, 
                    debit = debit + %s
                    WHERE name = %s
                """, (balance, savings_product.monthly_fees, existing_entry[0]["name"]))
                frappe.db.commit()

                coa_account_name2 = frappe.get_doc("Account", {"name": savings_product.customer_balance_account})
                saving_transactionr2 = frappe.get_doc({
                    'doctype': 'General Ledger II',
                    'account': savings_product.customer_balance_account,
                    'label_for_report': coa_account_name2.name,  # Ensure this is a string
                    'transaction_type': 1,
                    'transaction_type_name': "withdraw",
                    'posting_date': datetime.now().date(),
                    'company': savings_product.company,
                    'branch': savings_product.branch,
                    'amount': balance,
                    'credit': 0,
                    'debit': balance,
                    'main_parent': "Liabilities",
                    'sub_parent': "Balances On Customer Account",
                    'category': coa_account_name2,
                    'savings_account': savings_account_id
                })
                saving_transactionr2.insert()
                saving_transactionr2.submit()

                saving_transactionr = frappe.get_doc({
                    'doctype': 'General Ledger II',
                    'account': savings_product.monthly_fees_account,
                    'label_for_report': coa_account_name3.name,
                    'transaction_type': 1,
                    'transaction_type_name': "Monthly Fees",
                    'posting_date': datetime.now().date(),
                    'company': savings_product.company,
                    'branch': savings_product.branch,
                    'amount': savings_product.monthly_fees,
                    'credit': savings_product.monthly_fees,
                    'debit': 0,
                    'main_parent': "Income",
                    'sub_parent': "Income",
                    'category': coa_account_name3,
                    'savings_account': savings_account_id
                })
                saving_transactionr.insert()
                saving_transactionr.submit()

                    

            else:
                saving_transactionr = frappe.get_doc({
                    'doctype': 'General Ledger II',
                    'account': monthly_fees_receivable,
                    'label_for_report': monthly_fees_receivablen.name,  # Ensure this is a string
                    'transaction_type': 1,
                    'transaction_type_name': "monthlyfessrecivable",
                    'posting_date': datetime.now().date(),
                    'company': savings_product.company,
                    'branch': savings_product.branch,
                    'amount': savings_product.monthly_fees,
                    'credit': balance,
                    'debit': savings_product.monthly_fees,
                    'main_parent': "Assets",
                    'sub_parent': "Debtors & Receivables",
                    'category': monthly_fees_receivablen,
                    'savings_account': savings_account_id
                })
                saving_transactionr.insert()
                saving_transactionr.submit()

                coa_account_name2 = frappe.get_doc("Account", {"name": savings_product.customer_balance_account})
                saving_transactionr2 = frappe.get_doc({
                    'doctype': 'General Ledger II',
                    'account': savings_product.customer_balance_account,
                    'label_for_report': coa_account_name2.name,  # Ensure this is a string
                    'transaction_type': 1,
                    'transaction_type_name': "withdraw",
                    'posting_date': datetime.now().date(),
                    'company': savings_product.company,
                    'branch': savings_product.branch,
                    'amount': balance,
                    'credit': 0,
                    'debit': balance,
                    'main_parent': "Liabilities",
                    'sub_parent': "Balances On Customer Account",
                    'category': coa_account_name2,
                    'savings_account': savings_account_id
                })
                saving_transactionr2.insert()
                saving_transactionr2.submit()

                saving_transactionr = frappe.get_doc({
                    'doctype': 'General Ledger II',
                    'account': savings_product.monthly_fees_account,
                    'label_for_report': coa_account_name3.name,
                    'transaction_type': 1,
                    'transaction_type_name': "Monthly Fees",
                    'posting_date': datetime.now().date(),
                    'company': savings_product.company,
                    'branch': savings_product.branch,
                    'amount': savings_product.monthly_fees,
                    'credit': savings_product.monthly_fees,
                    'debit': 0,
                    'main_parent': "Income",
                    'sub_parent': "Income",
                    'category': coa_account_name3,
                    'savings_account': savings_account_id
                })
                saving_transactionr.insert()
                saving_transactionr.submit()


        else:
            existing_entry = frappe.get_list("General Ledger II", filters={
                'account': monthly_fees_receivable,
                'transaction_type_name': "monthlyfessrecivable",
                'savings_account': savings_account_id
            }, fields=["name", "credit", "debit"])

            if existing_entry:
                frappe.db.sql("""
                    UPDATE `tabGeneral Ledger II` 
                    SET  
                    debit = debit + %s
                    WHERE name = %s
                """, (savings_product.monthly_fees, existing_entry[0]["name"]))
                frappe.db.commit()

                saving_transactionr = frappe.get_doc({
                    'doctype': 'General Ledger II',
                    'account': savings_product.monthly_fees_account,
                    'label_for_report': coa_account_name3.name,
                    'transaction_type': 1,
                    'transaction_type_name': "Monthly Fees",
                    'posting_date': datetime.now().date(),
                    'company': savings_product.company,
                    'branch': savings_product.branch,
                    'amount': savings_product.monthly_fees,
                    'credit': savings_product.monthly_fees,
                    'debit': 0,
                    'main_parent': "Income",
                    'sub_parent': "Income",
                    'category': coa_account_name3,
                    'savings_account': savings_account_id
                })
                saving_transactionr.insert()
                saving_transactionr.submit()

            else:
                saving_transactionr = frappe.get_doc({
                    'doctype': 'General Ledger II',
                    'account': monthly_fees_receivable,
                    'label_for_report': monthly_fees_receivablen.name,  # Ensure this is a string
                    'transaction_type': 1,
                    'transaction_type_name': "monthlyfessrecivable",
                    'posting_date': datetime.now().date(),
                    'company': savings_product.company,
                    'branch': savings_product.branch,
                    'amount': savings_product.monthly_fees,
                    'credit': 0,
                    'debit': savings_product.monthly_fees,
                    'main_parent': "Assets",
                    'sub_parent': "Debtors & Receivables",
                    'category': monthly_fees_receivablen,
                    'savings_account': savings_account_id
                })
                saving_transactionr.insert()
                saving_transactionr.submit()

                saving_transactionr = frappe.get_doc({
                    'doctype': 'General Ledger II',
                    'account': savings_product.monthly_fees_account,
                    'label_for_report': coa_account_name3.name,
                    'transaction_type': 1,
                    'transaction_type_name': "Monthly Fees",
                    'posting_date': datetime.now().date(),
                    'company': savings_product.company,
                    'branch': savings_product.branch,
                    'amount': savings_product.monthly_fees,
                    'credit': savings_product.monthly_fees,
                    'debit': 0,
                    'main_parent': "Income",
                    'sub_parent': "Income",
                    'category': coa_account_name3,
                    'savings_account': savings_account_id
                })
                saving_transactionr.insert()
                saving_transactionr.submit()
    else:
        saving_transactionr = frappe.get_doc({
            'doctype': 'General Ledger II',
            'account': savings_product.monthly_fees_account,
            'label_for_report': coa_account_name3.name,
            'transaction_type': 1,
            'transaction_type_name': "Monthly Fees",
            'posting_date': datetime.now().date(),
            'company': savings_product.company,
            'branch': savings_product.branch,
            'amount': savings_product.monthly_fees,
            'credit': savings_product.monthly_fees,
            'debit': 0,
            'main_parent': "Income",
            'sub_parent': "Income",
            'category': coa_account_name3,
            'savings_account': savings_account_id
        })
        saving_transactionr.insert()
        saving_transactionr.submit()
        
        coa_account_name2 = frappe.get_doc("Account", {"name": savings_product.customer_balance_account})
        saving_transactionr2 = frappe.get_doc({
            'doctype': 'General Ledger II',
            'account': savings_product.customer_balance_account,
            'label_for_report': coa_account_name2.name,
            'transaction_type': 1,
            'transaction_type_name': "Monthly Fees",
            'posting_date': datetime.now().date(),
            'company': savings_product.company,
            'branch': savings_product.branch,
            'amount': savings_product.monthly_fees,
            'credit': 0,
            'debit': savings_product.monthly_fees,
            'main_parent': "Liabilities",
            'sub_parent': "Balances On Customer Account",
            'category': coa_account_name2,
            'savings_account': savings_account_id
        })
        saving_transactionr2.insert()
        saving_transactionr2.submit()
        
import frappe
from frappe.utils import nowdate
from datetime import datetime

@frappe.whitelist(allow_guest=True)
def run_monthly_savings_charges():
    accounts = frappe.db.sql("""
        SELECT sa.name
        FROM `tabSavings Account` sa
        JOIN `tabSaving Product` sp ON sa.saving_product = sp.name
        WHERE sa.status != 'Inactive' AND sp.monthly_fees > 0
    """, as_dict=True)

    if not accounts:
        return "No active accounts found."

    account_names = [d.name for d in accounts]
    batch_size = 50

    for i in range(0, len(account_names), batch_size):
        batch = account_names[i:i + batch_size]
        frappe.enqueue(
            __name__ + ".process_account_batch",
            account_list=batch,
            queue='long',
            timeout=1500
        )

    return f"Started processing {len(account_names)} accounts in background batches."

def process_account_batch(account_list):
    for account_name in account_list:
        try:
            process_single_account_charge(account_name)
            frappe.db.commit()
        except Exception:
            frappe.db.rollback()
            frappe.log_error(frappe.get_traceback(), f"Charge Failed for {account_name}")

def process_single_account_charge(account_name):
    acc_data = frappe.db.sql("""
        SELECT sa.name, sa.saving_product, sa.balance_derived, 
               sp.monthly_fees, sp.branch, sp.company,
               sp.monthly_fees_account, sp.customer_balance_account, sp.monthly_fees_receivable
        FROM `tabSavings Account` sa
        JOIN `tabSaving Product` sp ON sa.saving_product = sp.name
        WHERE sa.name = %s FOR UPDATE
    """, (account_name,), as_dict=True)

    if not acc_data:
        return

    row = acc_data[0]
    fee = row.monthly_fees
    balance = row.balance_derived
    narration = f"Monthly Charges - {datetime.now().strftime('%B')}"
    transaction_type = frappe.db.get_value("Saving Transaction Type", {"type_name": "Deposit Charge"}, "name")

    st = frappe.get_doc({
        'doctype': 'Saving Transaction',
        'account': row.name,
        'transaction_type': transaction_type,
        'posting_date': nowdate(),
        'branch': row.branch,
        'amount': fee,
        'debit': fee,
        'client_account': row.name,
        'reference': row.name,
        'description': narration,
        'is_parent': 1,
        'allow_charges': 0,
        'docstatus': 1
    }).insert()

    amount_from_balance = min(balance, fee) if balance > 0 else 0
    amount_to_receivable = fee - amount_from_balance

    create_gl_entry(row, row.monthly_fees_account, "Monthly Fees", fee, credit=fee, parent_type="Income")

    if amount_from_balance > 0:
        create_gl_entry(row, row.customer_balance_account, "withdraw", amount_from_balance, debit=amount_from_balance, parent_type="Liabilities")

    if amount_to_receivable > 0:
        manage_receivable(row, amount_to_receivable)

def create_gl_entry(row, gl_account, type_name, amount, debit=0, credit=0, parent_type=""):
    frappe.get_doc({
        'doctype': 'General Ledger II',
        'account': gl_account,
        'label_for_report': gl_account,
        'transaction_type': 1,
        'transaction_type_name': type_name,
        'posting_date': nowdate(),
        'company': row.company,
        'branch': row.branch,
        'amount': amount,
        'debit': debit,
        'credit': credit,
        'main_parent': parent_type,
        'category': gl_account,
        'savings_account': row.name,
        'docstatus': 1
    }).insert()

def manage_receivable(row, amount):
    existing = frappe.db.get_value(
        "General Ledger II",
        {'account': row.monthly_fees_receivable, 'transaction_type_name': "monthlyfessrecivable", 'savings_account': row.name},
        ["name", "debit"], as_dict=True
    )

    if existing:
        new_val = existing.debit + amount
        frappe.db.set_value("General Ledger II", existing.name, {"debit": new_val, "amount": new_val}, update_modified=True)
    else:
        create_gl_entry(row, row.monthly_fees_receivable, "monthlyfessrecivable", amount, debit=amount, parent_type="Assets")

def savings_transaction(date, account, savings_product, amount, trans_type="12"):
    transaction_type = frappe.get_value("Saving Transaction Type", {"name": trans_type})
    
    try:
        saving_transaction = frappe.get_doc({
            'doctype': 'Saving Transaction',
            'account': account.name,
            'transaction_type': transaction_type,
            'posting_date': date,
            'branch': account.branch,
            'amount': amount,
            'debit': amount,
            'client_account': account.name,
            'reference': account.name,
            'description': f'Monthly Charge for {savings_product.product_name}',
            'is_parent': 1,
            'allow_charges': 0 # Ensure this field exists in the Saving Transaction doctype
        })

        saving_transaction.insert()
        saving_transaction.submit()

    except Exception as e:
        frappe.log_error(f"Error in savings_transaction: {e}")

def check_last_three_transactions(account_name):
    transactions = frappe.get_all("Saving Transaction", 
                                  filters={'account': account_name.name}, 
                                  fields=['description', 'creation'], 
                                  order_by='creation desc', 
                                  limit=3)
    
    # Check if there are at least three transactions
    if len(transactions) < 3:
        return False
    # Check if the last three transactions are monthly charges
    for transaction in transactions:
        if "Monthly Charge" not in transaction['description']:
            return False
        
    return True

