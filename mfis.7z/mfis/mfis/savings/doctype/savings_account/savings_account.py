# Copyright (c) 2022, Abbey and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document
import random

import frappe
import requests
import mfis.savings.doctype.savings_charges.savings_charges as savings_charges
import urllib.parse
from datetime import datetime
import mfis.savings.doctype.saving_transaction.saving_transaction as saving_transaction
from mfis.savings.doctype.saving_transaction.saving_transaction import create_deposit_transaction,validate_accounting_period
from frappe.utils import now, get_date_str, today, cint, getdate
from mfis.clients import send_message_to_clients_opening
from frappe.query_builder.functions import _sum


class SavingsAccount(Document):

    def after_insert(self):
        self.account_number = self.name
        set_representatives(self)

    def on_submit(self):
        validate_accounting_period(self)
        create_opening_balance2(self, "on_submit")
        
        send_otp2(self, self.creation, self.client_type)

    def before_save(self):
        self.generate_full_name()
        if self.get('external_id') is None:
            self.set_client_photo()
        # self.branch_name = frappe.db.get_value("Branch", self.branch)

    def set_client_photo(self):
        if self.client_type == 'Client':
            client_photo, client_signature = frappe.db.get_value("Client", self.client, ["photo", 'signature'])

            if client_photo is not None:
                self.client_photo = client_photo
                self.client_signature = client_signature

    def generate_full_name(self):
        if frappe.db.exists(self.client_type, self.client):
            doc = frappe.get_doc(self.client_type, self.client)
            if self.client_type == "Client":
                self.client_name = doc.full_name
            elif self.client_type == "Guarantors_":
                self.client_name = " ".join([doc.get(field) for field in ("first_name", "middle_name", "last_name") if doc.get(field)])
            elif self.client_type == "Account Agent":
                self.client_name = " ".join([doc.get(field) for field in ("first_name", "middle_name", "last_name") if doc.get(field)])
            elif self.client_type == "Group Account":
                self.client_name = doc.first_name                               
            elif self.client_type == "Joint Accounts":
                self.client_name = doc.full_name
                
    @frappe.whitelist()
    def change_officer3(**kwargs):
        savings_account = kwargs.get('account')
        staff_id = kwargs.get('staff_id')
        doc = frappe.get_doc(staff_id, savings_account)
        if staff_id == "Client":
            return doc.full_name
        elif staff_id == "Guarantors_":
            return " ".join([doc.get(field) for field in ("first_name", "middle_name", "last_name") if doc.get(field)])
        elif staff_id == "Account Agent":
            return " ".join([doc.get(field) for field in ("first_name", "middle_name", "last_name") if doc.get(field)])
        elif staff_id == "Group Account":
            return doc.first_name                               
        elif staff_id == "Joint Accounts":
            return doc.full_name



    def autoname(self):
        if self.external_number is None:
            self.name = self.generate_name()
        else:
            self.name = self.external_number
            self.account_number = self.external_number

    def generate_name(self):
        name = self.branch
        saving_product = frappe.get_doc('Saving Product', self.saving_product)
        name += str(saving_product.code)
        name += self.generate_random()

        if frappe.db.exists("Savings Account", name):
            name += self.generate_random()

        return name

    def generate_random(self):
        x = int(random.random() * (99999 - 10000) + 10000)

        return str(x)

    def on_change(self):
        phone_number, email = update_phone_number(self)
        self.phone_number = phone_number
        self.email = email
      
        update_interest_dates(self.name)
        deposit_account_opening_balance(self)

    @frappe.whitelist()
    def actual_balance(self):
        return calculate_account_balance(self.name)

    @frappe.whitelist()
    def available_balance(self, end_date=None):
        return calculate_available_balance(self.name)

def verify_officer(doc, method=None):
    old_doc = doc.get_doc_before_save()

    if old_doc and doc.status == "Active" and old_doc.status in ["Pending", "Approved"] and cint(
            doc.is_old_account) == 0:
        if not doc.staff_id:
            frappe.throw("Please attach officer")


def calculate_available_balance(account, end_date=None):
    actual = calculate_account_balance(account, end_date=end_date)

    if end_date is None:
        end_date = today()

    held_amount = _sum("Account Hold", fieldname="amount", filters={
        "account": account,
        "active": 1,
        'docstatus': 1,
        # "held_on": ['<=', end_date]
    })

    # print(f'held {held_amount}')

    if held_amount is None:
        held_amount = 0

    return actual - held_amount

def send_otp(phone_number, doc, last_4_digits):
    if doc.status == "Active":
        try:
            otp = random.randint(100000, 999999)
            message = f"Welcome to Uwezo Microfinance, {doc.client_name}! Your new {doc.saving_product_name} account ending in {doc.saving_product_name[-6:]} is now open. Thank you for choosing Uwezo Microfinace !"
            url = "https://mortarbulksms.online/apisend_uwezo2.php"
            payload = {
                'number': phone_number,
                'name': message
            }
            headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'Authorization': 'Bearer 68o3IgTdNwAvm0BBGDVeklrdUoJKXDIzRWRpYzRVIP5MKr4CPkpfZJAjc38He1lDtDTGXIJy6BwLkO8x'
            }

            response = requests.post(url, json=payload, headers=headers)
            response.raise_for_status()
            return otp
        except Exception as e:
            return None

def deposit_account_opening_balance(doc, method=None):
    old_doc = doc.get_doc_before_save()

    if old_doc:
        if doc.status == "Active" and old_doc.status in ["Pending", "Approved"]:
            if 1:
                # frappe.enqueue(
                #     method=create_opening_deposit,
                #     queue='long',
                #     timeout=300,
                #     now=False,
                #     doc=doc
                # )
                
                create_opening_deposit(doc)
                

                # frappe.throw(f'{doc.opening_balance}')


def create_opening_deposit(doc):
    deposit_conditions = {
        "account": doc.name,
        "is_opening": True,
        "branch": doc.branch,
        "docstatus": 1
    }
    deposits = frappe.db.exists("Deposit", deposit_conditions)

    if deposits:
        deposits = frappe.get_doc("Deposit", deposit_conditions)
        deposits.cancel()

    deposit = frappe.get_doc({
        "doctype": "Deposit",
        "account": doc.name,
        "amount": 0,
        "branch": doc.branch,
        "posting_date": frappe.utils.now(),
        "is_opening": True,
        "allow_charges": 0
    })

    deposit.save()
    deposit.submit()

@frappe.whitelist(allow_guest=True)
def change_officer3(account: any = None, staff_id: any = None):
    savings_account = kwargs.get('account')
    staff_id = kwargs.get('staff_id')
    frappe.throw(savings_account)
    doc = frappe.get_doc(staff_id, savings_account)
    if staff_id == "Client":
      return doc.full_name
    elif staff_id == "Guarantors_":
      return " ".join([doc.get(field) for field in ("first_name", "middle_name", "last_name") if doc.get(field)])
    elif staff_id == "Account Agent":
      return " ".join([doc.get(field) for field in ("first_name", "middle_name", "last_name") if doc.get(field)])
    elif staff_id == "Group Account":
      return doc.first_name                               
    elif staff_id == "Joint Accounts":
      return doc.full_name

@frappe.whitelist()
def change_officer(**kwargs):
    savings_account = kwargs.get('account')

    doc = frappe.get_doc("Savings Account", savings_account)

    staff_id = kwargs.get('staff_id')
    doc.staff_id = staff_id

    doc.save()

    portfolios = frappe.db.sql(
        """
        SELECT portfolio.account as account, 
        employee.name as employee_name, 
        portfolio.name as portfolio_name
        FROM `tabSaving Portifolio` as portfolio
        LEFT JOIN tabEmployee as employee on  portfolio.parent = employee.name
        WHERE
            portfolio.parenttype = 'Employee'
            and
            portfolio.parentfield = 'clients'
            and
            portfolio.account = %(acc)s
        """,
        {
            "acc": savings_account
        },
        as_dict=True
    )

    if portfolios:
        for portfolio in portfolios:
            frappe.db.delete("Saving Portifolio", portfolio.portfolio_name)

    employee = frappe.get_doc("Employee", staff_id)

    employee.append("clients", {
        "account": savings_account
    })

    employee.save()
 
@frappe.whitelist()
def change_officer2(**kwargs):
    savings_account = kwargs.get('account')
    staff_id = kwargs.get('staff_id')

    if not savings_account or not staff_id:
        frappe.throw("Both 'account' and 'staff_id' must be provided.")

    # Update Client documents
    clients = frappe.get_all("Client", filters={"staff_id": savings_account}, fields=["name"])
    for client in clients:
        frappe.db.set_value("Client", client.name, "staff_id", staff_id)

    # Direct SQL Update for Loan Application Plus documents
    if savings_account != staff_id:  # Make sure account and staff_id are not the same
        query = """
            UPDATE `tabLoan Application Plus`
            SET loan_portfolio = %s
            WHERE loan_portfolio = %s
        """
        frappe.db.sql(query, (staff_id, savings_account))




def update_phone_number(doc):
    phone_number = ""
    email = ""

    mobile, email_address = frappe.db.get_value(doc.client_type, doc.client, ['mobile', 'email'])

    if mobile is not None:
        phone_number = mobile

    if email_address is not None:
        email = email_address

    return phone_number, email


def verify_account_opening(doc, method=None):
    old_doc = doc.get_doc_before_save()

    if old_doc and doc.status == "Active" and old_doc.status in ["Pending", "Approved"] and cint(
            doc.is_old_account) == 0:
        if doc.overdraft_derived > 0:
            frappe.throw("Please deposit account opening fees")

def get_phone_number(table, column, namer):
    query = f"SELECT {column} FROM `tab{table}` WHERE name = %s"
    result = frappe.db.sql(query, (namer,), as_dict=True)
    
    if not result:
        frappe.throw(f"Client with name {namer} not found in table {table}.")
    
    return result[0][column]

def send_otp2(account, posting_date, typer):
    phone_number = get_phone_number(typer, "mobile",  account.client)
    client_name = get_phone_number(typer, "full_name",  account.client)
    send_sms_notification(client_name, account.saving_product_name, account.name, phone_number, posting_date)
 
def send_sms_notification(client_name, account, account2,  phone_number, posting_date):
    try:
        # Prepare the SMS message content
        message = (
            f"Welcome to Uwezo Microfinance, {client_name}! Your {account} account-number  {account2} is now Active. Thnks 4 Choosing Uwezo!"
        )

        message2 = f"Dear {client_name}, your new account with {account} at [Bank Name] has been successfully opened on {posting_date}. Welcome aboard!"

        phone_number_clean = urllib.parse.quote(phone_number.replace("-", ""))
        message_encoded = urllib.parse.quote(message)

        send_message_to_clients_opening(
            recipients=phone_number_clean,
            message=message
        )

        # url = f"https://mortarbulksms.online/apisend_uwezo2.php?number={phone_number_clean}&name={message_encoded}"
        # # Set headers for the API request
        # headers = {
        #     'Content-Type': 'application/json',
        #     'Accept': 'application/json',
        #     'Authorization': 'Bearer 68o3IgTdNwAvm0BBGDVeklrdUoJKXDIzRWRpYzRVIP5MKr4CPkpfZJAjc38He1lDtDTGXIJy6BwLkO8x'
        # }

        # # Send the GET request to the SMS API
        # response = requests.get(url, headers=headers)
        # response.raise_for_status()  # Raise an HTTPError for bad responses

    except requests.exceptions.RequestException as e:
        # Handle specific exceptions from the requests library
        frappe.throw(f"Error sending SMS: {e}")
    except Exception as error:
        # Handle any other unexpected errors
        frappe.throw(f"An unexpected error occurred: {error}")

def create_opening_balance2(doc, method):
    savings_product = frappe.get_doc("Saving Product", {"name": doc.saving_product})
    for charge in savings_product.product_charges:
        charge_value = charge.charge
        charge_nal = frappe.get_doc("Charge", {"name": charge_value})
       
        
        if charge_nal.charge_name == "Account Opening Fees" and charge.branch == doc.branch:
            charge_nal = frappe.get_doc("Charge", {"name": charge_value})
       


            amount = charge_nal.amount
            savings_account_id = doc.name
            
            transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": 12})

            saving_transaction = frappe.get_doc({
                'doctype': 'Saving Transaction',
                'account': doc.name,
                'transaction_type': transaction_type,
                'posting_date': datetime.now().date(),
                'branch': doc.branch,
                'amount': amount,
                'debit': amount,
                'client_account': doc.name,
                'reference': doc.name,
                'description': 'Account Opening2',
                'is_parent': 1,
                'allow_charges': 0
            })
            saving_transaction.insert()
            saving_transaction.submit()

            savings_account3 = frappe.get_doc("Account", {"name": savings_product.acc2})
            account_name2 = savings_account3.name
            saving_transactionr = frappe.get_doc({
                'doctype': 'General Ledger II',
                'account': account_name2,
                'label_for_report': account_name2,
                'transaction_type': transaction_type,
                'transaction_type_name': "accountrecivable",
                'posting_date': datetime.now().date(),
                'company': doc.company,
                'branch': doc.branch,
                'amount': amount,
                'credit': 0,
                'debit': amount,
                'main_parent': "Assets",
                'sub_parent': "Debtors & Receivables",
                'category': account_name2,
                'savings_account': savings_account_id
            })
            saving_transactionr.insert()
            saving_transactionr.submit()

            savings_account = frappe.get_doc("Account", {"name": savings_product.acc})
            account_name = savings_account.name
            saving_transactionr2 = frappe.get_doc({
                'doctype': 'General Ledger II',
                'account': account_name,
                'label_for_report': account_name,
                'transaction_type': transaction_type,
                'transaction_type_name': "Account Opening Fees",
                'posting_date': datetime.now().date(),
                'company': doc.company,
                'branch': doc.branch,
                'amount': amount,
                'credit': amount,
                'debit': 0,
                'main_parent': "Income",
                'sub_parent': "Income",
                'category': account_name,
                'savings_account': savings_account_id
            })
            saving_transactionr2.insert()
            saving_transactionr2.submit()

            # from mfis.clients import get_total_outstanding, close_cycle_renew
            # get_total_outstanding(savings_account_id)



def update_interest_dates(doc):
    saving_account = frappe.get_doc("Savings Account", doc)

    if saving_account.status == "Active":
        if saving_account.start_interest_calculation_date is None and saving_account.start_interest_posting_date is None:
            frappe.db.set_value("Savings Account", saving_account.name, {
                "start_interest_calculation_date": frappe.utils.today(),
                "start_interest_posting_date": frappe.utils.today(),
            })
        if saving_account.last_interest_calculation_date is None:
            frappe.db.set_value("Savings Account", saving_account.name, {
                "last_interest_calculation_date": frappe.utils.today(),
                "last_interest_posting_date": frappe.utils.today(),
            })
        saving_product = frappe.get_doc("Saving Product", saving_account.saving_product)

        if saving_product:
            next_interest_calculation_date = saving_account.next_interest_calculation_date

            if next_interest_calculation_date is None:
                if saving_product.interest_compounding_period_type == "Daily":
                    next_interest_calculation_date = frappe.utils.add_to_date(now(), days=1)

                if saving_product.interest_compounding_period_type == "Weekly":
                    next_interest_calculation_date = frappe.utils.add_to_date(now(), days=7)

                if saving_product.interest_compounding_period_type == "Monthly":
                    next_interest_calculation_date = frappe.utils.add_to_date(now(), months=1)

                if saving_product.interest_compounding_period_type == "Biannual":
                    next_interest_calculation_date = frappe.utils.add_to_date(now(), months=6)

                if saving_product.interest_compounding_period_type == "Annual":
                    next_interest_calculation_date = frappe.utils.add_to_date(now(), months=12)

                frappe.db.set_value("Savings Account", saving_account.name, {
                    "next_interest_calculation_date": next_interest_calculation_date
                })

            next_interest_posting_date = saving_account.next_interest_posting_date

            if next_interest_posting_date is None:
                if saving_product.interest_posting_period_type == "Monthly":
                    next_interest_posting_date = frappe.utils.add_to_date(now(), months=1)

                if saving_product.interest_posting_period_type == "Biannual":
                    next_interest_posting_date = frappe.utils.add_to_date(now(), months=6)

                if saving_product.interest_posting_period_type == "Annual":
                    next_interest_posting_date = frappe.utils.add_to_date(now(), months=12)

                frappe.db.set_value("Savings Account", saving_account.name, {
                    "next_interest_posting_date": next_interest_posting_date
                })


@frappe.whitelist()
def calculate_account_balance(account=None, start_date=None, end_date=None):
    if account is None:
        frappe.throw("Invalid Savings account")

    savings_account = frappe.get_doc("Savings Account", account)

    if savings_account is None:
        frappe.throw("Invalid Savings Account")

    # opening_balance = savings_account.opening_balance

    minimum_account_bal = frappe.db.get_value("Saving Product", savings_account.saving_product, 'min_required_balance')
    conditions = {'account': savings_account.name, 'docstatus': 1}
    if start_date is not None and end_date is not None:
        conditions = {
            'account': savings_account.name,
            # 'docstatus': 1,
            'posting_date': ['between', [start_date, end_date]],
            "is_cancelled": 0
        }

    if start_date and end_date is None:
        conditions = {
            'account': savings_account.name,
            # 'docstatus': 1,
            'posting_date': ['>=', start_date],
            "is_cancelled": 0
        }

    if end_date and start_date is None:
        conditions = {
            'account': savings_account.name,
            # 'docstatus': 1,
            'posting_date': ["<=", getdate(end_date)],
            "is_cancelled": 0
        }

    credit_total = _sum("Saving Transaction", "credit", filters=conditions)
    debit_total = _sum("Saving Transaction", "debit", filters=conditions)

    balance = credit_total - debit_total

    # balance += savings_account.opening_balance

    return balance


@frappe.whitelist()
def update_overdraft(account):
    overdraft = calculate_overdraft(account)

    frappe.db.set_value("Savings Account", account, 'overdraft_derived', overdraft)


def calculate_overdraft(account):
    balance = calculate_account_balance(account)

    overdraft = 0
    if balance < 0:
        overdraft = abs(calculate_account_balance(account))

    return overdraft


def set_representatives(account):
    if account.client_type == "Group":
        clients = frappe.db.get_list("Group Client", filters={"parent": account.client}, fields=["client"])

        if clients:
            for client in clients:
                doc = frappe.get_doc({
                    "doctype": "Account Representative",
                    "client": client.client,
                    "account": account.name
                })

                doc.save()

@frappe.whitelist()
def get_required_signatories(account):

    count = frappe.db.count("Account Representative", {
        "account": account,
        "can_withdraw": 1,
        "active": 1
    })

    return count
