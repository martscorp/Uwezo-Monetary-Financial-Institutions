import frappe

from frappe.utils.dateutils import get_period, get_dates_from_timegrain

from frappe.utils import now

from frappe.utils.data import (
    get_year_start, getdate, today,
)
from mfis import get_default_cost_center


def calculate():
    monthly_dates, biannual_dates, annual_dates = get_dates()

    companies = frappe.db.get_list("Company", pluck="name")

    for company in companies:

        branches = frappe.db.get_list("Branch", filters={"company": company}, pluck="name")

        for branch in branches:
            savings = get_savings_accounts(branch, company)

            if len(savings) > 0:
                calculate_savings_interest(savings, branch, company)


def calculate_savings_interest(savings, branch, company):
    if not savings:
        return

    total_interest_derived = 0

    for saving in savings:
        interest_rate = saving.nominal_annual_interest_rate

        days_in_year = int(saving.interest_calculation_days_in_year_type) or 365

        interest = saving.calculated_interest

        delta = saving.next_interest_calculation_date - saving.last_interest_calculation_date

        days = delta.days

        if days <= 0:
            continue

        balance = saving.balance_derived

        if saving.interest_calculation_type == "Daily Balance":
            if balance > saving.minbalance_for_interest_calculation:
                interest = interest + ((balance + interest) * days * interest_rate / (100 * days_in_year))

        if saving.interest_calculation_type == "Average Daily Balance":

            total_days = 0
            total_balance = 0

            # days = 1
            total_days = total_days + days
            total_balance = total_balance + balance

            balance = total_balance / total_days

            if balance > saving.minbalance_for_interest_calculation:
                interest = interest + ((balance + interest) * total_days * interest_rate / (100 * days_in_year))

        next_interest_calculation_date = None

        if saving.interest_compounding_period_type == "Daily":
            next_interest_calculation_date = frappe.utils.add_to_date(now(), days=1)

        if saving.interest_compounding_period_type == "Weekly":
            next_interest_calculation_date = frappe.utils.add_to_date(now(), days=7)

        if saving.interest_compounding_period_type == "Monthly":
            next_interest_calculation_date = frappe.utils.add_to_date(now(), months=1)

        if saving.interest_compounding_period_type == "Biannual":
            next_interest_calculation_date = frappe.utils.add_to_date(now(), months=6)

        if saving.interest_compounding_period_type == "Annual":
            next_interest_calculation_date = frappe.utils.add_to_date(now(), months=12)

        if next_interest_calculation_date:
            frappe.db.set_value("Savings Account", saving.name, {
                "next_interest_calculation_date": next_interest_calculation_date,
                "calculated_interest": interest,
                "last_interest_calculation_date": now()
            })
            total_interest_derived += interest

    if total_interest_derived > 0:
        make_journal_entry(total_interest=total_interest_derived, branch=branch, company=company)


def make_journal_entry(total_interest, branch, company):
    interest_expense_account, provision_for_interests_account = frappe.db.get_value("Interest Accounts", {
        "branch": branch
    }, ["interest_expense_account", "provision_for_interests_account"])

    if interest_expense_account is None or provision_for_interests_account is None:
        return

    cost_center = get_default_cost_center(branch=branch, company=company)

    journal_entry = frappe.new_doc("Journal Entry")

    journal_entry.title = "Interest Calculation"
    journal_entry.voucher_type = "Journal Entry"
    journal_entry.branch = branch
    journal_entry.company = company
    journal_entry.posting_date = today()

    journal_entry.append("accounts", {
        "account": interest_expense_account,
        "debit": total_interest,
        "debit_in_account_currency": total_interest,
        "against_account": provision_for_interests_account,
        "cost_center": cost_center,
    })

    journal_entry.append("accounts", {
        "account": provision_for_interests_account,
        "credit": total_interest,
        "credit_in_account_currency": total_interest,
        "against_account": interest_expense_account,
        "cost_center": cost_center
    })

    journal_entry.insert(ignore_permissions=True)
    journal_entry.flags.ignore_permissions = True
    journal_entry.submit()


def get_dates():
    monthly_dates, biannual_dates, annual_dates = [], [], []

    year_start = get_year_start(now())

    dates = get_dates_from_timegrain(year_start, frappe.utils.add_to_date(get_year_start(year_start), months=11),
                                     timegrain="Monthly")

    month_index = 0
    for i in dates:
        monthly_dates.append({
            'date': i
        })
        if month_index == 5 or month_index == 11:
            biannual_dates.append({
                'date': i
            })
        if month_index == 11:
            annual_dates.append({
                'date': i
            })

        month_index += 1

    return monthly_dates, biannual_dates, annual_dates


def get_savings_accounts(branch=None, company=None):
    savings = frappe.qb.DocType("Savings Account")

    saving_product = frappe.qb.DocType("Saving Product")

    results = (
        frappe.qb.from_(savings)
        .join(saving_product)
        .on(savings.saving_product == saving_product.name)
        .select(savings.name, savings.branch, savings.company, savings.client, savings.interest_rate,
                savings.balance_derived,
                savings.total_interest_posted_derived,
                savings.start_interest_posting_date, savings.next_interest_posting_date,
                savings.start_interest_calculation_date,
                savings.next_interest_calculation_date, savings.last_interest_calculation_date,
                savings.last_interest_posting_date,
                savings.calculated_interest, saving_product.interest_compounding_period_type,
                saving_product.nominal_annual_interest_rate,
                saving_product.interest_calculation_days_in_year_type,
                saving_product.interest_calculation_type, saving_product.minbalance_for_interest_calculation)
        .where(savings.status == "Active")
        .where(savings.next_interest_calculation_date == f'{frappe.utils.getdate()}')
        .where(savings.interest_rate > 0)
        .where(savings.branch == branch)
        .where(savings.company == company)
    )

    return results.run(as_dict=True)
