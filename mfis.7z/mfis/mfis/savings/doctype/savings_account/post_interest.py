import frappe
from frappe.utils import today
from mfis import get_default_cost_center

from mfis.savings.doctype.saving_transaction_type.saving_transaction_type import \
    get_saving_transaction_type_alias


def process_interest():

    companies = frappe.db.get_list("Company", pluck="name")

    for company in companies:
        saving_products = frappe.db.get_list("Saving Product",
                                             filters={"company": company},
                                             pluck="name")

        branches = frappe.db.get_list("Branch",
                                      filters={"company": company},
                                      pluck="name")

        for branch in branches:
            for product in saving_products:
                savings = get_savings_accounts(branch, product)

                if len(savings) > 0:
                    post_interest(savings, branch, product, company)


def post_interest(savings, branch, product, company=None):
    transaction_type = get_saving_transaction_type_alias("apply_interest")

    total_interest_posted = 0

    for saving in savings:
        now = frappe.utils.now()
        doc = frappe.get_doc({
            'doctype': 'Saving Transaction',
            'account': saving.name,
            'transaction_type': transaction_type,
            'posting_date': now,
            'branch': saving.branch,
            'amount': saving.calculated_interest,
            'reference': "interest_posting",
            'description': "Interest posting",
            'is_parent': 1,
            'allow_charges': 0,
            'reversible': 1,
        })

        doc.insert()
        doc.submit()

        total_interest_posted += saving.calculated_interest

        next_interest_posting_date = None

        if saving.interest_posting_period_type == "Monthly":
            next_interest_posting_date = frappe.utils.add_to_date(now, months=1)

        if saving.interest_posting_period_type == "Biannual":
            next_interest_posting_date = frappe.utils.add_to_date(now, months=6)

        if saving.interest_posting_period_type == "Annually":
            next_interest_posting_date = frappe.utils.add_to_date(now, months=12)

        total_interest_posted_derived = saving.total_interest_posted_derived

        total_interest_posted_derived = float(total_interest_posted_derived) + saving.calculated_interest

        if next_interest_posting_date:
            frappe.db.set_value("Savings Account", saving.name, {
                'calculated_interest': 0,
                'last_interest_posting_date': now,
                'next_interest_posting_date': next_interest_posting_date,
                'total_interest_posted_derived': total_interest_posted_derived
            })

    if total_interest_posted > 0:
        make_journal_entry(total_interest_posted, branch, product, company)


def make_journal_entry(total_interest, branch, product, company):
    provision_for_interests_account = frappe.db.get_value("Interest Accounts", {
        "branch": branch
    }, "provision_for_interests_account")

    if provision_for_interests_account is None:
        return

    portfolio_account = frappe.db.get_value("Saving Product Accounts", {
        "parent": product,
        "branch": branch
    }, "portfolio_account")

    if portfolio_account is None:
        return

    cost_center = get_default_cost_center(branch=branch, company=company)

    journal_entry = frappe.new_doc("Journal Entry")

    journal_entry.title = "Interest Posting to savings"
    journal_entry.voucher_type = "Journal Entry"
    journal_entry.branch = branch
    journal_entry.company = company
    journal_entry.posting_date = today()

    journal_entry.append("accounts", {
        "account": provision_for_interests_account,
        "debit": total_interest,
        "debit_in_account_currency": total_interest,
        "against_account": portfolio_account,
        "cost_center": cost_center
    })

    journal_entry.append("accounts", {
        "account": portfolio_account,
        "credit": total_interest,
        "credit_in_account_currency": total_interest,
        "against_account": provision_for_interests_account,
        "cost_center": cost_center
    })

    journal_entry.insert(ignore_permissions=True)
    journal_entry.flags.ignore_permissions = True
    journal_entry.submit()


def get_savings_accounts(branch, product):
    savings = frappe.qb.DocType("Savings Account")

    saving_product = frappe.qb.DocType("Saving Product")

    results = (
        frappe.qb.from_(savings)
        .join(saving_product)
        .on(savings.saving_product == saving_product.name)
        .select(savings.name, savings.branch, savings.company, savings.calculated_interest, savings.next_interest_posting_date,
                savings.last_interest_posting_date, savings.total_interest_posted_derived, savings.saving_product,
                saving_product.interest_posting_period_type)
        .where(savings.status == "Active")
        .where(savings.next_interest_posting_date == f'{frappe.utils.getdate()}')
        .where(savings.calculated_interest > 0)
        .where(savings.branch == branch)
        .where(savings.saving_product == product)
    )

    return results.run(as_dict=True)
