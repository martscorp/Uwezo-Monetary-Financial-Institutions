# Copyright (c) 2024, Abbey and contributors
# For license information, please see license.txt

# import frappe
import frappe
from frappe.utils import nowdate
from frappe.utils.background_jobs import enqueue
from mfis.clients import get_total_outstanding
from frappe.model.document import Document

class ApplyCharges2(Document):

    def on_submit(self):
        process_charges(self)

def process_charges(doc):
		savings_product = frappe.get_doc("Savings Account", doc.savings_account)
		savings_product2 = frappe.get_doc("Saving Product", savings_product.saving_product)
		
		create_savings_transactions(savings_product, savings_product2, doc)
		get_total_outstanding(savings_product.name)
        

def create_savings_transactions(account, savings_product, self):
    date = nowdate()
    amount_disbursed = savings_product.monthly_fees
    enqueue(
            method=savings_transaction(date, account, savings_product,amount_disbursed),
            queue='long',
            timeout=300,
            now=False,
            job_name=None,
            event=None,
            is_async=True
        )


def savings_transaction(date, account, savings_product, amount, trans_type="4"):
    transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": trans_type})
    
    try:
        saving_transaction = frappe.get_doc({
            'doctype': 'Saving Transaction',
            'account': account.name,
            'transaction_type': transaction_type,
            'posting_date': date,
            'branch': account.branch,
            'amount': amount,
            'debit': amount,
            'client_account': account.name,
            'reference': account.name,
            'description': f'Monthly Charge for {savings_product.product_name}',
            'is_parent': 1,
            'allow_charges': 0 # Ensure this field exists in the Saving Transaction doctype
        })
        
        saving_transaction.insert()
        saving_transaction.submit()

    except Exception as e:
        frappe.log_error(f"Error in savings_transaction: {e}")

   # for company in companies:
    #     execute(company)


# def execute(company):
#     branches = frappe.db.get_list("Branch", filters={"company": company}, pluck="name")

#     for branch in branches:
#         savings_accounts = frappe.qb.DocType("Savings Account")
#         results = (
#             frappe.qb.from_(savings_accounts)
#             .select(savings_accounts.name, savings_accounts.account_number, savings_accounts.status,
#                     savings_accounts.saving_product, savings_accounts.branch,
#                     savings_accounts.balance_derived, savings_accounts.company)
#             .where(savings_accounts.status == "Active")
#             .where(savings_accounts.branch == branch)
#         )
#         results = results.run(as_dict=True)
#         today = datetime.now()
#         for saving_account in results:
#             amount, savings_charges_to_process = savings_charges_service.get_charges(
#                 saving_product=saving_account.saving_product, charge_time_type_name="Monthly",
#                 transaction_amount=saving_account.balance_derived, branch=saving_account.branch,
#                 company=savings_accounts.company)

#             for saving_charge in savings_charges_to_process:
#                 transactions.make_charge_transaction(
#                     client_account=saving_account.name,
#                     posting_date=now(),
#                     branch=saving_account.branch,
#                     amount=saving_charge.get('amount'),
#                     charge=saving_charge.get('charge'),
#                     reference=f"monthly-charge-{today.strftime('%B')}",
#                     description=f"Month charges for {today.strftime('%B')}",
#                     company=company
#                 )
