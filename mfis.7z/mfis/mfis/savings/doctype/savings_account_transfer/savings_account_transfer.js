// Copyright (c) 2024, Abbey and contributors
// For license information, please see license.txt

frappe.ui.form.on('Savings Account Transfer', {
	refresh: function(frm) {
		var user_email = frappe.session.user;
        
		// Get the value of the 'name' field from the 'Employee' doctype where the 'user' field matches user_email
		frappe.db.get_value('Employee', { user: user_email }, 'name', function(result) {
			// Check if the result contains a 'name' field
			if (result && result.name) {
				// Store the retrieved name in the selectedAccount variable
				var selectedAccount = result.name;
		
				// Set the value of the 'loan_portfolio' field in the form to the retrieved name
				frm.set_value('created_by', selectedAccount);
		
				// Alert the retrieved name
			  
			} else {
				// Log an error message if no matching Employee document is found
			//    alert("No Employee document found with the specified email.");
			}
		});
	}
});
