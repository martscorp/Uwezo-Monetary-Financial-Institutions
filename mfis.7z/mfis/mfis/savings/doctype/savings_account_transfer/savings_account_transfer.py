import frappe
from frappe.model.document import Document
from frappe.utils import cint, flt, nowdate
from frappe.utils.background_jobs import enqueue
import requests
import urllib.parse
from mfis.savings.doctype.saving_transaction.saving_transaction import create_deposit_transaction,validate_accounting_period

class SavingsAccountTransfer(Document):
    def on_submit(self):
        validate_accounting_period(self)
        create_savings_transactions(self)

def create_savings_transactions(doc, method=None):
    from_account = frappe.get_doc("Savings Account", doc.from_account)
    to_account = frappe.get_doc("Savings Account", doc.to_account)
    from_accountm = frappe.get_doc("Client", from_account.client)
    to_accountm = frappe.get_doc("Client", to_account.client)
    date = nowdate()
    amount_disbursed = doc.amount

    sender_sms = (f"Dear {from_account.client_name},We have successfully processed a bank transfer of "
                  f"{amount_disbursed} UGX from your account to account {to_account.client_name}-{to_account.name}. For transaction "
                  "details and updates, please use our official mobile app: [App Link].Thank you for banking with us.")
    receiver_sms = (f"Dear {to_account.client_name},You have received a bank transfer of {amount_disbursed} UGX "
                    f"into your account from {from_account.client_name}-{from_account.name}.. For transaction details and updates, please use "
                    "our official mobile app: [App Link].Thank you for choosing our bank.")
    enqueue( 
            method=savings_transaction(date, from_account, amount_disbursed,to_account),
            queue='long',
            timeout=300,
            now=False,
            job_name=None,
            event=None,
            is_async=True
        )
    send_otp(from_accountm.mobile, sender_sms)

    enqueue(
            method=savings_transaction(date, to_account, amount_disbursed,from_account,"2"),
            queue='long',
            timeout=300,
            now=False,
            job_name=None,
            event=None,
            is_async=True
        )
    send_otp(to_accountm.mobile, receiver_sms)

def savings_transaction(date, loan, amount, loan2, trans_tttyype="1", trans_type="1"):
    gg = "To"
    if trans_tttyype == "2":
        gg = "From"
    transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": trans_type})
    try:
        saving_transaction = frappe.get_doc({
            'doctype': 'Saving Transaction',
            'account': loan.name,
            'transaction_type': transaction_type,
            'posting_date': date,
            'branch': loan.branch,
            'amount': amount,
            'credit': amount,
            'client_account': loan.name,  # Ensure this field exists in the Saving Transaction doctype
            'reference': loan.name,
            'description': f'Cash Transfer {gg} {loan2.client_name} {loan2.name}',
            'is_parent': 1,
            'allow_charges': 0
        })

        saving_transaction.insert()
        saving_transaction.submit()

    except Exception as e:
        frappe.log_error(f"Error in savings_transaction: {e}")

def get_phone_number(table, column, filters):
    try:
        query = f"SELECT {column} FROM `tab{table}` WHERE name = %s"
        result = frappe.db.sql(query, filters['name'], as_dict=True)
        if result and result[0].get(column):
            return result[0][column]
        else:
            frappe.throw(f"Client with name {filters['name']} not found")
    except Exception as e:
        frappe.throw(f"Error fetching phone number: {e}")

def send_otp(phone_number, message):
    try:
        url = (f"https://mortarbulksms.online/apisend_uwezo.php?"
               f"number={urllib.parse.quote(str(phone_number))}&name={urllib.parse.quote(str(message))}")
        
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': 'Bearer 68o3IgTdNwAvm0BBGDVeklrdUoJKXDIzRWRpYzRVIP5MKr4CPkpfZJAjc38He1lDtDTGXIJy6BwLkO8x'
        }

        response = requests.get(url, headers=headers)
        response.raise_for_status()

    except requests.exceptions.RequestException as e:
        frappe.throw(f"Error sending OTP: {e}")
    except Exception as error:
        frappe.throw(f"An unexpected error occurred while sending OTP: {error}")
