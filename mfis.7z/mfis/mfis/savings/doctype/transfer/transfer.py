# Copyright (c) 2023, Abbey and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document
from mfis.savings.doctype.saving_transaction.saving_transaction import create_transfer_transaction


class Transfer(Document):
	def on_submit(self):
		create_transfer_transaction(self)

		def on_cancel(self):
			cancel_transaction(self)


def cancel_transaction(doc, method=None):
	conditions = {
		'transfer': doc.name,
		'docstatus': 1
	}
	transaction = frappe.db.exists("Saving Transaction", conditions)

	if transaction:
		transaction = frappe.get_doc("Saving Transaction", conditions)
		transaction.cancel()

