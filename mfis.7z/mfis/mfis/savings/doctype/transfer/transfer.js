// Copyright (c) 2023, Abbey and contributors
// For license information, please see license.txt

frappe.ui.form.on('Transfer', {
	// refresh: function(frm) {

	// }
    onload: function (frm){
        frm.set_query("to_account", function (){
            return {
                "filters" : [
                    ["name", "!=", frm.doc.account],
                    ["status", "=", "Active"]
                ]
            }
        })
    }
});
