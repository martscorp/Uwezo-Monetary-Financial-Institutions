# Copyright (c) 2022, Abbey and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document
import frappe
from mfis import get_default_company
from datetime import datetime

class SavingsCharges(Document):
    pass


import frappe

def get_charges(saving_product=None, charge_time_type_name=None, transaction_amount=0, is_penalty=0, branch=None,
                company=None, trans_type="12"):
  

    amount = 0
    savings_charges = []


    return amount, charge_time_type



def calculate_charge_amount(amount, charge_amount, charge_calculation_type, transaction_amount=0.0):
    charge_fee_amount = 0

    if charge_calculation_type == 'Flat':
        charge_fee_amount = float(charge_amount)
        amount += charge_fee_amount
    elif charge_calculation_type == "Percentage":
        charge_fee_amount = (float(charge_amount) / 100) * transaction_amount
        amount += charge_fee_amount

    return amount, charge_fee_amount
