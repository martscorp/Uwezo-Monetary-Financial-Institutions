// Copyright (c) 2022, Abbey and contributors
// For license information, please see license.txt
frappe.provide("mfis.saving_charge_account");


frappe.ui.form.on('Savings Charges', {
	refresh: function(frm) {
        mfis.saving_charge_account.setup_queries(frm)
	},
    onload: function (frm){
        frm.set_query("charge", function (){
            return {
                "filters" : [
                    ["charge_applies_to", "IN", ["Savings"]],
                    ["active", "=", "1"]
                ]
            }
        })
    }
});

mfis.saving_charge_account.setup_queries = function (frm){
    $.each([
        ["income_account", {"root_type": "Income"}],
        ["accounts_receivable", {"root_type": "Asset", "account_type": "Receivable"}],
        // ["inter_branch_account", {"root_type": "Asset"}],
    ], function (i, v){
        mfis.saving_charge_account.set_custom_query(frm, v)
    })
}


mfis.saving_charge_account.set_custom_query = function(frm, v) {
	var filters = {
		"is_group": 0
	};

	for (var key in v[1]) {
		filters[key] = v[1][key];
	}

    frm.fields_dict["branch_accounts"].grid.get_field(v[0]).get_query = function(doc, cdt, cdn) {
			var d = locals[cdt][cdn];

            filters["branch"] = d.branch
			return {
				filters: filters
			}
    }
}

frappe.ui.form.on('Branch Charge Account', {
    branch: function (frm, cdt, cdn){
         var d = locals[cdt][cdn];

        frappe.model.set_value(cdt, cdn, 'min_cap', frm.doc.min_cap);
        frappe.model.set_value(cdt, cdn, 'max_cap', frm.doc.max_cap);
        frappe.model.set_value(cdt, cdn, 'amount', frm.doc.amount);
    }
})

