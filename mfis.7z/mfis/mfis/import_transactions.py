import frappe
from frappe.utils import today, cint



def create(existing_trans=None):
    from mfis.import_loans import get_import_settings
    from mfis.data_import import create_connection
    allow_import = get_import_settings()

    if allow_import == 0:
        return
    if existing_trans is None:
        existing_trans = []
        old_trans = frappe.get_list("Saving Transaction", fields=["external_id"])

        if len(old_trans):
            for transaction in old_trans:
                if transaction.external_id:
                    existing_trans.append(transaction.external_id)

    # return existing_trans
    connection = create_connection()

    mycursor = connection.cursor(dictionary=True)

    sql_query = """
    SELECT account.account_number as account, trans.id as external_id, trans.type as transaction_type, trans.amount as amount, trans.paid_at as posting_date,
     trans.description as description, trans.reference as reference, trans.done_by as deposited_by, trans.company_id as branch
    FROM fgy_transactions as trans
    LEFT JOIN fgy_client_accounts as account on account.id = trans.account_id
    WHERE trans.deleted_at is null
    and trans.account_type_id = 1
    """

    if len(existing_trans):
        result_string = '(' + ', '.join(existing_trans) + ')'
        sql_query += f"and trans.id not in {result_string}"

    sql_query += " LIMIT 100"

    mycursor.execute(sql_query)

    data = mycursor.fetchall()

    frappe.cache().set_value("transactions", data)

    connection.close()

    data = frappe.cache().get_value("transactions")

    transaction_types = {
        "deposit": "1",
        "charge": "4",
        "withdraw": "5",
        "withdraw_fees": "4",
        "deposit_fees": "4",
        "monthly_charge": "4",
        "account_opening": "3",
        "reconciliation": "1"
    }

    branches = {
        1: "10",
        2: "20",
    }

    if len(data):
        for row in data:
            if not frappe.db.exists("Savings Account", row["account"]):
                continue
            row["transaction_type"] = clean_transactions(row.get("transaction_type"), transaction_types)
            if row["transaction_type"] is None:
                continue
            row["branch"] = clean_transactions(row.get('branch'), branches)

            row["doctype"] = "Saving Transaction"
            row["is_import"] = 1
            if frappe.db.exists("Saving Transaction Type", row["transaction_type"]):
                transaction_type_name = frappe.db.get_value("Saving Transaction Type", row["transaction_type"],
                                                            'type_name')
                row["transaction_type_name"] = transaction_type_name

            transaction = frappe.get_doc(row)
            transaction.insert(ignore_links=True, ignore_permissions=True, ignore_if_duplicate=True)
            transaction.submit()
            existing_trans.append(str(row["external_id"]))

        frappe.db.commit()
        frappe.cache().set_value("transactions", [])
        create(existing_trans)

    else:
        return


def fetch_account_transactions():
    from mfis.import_loans import get_import_settings
    allow_import = get_import_settings()

    if allow_import == 0:
        return
    accounts = frappe.get_list("Savings Account", fields=["name", "external_id"])

    for account in accounts:
        id = account.external_id

        if id is None:
            continue

        fetch_and_process_transactions(id)


@frappe.whitelist()
def fetch_and_process_transactions(account=None):
    from mfis.import_loans import get_import_settings
    from mfis.data_import import create_connection
    allow_import = get_import_settings()

    if allow_import == 0:
        return
    # frappe.log_error("Transactions import", "start")
    existing_trans = []
    old_trans = frappe.get_list("Saving Transaction", fields=["external_id"])

    for transaction in old_trans:
        if transaction.external_id:
            existing_trans.append(transaction.external_id)

    connection = create_connection()
    mycursor = connection.cursor(dictionary=True)

    transaction_types = {
        "deposit": "1",
        "charge": "4",
        "withdraw": "5",
        "withdraw_fees": "4",
        "deposit_fees": "4",
        "monthly_charge": "4",
        "account_opening": "3",
        "reconciliation": "1",
    }

    branches = {
        1: "10",
        2: "20",
    }

    while True:
        sql_query = """
        SELECT account.account_number as account, trans.account_id as account_id, trans.id as external_id, trans.type as transaction_type, trans.amount as amount, trans.paid_at as posting_date,
         trans.description as description, trans.reference as reference, trans.done_by as deposited_by, trans.company_id as branch
        FROM fgy_transactions as trans
        LEFT JOIN fgy_client_accounts as account on account.id = trans.account_id and account.type LIKE '%ClientAccount%'
        WHERE trans.deleted_at is null
        and trans.account_type_id = 1
        and trans.type not in ('expense', 'income', 'expenses')
        """

        if existing_trans:
            result_string = ', '.join(existing_trans)
            sql_query += f"and trans.id NOT IN ({result_string})"

        if account:
            sql_query += f"and trans.account_id = {account}"

        sql_query += """ ORDER BY 
                        trans.created_at DESC
                        LIMIT 1000"""

        mycursor.execute(sql_query)
        data = mycursor.fetchall()

        if not data:
            break

        for row in data:
            account = row['account']
            account_id = row['account_id']
            if not frappe.db.exists("Savings Account", account):
                account = frappe.db.get_value("Savings Account", {"external_id": account_id}, "name")
                if account is None:
                    continue

            row['account'] = account
            # print(f"Original {row['transaction_type']}")

            row["transaction_type"] = transaction_types.get(row.get("transaction_type"))
            row["branch"] = branches.get(row.get('branch'))

            # print(f"{row['transaction_type']} ")
            # frappe.log_error(f"Transactions import", f"transaction id: {row['transaction_type']}")

            if row["transaction_type"] is None:
                continue

            if row["transaction_type"] is not None:
                row["doctype"] = "Saving Transaction"
                row["is_import"] = 1
                if frappe.db.exists("Saving Transaction Type", row["transaction_type"]):
                    transaction_type_name = frappe.db.get_value("Saving Transaction Type", row["transaction_type"],
                                                                'type_name')
                    row["transaction_type_name"] = transaction_type_name

                try:
                    transaction = frappe.get_doc(row)
                    transaction.insert(ignore_links=True, ignore_permissions=True, ignore_if_duplicate=True)
                    transaction.submit()
                    existing_trans.append(str(row["external_id"]))

                    frappe.db.commit()
                except Exception as e:
                    continue

    frappe.cache().set_value("transactions", [])


def clean_transactions(transaction_type, transaction_types):
    from mfis.import_loans import get_import_settings
    allow_import = get_import_settings()

    if allow_import == 0:
        return
    transaction_value = transaction_types.get(transaction_type, None)

    if transaction_value is None:
        print(f'{transaction_type} not available')

    return transaction_value


def make_jv():
    # frappe.db.delete("GL Entry")
    # frappe.db.delete("Journal Entry")
    # frappe.db.delete("Journal Entry Account")
    companies = frappe.get_list("Company", fields=["name"])

    for company in companies:
        saving_products = frappe.get_all("Saving Product", filters={"company": company.name},
                                         fields=["name", "product_name"])

        branches = frappe.get_list("Branch", filters={"company": company.name},
                                   fields=["name", "default_opening_balances"])

        if len(saving_products):
            for branch in branches:
                for product in saving_products:
                    sql_query = """
                    SELECT COALESCE(SUM(transactions.credit - transactions.debit), 0) as amount
                    FROM `tabSaving Transaction` as transactions
                    LEFT JOIN `tabSavings Account` as account on account.name = transactions.account
                    WHERE account.saving_product = %(saving_product)s
                    and account.branch = %(branch)s
                    """

                    results = frappe.db.sql(sql_query, {"saving_product": product.name, "branch": branch.name},
                                            as_dict=True)

                    if results[0].amount > 0:
                        create_jv(branch, company, product, results)
                        print(results[0].amount)


def create_jv(branch, company, product, results):
    portfolio_account, receivables = frappe.db.get_value("Saving Product Accounts",
                                                         {"parent": product.name, "branch": branch.name},
                                                         fieldname=["portfolio_account", "overdraw_account"])

    if portfolio_account is None:
        return

    cost_center = frappe.get_cached_value("Branch", branch.name, "cost_center")

    journal_entry = frappe.new_doc("Journal Entry")
    journal_entry.title = f"Opening balance for {product.product_name} in {branch.name}"
    journal_entry.voucher_type = "Journal Entry"
    journal_entry.branch = branch.name
    journal_entry.company = company.name
    journal_entry.posting_date = today()

    if portfolio_account is None:
        return

    account = portfolio_account

    if cint(results[0].amount) < 0:
        if receivables is None:
            return
        account = receivables

    amount = abs(results[0].amount)

    journal_entry.append("accounts", {
        "account": branch.default_opening_balances,
        "debit": amount,
        "debit_in_account_currency": amount,
        "cost_center": cost_center,
        "against_account": account
    })
    journal_entry.append("accounts", {
        "account": account,
        "credit": amount,
        "credit_in_account_currency": amount,
        "cost_center": cost_center,
        "against_account": branch.default_opening_balances
    })
    journal_entry.insert(ignore_permissions=True)
    journal_entry.submit()
    frappe.db.commit()
