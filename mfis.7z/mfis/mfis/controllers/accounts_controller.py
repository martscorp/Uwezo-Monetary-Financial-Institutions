import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import formatdate
from mfis.accounts.doctype.account.account import get_account_currency
from mfis.accounts.doctype.accounting_dimension.accounting_dimension import get_accounting_dimensions
from mfis.accounts.utils import get_fiscal_years


class AccountMissingError(frappe.ValidationError):
    pass


class AccountsController(Document):
    def __init__(self, *args, **kwargs):
        super(AccountsController, self).__init__(*args, **kwargs)

    def get_gl_dict(self, args, account_currency=None, item=None):
        """this method populates the common properties of a gl entry record"""

        posting_date = args.get("posting_date") or self.get("posting_date")
        fiscal_years = get_fiscal_years(posting_date, branch=self.branch)
        if len(fiscal_years) > 1:
            frappe.throw(
                _("Multiple fiscal years exist for the date {0}. Please set branch in Fiscal Year").format(
                    formatdate(posting_date)
                )
            )
        else:
            fiscal_year = fiscal_years[0][0]

        gl_dict = frappe._dict(
            {
                "branch": self.branch,
                "posting_date": posting_date,
                "fiscal_year": fiscal_year,
                "voucher_type": self.doctype,
                "voucher_no": self.name,
                "remarks": self.get("remarks") or self.get("remark"),
                "debit": 0,
                "credit": 0,
                "debit_in_account_currency": 0,
                "credit_in_account_currency": 0,
                "is_opening": self.get("is_opening") or "No",
                "party_type": None,
                "party": None,
                "project": self.get("project"),
                "post_net_value": args.get("post_net_value"),
            }
        )

        accounting_dimensions = get_accounting_dimensions()
        dimension_dict = frappe._dict()

        for dimension in accounting_dimensions:
            dimension_dict[dimension] = self.get(dimension)
            if item and item.get(dimension):
                dimension_dict[dimension] = item.get(dimension)

        gl_dict.update(dimension_dict)
        gl_dict.update(args)

        if not account_currency:
            account_currency = get_account_currency(gl_dict.account)

        # if gl_dict.account and self.doctype not in [
        #     "Journal Entry",
        #     "Period Closing Voucher",
        # ]:
        #     self.validate_account_currency(gl_dict.account, account_currency)

        # if gl_dict.account and self.doctype not in [
        #     "Journal Entry",
        #     "Period Closing Voucher",
        #     "Payment Entry",
        # ]:
        #     set_balance_in_account_currency(
        #         gl_dict, account_currency, self.get("conversion_rate"), self.branch_currency
        #     )

        return gl_dict
