from mfis.accounts.general_ledger import make_gl_entries, make_reverse_gl_entries

import frappe

import mfis


def get_gl_entries():
    branch = mfis.get_default_company()

    cost_center = mfis.get_default_cost_center(branch)

    gl_entries = [
        frappe._dict({
            "account": "1110 - Cash - UM",
            # "party_type": "Savings Account",
            # "party": self.customer,
            "due_date": frappe.utils.now(),
            "against": "5202 - Commission on Sales - UM",
            "credit": 10000,
            "voucher_type": "Saving Transaction",
            "voucher_no": "1402232",
            "cost_center": cost_center
        },
        )
        ,
        frappe._dict({
            "account": "5202 - Commission on Sales - UM",
            # "party_type": "Savings Account",
            # "party": self.customer,
            "due_date": frappe.utils.now(),
            "against": '1110 - Cash - UM',
            "debit": 10001,
            "voucher_type": "Saving Transaction",
            "voucher_no": "1402232",
            "cost_center": cost_center
        }),
        frappe._dict({
            "account": "1110 - Cash - UM",
            # "party_type": "Savings Account",
            # "party": self.customer,
            "due_date": frappe.utils.now(),
            "against": "5202 - Commission on Sales - UM",
            "credit": 1,
            "voucher_type": "Saving Transaction",
            "voucher_no": "1402232",
            "cost_center": cost_center
        },
        )

    ]

    # for g in gl_entries:
    #     print(type(g))

    if gl_entries:
        make_gl_entries(
            gl_entries,
            merge_entries=False,
        )
