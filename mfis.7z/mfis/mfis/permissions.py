import frappe


def branch_query(user):
    if not user:
        user = frappe.session.user

    if "System Manager" in frappe.get_roles(user):
        return

    if frappe.db.exists("Employee", {"user": user}):
        branches = []

        
        query = frappe.db.sql("""
        SELECT e.branch
        FROM  `tabEmployee` as e 
        WHERE e.user = %(user)s
        """, {"user": user}, as_dict=True)

        if len(query):
            for row in query:
                branches.append(row.branch)

            if len(branches):
                branches = '(' + ', '.join(branches) + ')'

            return "(`tabBranch`.name in {branches})".format(branches=branches)
        else:
            frappe.throw("Please contact Administrator to attach branch")

    else:
        frappe.throw("Please contact Administrator to attach branch")
