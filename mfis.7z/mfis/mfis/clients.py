import frappe
from frappe.utils import getdate, now_datetime
from datetime import datetime, timedelta
from frappe.query_builder.functions import _sum
from frappe.query_builder import Field
from frappe.query_builder.functions import Sum
from dateutil.relativedelta import relativedelta
from frappe.utils import nowdate, add_days
import calendar
import json
from frappe import _  # Import translation function



frappe.whitelist(allow_guest=True)
def get_clients(user=None):
    if user is None:
        user = frappe.session.user

    if user is None:
        frappe.local.response["message"] = {
            "success_key": 0,
            "message": "No user details"
        }

    data = frappe.db.sql("""
    SELECT client.name, first_name, last_name, middle_name, full_name,
    gender, mobile, home_mobile, marital_status, photo, signature,
    id_attachement, country, title, branch
    FROM tabClient as client
    WHERE client.owner = %(user)s
    """, {"user": user}, as_dict=True)

    clients = []

    if data:
        clients = data

    frappe.local.response["message"] = clients


@frappe.whitelist(allow_guest=True)
def search_client(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"

        data = frappe.db.sql("""
        SELECT client.name as name, 
        client.full_name as full_name
        FROM tabClient as client
        WHERE client.full_name LIKE %(keyword)s
        OR client.name LIKE %(keyword)s
        OR client.first_name LIKE %(keyword)s
        OR client.last_name LIKE %(keyword)s
        OR client.middle_name LIKE %(keyword)s
        """, {"keyword": keyword}, as_dict=True)

        if data:
            results = data

    return results

##hudson

@frappe.whitelist(allow_guest=True)
def get_dormant_accounts():
    threshold_date = add_days(nowdate(), -90)
    dormant_accounts = frappe.db.sql("""
        SELECT 
            sa.client_name,
            sa.name,
            MAX(st.creation) AS last_transaction_date
        FROM 
            `tabSavings Account` sa
        LEFT JOIN 
            `tabSaving Transaction` st ON sa.name = st.account
        GROUP BY 
            sa.client_name, sa.name
        HAVING 
            last_transaction_date < %(threshold_date)s OR last_transaction_date IS NULL
        ORDER BY 
            sa.name;
    """, {"threshold_date": threshold_date}, as_dict=True)
    
    # Format the date in Python
    for account in dormant_accounts:
        last_transaction_date = account.get('last_transaction_date')
        if last_transaction_date:
            account['last_transaction_date_in_words'] = datetime.strftime(last_transaction_date, '%A, %B %d, %Y')
        else:
            account['last_transaction_date_in_words'] = 'No transactions'

    return dormant_accounts

@frappe.whitelist(allow_guest=True)
def get_non_interest_income(date_range=None, branch=None):
    conditions = []
    values = {}

    # Define default date range if not provided
    if not date_range:
        date_range = [frappe.utils.add_days(frappe.utils.today(), -30), frappe.utils.today()]

    # Parse dates from date_range
    start_date = frappe.utils.getdate(date_range[0])
    end_date = frappe.utils.getdate(date_range[1])

    # Add date conditions
    conditions.append("posting_date BETWEEN %(start_date)s AND %(end_date)s")
    values['start_date'] = start_date
    values['end_date'] = end_date

    # Add branch filter if provided
    if branch:
        conditions.append("branch = %(branch)s")
        values['branch'] = branch

    conditions_str = " AND ".join(conditions) if conditions else "1=1"

    # Construct the SQL query
    sql_query = f"""
        SELECT 
            posting_date AS "Date",
            company AS "Company",
            branch AS "Branch",
            type AS "Type",
            SUM(amount) AS "Amount"
        FROM
            `tabBank Transactions`
        WHERE
            {conditions_str}
            AND type IN ('Account Opening Fees', 'Deposit Fees', 'Withdrawal Fees', 'Penalties', 'Monthly Fees')
        GROUP BY
            posting_date, company, branch, type
        ORDER BY
            posting_date DESC;
    """

    # Execute the query and return results as a dictionary
    non_interest_income = frappe.db.sql(sql_query, values, as_dict=True)
    
    return non_interest_income



@frappe.whitelist(allow_guest=True)
def get_income_by_product():
    threshold_date = add_days(nowdate(), -90)
    
    conditions = []
    # You can add conditions based on your requirements, for example:
    # conditions.append("creation >= '{}'".format(threshold_date))
    
    conditions_str = " AND ".join(conditions) if conditions else "1=1"
    
    data = frappe.db.sql("""
        SELECT
            product_name,
            default_principal,
            default_loan_term,
            default_interest_rate,
            minimum_principal,
            maximum_principal,
            SUM(default_principal * default_interest_rate / 100) as total_income,
            COUNT(name) as number_of_loans
        FROM
            `tabLoan Product`
        WHERE
            {conditions}
        GROUP BY
            product_name, default_principal, default_loan_term, default_interest_rate, minimum_principal, maximum_principal
    """.format(conditions=conditions_str), as_dict=1)
    
    return data

@frappe.whitelist()
def get_clients_loan(txt=None, doctype=None, ignore_user_permissions=False, reference_doctype=None):
    # Example of handling the arguments (you may adjust as per your requirements)
    if not txt:
        txt = ''
    # Fetch existing clients (savings accounts) with status 'Running' from Loan Application Plus
    return frappe.db.sql("""
       SELECT name
        FROM tabSavings Account
        WHERE name NOT IN (
            SELECT clients
            FROM tabLoan Application Plus
            
        )
    """, {
        'txt': "%%%s%%" % txt,
    }, as_dict=True)


@frappe.whitelist(allow_guest=True)
def get_balance_at_hand(keyword: str = None, from_date: str = None, to_date: str = None):
    note_types = [50, 100, 500, 1000, 2000, 5000, 10000, 20000, 50000]
    total_balance = 0
    account_name = frappe.get_value("Banking Account", {

        "chart_of_account": keyword
    })
    user = get_phone_number("Employee", "user", filters={"account": account_name})

    date_conditions = ""
    if from_date:
        date_conditions += " AND ap.creation >= %(from_date)s"
    if to_date:
        date_conditions += " AND ap.creation <= %(to_date)s"

    for note_type in note_types:
        try:
            total_purchase = frappe.db.sql(f"""
                SELECT COALESCE(SUM(cd.qty), 0)
                FROM `tabFloat Purchase` ap, `tabDenominations` cd 
                WHERE ap.account_name = %(account_name)s
                AND cd.parent = ap.name
                AND cd.note = %(note_type)s
                {date_conditions}
            """, {
                "account_name": keyword,
                "note_type": note_type,
                "from_date": from_date,
                "to_date": to_date
            })[0][0] or 0

            total_sell = frappe.db.sql(f"""
                SELECT COALESCE(SUM(cd.qty), 0)
                FROM `tabFloat Sell` ap, `tabDenominations` cd 
                WHERE ap.from_account = %(account_name)s
                AND cd.parent = ap.name
                AND cd.note = %(note_type)s
                {date_conditions}
            """, {
                "account_name": keyword,
                "note_type": note_type,
                "from_date": from_date,
                "to_date": to_date
            })[0][0] or 0

            total_deposit = frappe.db.sql(f"""
                SELECT COALESCE(SUM(cd.qty), 0)
                FROM `tabDeposit` ap, `tabDenominations` cd 
                WHERE ap.modified_by = %(account_name)s
                AND cd.parent = ap.name
                AND cd.note = %(note_type)s
                {date_conditions}
            """, {
                "account_name": user,
                "note_type": note_type,
                "from_date": from_date,
                "to_date": to_date
            })[0][0] or 0

            total_withdrawal = frappe.db.sql(f"""
                SELECT COALESCE(SUM(cd.qty), 0)
                FROM `tabWithdraw` ap, `tabDenominations` cd 
                WHERE ap.modified_by = %(account_name)s
                AND cd.parent = ap.name
                AND cd.note = %(note_type)s
                {date_conditions}
            """, {
                "account_name": user,
                "note_type": note_type,
                "from_date": from_date,
                "to_date": to_date
            })[0][0] or 0

            note_balance = (total_purchase + total_deposit) - (total_sell + total_withdrawal)
            total_balance += note_balance * note_type

        except Exception as e:
            frappe.log_error(f"Error in get_balance_at_hand for note {note_type}: {str(e)}", "get_balance_at_hand")

    return total_balance

@frappe.whitelist(allow_guest=True)
def get_sub_accounts(keyword: str = None):
    if not keyword:
        return []

    client = frappe.db.get_value("Savings Account", keyword, "client")
    if not client:
        return []

    return frappe.db.get_all(
        "Group Account Members",
        filters={"parent": client},
        fields=["client_name", "accountsn", "grouppositions", "authorize_withdraw", "transaction_message"],
        limit=10
    )
import frappe

@frappe.whitelist(allow_guest=True)
def get_chat_messages(room_name: str = None):
    if not room_name:
        return []

    # Ensure the Chat Room exists
    if not frappe.db.exists("Chat Room", {"name": room_name}):
        return []

    # Use raw SQL to fetch chat messages
    messages = frappe.db.sql("""
        SELECT
            m.name,
            m.sender,
            m.sender_email,
            m.content,
            m.creation,
            m.modified,
            m.owner,
            m.room
        FROM
            `tabChat Message` m
        WHERE
            m.room = %s
        ORDER BY
            m.creation DESC
        LIMIT 50
    """, (room_name,), as_dict=True)

    return messages

import frappe
from frappe import _

from datetime import datetime, timedelta, time
from dateutil.relativedelta import relativedelta
import frappe
from frappe.utils import getdate, add_days

from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import frappe
from frappe.utils import getdate
import frappe
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from frappe.utils import getdate


import frappe
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from frappe.utils import getdate, now_datetime

@frappe.whitelist(allow_guest=True)
def process_all_loans():
    loan_names = frappe.get_all(
        "Loan Application Plus",
        fields=["name"],
        filters={
            "payment_intervals": "Days"
        }
    )

    for loan in loan_names:
        post_loan_arrears(loan.name)


@frappe.whitelist(allow_guest=True)
def process_all_loans2():
    # Get all loan applications from 'Loan Application Plus'
    loan_names = frappe.get_all(
        "Loan Application Plus",
        fields=["name"],
        filters={
            "payment_intervals": "Months"
        }
    )

    for loan in loan_names:
        post_loan_arrearsm(loan.name)
    

import frappe
from collections import defaultdict

@frappe.whitelist(allow_guest=True)
def close_old_loans_grouped_by_client():
    loans = frappe.db.get_all("Loan Application Plus",
        fields=["name", "clients", "creation", "status"],
        order_by="clients ASC, creation DESC"
    )

    grouped = defaultdict(list)
    for loan in loans:
        grouped[loan.clients].append(loan)

    closed = []
    for client, loan_list in grouped.items():
        for loan in loan_list[1:]:
            if loan.status != "Closed Loan":
                frappe.db.set_value("Loan Application Plus", loan.name, "status", "Closed Loan")
                closed.append(loan.name)

    frappe.db.commit()
    return {"closed_loans": closed}


# Close a single loan from a transaction string
def close_loan_from_transaction_string(transaction_text):
    try:
        loan_number = transaction_text.strip().split()[-1]
        if frappe.db.exists("Loan Application Plus", loan_number):
            frappe.db.set_value("Loan Application Plus", loan_number, {
                "workflow_state": "Closed",
                "status": "Closed Loan"
            })
            frappe.db.commit()  # Ensure the changes are saved
            return loan_number  # Return the loan number if successful
    except Exception as e:
        frappe.log_error(frappe.get_traceback(), f"Error processing transaction: {transaction_text}")
    return None  # failure or not found
import frappe
from datetime import datetime

@frappe.whitelist()
def update_loan_creation_dates_from_names():
    updated = 0
    loans = frappe.get_all("Loan Application Plus", fields=["name"])

    for loan in loans:
        name = loan["name"]
        try:
            # Expected format: LOAN/2024/11/14/19293
            parts = name.split("/")
            if len(parts) >= 5:
                date_str = f"{parts[1]}-{parts[2]}-{parts[3]}"  # YYYY-MM-DD
                new_creation = datetime.strptime(date_str, "%Y-%m-%d")

                # Direct SQL update required to modify `creation`
                frappe.db.sql("""
                    UPDATE `tabLoan Application Plus`
                    SET creation = %s
                    WHERE name = %s
                """, (new_creation, name))

                updated += 1

        except Exception as e:
            frappe.log_error(frappe.get_traceback(), f"Failed to update creation date for {name}")

    frappe.db.commit()
    frappe.msgprint(f"Updated creation date for {updated} loan(s).")
    return updated
import frappe
from datetime import datetime

@frappe.whitelist(allow_guest=True)
def update_loan_creation_dates_from_names():
    updated = 0
    loans = frappe.get_all("Loan Application Plus", fields=["name"])

    for loan in loans:
        name = loan["name"]
        try:
            # Expected format: LOAN/2024/11/14/19293
            parts = name.split("/")
            if len(parts) >= 5:
                date_str = f"{parts[1]}-{parts[2]}-{parts[3]}"  # YYYY-MM-DD
                new_creation = datetime.strptime(date_str, "%Y-%m-%d")

                # Direct SQL update required to modify `creation`
                frappe.db.sql("""
                    UPDATE `tabLoan Application Plus`
                    SET creation = %s
                    WHERE name = %s
                """, (new_creation, name))

                updated += 1

        except Exception as e:
            frappe.log_error(frappe.get_traceback(), f"Failed to update creation date for {name}")

    frappe.db.commit()
    frappe.msgprint(f"Updated creation date for {updated} loan(s).")
    return updated


@frappe.whitelist(allow_guest=True)
def close_all_refunded_loans():
    closed_loans = []

    transactions = frappe.get_all(
        "Saving Transaction",
        filters={"description": ["like", "Refund of Loan payment Deposit%"]},
        fields=["name", "description"]
    )

    for tx in transactions:
        loan_number = close_loan_from_transaction_string(tx["description"])
        if loan_number:
            closed_loans.append(loan_number)

    frappe.msgprint(f"Closed {len(closed_loans)} loan(s): {', '.join(closed_loans)}")
    return closed_loans

@frappe.whitelist(allow_guest=True)
def close_all_refunded_loans2():
    closed_loans = []

    transactions = frappe.get_all(
        "Saving Transaction",
        filters={"description": ["like", "Refund of Loan payment Deposit%"]},
        fields=["name", "description", "posting_date", "amount"]
    )

    for tx in transactions:
        loan_number = close_loan_from_transaction_string(tx["description"])
        if loan_number:
            closed_loans.append(loan_number)

            # Use the new function to create loan refund transaction
            create_loan_refund_transaction(
                loan_number=loan_number,
                posting_date=tx.get("posting_date"),
                amount=tx.get("amount"),
                reference_no=tx.get("name")
            )

    frappe.msgprint(f"Closed {len(closed_loans)} loan(s): {', '.join(closed_loans)}")
    return closed_loans

@frappe.whitelist(allow_guest=True)
def create_loan_refund_transaction(loan_number, posting_date, amount, reference_no):
    doc = frappe.get_doc({
        "doctype": "Loan Transaction2",
        "loan": loan_number,
        "transaction_type": 4,
        "created_on": posting_date,
        "amount": amount,
        "reference_no": reference_no,
        "description": "Auto-created Loan Refund from Saving Transaction"
    })
    doc.insert(ignore_permissions=True)
    frappe.db.commit()  # Ensure changes are saved

import frappe
from frappe.utils import getdate, nowdate
from datetime import timedelta
from dateutil.relativedelta import relativedelta

@frappe.whitelist(allow_guest=True)
def post_loan_arrearsm(loan):
    if not loan:
        return []

    # Fetch loan document
    loan_data = frappe.get_doc("Loan Application Plus", loan)

    # Fetch loan disbursement
    loan_disbursement = frappe.db.get_list(
        "Loan Disbursement",
        filters={"loan": loan},
        fields=["disbursement_date", "disbursed_amount"],
        limit=1
    )

    if not loan_disbursement:
        return []

    loan_start_date = getdate(loan_disbursement[0].disbursement_date)
    grace_period_days = loan_data.grace_period_on_disbursment or 0
    
    loan_tenure = 12

    repayment_txn_dates = frappe.db.sql("""
        SELECT DATE(created_on) as txn_date
        FROM `tabLoan Transaction2`
        WHERE loan = %s AND transaction_type = 'Repayment'
    """, (loan,), as_dict=True)

    repayment_form_dates = frappe.db.sql("""
        SELECT DATE(created_on) as txn_date
        FROM `tabLoan Repayment`
        WHERE loan = %s
    """, (loan,), as_dict=True)

    repayment_dates = {
        getdate(row.txn_date) for row in repayment_txn_dates + repayment_form_dates
    }

    existing_arrears_dates = frappe.db.sql("""
        SELECT DATE(created_on) as txn_date
        FROM `tabLoan Transaction2`
        WHERE loan = %s AND transaction_type = 'Arrears'
    """, (loan,), as_dict=True)

    existing_arrears_dates = {
        getdate(row.txn_date) for row in existing_arrears_dates
    }

    # === Fixed Uganda Public Holidays from 2019–2025 ===
    uganda_holidays = {
        "2019-01-01", "2019-04-22", "2019-06-04", "2019-08-11", "2019-12-25", "2019-12-26",
        "2020-01-01", "2020-04-13", "2020-05-24", "2020-07-31", "2020-12-25", "2020-12-26",
        "2021-01-01", "2021-04-05", "2021-05-13", "2021-07-20", "2021-12-25", "2021-12-26",
        "2022-01-01", "2022-04-18", "2022-05-02", "2022-07-09", "2022-12-25", "2022-12-26",
        "2023-01-01", "2023-04-10", "2023-04-21", "2023-06-28", "2023-12-25", "2023-12-26",
        "2024-01-01", "2024-04-01", "2024-04-10", "2024-06-16", "2024-12-25", "2024-12-26",
        "2025-01-01", "2025-03-30", "2025-04-21", "2025-06-07", "2025-12-25", "2025-12-26","2021-12-18",
        "2022-12-16","2024-12-20"
    }
    uganda_holidays = {getdate(d) for d in uganda_holidays}
    
    inserted_entries = []
    fixed_penalty_amount = 138.89

    for i in range(1, loan_tenure + 1):
        due_date = loan_start_date + relativedelta(months=i)
        due_date -= timedelta(days=1)
        check_date = due_date
        while check_date.weekday() == 6 or check_date in uganda_holidays:
            check_date += timedelta(days=1)
            
        repayment_made = any(d <= check_date and d.month == check_date.month and d.year == check_date.year for d in repayment_dates)
        arrears_entry_exists = any(d.month == check_date.month and d.year == check_date.year for d in existing_arrears_dates)

        if not repayment_made and not arrears_entry_exists:
            transaction_id = f"ARREARS-{i}"
            name = f"{transaction_id}-{frappe.generate_hash(length=5)}"
            
            try:
                doc = frappe.get_doc({
                    "doctype": "Loan Transaction2",
                    "name": name,
                    "loan": loan,
                    "transaction_type": 6,
                    "amount": fixed_penalty_amount,
                    "credit": 0,
                    "transaction_id": transaction_id,
                    "org_desc": "Arrears",
                    "created_on": check_date,
                    "docstatus": 1
                })
                doc.insert(ignore_permissions=True)
                inserted_entries.append({
                    "name": name,
                    "transaction_id": transaction_id,
                    "created_on": str(check_date)
                })
            except Exception:
                frappe.log_error(frappe.get_traceback(), f"Arrears Insert Failed for {check_date}")

    frappe.db.commit()

# mfi/client.py



import frappe
from frappe.utils import getdate, nowdate
from datetime import timedelta, datetime, date

def to_date_safe(value):
    """
    Safely converts various date-like values to a date object.
    
    Args:
        value (any): The value to convert. Can be a string, datetime.date,
                     or datetime.datetime object.
    
    Returns:
        datetime.date: The converted date object.
        
    Raises:
        TypeError: If the input value cannot be safely converted.
    """
    if isinstance(value, str):
        # Handle string input by using Frappe's getdate
        return getdate(value)
    elif isinstance(value, datetime):
        # If it's a datetime object, extract the date part
        return value.date()
    elif isinstance(value, date):
        # If it's already a date object, return it as is
        return value
    return value



def get_repayment_dates_length(start_date_str, grace_period, loan_tenure):
    start_date = datetime.strptime(start_date_str, "%Y-%m-%d")
    # Assuming grace_period and loan_tenure are in days
    end_date = start_date + timedelta(days=loan_tenure)

    repayment_days = 0
    current_date = start_date

    # Iterate through the date range
    while current_date <= end_date:
        if current_date.weekday() != 6 :  # 6 = Sunday
            repayment_days += 1
        current_date += timedelta(days=1)

    return (repayment_days-grace_period)



@frappe.whitelist(allow_guest=True)
def get_unpaid(loan):
    """
    Calculates unpaid principal, interest, and penalties for a given loan.
    Preserves original logic, fixes date comparison issues.
    Returns: unpaid_principal, unpaid_interest, penaltiess, lastpayemnetdast
    """
    from datetime import timedelta, datetime
    from frappe.utils import getdate, nowdate



    loan_id = loan

    if not frappe.db.exists("Loan Application Plus", loan_id):
        frappe.throw(f"Loan Application Plus with ID '{loan_id}' not found.")

    loan_data = frappe.get_doc("Loan Application Plus", loan_id)

    loan_disbursement = frappe.db.get_list(
        "Loan Disbursement",
        filters={"loan": loan_id},
        fields=["disbursement_date", "disbursed_amount"],
        limit=1
    )

    if not loan_disbursement:
        frappe.throw(f"Loan Disbursement record not found for loan ID '{loan_id}'.")

    loan_disbursement_doc = loan_disbursement[0]
    loan_start_date = to_date_safe(loan_disbursement_doc.disbursement_date)
    disbursed_amount = loan_disbursement_doc.disbursed_amount

    payment_intervals = loan_data.payment_intervals
    grace_period = float(loan_data.grace_period_on_disbursment)
    interestrater = float(loan_data.loan_interest + loan_data.collection_fees)
    loan_tenure = float(loan_data.loan_tenure)

    loan_interest_expected_list = frappe.db.get_list(
        "Loan Transaction2",
        filters={"loan": loan_id, "transaction_type": 2},
        fields=["amount"],
    )
    loan_interest_expected = loan_interest_expected_list[0]["amount"] if loan_interest_expected_list else 0

    transaction_query = f"""
        SELECT
            transactions.creation AS posting_date,
            transaction_types.description AS description,
            transactions.amount AS amount,
            0 AS credit,
            transactions.principal_repaid_derived + transactions.principal_recovered AS principal,
            transactions.interest_repaid_derived + transactions.interest_recovered AS interest,
            transactions.penalties_repaid_derived + transactions.penalties_recovered AS penalty,
            transactions.name AS transaction_id,
            transactions.description AS org_desc
        FROM `tabLoan Transaction2` AS transactions
        JOIN `tabLoan Transaction Type` AS transaction_types ON transactions.transaction_type = transaction_types.name
        WHERE transactions.loan = '{loan_id}'
            AND transaction_types.description NOT IN ('Apply Interest')
            #  

        UNION ALL

        SELECT
            repayment.creation AS posting_date,
            'Loan Repayment' AS description,
            repayment.amount AS amount,
            repayment.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            repayment.name AS transaction_id,
            '' AS org_desc
        FROM `tabLoan Repayment` AS repayment
        WHERE  repayment.loan = '{loan_id}'

        UNION ALL

        SELECT
            waive.creation AS posting_date,
            CONCAT('Waive Loan II-', waive.waive_type) AS description,
            waive.amount AS amount,
            waive.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            waive.name AS transaction_id,
            '' AS org_desc
        FROM `tabWaive Loan II` AS waive
        WHERE waive.loan = '{loan_id}'

        UNION ALL

        SELECT
            writeoff.creation AS posting_date,
            CONCAT('Write off II-', writeoff.waive_type) AS description,
            writeoff.amount AS amount,
            writeoff.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            writeoff.name AS transaction_id,
            '' AS org_desc
        FROM `tabWrite Off Loan II` AS writeoff
        WHERE writeoff.loan = '{loan_id}'

        ORDER BY posting_date asc
    """

    existing_transactions = frappe.db.sql(transaction_query, as_dict=True)

    running_principal_balance = disbursed_amount + loan_interest_expected
    unpaid_interest_arreas = 0.0
    unpaid_penalty_arreas = 0.0
    last_posted_date = None

    daily_interest_rate = (interestrater / 100) / 30
    daily_interest = disbursed_amount * daily_interest_rate
    daily_interest2 = disbursed_amount * daily_interest_rate
    principal_arreas=0
    unpaidintrest = 0.0
    unpaidpriciple = 0.0
    penalty_paid = 0.0
    grace_date_repayment_made = False

    for txn in existing_transactions:
        amount = txn.get("amount", 0.0)

        penalty_paid2 = 0
        principal_paid = 0
        principal_paid2 = 0
        interest_paid = 0
        interest_paid2 = 0
        interest_paid_arrears = 0
        credit = 0
        debit = 0
        original_description = txn.get("org_desc","")
       
        start_date_str  = to_date_safe(loan_start_date)
        repayment_days_length = get_repayment_dates_length(str(start_date_str), grace_period, loan_tenure)
        current_date = txn["posting_date"].date() if isinstance(txn["posting_date"], datetime) else txn["posting_date"]
        daily_interest = disbursed_amount * ((interestrater / 100) / 30)
        daily_interest2 = disbursed_amount * ((interestrater / 100) / 30)
        grace_period_interest = grace_period * daily_interest
        total_interest = ((loan_tenure - grace_period) * daily_interest) + grace_period_interest
        constant_due_amount = (disbursed_amount + total_interest) / (repayment_days_length-1)     
        
        today = datetime.today()
        daily_interest_p2 = ((disbursed_amount + total_interest) / (repayment_days_length)) -daily_interest
        daily_interest_p = round((daily_interest_p2),0) 
        daily_interest_p2 = daily_interest_p           
        grace_period_days = grace_period

        if payment_intervals == "Weeks":
            grace_period_days=7
            grace_period = 7
        elif payment_intervals == "Months":
            grace_period_days=30
            grace_period = 30
        

        loan_start_date_str = start_date_str
        loan_start_date = getdate(loan_start_date_str)
        grace_period_end_date = loan_start_date + timedelta(days=grace_period_days)
        
        if today.weekday() == 1:
            daily_interest = (daily_interest*2)
        isskippale = 0
        if today.weekday() == 5 or today.weekday() == 6:
            isskippale = 1
        

        arrears_txn = {}
        if txn["description"] not in ("Disburserment"):

            if txn["posting_date"].weekday() == 0:
                daily_interest = daily_interest*2
                daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
            else:
                daily_interest = daily_interest2				
                daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
 
            import datetime

            if txn["description"] in ("Arreas"):
                if grace_date_repayment_made:
                    continue
                if  current_date == to_date_safe(grace_period_end_date) and grace_date_repayment_made == False:	
                    if grace_period_days > 0:
                        grace_date_repayment_made = True
                        if isinstance(txn["posting_date"], str):
                            txn_date = datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                        else:
                            txn_date = txn["posting_date"]

                        prev_day = txn_date - datetime.timedelta(days=1)
                        posting_datetime = datetime.combine(prev_day, time(23, 0))
                        unpaidintrest += daily_interest2*(grace_period_days)
                        daily_interest_p = daily_interest_p2 - unpaidintrest
                     
                    else:
                        daily_interest_p = daily_interest_p2
						 	
                if isinstance(txn["posting_date"], str):
                    txn_date = datetime.datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                else:
                    txn_date = txn["posting_date"]

                if txn["posting_date"].weekday() == 0:
                   
                    daily_interest = daily_interest2*2
                  
                    daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
                    
                else:
                    daily_interest = daily_interest2
                 
                    # daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest


                if daily_interest_p > 0:
                    unpaidpriciple += (daily_interest_p) 
                else:
                    unpaidpriciple += (daily_interest_p) 

                penalty_paid  += (1.25/100)/30*((unpaidpriciple))
                running_principal_balance += (1.25/100)/30*((unpaidpriciple))	
                unpaidintrest += (daily_interest) 
                unpaid_interest_arreas += daily_interest
                unpaid_penalty_arreas += penalty_paid
            elif txn["description"] in ("Penalty"):
                unpaid_penalty_arreas += amount
                debit = amount
       
            elif txn["description"] in ("Loan Repayment",):
                if txn["posting_date"].weekday() == 0:
                    daily_interest = daily_interest2*2
                    daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
                else:
                    daily_interest = daily_interest2
                if  current_date >= to_date_safe(grace_period_end_date) and grace_date_repayment_made == False:	
                    if grace_period_days > 0:
                        if isinstance(txn["posting_date"], str):
                            txn_date = datetime.datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                        else:
                            txn_date = txn["posting_date"]
                        # frappe.throw(str(daily_interest))
                        yy=1
                        if  current_date >= to_date_safe(grace_period_end_date):
                            yy=2
                        next_day = txn_date - timedelta(days=yy)
                        posting_datetime = next_day
                        unpaidintrest += daily_interest2*(grace_period_days)
                        daily_interest_p = daily_interest_p2 - unpaidintrest
                      	
                        grace_date_repayment_made = True
                    else:
                        daily_interest_p = daily_interest_p2 		
                if grace_period == 0 or current_date >= to_date_safe(grace_period_end_date):
                    credit = amount
                    payment_allocation = credit
                    # 1. Pay Penalty Arrears
                    if payment_allocation > 0 and unpaid_penalty_arreas <= payment_allocation:
                        penalty_paid2 = unpaid_penalty_arreas
                        penalty_paid -= penalty_paid2
                        if penalty_paid < 0 :
                            penalty_paid=0
                        unpaid_penalty_arreas -= penalty_paid2
                        payment_allocation -= penalty_paid2
                        running_principal_balance -= penalty_paid2	
                    elif payment_allocation > 0:
                        penalty_paid2 = payment_allocation
                        penalty_paid -= penalty_paid2
                        if penalty_paid < 0 :
                            penalty_paid=0
                        unpaid_penalty_arreas -= penalty_paid2
                        payment_allocation = 0
                        running_principal_balance -= penalty_paid2

                    # 2. Pay Interest Arrears
                    if payment_allocation > 0 and unpaidintrest <= payment_allocation:
                        interest_paid_arrears = unpaidintrest
                        interest_paid += unpaidintrest
                        unpaidintrest -= interest_paid_arrears
                        payment_allocation -= interest_paid_arrears
                        running_principal_balance -= interest_paid_arrears
                    elif payment_allocation > 0:
                        interest_paid_arrears = payment_allocation
                        interest_paid += payment_allocation
                        unpaidintrest -= interest_paid_arrears
                        payment_allocation = 0
                        running_principal_balance -= interest_paid_arrears

                    if payment_allocation >= daily_interest:
                        interest_paid_today = daily_interest
                        interest_paid2 += interest_paid_today
                        interest_paid2b += interest_paid_today
                        payment_allocation -= interest_paid_today
                        running_principal_balance -= interest_paid_today						
                    else:
                        interest_paid_today = payment_allocation
                        unpaidintrest  += (daily_interest - interest_paid_today)
                        interest_paid2 += interest_paid_today
                        interest_paid2b += interest_paid_today
                        payment_allocation = 0
                        running_principal_balance -= interest_paid_today

                    # 4. Pay Principal Arrears
                    if payment_allocation > 0 and unpaidpriciple <= payment_allocation:
                        principal_paid_arrears = unpaidpriciple
                        unpaidpriciple -= principal_paid_arrears
                        principal_paid2 += principal_paid_arrears
                        payment_allocation -= principal_paid_arrears
                        running_principal_balance -= principal_paid_arrears
                    elif payment_allocation > 0:
                        principal_paid_arrears = payment_allocation
                        unpaidpriciple -= principal_paid_arrears
                        principal_paid2 += principal_paid_arrears
                        payment_allocation = 0
                        running_principal_balance -= principal_paid_arrears

                    # 5. Pay Current Principal
                    if payment_allocation >= daily_interest_p:
                        principal_paid_current = payment_allocation
                        principal_paid += principal_paid_current
                        payment_allocation -= principal_paid_current
                        running_principal_balance -= principal_paid_current
                    else:
                        principal_paid_current = payment_allocation
                        unpaidpriciple  += (daily_interest_p - principal_paid_current)
                        principal_paid += principal_paid_current
                        payment_allocation = 0
                        running_principal_balance -= principal_paid_current
                  

                    if unpaidpriciple > 0:
                        if isinstance(txn["posting_date"], str):
                            txn_date = datetime.datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                        else:
                            txn_date = txn["posting_date"]
                       
                        next_day = txn_date + timedelta(days=0)
                        posting_datetime = next_day
                        penalty_paid  = (1.25/100)/30*((unpaidpriciple))
                        unpaid_penalty_arreas += penalty_paid
                        penalebalce = max(penalty_paid - penalty_paid2, 0)
                        if unpaidintrest < 0:
                            unpaidintrest = 0
                    
                else:
                    credit = amount
                    payment_allocation = credit

                    # 5. Pay Current Principal
                    if payment_allocation > 0 and daily_interest_p <= payment_allocation:
                        principal_paid_current = credit
                        principal_paid += principal_paid_current
                        payment_allocation -= principal_paid_current
                        running_principal_balance -= principal_paid_current
                    else:
                        principal_paid_current = payment_allocation
                        principal_paid += principal_paid_current
                        payment_allocation -= principal_paid_current
                        running_principal_balance -= principal_paid_current


            elif txn["description"] in ( "Write off II-Principle", "Savings To Loan Transfer", "Loan Closure"):
                credit = amount
                payment_allocation = credit
                running_principal_balance -= amount
       
            elif txn["description"]  in ("Loan Closure"):
                amount = running_principal_balance
                debit = amount
                running_principal_balance -= credit
                payment_allocation = credit
                penalty_paid = 0

                # 4. Pay Principal Arrears
                if payment_allocation > 0 and principal_arreas <= payment_allocation:
                    principal_paid_arrears = min(payment_allocation, principal_arreas)
                    principal_arreas -= principal_paid_arrears
                    principal_paid2 += principal_paid_arrears
                    payment_allocation -= principal_paid_arrears
                else:
                    principal_paid_arrears = payment_allocation  # Pay whatever is left in payment_allocation
                    principal_arreas -= principal_paid_arrears
                    principal_paid2 += principal_paid_arrears
                    payment_allocation -= principal_paid_arrears

                    # 1. Pay Interest Arrears
                if payment_allocation > 0 and interest_arreas <= payment_allocation:
                    interest_paid_arrears = min(payment_allocation, unpaid_interest_arreas)
                    interest_paid_arrears = payment_allocation  # Pay whatever is left in payment_allocation
                    unpaid_interest_arreas -= interest_paid_arrears
                    if unpaid_interest_arreas < 0:
                        unpaid_interest_arreas = 0  # Prevent negative values
                    
                    payment_allocation -= interest_arreas
                    interest_paid += interest_arreas
                    interest_arreas -= interest_arreas
                    if interest_arreas < 0:
                        interest_arreas = 0  
                else:
                    # If payment_allocation is less than interest_arreas, pay the remaining amount in interest arrears
                    interest_paid_arrears = payment_allocation  # Pay whatever is left in payment_allocation
                    unpaid_interest_arreas -= interest_paid_arrears
                    if unpaid_interest_arreas < 0:
                        unpaid_interest_arreas = 0  # Prevent negative values
                    
                    payment_allocation -= interest_paid_arrears
                    interest_paid += interest_paid_arrears
                    interest_arreas -= interest_paid_arrears
                    if interest_arreas < 0:
                        interest_arreas = 0  # Prevent negative values


                # 2. Pay Penalty Arrears
                if payment_allocation > 0 and unpaid_penalty_arreas <= payment_allocation:
                    penalty_paid2 = min(payment_allocation, unpaid_penalty_arreas)
                    unpaid_penalty_arreas -= penalty_paid2
                    payment_allocation -= penalty_paid2
                else:
                    penalty_paid2 = payment_allocation  # Pay whatever is left in payment_allocation
                    unpaid_penalty_arreas -= penalty_paid2
                    payment_allocation -= penalty_paid2
               
			   
                    # 5. Pay Current Principal
                if payment_allocation >= daily_interest_p:
                    principal_paid_current = payment_allocation
                    principal_paid += principal_paid_current
                    payment_allocation -= principal_paid_current
                    running_principal_balance -= principal_paid_current
                else:
                    principal_paid_current = payment_allocation
                    principal_arreas  += (daily_interest_p - principal_paid_current)
                    principal_paid += principal_paid_current
                    payment_allocation = 0
                    running_principal_balance -= principal_paid_current

            elif txn["description"] not in ("Disbursement"):
                debit = amount # Handle other debit transactions
                append_transaction_data(
                output, txn, debit, credit, principal_arreas, unpaidintrest, principal_paid, interest_paid,interest_paid2, penalty_paid, days_in_arrears,
                running_principal_balance ,principal_paid2,penalty_paid2
                )
            

            lastpaidpriciple = principal_paid
            lastpaidpriciple2 = interest_paid2
            if interest_paid2 > daily_interest:
                localalace  =constant_due_amount-principal_paid
                # principal_arreas += localalace
                if localalace >= 0:
                    penalty_paid  += (2.5/100)/30*((localalace))

    return {
        "unpaid_principal": unpaidpriciple,
        "unpaid_interest": unpaidintrest,
        "penaltiess": unpaid_penalty_arreas,
        "lastpayemnetdast": last_posted_date.strftime("%Y/%m/%d") if last_posted_date else ""
    }

import frappe
import datetime
from datetime import datetime, timedelta
import datetime
from datetime import timedelta
from frappe.utils import getdate

@frappe.whitelist(allow_guest=True)
def get_loan_arrears_summary_close(loan_id):

    loan_data = frappe.get_doc("Loan Application Plus", loan_id)
    loan_disbursements = frappe.get_all(
        "Loan Disbursement",
        filters={ "loan": loan_id},
        fields=["*"]
    )
    if loan_disbursements:
        loan_data2 = loan_disbursements[0]  # Get the first matching record
        disbursement_date = loan_data2.get('disbursement_date')


    loan_disbursement = frappe.db.get_list("Loan Disbursement", filters={"loan": loan_id}, fields=["disbursement_date", "disbursed_amount"], limit=1)

    if not loan_disbursement: 
        frappe.throw("Loan Disbursement record not found for the selected loan.")
    payment_intervals = loan_data.payment_intervals
    loan_interest_expected_ = frappe.db.get_list(
        "Loan Transaction2",
        filters={"loan": loan_id, "transaction_type": 2},
        fields=["amount"],
        
    )
    loan_interest_expected = loan_interest_expected_[0]["amount"] if loan_interest_expected_ else 0
    grace_period = float(loan_data.grace_period_on_disbursment)
    interestrater = float(loan_data.loan_interest + loan_data.collection_fees)
    loan_start_date = loan_disbursement[0].disbursement_date
    disbursed_amount = loan_disbursement[0].disbursed_amount
    
    loan_start_date_dt = loan_start_date
    
    loan_tenure  = float(loan_data.loan_tenure)
    daily_interest_rate = (interestrater / 100) / 30 if 30 else 0
    penalty_rate = (2.5 / 100) / 30 if 30 else 0
    from mfis.clients import get_daily_interest
    daily_interest = get_daily_interest(loan_id)
    daily_interest22 = get_daily_interest(loan_id)
    # Fetch loan data
    loan_data = frappe.get_doc("Loan Application Plus", loan_id)
    loan_disbursement = frappe.db.get_list("Loan Disbursement", filters={"loan": loan_id}, fields=["disbursement_date", "disbursed_amount"], limit=1)

    if not loan_disbursement:
        frappe.throw("Loan Disbursement record not found for the selected loan.")

    disbursed_amount = loan_disbursement[0].disbursed_amount
    loan_start_date = loan_disbursement[0].disbursement_date

    payment_intervals = loan_data.payment_intervals
    grace_period_days = float(loan_data.grace_period_on_disbursment)
    interestrater = float(loan_data.loan_interest + loan_data.collection_fees)
    loan_tenure = float(loan_data.loan_tenure)

    # Daily interest and penalty rates
    daily_interest_rate = (interestrater / 100) / 30
    penalty_rate = (2.5 / 100) / 30

    # Fetch all transactions including repayments, waives, and write-offs
    transaction_query = f"""
        SELECT
            transactions.creation AS posting_date,
            transaction_types.description AS description,
            transactions.amount AS amount,
            0 AS credit,
            transactions.principal_repaid_derived + transactions.principal_recovered AS principal,
            transactions.interest_repaid_derived + transactions.interest_recovered AS interest,
            transactions.penalties_repaid_derived + transactions.penalties_recovered AS penalty,
            transactions.name AS transaction_id,
            transactions.description AS org_desc
        FROM `tabLoan Transaction2` AS transactions
        JOIN `tabLoan Transaction Type` AS transaction_types ON transactions.transaction_type = transaction_types.name
        WHERE transactions.loan = '{loan_id}'
            AND transaction_types.description NOT IN ('Apply Interest')
            #  

        UNION ALL

        SELECT
            repayment.creation AS posting_date,
            'Loan Repayment' AS description,
            repayment.amount AS amount,
            repayment.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            repayment.name AS transaction_id,
            '' AS org_desc
        FROM `tabLoan Repayment` AS repayment
        WHERE  repayment.loan = '{loan_id}'

        UNION ALL

        SELECT
            waive.creation AS posting_date,
            CONCAT('Waive Loan II-', waive.waive_type) AS description,
            waive.amount AS amount,
            waive.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            waive.name AS transaction_id,
            '' AS org_desc
        FROM `tabWaive Loan II` AS waive
        WHERE waive.loan = '{loan_id}'

        UNION ALL

        SELECT
            writeoff.creation AS posting_date,
            CONCAT('Write off II-', writeoff.waive_type) AS description,
            writeoff.amount AS amount,
            writeoff.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            writeoff.name AS transaction_id,
            '' AS org_desc
        FROM `tabWrite Off Loan II` AS writeoff
        WHERE writeoff.loan = '{loan_id}'

        ORDER BY posting_date asc
    """

    existing_transactions = frappe.db.sql(transaction_query, as_dict=True)

    unpaid_principal = 0
    unpaid_interest = 0
    unpaid_penalty = 0
    last_posted_date = None

    running_principal_balance = disbursed_amount
    daily_interest = disbursed_amount * daily_interest_rate
    unpaid_interest_arreas = 0
    unpaid_penalty_arreas = 0
    grace_date_repayment_made = False
    initial_outstanding_balance = running_principal_balance + loan_interest_expected
    interest_arreas = 0  # Initialize interest_arreas here
    totaldailpaid = 0
    lastpaidpriciple = 0
    lastpaidpriciple2 = 0
    lastpaidpriciple3 = 0
    lastpaidpriciple33 = 0
    lastpaidpriciple4 = 0
    lastpaidpriciple5 = 0
    lastpaidpriciple6 = 0
    lastpaidpriciple7 = 0
    lastpaidpriciple8 = 0
    penalty_paid = 0
    interest_paid2b = 0
    unpaidintrest = 0
    unpaidpenalt = 0
    unpaidpriciple = 0
    principal_arreas = 0 
    grace_date_repayment_made = False
    for txn in existing_transactions:
        amount = txn.get("amount", 0.0)

        penalty_paid2 = 0
        principal_paid = 0
        principal_paid2 = 0
        interest_paid = 0
        interest_paid2 = 0
        interest_paid_arrears = 0
        credit = 0
        debit = 0
        original_description = txn.get("org_desc","")
        
        start_date_str = getdate(loan_start_date)
        repayment_days_length = get_repayment_dates_length(str(start_date_str), grace_period, loan_tenure)
        current_date = txn["posting_date"].date() if isinstance(txn["posting_date"], datetime) else txn["posting_date"]
        daily_interest = disbursed_amount * ((interestrater / 100) / 30)
        daily_interest2 = disbursed_amount * ((interestrater / 100) / 30)
        grace_period_interest = grace_period * daily_interest
        total_interest = ((loan_tenure - grace_period) * daily_interest) + grace_period_interest
        constant_due_amount = (disbursed_amount + total_interest) / (repayment_days_length-1)      
   
        today = datetime.today()
        daily_interest_p2 = ((disbursed_amount + total_interest) / (repayment_days_length)) -daily_interest
        daily_interest_p = round((daily_interest_p2),0) 
        daily_interest_p2 = daily_interest_p          
        grace_period_days = grace_period

        if payment_intervals == "Weeks":
            grace_period_days=7
            grace_period = 7
        elif payment_intervals == "Months":
            grace_period_days=30
            grace_period = 30
        

        loan_start_date_str = start_date_str
        loan_start_date = getdate(loan_start_date_str)
        grace_period_end_date = loan_start_date + timedelta(days=grace_period_days)
        
        if today.weekday() == 1:
            daily_interest = (daily_interest*2)
        isskippale = 0
        if today.weekday() == 5 or today.weekday() == 6:
            isskippale = 1
        

        arrears_txn = {}
        if txn["description"] not in ("Disburserment"):

            if txn["posting_date"].weekday() == 0:
                daily_interest = daily_interest*2
                daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
            else:
                daily_interest = daily_interest2                
                daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest

            if txn["description"] in ("Arreas"):
                # if grace_date_repayment_made:
                #     continue
                # if  current_date == getdate(grace_period_end_date) and grace_date_repayment_made == False:    
                #     if grace_period_days > 0:
                #         grace_date_repayment_made = True
                #         if isinstance(txn["posting_date"], str):
                #             txn_date = datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                #         else:
                #             txn_date = txn["posting_date"]
                #         next_day = txn_date - timedelta(days=1)
                #         posting_datetime = next_day
                #         unpaidintrest += daily_interest2*(grace_period_days)
                #         daily_interest_p = daily_interest_p2 - unpaidintrest
        
                #     else:
                #         daily_interest_p = daily_interest_p2                             
    
                # if isinstance(txn["posting_date"], str):
                #     txn_date = datetime.datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                # else:
                #     txn_date = txn["posting_date"]

                # if txn["posting_date"].weekday() == 0:
                    
                #     daily_interest = daily_interest2*2
                    
                #     daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
                    
                # else:
                #     daily_interest = daily_interest2
                    
                #     # daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest


                # if daily_interest_p > 0:
                #     unpaidpriciple += (daily_interest_p)    
                # else:
                #     unpaidpriciple += (daily_interest_p)    

                # penalty_paid  += (1.25/100)/30*((unpaidpriciple))
                # running_principal_balance += (1.25/100)/30*((unpaidpriciple))    
                # unpaidintrest += (daily_interest)    
                # unpaid_interest_arreas += daily_interest
                unpaid_penalty_arreas += penalty_paid
    
            elif txn["description"] in ("Penalty"):
                unpaid_penalty_arreas += amount
                debit = amount

            elif txn["description"] in ("Loan Repayment",):
                if txn["posting_date"].weekday() == 0:
                    daily_interest = daily_interest2*2
                    daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
                else:
                    daily_interest = daily_interest2
                if  current_date >= to_date_safe(grace_period_end_date) and grace_date_repayment_made == False:	
                    if grace_period_days > 0:
                        if isinstance(txn["posting_date"], str):
                            txn_date = datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                        else:
                            txn_date = txn["posting_date"]
                        # frappe.throw(str(daily_interest))
                        yy=1
                        if  current_date >= to_date_safe(grace_period_end_date):
                            yy=2
                        next_day = txn_date - timedelta(days=2)
                        posting_datetime = next_day
                        unpaidintrest += daily_interest2*(grace_period_days)
                        daily_interest_p = daily_interest_p2 - unpaidintrest
            
                        grace_date_repayment_made = True
                    else:
                        daily_interest_p = daily_interest_p2 		
                if grace_period == 0 or current_date >= to_date_safe(grace_period_end_date):
                    credit = amount
                    payment_allocation = credit
                    # 1. Pay Penalty Arrears
                    if payment_allocation > 0 and unpaid_penalty_arreas <= payment_allocation:
                        penalty_paid2 = unpaid_penalty_arreas
                        penalty_paid -= penalty_paid2
                        if penalty_paid < 0 :
                            penalty_paid=0
                        unpaid_penalty_arreas -= penalty_paid2
                        payment_allocation -= penalty_paid2
                        running_principal_balance -= penalty_paid2	
                    elif payment_allocation > 0:
                        penalty_paid2 = payment_allocation
                        penalty_paid -= penalty_paid2
                        if penalty_paid < 0 :
                            penalty_paid=0
                        unpaid_penalty_arreas -= penalty_paid2
                        payment_allocation = 0
                        running_principal_balance -= penalty_paid2

                    # 2. Pay Interest Arrears
                    if payment_allocation > 0 and unpaidintrest <= payment_allocation:
                        interest_paid_arrears = unpaidintrest
                        interest_paid += unpaidintrest
                        unpaidintrest -= interest_paid_arrears
                        payment_allocation -= interest_paid_arrears
                        running_principal_balance -= interest_paid_arrears
                    elif payment_allocation > 0:
                        interest_paid_arrears = payment_allocation
                        interest_paid += payment_allocation
                        unpaidintrest -= interest_paid_arrears
                        payment_allocation = 0
                        running_principal_balance -= interest_paid_arrears

                    if payment_allocation >= daily_interest:
                        interest_paid_today = daily_interest
                        interest_paid2 += interest_paid_today
                        interest_paid2b += interest_paid_today
                        payment_allocation -= interest_paid_today
                        running_principal_balance -= interest_paid_today						
                    else:
                        interest_paid_today = payment_allocation
                        unpaidintrest  += (daily_interest - interest_paid_today)
                        interest_paid2 += interest_paid_today
                        interest_paid2b += interest_paid_today
                        payment_allocation = 0
                        running_principal_balance -= interest_paid_today

                    # 4. Pay Principal Arrears
                    if payment_allocation > 0 and unpaidpriciple <= payment_allocation:
                        principal_paid_arrears = unpaidpriciple
                        unpaidpriciple -= principal_paid_arrears
                        principal_paid2 += principal_paid_arrears
                        payment_allocation -= principal_paid_arrears
                        running_principal_balance -= principal_paid_arrears
                    elif payment_allocation > 0:
                        principal_paid_arrears = payment_allocation
                        unpaidpriciple -= principal_paid_arrears
                        principal_paid2 += principal_paid_arrears
                        payment_allocation = 0
                        running_principal_balance -= principal_paid_arrears

                    # 5. Pay Current Principal
                    if payment_allocation >= daily_interest_p:
                        principal_paid_current = payment_allocation
                        principal_paid += principal_paid_current
                        payment_allocation -= principal_paid_current
                        running_principal_balance -= principal_paid_current
                    else:
                        principal_paid_current = payment_allocation
                        unpaidpriciple  += (daily_interest_p - principal_paid_current)
                        principal_paid += principal_paid_current
                        payment_allocation = 0
                        running_principal_balance -= principal_paid_current
                  



                    if unpaidpriciple > 0:
                        if isinstance(txn["posting_date"], str):
                            txn_date = datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                        else:
                            txn_date = txn["posting_date"]
                       
                        next_day = txn_date + timedelta(days=0)
                        posting_datetime = next_day
                        penalty_paid  = (1.25/100)/30*((unpaidpriciple))
                        unpaid_penalty_arreas += penalty_paid
                        penalebalce = max(penalty_paid - penalty_paid2, 0)
                        if unpaidintrest < 0:
                            unpaidintrest = 0
         

                else:
                    credit = amount
                    payment_allocation = credit

                    # 5. Pay Current Principal
                    if payment_allocation > 0 and daily_interest_p <= payment_allocation:
                        principal_paid_current = credit
                        principal_paid += principal_paid_current
                        payment_allocation -= principal_paid_current
                        running_principal_balance -= principal_paid_current
                    else:
                        principal_paid_current = payment_allocation
                        principal_paid += principal_paid_current
                        payment_allocation -= principal_paid_current
                        running_principal_balance -= principal_paid_current
						
            elif txn["description"] in ( "Write off II-Principle", "Savings To Loan Transfer"):
                credit = amount
                payment_allocation = credit
                running_principal_balance -= amount
                principal_paid_current = payment_allocation
                principal_paid += principal_paid_current
                payment_allocation -= principal_paid_current
                running_principal_balance -= principal_paid_current
    
            elif txn["description"] in ( "Write off II-Interest"):
                credit = amount
                payment_allocation = credit
                running_principal_balance -= amount
                interest_paid_today = payment_allocation
                interest_paid2 += interest_paid_today
                interest_paid2b += interest_paid_today
                payment_allocation -= interest_paid_today
                running_principal_balance -= interest_paid_today	
           
            elif txn["description"] in ("Loan Closure"):
                amount = running_principal_balance
                debit = amount
                running_principal_balance -= credit
                payment_allocation = credit
                penalty_paid = 0

                # 4. Pay Principal Arrears
                if payment_allocation > 0 and principal_arreas <= payment_allocation:
                    principal_paid_arrears = min(payment_allocation, principal_arreas)
                    principal_arreas -= principal_paid_arrears
                    principal_paid2 += principal_paid_arrears
                    payment_allocation -= principal_paid_arrears
                else:
                    principal_paid_arrears = payment_allocation  # Pay whatever is left in payment_allocation
                    principal_arreas -= principal_paid_arrears
                    principal_paid2 += principal_paid_arrears
                    payment_allocation -= principal_paid_arrears

                    # 1. Pay Interest Arrears
                if payment_allocation > 0 and interest_arreas <= payment_allocation:
                    interest_paid_arrears = min(payment_allocation, unpaid_interest_arreas)
                    interest_paid_arrears = payment_allocation  # Pay whatever is left in payment_allocation
                    unpaid_interest_arreas -= interest_paid_arrears
                    if unpaid_interest_arreas < 0:
                        unpaid_interest_arreas = 0  # Prevent negative values
                    
                    payment_allocation -= interest_arreas
                    interest_paid += interest_arreas
                    interest_arreas -= interest_arreas
                    if interest_arreas < 0:
                        interest_arreas = 0  
                else:
                    # If payment_allocation is less than interest_arreas, pay the remaining amount in interest arrears
                    interest_paid_arrears = payment_allocation  # Pay whatever is left in payment_allocation
                    unpaid_interest_arreas -= interest_paid_arrears
                    if unpaid_interest_arreas < 0:
                        unpaid_interest_arreas = 0  # Prevent negative values
                    
                    payment_allocation -= interest_paid_arrears
                    interest_paid += interest_paid_arrears
                    interest_arreas -= interest_paid_arrears
                    if interest_arreas < 0:
                        interest_arreas = 0  # Prevent negative values


                # 2. Pay Penalty Arrears
                if payment_allocation > 0 and unpaid_penalty_arreas <= payment_allocation:
                    penalty_paid2 = min(payment_allocation, unpaid_penalty_arreas)
                    unpaid_penalty_arreas -= penalty_paid2
                    payment_allocation -= penalty_paid2
                else:
                    penalty_paid2 = payment_allocation  # Pay whatever is left in payment_allocation
                    unpaid_penalty_arreas -= penalty_paid2
                    payment_allocation -= penalty_paid2
               
               
                    # 5. Pay Current Principal
                if payment_allocation >= daily_interest_p:
                    principal_paid_current = payment_allocation
                    principal_paid += principal_paid_current
                    payment_allocation -= principal_paid_current
                    running_principal_balance -= principal_paid_current
                else:
                    principal_paid_current = payment_allocation
                    principal_arreas  += (daily_interest_p - principal_paid_current)
                    principal_paid += principal_paid_current
                    payment_allocation = 0
                    running_principal_balance -= principal_paid_current

            elif txn["description"] not in ("Disbursement"):
                debit = amount # Handle other debit transactions
      

            lastpaidpriciple = principal_paid
            lastpaidpriciple2 = interest_paid2
            if interest_paid2 > daily_interest:
                localalace  =constant_due_amount-principal_paid
                # principal_arreas += localalace
                if localalace >= 0:
                    penalty_paid  += (2.5/100)/30*((localalace))
            
            lastpaidpriciple = principal_paid
            lastpaidpriciple2 = interest_paid2
            lastpaidpriciple3 += (principal_paid2+principal_paid)
            lastpaidpriciple33 += (principal_paid)
            lastpaidpriciple4 = unpaidpriciple
            lastpaidpriciple5 += (interest_paid+interest_paid2)
            lastpaidpriciple6 += interest_arreas
            lastpaidpriciple7 += penalty_paid2
            lastpaidpriciple8 += penalty_paid

    return {
        'Principle_Paid': lastpaidpriciple3,
        'Principle_Paid2': lastpaidpriciple33,
        'Principle_Outstanding': lastpaidpriciple4,
        'Interest_paid': lastpaidpriciple5,
        'Interest_In_Arrears': lastpaidpriciple6,
        'Penalties_Paid': lastpaidpriciple7,
        'Penalties_Expected': lastpaidpriciple8,

    }


@frappe.whitelist(allow_guest=True)
def get_loan_arrears_summary(loan_id):

    loan_data = frappe.get_doc("Loan Application Plus", loan_id)
    loan_disbursements = frappe.get_all(
        "Loan Disbursement",
        filters={ "loan": loan_id},
        fields=["*"]
    )
    if loan_disbursements:
        loan_data2 = loan_disbursements[0]  # Get the first matching record
        disbursement_date = loan_data2.get('disbursement_date')


    loan_disbursement = frappe.db.get_list("Loan Disbursement", filters={"loan": loan_id}, fields=["disbursement_date", "disbursed_amount"], limit=1)

    if not loan_disbursement:
        frappe.throw("Loan Disbursement record not found for the selected loan.")
    payment_intervals = loan_data.payment_intervals
    loan_interest_expected_ = frappe.db.get_list(
        "Loan Transaction2",
        filters={"loan": loan_id, "transaction_type": 2},
        fields=["amount"],
        
    )
    loan_interest_expected = loan_interest_expected_[0]["amount"] if loan_interest_expected_ else 0
    grace_period = float(loan_data.grace_period_on_disbursment)
    interestrater = float(loan_data.loan_interest + loan_data.collection_fees)
    loan_start_date = loan_disbursement[0].disbursement_date
    disbursed_amount = loan_disbursement[0].disbursed_amount
    
    loan_start_date_dt = loan_start_date
    
    loan_tenure  = float(loan_data.loan_tenure)
    daily_interest_rate = (interestrater / 100) / 30 if 30 else 0
    penalty_rate = (2.5 / 100) / 30 if 30 else 0
    from mfis.clients import get_daily_interest
    daily_interest = get_daily_interest(loan_id)
    # Fetch loan data
    loan_data = frappe.get_doc("Loan Application Plus", loan_id)
    loan_disbursement = frappe.db.get_list("Loan Disbursement", filters={"loan": loan_id}, fields=["disbursement_date", "disbursed_amount"], limit=1)

    if not loan_disbursement:
        frappe.throw("Loan Disbursement record not found for the selected loan.")

    disbursed_amount = loan_disbursement[0].disbursed_amount
    loan_start_date = loan_disbursement[0].disbursement_date

    payment_intervals = loan_data.payment_intervals
    grace_period_days = float(loan_data.grace_period_on_disbursment)
    interestrater = float(loan_data.loan_interest + loan_data.collection_fees)
    loan_tenure = float(loan_data.loan_tenure)

    # Daily interest and penalty rates
    daily_interest_rate = (interestrater / 100) / 30
    penalty_rate = (2.5 / 100) / 30

    # Fetch all transactions including repayments, waives, and write-offs
    transaction_query = f"""
        SELECT
            transactions.creation AS posting_date,
            transaction_types.description AS description,
            transactions.amount AS amount,
            0 AS credit,
            transactions.principal_repaid_derived + transactions.principal_recovered AS principal,
            transactions.interest_repaid_derived + transactions.interest_recovered AS interest,
            transactions.penalties_repaid_derived + transactions.penalties_recovered AS penalty,
            transactions.name AS transaction_id,
            transactions.description AS org_desc
        FROM `tabLoan Transaction2` AS transactions
        JOIN `tabLoan Transaction Type` AS transaction_types ON transactions.transaction_type = transaction_types.name
        WHERE transactions.loan = '{loan_id}'
            AND transaction_types.description NOT IN ('Apply Interest')
            #  

        UNION ALL

        SELECT
            repayment.creation AS posting_date,
            'Loan Repayment' AS description,
            repayment.amount AS amount,
            repayment.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            repayment.name AS transaction_id,
            '' AS org_desc
        FROM `tabLoan Repayment` AS repayment
        WHERE  repayment.loan = '{loan_id}'

        UNION ALL

        SELECT
            waive.creation AS posting_date,
            CONCAT('Waive Loan II-', waive.waive_type) AS description,
            waive.amount AS amount,
            waive.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            waive.name AS transaction_id,
            '' AS org_desc
        FROM `tabWaive Loan II` AS waive
        WHERE waive.loan = '{loan_id}'

        UNION ALL

        SELECT
            writeoff.creation AS posting_date,
            CONCAT('Write off II-', writeoff.waive_type) AS description,
            writeoff.amount AS amount,
            writeoff.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            writeoff.name AS transaction_id,
            '' AS org_desc
        FROM `tabWrite Off Loan II` AS writeoff
        WHERE writeoff.loan = '{loan_id}'

        ORDER BY posting_date asc
    """

    existing_transactions = frappe.db.sql(transaction_query, as_dict=True)

    unpaid_principal = 0
    unpaid_interest = 0
    unpaid_penalty = 0
    last_posted_date = None

    running_principal_balance = disbursed_amount
    daily_interest = disbursed_amount * daily_interest_rate
    unpaid_interest_arreas = 0
    unpaid_penalty_arreas = 0
    grace_date_repayment_made = False
    initial_outstanding_balance = running_principal_balance + loan_interest_expected
    interest_arreas = 0  # Initialize interest_arreas here
    totaldailpaid = 0
    lastpaidpriciple = 0
    lastpaidpriciple2 = 0
    penalty_paid = 0
    interest_paid2b = 0
    unpaidintrest = 0
    unpaidpenalt = 0
    unpaidpriciple = 0
    grace_date_repayment_made = False
    for txn in existing_transactions:
        amount = txn.get("amount", 0.0)

        penalty_paid2 = 0
        principal_paid = 0
        principal_paid2 = 0
        interest_paid = 0
        interest_paid2 = 0
        interest_paid_arrears = 0
        credit = 0
        debit = 0
        original_description = txn.get("org_desc","")
        
        start_date_str = getdate(loan_start_date)
        repayment_days_length = get_repayment_dates_length(str(start_date_str), grace_period, loan_tenure)
        current_date = txn["posting_date"].date() if isinstance(txn["posting_date"], datetime) else txn["posting_date"]
        daily_interest = disbursed_amount * ((interestrater / 100) / 30)
        daily_interest2 = disbursed_amount * ((interestrater / 100) / 30)
        grace_period_interest = grace_period * daily_interest
        total_interest = ((loan_tenure - grace_period) * daily_interest) + grace_period_interest
        constant_due_amount = (disbursed_amount + total_interest) / (repayment_days_length-1)      
   
        today = datetime.today()
        daily_interest_p2 = ((disbursed_amount + total_interest) / (repayment_days_length)) -daily_interest
        daily_interest_p = round((daily_interest_p2),0) 
        daily_interest_p2 = daily_interest_p          
        grace_period_days = grace_period

        if payment_intervals == "Weeks":
            grace_period_days=7
            grace_period = 7
        elif payment_intervals == "Months":
            grace_period_days=30
            grace_period = 30
        

        loan_start_date_str = start_date_str
        loan_start_date = getdate(loan_start_date_str)
        grace_period_end_date = loan_start_date + timedelta(days=grace_period_days)
        
        if today.weekday() == 1:
            daily_interest = (daily_interest*2)
        isskippale = 0
        if today.weekday() == 5 or today.weekday() == 6:
            isskippale = 1
        

        arrears_txn = {}
        if txn["description"] not in ("Disburserment"):

            if txn["posting_date"].weekday() == 0:
                daily_interest = daily_interest*2
                daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
            else:
                daily_interest = daily_interest2                
                daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest


            if txn["description"] in ("Arreas"):
                if grace_date_repayment_made:
                    continue
                if  current_date == getdate(grace_period_end_date) and grace_date_repayment_made == False:    
                    if grace_period_days > 0:
                        grace_date_repayment_made = True
                        if isinstance(txn["posting_date"], str):
                            txn_date = datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                        else:
                            txn_date = txn["posting_date"]
                        next_day = txn_date - timedelta(days=1)
                        posting_datetime = next_day
                        unpaidintrest += daily_interest2*(grace_period_days)
                        daily_interest_p = daily_interest_p2 - unpaidintrest
        
                    else:
                        daily_interest_p = daily_interest_p2                             
    
                if isinstance(txn["posting_date"], str):
                    txn_date = datetime.datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                else:
                    txn_date = txn["posting_date"]

                if txn["posting_date"].weekday() == 0:
                    
                    daily_interest = daily_interest2*2
                    
                    daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
                    
                else:
                    daily_interest = daily_interest2
                    
                    # daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest


                if daily_interest_p > 0:
                    unpaidpriciple += (daily_interest_p)    
                else:
                    unpaidpriciple += (daily_interest_p)    

                penalty_paid  += (1.25/100)/30*((unpaidpriciple))
                running_principal_balance += (1.25/100)/30*((unpaidpriciple))    
                unpaidintrest += (daily_interest)    
                unpaid_interest_arreas += daily_interest
                unpaid_penalty_arreas += penalty_paid
    
            elif txn["description"] in ("Penalty"):
                unpaid_penalty_arreas += amount
                debit = amount

            elif txn["description"] in ("Loan Repayment",):
                last_posted_date = txn["posting_date"].date() if isinstance(txn["posting_date"], datetime) else txn["posting_date"]
                if txn["posting_date"].weekday() == 0:
                    daily_interest = daily_interest2*2
                    daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
                else:
                    daily_interest = daily_interest2
                if  current_date >= getdate(grace_period_end_date) and grace_date_repayment_made == False:    
                    if grace_period_days > 0:
                        if isinstance(txn["posting_date"], str):
                            txn_date = datetime.datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                        else:
                            txn_date = txn["posting_date"]
                        # frappe.throw(str(daily_interest))
                        yy=1
                        if  current_date >= getdate(grace_period_end_date):
                            yy=2
                        next_day = txn_date - timedelta(days=1)
                        posting_datetime = next_day
                        unpaidintrest += daily_interest2*(grace_period_days)
                        daily_interest_p = daily_interest_p2 - unpaidintrest
             
                        grace_date_repayment_made = True
                    else:
                        daily_interest_p = daily_interest_p2         
                if grace_period == 0 or current_date >= getdate(grace_period_end_date):
                    credit = amount
                    payment_allocation = credit
                    # 1. Pay Penalty Arrears
                    if payment_allocation > 0 and unpaid_penalty_arreas <= payment_allocation:
                        penalty_paid2 = unpaid_penalty_arreas
                        penalty_paid -= penalty_paid2
                        if penalty_paid < 0 :
                            penalty_paid=0
                        unpaid_penalty_arreas -= penalty_paid2
                        payment_allocation -= penalty_paid2
                        running_principal_balance -= penalty_paid2    
                    elif payment_allocation > 0:
                        penalty_paid2 = payment_allocation
                        penalty_paid -= penalty_paid2
                        if penalty_paid < 0 :
                            penalty_paid=0
                        unpaid_penalty_arreas -= penalty_paid2
                        payment_allocation = 0
                        running_principal_balance -= penalty_paid2

                    # 2. Pay Interest Arrears
                    if payment_allocation > 0 and unpaidintrest <= payment_allocation:
                        interest_paid_arrears = unpaidintrest
                        interest_paid += unpaidintrest
                        unpaidintrest -= interest_paid_arrears
                        payment_allocation -= interest_paid_arrears
                        running_principal_balance -= interest_paid_arrears
                    elif payment_allocation > 0:
                        interest_paid_arrears = payment_allocation
                        interest_paid += payment_allocation
                        unpaidintrest -= interest_paid_arrears
                        payment_allocation = 0
                        running_principal_balance -= interest_paid_arrears

                    if payment_allocation >= daily_interest:
                        interest_paid_today = daily_interest
                        interest_paid2 += interest_paid_today
                        interest_paid2b += interest_paid_today
                        payment_allocation -= interest_paid_today
                        running_principal_balance -= interest_paid_today                        
                    else:
                        interest_paid_today = payment_allocation
                        unpaidintrest += (daily_interest - interest_paid_today)
                        interest_paid2 += interest_paid_today
                        interest_paid2b += interest_paid_today
                        payment_allocation = 0
                        running_principal_balance -= interest_paid_today

                    # 4. Pay Principal Arrears
                    if payment_allocation > 0 and unpaidpriciple <= payment_allocation:
                        principal_paid_arrears = unpaidpriciple
                        unpaidpriciple -= principal_paid_arrears
                        principal_paid2 += principal_paid_arrears
                        payment_allocation -= principal_paid_arrears
                        running_principal_balance -= principal_paid_arrears
                    elif payment_allocation > 0:
                        principal_paid_arrears = payment_allocation
                        unpaidpriciple -= principal_paid_arrears
                        principal_paid2 += principal_paid_arrears
                        payment_allocation = 0
                        running_principal_balance -= principal_paid_arrears

                    # 5. Pay Current Principal
                    if payment_allocation >= daily_interest_p:
                        principal_paid_current = payment_allocation
                        principal_paid += principal_paid_current
                        payment_allocation -= principal_paid_current
                        running_principal_balance -= principal_paid_current
                    else:
                        principal_paid_current = payment_allocation
                        unpaidpriciple += (daily_interest_p - principal_paid_current)
                        principal_paid += principal_paid_current
                        payment_allocation = 0
                        running_principal_balance -= principal_paid_current
                    

                    if unpaidpriciple > 0:
                        if isinstance(txn["posting_date"], str):
                            txn_date = datetime.datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                        else:
                            txn_date = txn["posting_date"]
                        
            
                        next_day = txn_date - timedelta(days=1)
                        posting_datetime = next_day
                        penalty_paid  = (1.25/100)/30*((unpaidpriciple))
                        unpaid_penalty_arreas += penalty_paid
                        penalebalce = max(penalty_paid - penalty_paid2, 0)
                        if unpaidintrest < 0:
                            unpaidintrest = 0
                        
                else:
                    credit = amount
                    payment_allocation = credit

                    # 5. Pay Current Principal
                    if payment_allocation > 0 and daily_interest_p <= payment_allocation:
                        principal_paid_current = credit
                        principal_paid += principal_paid_current
                        payment_allocation -= principal_paid_current
                        running_principal_balance -= principal_paid_current
                    else:
                        principal_paid_current = payment_allocation
                        principal_paid += principal_paid_current
                        payment_allocation -= principal_paid_current
                        running_principal_balance -= principal_paid_current
                        

            elif txn["description"] in ( "Write off II-Principle", "Savings To Loan Transfer", "Loan Closure"):
                credit = amount
                payment_allocation = credit
                running_principal_balance -= amount
                principal_paid_current = payment_allocation
                principal_paid += principal_paid_current
                payment_allocation -= principal_paid_current
                running_principal_balance -= principal_paid_current
    
            elif txn["description"] in ( "Write off II-Interest"):
                credit = amount
                payment_allocation = credit
                running_principal_balance -= amount
                interest_paid_today = payment_allocation
                interest_paid2 += interest_paid_today
                interest_paid2b += interest_paid_today
                payment_allocation -= interest_paid_today
                running_principal_balance -= interest_paid_today	
                
            elif txn["description"] in ("Loan Closure"):
                amount = running_principal_balance
                debit = amount
                running_principal_balance -= credit
                payment_allocation = credit
                penalty_paid = 0

                # 4. Pay Principal Arrears
                if payment_allocation > 0 and principal_arreas <= payment_allocation:
                    principal_paid_arrears = min(payment_allocation, principal_arreas)
                    principal_arreas -= principal_paid_arrears
                    principal_paid2 += principal_paid_arrears
                    payment_allocation -= principal_paid_arrears
                else:
                    principal_paid_arrears = payment_allocation  # Pay whatever is left in payment_allocation
                    principal_arreas -= principal_paid_arrears
                    principal_paid2 += principal_paid_arrears
                    payment_allocation -= principal_paid_arrears

                    # 1. Pay Interest Arrears
                if payment_allocation > 0 and interest_arreas <= payment_allocation:
                    interest_paid_arrears = min(payment_allocation, unpaid_interest_arreas)
                    interest_paid_arrears = payment_allocation  # Pay whatever is left in payment_allocation
                    unpaid_interest_arreas -= interest_paid_arrears
                    if unpaid_interest_arreas < 0:
                        unpaid_interest_arreas = 0  # Prevent negative values
                    
                    payment_allocation -= interest_arreas
                    interest_paid += interest_arreas
                    interest_arreas -= interest_arreas
                    if interest_arreas < 0:
                        interest_arreas = 0  
                else:
                    # If payment_allocation is less than interest_arreas, pay the remaining amount in interest arrears
                    interest_paid_arrears = payment_allocation  # Pay whatever is left in payment_allocation
                    unpaid_interest_arreas -= interest_paid_arrears
                    if unpaid_interest_arreas < 0:
                        unpaid_interest_arreas = 0  # Prevent negative values
                    
                    payment_allocation -= interest_paid_arrears
                    interest_paid += interest_paid_arrears
                    interest_arreas -= interest_paid_arrears
                    if interest_arreas < 0:
                        interest_arreas = 0  # Prevent negative values


                # 2. Pay Penalty Arrears
                if payment_allocation > 0 and unpaid_penalty_arreas <= payment_allocation:
                    penalty_paid2 = min(payment_allocation, unpaid_penalty_arreas)
                    unpaid_penalty_arreas -= penalty_paid2
                    payment_allocation -= penalty_paid2
                else:
                    penalty_paid2 = payment_allocation  # Pay whatever is left in payment_allocation
                    unpaid_penalty_arreas -= penalty_paid2
                    payment_allocation -= penalty_paid2
                
                 
                    # 5. Pay Current Principal
                if payment_allocation >= daily_interest_p:
                    principal_paid_current = payment_allocation
                    principal_paid += principal_paid_current
                    payment_allocation -= principal_paid_current
                    running_principal_balance -= principal_paid_current
                else:
                    principal_paid_current = payment_allocation
                    principal_arreas += (daily_interest_p - principal_paid_current)
                    principal_paid += principal_paid_current
                    payment_allocation = 0
                    running_principal_balance -= principal_paid_current

            elif txn["description"] not in ("Disbursement"):
                debit = amount # Handle other debit transactions

            
            lastpaidpriciple = principal_paid
            lastpaidpriciple2 = interest_paid2
            if interest_paid2 > daily_interest:
                localalace  =constant_due_amount-principal_paid
                # principal_arreas += localalace
                if localalace >= 0:
                    penalty_paid  += (2.5/100)/30*((localalace))

    return {
        'unpaid_principal': unpaidpriciple,
        'unpaid_interest': unpaidintrest,
        'penaltiess': penalty_paid,
        'lastpayemnetdast': last_posted_date
    }

@frappe.whitelist(allow_guest=True)
def get_loan_arrears_summary2(loan_id):

    loan_data = frappe.get_doc("Loan Application Plus", loan_id)
    loan_disbursements = frappe.get_all(
        "Loan Disbursement",
        filters={ "loan": loan_id},
        fields=["*"]
    )
    if loan_disbursements:
        loan_data2 = loan_disbursements[0]  # Get the first matching record
        disbursement_date = loan_data2.get('disbursement_date')


    loan_disbursement = frappe.db.get_list("Loan Disbursement", filters={"loan": loan_id}, fields=["disbursement_date", "disbursed_amount"], limit=1)

    if not loan_disbursement:
        frappe.throw("Loan Disbursement record not found for the selected loan.")
    payment_intervals = loan_data.payment_intervals
    loan_interest_expected_ = frappe.db.get_list(
        "Loan Transaction2",
        filters={"loan": loan_id, "transaction_type": 2},
        fields=["amount"],
        
    )
    loan_interest_expected = loan_interest_expected_[0]["amount"] if loan_interest_expected_ else 0
    grace_period = float(loan_data.grace_period_on_disbursment)
    interestrater = float(loan_data.loan_interest + loan_data.collection_fees)
    loan_start_date = loan_disbursement[0].disbursement_date
    disbursed_amount = loan_disbursement[0].disbursed_amount
    
    loan_start_date_dt = loan_start_date
    
    loan_tenure  = float(loan_data.loan_tenure)
    daily_interest_rate = (interestrater / 100) / 30 if 30 else 0
    penalty_rate = (2.5 / 100) / 30 if 30 else 0
    from mfis.clients import get_daily_interest
    daily_interest = get_daily_interest(loan_id)
    # Fetch loan data
    loan_data = frappe.get_doc("Loan Application Plus", loan_id)
    loan_disbursement = frappe.db.get_list("Loan Disbursement", filters={"loan": loan_id}, fields=["disbursement_date", "disbursed_amount"], limit=1)

    if not loan_disbursement:
        frappe.throw("Loan Disbursement record not found for the selected loan.")

    disbursed_amount = loan_disbursement[0].disbursed_amount
    loan_start_date = loan_disbursement[0].disbursement_date

    payment_intervals = loan_data.payment_intervals
    grace_period_days = float(loan_data.grace_period_on_disbursment)
    interestrater = float(loan_data.loan_interest + loan_data.collection_fees)
    loan_tenure = float(loan_data.loan_tenure)

    # Daily interest and penalty rates
    daily_interest_rate = (interestrater / 100) / 30
    penalty_rate = (2.5 / 100) / 30

    # Fetch all transactions including repayments, waives, and write-offs
    transaction_query = f"""
        SELECT
            transactions.creation AS posting_date,
            transaction_types.description AS description,
            transactions.amount AS amount,
            0 AS credit,
            transactions.principal_repaid_derived + transactions.principal_recovered AS principal,
            transactions.interest_repaid_derived + transactions.interest_recovered AS interest,
            transactions.penalties_repaid_derived + transactions.penalties_recovered AS penalty,
            transactions.name AS transaction_id,
            transactions.description AS org_desc
        FROM `tabLoan Transaction2` AS transactions
        JOIN `tabLoan Transaction Type` AS transaction_types ON transactions.transaction_type = transaction_types.name
        WHERE transactions.loan = '{loan_id}'
            AND transaction_types.description NOT IN ('Apply Interest')
            #  

        UNION ALL

        SELECT
            repayment.creation AS posting_date,
            'Loan Repayment' AS description,
            repayment.amount AS amount,
            repayment.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            repayment.name AS transaction_id,
            '' AS org_desc
        FROM `tabLoan Repayment` AS repayment
        WHERE  repayment.loan = '{loan_id}'

        UNION ALL

        SELECT
            waive.creation AS posting_date,
            CONCAT('Waive Loan II-', waive.waive_type) AS description,
            waive.amount AS amount,
            waive.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            waive.name AS transaction_id,
            '' AS org_desc
        FROM `tabWaive Loan II` AS waive
        WHERE waive.loan = '{loan_id}'

        UNION ALL

        SELECT
            writeoff.creation AS posting_date,
            CONCAT('Write off II-', writeoff.waive_type) AS description,
            writeoff.amount AS amount,
            writeoff.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            writeoff.name AS transaction_id,
            '' AS org_desc
        FROM `tabWrite Off Loan II` AS writeoff
        WHERE writeoff.loan = '{loan_id}'

        ORDER BY posting_date asc
    """

    existing_transactions = frappe.db.sql(transaction_query, as_dict=True)

    unpaid_principal = 0
    unpaid_interest = 0
    unpaid_penalty = 0
    last_posted_date = None
    principal_paid_ = 0
    interest_paid2_ = 0
    principal_paid_2 = 0
    interest_paid2_2 = 0
    running_principal_balance = disbursed_amount
    daily_interest = disbursed_amount * daily_interest_rate
    unpaid_interest_arreas = 0
    unpaid_penalty_arreas = 0
    grace_date_repayment_made = False
    initial_outstanding_balance = running_principal_balance + loan_interest_expected
    interest_arreas = 0  # Initialize interest_arreas here
    totaldailpaid = 0
    lastpaidpriciple = 0
    lastpaidpriciple2 = 0
    penalty_paid = 0
    interest_paid2b = 0
    unpaidintrest = 0
    unpaidpenalt = 0
    unpaidpriciple = 0
    grace_date_repayment_made = False
    for txn in existing_transactions:
        amount = txn.get("amount", 0.0)

        penalty_paid2 = 0
        principal_paid = 0
        principal_paid2 = 0
        interest_paid = 0
        interest_paid2 = 0
        interest_paid_arrears = 0
        credit = 0
        debit = 0
        original_description = txn.get("org_desc","")
        
        start_date_str = getdate(loan_start_date)
        repayment_days_length = get_repayment_dates_length(str(start_date_str), grace_period, loan_tenure)
        current_date = txn["posting_date"].date() if isinstance(txn["posting_date"], datetime) else txn["posting_date"]
        daily_interest = disbursed_amount * ((interestrater / 100) / 30)
        daily_interest2 = disbursed_amount * ((interestrater / 100) / 30)
        grace_period_interest = grace_period * daily_interest
        total_interest = ((loan_tenure - grace_period) * daily_interest) + grace_period_interest
        constant_due_amount = (disbursed_amount + total_interest) / (repayment_days_length-1)      
   
        today = datetime.today()
        daily_interest_p2 = ((disbursed_amount + total_interest) / (repayment_days_length)) -daily_interest
        daily_interest_p = round((daily_interest_p2),0) 
        daily_interest_p2 = daily_interest_p          
        grace_period_days = grace_period

        if payment_intervals == "Weeks":
            grace_period_days=7
            grace_period = 7
        elif payment_intervals == "Months":
            grace_period_days=30
            grace_period = 30
        

        loan_start_date_str = start_date_str
        loan_start_date = getdate(loan_start_date_str)
        grace_period_end_date = loan_start_date + timedelta(days=grace_period_days)
        
        if today.weekday() == 1:
            daily_interest = (daily_interest*2)
        isskippale = 0
        if today.weekday() == 5 or today.weekday() == 6:
            isskippale = 1
        

        arrears_txn = {}
        if txn["description"] not in ("Disburserment"):

            if txn["posting_date"].weekday() == 0:
                daily_interest = daily_interest*2
                daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
            else:
                daily_interest = daily_interest2                
                daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest


            if txn["description"] in ("Arreas"):
                if grace_date_repayment_made:
                    continue
                if  current_date == getdate(grace_period_end_date) and grace_date_repayment_made == False:    
                    if grace_period_days > 0:
                        grace_date_repayment_made = True
                        if isinstance(txn["posting_date"], str):
                            txn_date = datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                        else:
                            txn_date = txn["posting_date"]
                        next_day = txn_date - timedelta(days=1)
                        posting_datetime = next_day
                        unpaidintrest += daily_interest2*(grace_period_days)
                        daily_interest_p = daily_interest_p2 - unpaidintrest
        
                    else:
                        daily_interest_p = daily_interest_p2                             
    
                if isinstance(txn["posting_date"], str):
                    txn_date = datetime.datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                else:
                    txn_date = txn["posting_date"]

                if txn["posting_date"].weekday() == 0:
                    
                    daily_interest = daily_interest2*2
                    
                    daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
                    
                else:
                    daily_interest = daily_interest2
                    
                    # daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest


                if daily_interest_p > 0:
                    unpaidpriciple += (daily_interest_p)    
                else:
                    unpaidpriciple += (daily_interest_p)    

                penalty_paid  += (1.25/100)/30*((unpaidpriciple))
                running_principal_balance += (1.25/100)/30*((unpaidpriciple))    
                unpaidintrest += (daily_interest)    
                unpaid_interest_arreas += daily_interest
                unpaid_penalty_arreas += penalty_paid
    
            elif txn["description"] in ("Penalty"):
                unpaid_penalty_arreas += amount
                debit = amount

            elif txn["description"] in ("Loan Repayment",):
                last_posted_date = txn["posting_date"].date() if isinstance(txn["posting_date"], datetime) else txn["posting_date"]
                if txn["posting_date"].weekday() == 0:
                    daily_interest = daily_interest2*2
                    daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
                else:
                    daily_interest = daily_interest2
                if  current_date >= getdate(grace_period_end_date) and grace_date_repayment_made == False:    
                    if grace_period_days > 0:
                        if isinstance(txn["posting_date"], str):
                            txn_date = datetime.datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                        else:
                            txn_date = txn["posting_date"]
                        # frappe.throw(str(daily_interest))
                        yy=1
                        if  current_date >= getdate(grace_period_end_date):
                            yy=2
                        next_day = txn_date - timedelta(days=1)
                        posting_datetime = next_day
                        unpaidintrest += daily_interest2*(grace_period_days)
                        daily_interest_p = daily_interest_p2 - unpaidintrest
             
                        grace_date_repayment_made = True
                    else:
                        daily_interest_p = daily_interest_p2         
                if grace_period == 0 or current_date >= getdate(grace_period_end_date):
                    credit = amount
                    payment_allocation = credit
                    # 1. Pay Penalty Arrears
                    if payment_allocation > 0 and unpaid_penalty_arreas <= payment_allocation:
                        penalty_paid2 = unpaid_penalty_arreas
                        penalty_paid -= penalty_paid2
                        if penalty_paid < 0 :
                            penalty_paid=0
                        unpaid_penalty_arreas -= penalty_paid2
                        payment_allocation -= penalty_paid2
                        running_principal_balance -= penalty_paid2    
                    elif payment_allocation > 0:
                        penalty_paid2 = payment_allocation
                        penalty_paid -= penalty_paid2
                        if penalty_paid < 0 :
                            penalty_paid=0
                        unpaid_penalty_arreas -= penalty_paid2
                        payment_allocation = 0
                        running_principal_balance -= penalty_paid2

                    # 2. Pay Interest Arrears
                    if payment_allocation > 0 and unpaidintrest <= payment_allocation:
                        interest_paid_arrears = unpaidintrest
                        interest_paid += unpaidintrest
                        unpaidintrest -= interest_paid_arrears
                        payment_allocation -= interest_paid_arrears
                        running_principal_balance -= interest_paid_arrears
                    elif payment_allocation > 0:
                        interest_paid_arrears = payment_allocation
                        interest_paid += payment_allocation
                        unpaidintrest -= interest_paid_arrears
                        payment_allocation = 0
                        running_principal_balance -= interest_paid_arrears

                    if payment_allocation >= daily_interest:
                        interest_paid_today = daily_interest
                        interest_paid2 += interest_paid_today
                        interest_paid2b += interest_paid_today
                        payment_allocation -= interest_paid_today
                        running_principal_balance -= interest_paid_today                        
                    else:
                        interest_paid_today = payment_allocation
                        unpaidintrest += (daily_interest - interest_paid_today)
                        interest_paid2 += interest_paid_today
                        interest_paid2b += interest_paid_today
                        payment_allocation = 0
                        running_principal_balance -= interest_paid_today

                    # 4. Pay Principal Arrears
                    if payment_allocation > 0 and unpaidpriciple <= payment_allocation:
                        principal_paid_arrears = unpaidpriciple
                        unpaidpriciple -= principal_paid_arrears
                        principal_paid2 += principal_paid_arrears
                        payment_allocation -= principal_paid_arrears
                        running_principal_balance -= principal_paid_arrears
                    elif payment_allocation > 0:
                        principal_paid_arrears = payment_allocation
                        unpaidpriciple -= principal_paid_arrears
                        principal_paid2 += principal_paid_arrears
                        payment_allocation = 0
                        running_principal_balance -= principal_paid_arrears

                    # 5. Pay Current Principal
                    if payment_allocation >= daily_interest_p:
                        principal_paid_current = payment_allocation
                        principal_paid += principal_paid_current
                        payment_allocation -= principal_paid_current
                        running_principal_balance -= principal_paid_current
                    else:
                        principal_paid_current = payment_allocation
                        unpaidpriciple += (daily_interest_p - principal_paid_current)
                        principal_paid += principal_paid_current
                        payment_allocation = 0
                        running_principal_balance -= principal_paid_current
                    

                    if unpaidpriciple > 0:
                        if isinstance(txn["posting_date"], str):
                            txn_date = datetime.datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                        else:
                            txn_date = txn["posting_date"]
                        
            
                        next_day = txn_date - timedelta(days=1)
                        posting_datetime = next_day
                        penalty_paid  = (1.25/100)/30*((unpaidpriciple))
                        unpaid_penalty_arreas += penalty_paid
                        penalebalce = max(penalty_paid - penalty_paid2, 0)
                        if unpaidintrest < 0:
                            unpaidintrest = 0
                        
                else:
                    credit = amount
                    payment_allocation = credit

                    # 5. Pay Current Principal
                    if payment_allocation > 0 and daily_interest_p <= payment_allocation:
                        principal_paid_current = credit
                        principal_paid += principal_paid_current
                        payment_allocation -= principal_paid_current
                        running_principal_balance -= principal_paid_current
                    else:
                        principal_paid_current = payment_allocation
                        principal_paid += principal_paid_current
                        payment_allocation -= principal_paid_current
                        running_principal_balance -= principal_paid_current
                        


            elif txn["description"] in ( "Write off II-Principle", "Savings To Loan Transfer", "Loan Closure"):
                credit = amount
                payment_allocation = credit
                running_principal_balance -= amount
                principal_paid_current = payment_allocation
                principal_paid += principal_paid_current
                payment_allocation -= principal_paid_current
                running_principal_balance -= principal_paid_current
    
            elif txn["description"] in ( "Write off II-Interest"):
                credit = amount
                payment_allocation = credit
                running_principal_balance -= amount
                interest_paid_today = payment_allocation
                interest_paid2 += interest_paid_today
                interest_paid2b += interest_paid_today
                payment_allocation -= interest_paid_today
                running_principal_balance -= interest_paid_today	

            elif txn["description"] in ("Loan Closure"):
                amount = running_principal_balance
                debit = amount
                running_principal_balance -= credit
                payment_allocation = credit
                penalty_paid = 0

                # 4. Pay Principal Arrears
                if payment_allocation > 0 and principal_arreas <= payment_allocation:
                    principal_paid_arrears = min(payment_allocation, principal_arreas)
                    principal_arreas -= principal_paid_arrears
                    principal_paid2 += principal_paid_arrears
                    payment_allocation -= principal_paid_arrears
                else:
                    principal_paid_arrears = payment_allocation  # Pay whatever is left in payment_allocation
                    principal_arreas -= principal_paid_arrears
                    principal_paid2 += principal_paid_arrears
                    payment_allocation -= principal_paid_arrears

                    # 1. Pay Interest Arrears
                if payment_allocation > 0 and interest_arreas <= payment_allocation:
                    interest_paid_arrears = min(payment_allocation, unpaid_interest_arreas)
                    interest_paid_arrears = payment_allocation  # Pay whatever is left in payment_allocation
                    unpaid_interest_arreas -= interest_paid_arrears
                    if unpaid_interest_arreas < 0:
                        unpaid_interest_arreas = 0  # Prevent negative values
                    
                    payment_allocation -= interest_arreas
                    interest_paid += interest_arreas
                    interest_arreas -= interest_arreas
                    if interest_arreas < 0:
                        interest_arreas = 0  
                else:
                    # If payment_allocation is less than interest_arreas, pay the remaining amount in interest arrears
                    interest_paid_arrears = payment_allocation  # Pay whatever is left in payment_allocation
                    unpaid_interest_arreas -= interest_paid_arrears
                    if unpaid_interest_arreas < 0:
                        unpaid_interest_arreas = 0  # Prevent negative values
                    
                    payment_allocation -= interest_paid_arrears
                    interest_paid += interest_paid_arrears
                    interest_arreas -= interest_paid_arrears
                    if interest_arreas < 0:
                        interest_arreas = 0  # Prevent negative values


                # 2. Pay Penalty Arrears
                if payment_allocation > 0 and unpaid_penalty_arreas <= payment_allocation:
                    penalty_paid2 = min(payment_allocation, unpaid_penalty_arreas)
                    unpaid_penalty_arreas -= penalty_paid2
                    payment_allocation -= penalty_paid2
                else:
                    penalty_paid2 = payment_allocation  # Pay whatever is left in payment_allocation
                    unpaid_penalty_arreas -= penalty_paid2
                    payment_allocation -= penalty_paid2
                
                 
                    # 5. Pay Current Principal
                if payment_allocation >= daily_interest_p:
                    principal_paid_current = payment_allocation
                    principal_paid += principal_paid_current
                    payment_allocation -= principal_paid_current
                    running_principal_balance -= principal_paid_current
                else:
                    principal_paid_current = payment_allocation
                    principal_arreas += (daily_interest_p - principal_paid_current)
                    principal_paid += principal_paid_current
                    payment_allocation = 0
                    running_principal_balance -= principal_paid_current

            elif txn["description"] not in ("Disbursement"):
                debit = amount # Handle other debit transactions

            
            lastpaidpriciple += principal_paid
            lastpaidpriciple2 += interest_paid2
                        
            principal_paid_ += principal_paid
            interest_paid2_ += interest_paid

            principal_paid_2 += principal_paid2
            interest_paid2_2 += interest_paid2

            if interest_paid2 > daily_interest:
                localalace  =constant_due_amount-principal_paid
                # principal_arreas += localalace
                if localalace >= 0:
                    penalty_paid  += (2.5/100)/30*((localalace))

    return {
        'unpaid_principal': principal_paid_,
        'unpaid_interest': interest_paid2_2,
        'penaltiess': principal_paid_2,
        'lastpayemnetdast': interest_paid2_,
        'lastpayemnetdast2': unpaidintrest
    }

import frappe
@frappe.whitelist(allow_guest=True)
def get_teller_data(from_date=None, to_date=None, user_id=None):
    conditions = []
    conditions2 = []
    conditions3 = []


    if from_date and to_date:
        conditions.append(f"creation BETWEEN '{from_date}' AND '{to_date}'")
        conditions2.append(f"creation BETWEEN '{from_date}' AND '{to_date}'")
        conditions3.append(f"lr.creation BETWEEN '{from_date}' AND '{to_date}'")

    if user_id:
        if user_id != "All":
            conditions.append(f"(user='{user_id}')")
            conditions2.append(f"(owner='{user_id}')")
            conditions3.append(f"(lr.owner='{user_id}')")

        conditions.append(f"(docstatus='1')")
        conditions2.append(f"(docstatus='1')")
        conditions3.append(f"(lr.docstatus='1')")

        conditions.append(f"(flagged='0')")
        conditions2.append(f"(flagged='0')")
        conditions3.append(f"(lr.flagged='0')")

    where_clause = " AND ".join(conditions) if conditions else "1=1"
    where_clause2 = " AND ".join(conditions2) if conditions2 else "1=1"
    where_clause3 = " AND ".join(conditions3) if conditions3 else "1=1"
    query = f"""
        SELECT 
            lr.name AS dpname,
            lr.name AS name,
            lr.loan AS account,
            la.client_name AS client_name,
            lr.amount AS amount,
            lr.creation AS creation,
            lr.owner AS owner,
            NULL AS transaction_type_name,
            'Loan Repayment' AS source
        FROM `tabLoan Repayment` lr
        JOIN `tabLoan Application Plus` la 
            ON lr.loan = la.name
        WHERE {where_clause3}

        UNION ALL

        SELECT 
            ll.name AS dpname,
            ll.savings_id AS name,
            ll.account AS account,
            ll.client_name AS client_name,
            ll.amount AS amount,
            ll.creation AS creation,
            ll.owner AS owner,
            'Deposit' AS transaction_type_name,
            'Deposit' AS source
        FROM `tabDeposit` ll
        WHERE {where_clause2}

        UNION ALL

        SELECT 
            wd.name AS dpname,
            wd.transaction AS name,
            wd.account AS account,
            wd.client_name AS client_name,
            wd.amount AS amount,
            wd.creation AS creation,
            wd.owner AS owner,
            'Withdraw' AS transaction_type_name,
            'Withdraw' AS source
        FROM `tabWithdraw` wd
        WHERE {where_clause}


        ORDER BY creation ASC
    """


    return frappe.db.sql(query, as_dict=True)


import frappe
@frappe.whitelist(allow_guest=True)
def get_teller_data2(from_date=None, to_date=None, user_id=None):
    conditions = []
    conditions2 = []
    conditions3 = []

    if from_date and to_date:
        conditions.append(f"creation BETWEEN '{from_date}' AND '{to_date}'")
        conditions2.append(f"creation BETWEEN '{from_date}' AND '{to_date}'")
        conditions3.append(f"lr.creation BETWEEN '{from_date}' AND '{to_date}'")

    if user_id:
        if user_id != "All":
            conditions.append(f"(user='{user_id}')")
            conditions2.append(f"(owner='{user_id}')")
            conditions3.append(f"(lr.owner='{user_id}')")

        conditions.append(f"(docstatus='1')")
        conditions2.append(f"(docstatus='1')")
        conditions3.append(f"(lr.docstatus='1')")

        conditions.append(f"(flagged='1')")
        conditions2.append(f"(flagged='1')")
        conditions3.append(f"(lr.flagged='1')")

    where_clause = " AND ".join(conditions) if conditions else "1=1"
    where_clause2 = " AND ".join(conditions2) if conditions2 else "1=1"
    where_clause3 = " AND ".join(conditions3) if conditions3 else "1=1"
    query = f"""
        SELECT 
            lr.name AS dpname,
            lr.name AS name,
            lr.loan AS account,
            la.client_name AS client_name,
            lr.amount AS amount,
            lr.creation AS creation,
            lr.owner AS owner,
            NULL AS transaction_type_name,
            'Loan Repayment' AS source
        FROM `tabLoan Repayment` lr
        JOIN `tabLoan Application Plus` la 
            ON lr.loan = la.name
        WHERE {where_clause3}

        UNION ALL

        SELECT 
            ll.name AS dpname,
            ll.savings_id AS name,
            ll.account AS account,
            ll.client_name AS client_name,
            ll.amount AS amount,
            ll.creation AS creation,
            ll.owner AS owner,
            'Deposit' AS transaction_type_name,
            'Deposit' AS source
        FROM `tabDeposit` ll
        WHERE {where_clause2}

        UNION ALL

        SELECT 
            wd.name AS dpname,
            wd.transaction AS name,
            wd.account AS account,
            wd.client_name AS client_name,
            wd.amount AS amount,
            wd.creation AS creation,
            wd.owner AS owner,
            'Withdraw' AS transaction_type_name,
            'Withdraw' AS source
        FROM `tabWithdraw` wd
        WHERE {where_clause}

        ORDER BY creation ASC
    """

    return frappe.db.sql(query, as_dict=True)


def monthly_create_savings_transactions(account, savings_product, posting_date=None, narration=None):
    # Ensure account is a doc
    if isinstance(account, str):
        account = frappe.get_doc("Savings Account", account)

    posting_date = getdate(posting_date) if posting_date else nowdate()
    savings_account_id = account.name
    monthly_fee = savings_product.monthly_fees

    monthly_fees_receivable = savings_product.monthly_fees_receivable
    monthly_fees_receivable_doc = None
    if monthly_fees_receivable:
        monthly_fees_receivable_doc = frappe.get_doc("Account", {"name": monthly_fees_receivable})

    monthly_fees_account_doc = frappe.get_doc("Account", {"name": savings_product.monthly_fees_account})

    def _create_gl_entry(entry):
        doc = frappe.get_doc(entry)
        doc.insert()
        doc.submit()
        return doc

    transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": "Deposit Charge"})

    saving_transaction = frappe.get_doc({
        "doctype": "Saving Transaction",
        "account": savings_account_id,
        "transaction_type": transaction_type,
        "posting_date": posting_date,
        "branch": savings_product.branch,
        "amount": monthly_fee,
        "debit": monthly_fee,
        "client_account": savings_account_id,
        "reference": savings_account_id,
        "description": narration,
        "is_parent": 1,
        "allow_charges": 0
    })
    saving_transaction.insert()
    saving_transaction.submit()

    account_refresh = frappe.get_doc("Savings Account", savings_account_id)

    if account_refresh.balance_derived < monthly_fee:
        balance = account_refresh.balance_derived

        existing_entry = frappe.get_list(
            "General Ledger II",
            filters={
                "account": monthly_fees_receivable,
                "transaction_type_name": "monthlyfessrecivable",
                "savings_account": savings_account_id
            },
            fields=["name", "credit", "debit"]
        )

        if balance > 0:
            if 1:
                frappe.db.sql(
                    """
                    UPDATE `tabGeneral Ledger II`
                    SET credit = credit + %s,
                        debit = debit + %s
                    WHERE name = %s
                    """,
                    (balance, monthly_fee, existing_entry[0]["name"])
                )
                frappe.db.commit()

                coa_account_name2 = frappe.get_doc("Account", {"name": savings_product.customer_balance_account})

                _create_gl_entry({
                    "doctype": "General Ledger II",
                    "account": savings_product.customer_balance_account,
                    "label_for_report": coa_account_name2.name,
                    "transaction_type": 1,
                    "transaction_type_name": "withdraw",
                    "posting_date": posting_date,
                    "company": savings_product.company,
                    "branch": savings_product.branch,
                    "amount": balance,
                    "credit": 0,
                    "debit": balance,
                    "main_parent": "Liabilities",
                    "sub_parent": "Balances On Customer Account",
                    "category": coa_account_name2,
                    "savings_account": savings_account_id
                })

                _create_gl_entry({
                    "doctype": "General Ledger II",
                    "account": savings_product.monthly_fees_account,
                    "label_for_report": monthly_fees_account_doc.name,
                    "transaction_type": 1,
                    "transaction_type_name": "Monthly Fees",
                    "posting_date": posting_date,
                    "company": savings_product.company,
                    "branch": savings_product.branch,
                    "amount": monthly_fee,
                    "credit": monthly_fee,
                    "debit": 0,
                    "main_parent": "Income",
                    "sub_parent": "Income",
                    "category": monthly_fees_account_doc,
                    "savings_account": savings_account_id
                })

            else:
                _create_gl_entry({
                    "doctype": "General Ledger II",
                    "account": monthly_fees_receivable,
                    "label_for_report": monthly_fees_receivable_doc.name if monthly_fees_receivable_doc else monthly_fees_receivable,
                    "transaction_type": 1,
                    "transaction_type_name": "monthlyfessrecivable",
                    "posting_date": posting_date,
                    "company": savings_product.company,
                    "branch": savings_product.branch,
                    "amount": monthly_fee,
                    "credit": balance,
                    "debit": monthly_fee,
                    "main_parent": "Assets",
                    "sub_parent": "Debtors & Receivables",
                    "category": monthly_fees_receivable_doc,
                    "savings_account": savings_account_id
                })

                coa_account_name2 = frappe.get_doc("Account", {"name": savings_product.customer_balance_account})
                _create_gl_entry({
                    "doctype": "General Ledger II",
                    "account": savings_product.customer_balance_account,
                    "label_for_report": coa_account_name2.name,
                    "transaction_type": 1,
                    "transaction_type_name": "withdraw",
                    "posting_date": posting_date,
                    "company": savings_product.company,
                    "branch": savings_product.branch,
                    "amount": balance,
                    "credit": 0,
                    "debit": balance,
                    "main_parent": "Liabilities",
                    "sub_parent": "Balances On Customer Account",
                    "category": coa_account_name2,
                    "savings_account": savings_account_id
                })

                _create_gl_entry({
                    "doctype": "General Ledger II",
                    "account": savings_product.monthly_fees_account,
                    "label_for_report": monthly_fees_account_doc.name,
                    "transaction_type": 1,
                    "transaction_type_name": "Monthly Fees",
                    "posting_date": posting_date,
                    "company": savings_product.company,
                    "branch": savings_product.branch,
                    "amount": monthly_fee,
                    "credit": monthly_fee,
                    "debit": 0,
                    "main_parent": "Income",
                    "sub_parent": "Income",
                    "category": monthly_fees_account_doc,
                    "savings_account": savings_account_id
                })

        else:
            # balance <= 0 branch (customer has no balance)
            if existing_entry:
                frappe.db.sql(
                    """
                    UPDATE `tabGeneral Ledger II`
                    SET debit = debit + %s
                    WHERE name = %s
                    """,
                    (monthly_fee, existing_entry[0]["name"])
                )
                frappe.db.commit()

                _create_gl_entry({
                    "doctype": "General Ledger II",
                    "account": savings_product.monthly_fees_account,
                    "label_for_report": monthly_fees_account_doc.name,
                    "transaction_type": 1,
                    "transaction_type_name": "Monthly Fees",
                    "posting_date": posting_date,
                    "company": savings_product.company,
                    "branch": savings_product.branch,
                    "amount": monthly_fee,
                    "credit": monthly_fee,
                    "debit": 0,
                    "main_parent": "Income",
                    "sub_parent": "Income",
                    "category": monthly_fees_account_doc,
                    "savings_account": savings_account_id
                })
            else:
                _create_gl_entry({
                    "doctype": "General Ledger II",
                    "account": monthly_fees_receivable,
                    "label_for_report": monthly_fees_receivable_doc.name if monthly_fees_receivable_doc else monthly_fees_receivable,
                    "transaction_type": 1,
                    "transaction_type_name": "monthlyfessrecivable",
                    "posting_date": posting_date,
                    "company": savings_product.company,
                    "branch": savings_product.branch,
                    "amount": monthly_fee,
                    "credit": 0,
                    "debit": monthly_fee,
                    "main_parent": "Assets",
                    "sub_parent": "Debtors & Receivables",
                    "category": monthly_fees_receivable_doc,
                    "savings_account": savings_account_id
                })

                _create_gl_entry({
                    "doctype": "General Ledger II",
                    "account": savings_product.monthly_fees_account,
                    "label_for_report": monthly_fees_account_doc.name,
                    "transaction_type": 1,
                    "transaction_type_name": "Monthly Fees",
                    "posting_date": posting_date,
                    "company": savings_product.company,
                    "branch": savings_product.branch,
                    "amount": monthly_fee,
                    "credit": monthly_fee,
                    "debit": 0,
                    "main_parent": "Income",
                    "sub_parent": "Income",
                    "category": monthly_fees_account_doc,
                    "savings_account": savings_account_id
                })

    else:
        # Sufficient balance to cover fee — direct posting
        _create_gl_entry({
            "doctype": "General Ledger II",
            "account": savings_product.monthly_fees_account,
            "label_for_report": monthly_fees_account_doc.name,
            "transaction_type": 1,
            "transaction_type_name": "Monthly Fees",
            "posting_date": posting_date,
            "company": savings_product.company,
            "branch": savings_product.branch,
            "amount": monthly_fee,
            "credit": monthly_fee,
            "debit": 0,
            "main_parent": "Income",
            "sub_parent": "Income",
            "category": monthly_fees_account_doc,
            "savings_account": savings_account_id
        })

        coa_account_name2 = frappe.get_doc("Account", {"name": savings_product.customer_balance_account})
        _create_gl_entry({
            "doctype": "General Ledger II",
            "account": savings_product.customer_balance_account,
            "label_for_report": coa_account_name2.name,
            "transaction_type": 1,
            "transaction_type_name": "Monthly Fees",
            "posting_date": posting_date,
            "company": savings_product.company,
            "branch": savings_product.branch,
            "amount": monthly_fee,
            "credit": 0,
            "debit": monthly_fee,
            "main_parent": "Liabilities",
            "sub_parent": "Balances On Customer Account",
            "category": coa_account_name2,
            "savings_account": savings_account_id
        })

    # get_total_outstanding(account.name)

import frappe

@frappe.whitelist(allow_guest=True)
def process_charges_all_accounts():
    """Run monthly charges for August and September on all active savings accounts."""
    # Get all active savings accounts
    savings_accounts = frappe.get_all("Savings Account", filters={}, pluck="name",limit_page_length=0 )
    for account_name in savings_accounts:
        try:
            process_charges_single_month(account_name)
        except Exception as e:
            frappe.log_error(message=str(e), title=f"Error posting monthly charges for {account_name}")
    return f"Monthly charges processed for {len(savings_accounts)} active accounts."

@frappe.whitelist(allow_guest=True)
def process_charges_single_month(account_name):
    """Post monthly charges for August and September as separate transactions with exact posting dates, 
    only if account creation is earlier than the respective posting date."""
    account = frappe.get_doc("Savings Account", account_name)
    savings_product = frappe.get_doc("Saving Product", account.saving_product)
    if not savings_product.monthly_fees:
        return f"No monthly fees configured for product {savings_product.name}"
    transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": "Deposit Charge"})
    # -------------------
    # August 2025
    # -------------------
    august_posting_date = getdate("2025-08-31")
    if getdate(account.creation) < august_posting_date:
        aug_transaction = frappe.get_doc({
            "doctype": "Saving Transaction",
            "account": account.name,
            "transaction_type": transaction_type,
            "posting_date": august_posting_date,
            "branch": savings_product.branch,
            "amount": savings_product.monthly_fees,
            "debit": savings_product.monthly_fees,
            "client_account": account.name,
            "reference": account.name,
            "description": "Monthly Charges - August",
            "is_parent": 1,
            "allow_charges": 0
        })
        aug_transaction.insert()
        aug_transaction.submit()

        frappe.db.sql("""
            UPDATE `tabSaving Transaction`
            SET creation = %s, modified = %s
            WHERE name = %s
        """, (august_posting_date, august_posting_date, aug_transaction.name))
        frappe.db.commit()

    # -------------------
    # September 2025
    # -------------------
    september_posting_date = getdate("2025-09-30")
    if getdate(account.creation) < september_posting_date:
        september_transaction = frappe.get_doc({
            "doctype": "Saving Transaction",
            "account": account.name,
            "transaction_type": transaction_type,
            "posting_date": september_posting_date,
            "branch": savings_product.branch,
            "amount": savings_product.monthly_fees,
            "debit": savings_product.monthly_fees,
            "client_account": account.name,
            "reference": account.name,
            "description": "Monthly Charges - September",
            "is_parent": 1,
            "allow_charges": 0
        })
        september_transaction.insert()
        september_transaction.submit()

        frappe.db.sql("""
            UPDATE `tabSaving Transaction`
            SET creation = %s, modified = %s
            WHERE name = %s
        """, (september_posting_date, september_posting_date, september_transaction.name))
        frappe.db.commit()

    return f"Monthly charges posted for eligible months on account {account.name}"


@frappe.whitelist(allow_guest=True)
def post_loan_arrears(loan):
    from frappe.utils import getdate, nowdate
    from datetime import timedelta
    from dateutil.relativedelta import relativedelta

    if not loan:
        return []

    # Fetch loan document
    loan_data = frappe.get_doc("Loan Application Plus", loan)

    # Fetch loan disbursement
    loan_disbursement = frappe.db.get_list(
        "Loan Disbursement",
        filters={"loan": loan},
        fields=["disbursement_date", "disbursed_amount"],
        limit=1
    )

    if not loan_disbursement:
        return []

    loan_start_date = getdate(loan_disbursement[0].disbursement_date)
    grace_period_days = loan_data.grace_period_on_disbursment or 0

    # First payment date (after grace period)
    first_payment_date = loan_start_date + timedelta(days=grace_period_days)

    loan_end_date = (
        loan_start_date + relativedelta(days=loan_data.loan_tenure - 1)
        if loan_data.loan_tenure else getdate(nowdate())
    )

    today = getdate(nowdate())

    # Get repayment dates
    repayment_txn_dates = frappe.db.sql("""
        SELECT DATE(created_on) as txn_date
        FROM `tabLoan Transaction2`
        WHERE loan = %s AND transaction_type = 'Repayment'
    """, (loan,), as_dict=True)

    repayment_form_dates = frappe.db.sql("""
        SELECT DATE(created_on) as txn_date
        FROM `tabLoan Repayment`
        WHERE loan = %s
    """, (loan,), as_dict=True)

    repayment_dates = {
        getdate(row.txn_date) for row in repayment_txn_dates + repayment_form_dates
    }

    existing_arrears_dates = frappe.db.sql("""
        SELECT DATE(created_on) as txn_date
        FROM `tabLoan Transaction2`
        WHERE loan = %s AND transaction_type = 'Arrears'
    """, (loan,), as_dict=True)

    existing_arrears_dates = {
        getdate(row.txn_date) for row in existing_arrears_dates
    }

    # === Fixed Uganda Public Holidays from 2019–2025 ===
    uganda_holidays = {
        "2019-01-01", "2019-04-22", "2019-06-04", "2019-08-11", "2019-12-25", "2019-12-26",
        "2020-01-01", "2020-04-13", "2020-05-24", "2020-07-31", "2020-12-25", "2020-12-26",
        "2021-01-01", "2021-04-05", "2021-05-13", "2021-07-20", "2021-12-25", "2021-12-26",
        "2022-01-01", "2022-04-18", "2022-05-02", "2022-07-09", "2022-12-25", "2022-12-26",
        "2023-01-01", "2023-04-10", "2023-04-21", "2023-06-28", "2023-12-25", "2023-12-26",
        "2024-01-01", "2024-04-01", "2024-04-10", "2024-06-16", "2024-12-25", "2024-12-26",
        "2025-01-01", "2025-03-30", "2025-04-21", "2025-06-07", "2025-12-25", "2025-12-26","2021-12-18",
        "2022-12-16","2024-12-20"
    }
    uganda_holidays = {getdate(d) for d in uganda_holidays}

    inserted_entries = []

    # Start checking one day after first payment date to skip it
    check_date = first_payment_date 

    # Only generate arrears up to min(loan_end_date, today)
    max_arrears_date = min(loan_end_date, today)

    while check_date <= max_arrears_date:
        if (
            check_date.weekday() == 6 or  # Sunday
            check_date in uganda_holidays or
            check_date in repayment_dates or
            check_date in existing_arrears_dates
        ):
            check_date += timedelta(days=1)
            continue

        transaction_id = f"ARREARS-{check_date.strftime('%Y-%m-%d')}"
        name = f"{transaction_id}-{frappe.generate_hash(length=5)}"

        try:
            doc = frappe.get_doc({
                "doctype": "Loan Transaction2",
                "name": name,
                "loan": loan,
                "transaction_type": 6,
                "amount": 0,
                "credit": 0,
                "transaction_id": transaction_id,
                "org_desc": "Arrears",
                "created_on": check_date,
                "docstatus": 0
            })
            doc.insert(ignore_permissions=True)
            inserted_entries.append({
                "name": name,
                "transaction_id": transaction_id,
                "created_on": str(check_date)
            })
        except Exception:
            frappe.log_error(frappe.get_traceback(), f"Arrears Insert Failed for {check_date}")

        check_date += timedelta(days=1)

    frappe.db.commit()

    frappe.db.sql("""
        UPDATE `tabLoan Transaction2`
        SET creation = DATE(created_on)
        WHERE created_on IS NOT NULL
    """)
    frappe.db.commit()

    return {
        "inserted_arrears": inserted_entries
    }


@frappe.whitelist()
def normalize_creation_field():
    frappe.db.sql("""
        UPDATE `tabLoan Transaction2`
        SET creation = DATE(created_on)
        WHERE created_on IS NOT NULL
    """)
    frappe.db.commit()
    return "Creation field updated."



@frappe.whitelist(allow_guest=True)
def send_chat_message(room_name: str, sender: str, sender_email: str, content: str):
    if not (room_name and sender and content):
        return {"status": "error", "message": _("Missing required fields.")}

    if not frappe.db.exists("Chat Room", {"name": room_name}):
        return {"status": "error", "message": _("Chat room does not exist.")}

    # Create new Chat Message document
    chat_message = frappe.get_doc({
        "doctype": "Chat Message",
        "room": room_name,
        "sender": sender,
        "sender_email": sender_email,
        "content": content
    })

    chat_message.insert(ignore_permissions=True)
    frappe.db.commit()

    return {"status": "success", "message": _("Message sent successfully."), "message_id": chat_message.name}
    
@frappe.whitelist(allow_guest=True)
def get_clients_loan22(branch=None, search=None):
    # Default values
    search = search or ''
    conditions = "WHERE workflow_state = 'Activate Loan' "
    params = {}

    if branch:
        conditions += " AND branch = %(branch)s"
        params.update({'branch': branch})

    if search:
        conditions += """ AND (
            client_name LIKE %(search)s 
            OR name LIKE %(search)s
            OR RIGHT(name, 4) = %(last4)s
        )"""
        params.update({
            'search': f"%{search}%",
            'last4': search[-4:] if len(search) >= 4 else search
        })

    # Execute SQL query with dynamic conditions
    return frappe.db.sql(f"""
        SELECT *
        FROM `tabLoan Application Plus`
        {conditions}
        LIMIT 10;
    """, params, as_dict=True)




@frappe.whitelist(allow_guest=True)
def get_clients_loan2(user=None,start_date=None, end_date=None, branch=None, search=None, client_type=None):
    # Default values for optional parameters
   
    search = search or ''
  
    
    # Build dynamic conditions based on provided filters
    conditions = ""
    params = {}



    if branch:
        conditions += "WHERE   branch = %(branch)s"
        params.update({'branch': branch})

    if search:
        conditions += " AND (client_name LIKE %(search)s OR account_number LIKE %(search)s OR name LIKE %(search)s)"
        params.update({'search': f"%{search}%"})


    # Execute SQL query with dynamic conditions
    return frappe.db.sql(f"""
        SELECT *
        FROM `tabLoan Application Plus`
        {conditions}
        LIMIT 10;
    """, params, as_dict=True)


@frappe.whitelist()
def get_non_performing_loans(from_date, to_date):
    from_date = frappe.utils.getdate(from_date)
    to_date = frappe.utils.getdate(to_date)

    # Construct the SQL query with correct placeholders (%s) for parameters
    query = """
        SELECT
            name AS loan_id,
            client_name,
            principal AS principal_amount,
            principal_outstanding_derived AS outstanding_amount,
            expected_maturity_date AS due_date,
            status
        FROM
            `tabLoan`
        WHERE
            status = 'Pending'
            AND expected_maturity_date BETWEEN %s AND %s
    """

    # Execute the SQL query with positional parameters and fetch results as a dictionary
    loans = frappe.db.sql(query, (from_date, to_date), as_dict=True)

    return loans
##hudson
    
@frappe.whitelist(allow_guest=True)
def search_client_ag(keyword: str = None):
    results = []

    if keyword and len(keyword) >= 1:
        # Sanitize keyword for SQL query
        keyword = f"%{keyword}%"

        # Fetch user IDs from the Employee table
        employee_data = frappe.db.sql("""
            SELECT name
            FROM `tabEmployee`
            WHERE user LIKE %(keyword)s
        """, {"keyword": keyword}, as_dict=True)

        # Accumulate user IDs as strings
        staffids = [str(row["name"]) for row in employee_data]

        if staffids:
            # Combine user IDs into a single string
            dafa = "".join(staffids)

            # Fetch clients based on staff_id containing the keyword
            data = frappe.db.sql("""
                SELECT *
                FROM `tabClient` AS client
                WHERE client.staff_id LIKE %(keyword)s
            """, {"keyword": dafa}, as_dict=True)

            if data:
                results = data

    return results

from num2words import num2words
@frappe.whitelist()
def amount_to_words(amount):
    """
    Convert a numeric amount to words without mentioning any currency.

    Parameters:
    amount (float): The numeric amount to be converted.

    Returns:
    str: The amount in words.
    """
    try:
        # Ensure amount is a float
        amount = float(amount)
        
        # Separate the whole number and decimal parts
        whole_part = int(amount)
        decimal_part = round((amount - whole_part) * 100)

        # Convert each part to words
        whole_part_in_words = num2words(whole_part, lang='en')
        decimal_part_in_words = num2words(decimal_part, lang='en')

        # Create the final string
        if decimal_part > 0:
            amount_in_words = f"{whole_part_in_words} and {decimal_part_in_words} cents"
        else:
            amount_in_words = f"{whole_part_in_words}"
            
        return amount_in_words
    except Exception as e:
        return str(e)

@frappe.whitelist()
def update_transactionl(docer, docname,  reason, account=None):

    frappe.db.sql("""
        UPDATE `tab{}` 
        SET  workflow_state=%s,  status=%s
        WHERE name=%s
    """.format(docer), ("Closed", "Closed Loan", docname))
    
    frappe.db.commit()


          
    frappe.db.sql("""
        UPDATE `tab{}` 
        SET flagged = %s
        WHERE loan = %s
    """.format("General Ledger II"), ("1", docname)) 
    frappe.db.commit()


    frappe.db.sql("""
        UPDATE `tabSaving Transaction`
        SET flagged = %s
        WHERE description LIKE %s
    """, ("1", f"%{docname}%"))
    frappe.db.commit()
  
     
    return True

@frappe.whitelist()
def update_transaction_kl(docer, docname, reason, account):
    # Update the dynamic doctype
    try:
        frappe.db.sql("""
            UPDATE `tab{}` 
            SET flagged=%s
            WHERE name=%s
        """.format(docer), (reason, docname))
    except Exception as e:
        frappe.log_error(f"Failed to update {docer} for {docname}: {str(e)}", "update_transaction_kl")

    # Update Deposit (flag = 1)
    try:
        frappe.db.sql("""
            UPDATE `tabDeposit` 
            SET flagged=1
            WHERE savings_id=%s
        """, (docname,))
    except Exception as e:
        frappe.log_error(f"Failed to update Deposit for {docname}: {str(e)}", "update_transaction_kl")

    # Update Withdraw (flag = 1)
    try:
        frappe.db.sql("""
            UPDATE `tabWithdraw` 
            SET flagged=1
            WHERE savings_id=%s
        """, (docname,))
    except Exception as e:
        frappe.log_error(f"Failed to update Withdraw for {docname}: {str(e)}", "update_transaction_kl")

    frappe.db.commit()

@frappe.whitelist(allow_guest=True)
def submit_pending_withdraws():
    # Get all withdraws with status = "Pending" and not yet submitted
    withdraws = frappe.get_all(
        "Withdraw",
        filters={"status": "Pending", "docstatus": 0},
        fields=["name"]
    )

    for w in withdraws:
        try:
            doc = frappe.get_doc("Withdraw", w.name)
            doc.submit()
            frappe.db.commit()
            frappe.logger().info(f"✅ Submitted Withdraw: {w.name}")
        except Exception as e:
            frappe.logger().error(f"❌ Failed to submit {w.name}: {e}")




@frappe.whitelist(allow_guest=True)
def submit_all_withdarwa():
    """
    Submit only Withdraw documents whose names are in the given list.
    """
    doctype = "Withdraw"   # <-- change if your DocType name differs

    # Full list of allowed names
    allowed_names = [
        "2014","2013"]

    # Fetch only drafts from the given names
    names = frappe.db.get_all(
        doctype,
        filters={"docstatus": 0},
        pluck="name"
    )

    total = len(names)
    submitted = 0
    failed = []

    for i, docname in enumerate(names, start=1):
        try:
            doc = frappe.get_doc(doctype, docname)
            doc.flags.ignore_permissions = True
            doc.submit()
            submitted += 1

            if i % 50 == 0:  # commit in batches
                frappe.db.commit()

        except Exception as e:
            frappe.db.rollback()
            failed.append({"name": docname, "error": str(e)})

    frappe.db.commit()

    return {
        "total": total,
        "submitted": submitted,
        "failed": failed
    }

@frappe.whitelist(allow_guest=True)
def submit_all_withdarwa(name=None):
    """
    Submit draft Withdraw documents.
    If a name is provided, submit only that record.
    Otherwise, submit all draft records in order.
    """
    doctype = "Withdraw"   # <-- change if your DocType name differs

    if name:  # run only one
        names = [name]
    else:     # run all drafts
        names = frappe.db.get_all(doctype, filters={"docstatus": 0}, pluck="name")

    total = len(names)
    submitted = 0
    failed = []

    for i, docname in enumerate(names, start=1):
        try:
            doc = frappe.get_doc(doctype, docname)
            doc.flags.ignore_permissions = True
           
            doc.submit()
            submitted += 1

            if not name and i % 50 == 0:  # commit in batches only for bulk
                frappe.db.commit()

        except Exception as e:
            frappe.db.rollback()
            failed.append({"name": docname, "error": str(e)})

    frappe.db.commit()

    return {
        "total": total,
        "submitted": submitted,
        "failed": failed
    }

@frappe.whitelist(allow_guest=True)
def update_transaction_kl(docer, docname, reason, account):
    frappe.db.sql("""
        UPDATE `tabSaving Transaction`
        SET reason = %s, Flagged = %s
        WHERE name = %s
    """, (reason, "1", docname))

    frappe.db.commit()
    return {"status": "success"}


    disbursement_doc2 = frappe.get_all("Saving Transaction", filters={"deposit": docname}, fields=["name"])
    disbursement_doc2r = frappe.get_all("Saving Transaction", filters={"deposit": disbursement_doc2[0].name}, fields=["name"])
    frappe.db.sql("""
        UPDATE `tab{}`
        SET  flagged=%s
        WHERE deposit=%s
    """.format("Saving Transaction"), ( "1",  disbursement_doc2[0].name))
    

    frappe.db.sql("""
        UPDATE `tab{}`
        SET  flagged=%s
        WHERE deposit=%s
    """.format("Saving Transaction"), ( "1",  disbursement_doc2r[0].name))

    frappe.db.commit()

    frappe.db.sql("""
        UPDATE `tab{}`
        SET  flagged=%s
        WHERE deposit=%s
    """.format("Saving Transaction"), ( "1",  docname))
    frappe.db.commit()

    frappe.db.sql("""
        UPDATE `tab{}` 
        SET flagged = %s
        WHERE parent_transaction = %s
    """.format("General Ledger II"), ("1", docname))  # Pass docname directly
    frappe.db.commit()

    frappe.db.sql("""
        UPDATE `tab{}` 
        SET flagged = %s
        WHERE parent_transaction = %s
    """.format("General Ledger II"), ("1", disbursement_doc2[0].name)) 

    frappe.db.sql("""
        UPDATE `tab{}` 
        SET flagged = %s
        WHERE parent_transaction = %s
    """.format("General Ledger II"), ("1", disbursement_doc2r[0].name)) 
    
    # Commit changes
    frappe.db.commit()

    from mfis.clients import get_total_outstanding
    get_total_outstanding(account)

    return True


@frappe.whitelist()
def update_transactioncr(docer, docname, reason):
    # Update the Cash Receipt table
    frappe.db.sql("""
        UPDATE `tab{}` 
        SET flagged = %s
        WHERE name = %s
    """.format(docer), (1, docname))  # Corrected argument count
    
    # Update the General Ledger II table
    frappe.db.sql("""
        UPDATE `tab{}` 
        SET flagged = %s
        WHERE parent_transaction = %s
    """.format("General Ledger II"), ("1", docname))  # Pass docname directly
    
    # Commit changes
    frappe.db.commit()
    
    return True


@frappe.whitelist()
def update_transactionpy(docer, docname,  reason):
     # Update the Cash Receipt table
    frappe.db.sql("""
        UPDATE `tab{}` 
        SET flagged = %s
        WHERE name = %s
    """.format(docer), (1, docname))  # Corrected argument count
    
    # Update the General Ledger II table
    frappe.db.sql("""
        UPDATE `tab{}` 
        SET flagged = %s
        WHERE parent_transaction = %s
    """.format("General Ledger II"), ("1", docname))  # Pass docname directly
    
    # Commit changes
    frappe.db.commit()
    
    return True

from datetime import datetime, timedelta
import frappe

def get_loan_application_date(loan):
    # Query the Loan Disbursement DocType to find the document where the loan field matches the given loan
    disbursement_doc = frappe.get_all("Loan Disbursement", filters={"loan": loan}, fields=["disbursement_date"])
    
    if disbursement_doc:
        # Extract the loan application date from the first matching document
        loan_application_date = disbursement_doc[0].disbursement_date
        return loan_application_date
    else:
        return None
    

@frappe.whitelist()
def update_transactionw(docer, docname,  reason, account):
    # Perform the update using SQL
    frappe.db.sql("""
        UPDATE `tab{}` 
        SET  reason=%s,  flagged=%s
        WHERE name=%s
    """.format(docer), ( reason, "1", docname))
    
    frappe.db.commit()
    frappe.db.sql("""
        UPDATE `tab{}`
        SET  flagged=%s
        WHERE withdraw=%s
    """.format("Saving Transaction"), ( "1",  docname))
    frappe.db.commit()
    
    frappe.db.sql("""
        UPDATE `tab{}` 
        SET flagged = %s
        WHERE parent_transaction = %s
    """.format("General Ledger II"), ("1", docname))  # Pass docname directly
    
    # Commit changes
    frappe.db.commit()

    from mfis.clients import get_total_outstanding
    get_total_outstanding(account)
        

    
    return True

@frappe.whitelist()
def check_interim_transaction_access(user, current_date):
    from datetime import datetime, time

    # Convert current_date (string) to datetime.date
    if isinstance(current_date, str):
        current_date = datetime.strptime(current_date, "%Y-%m-%d").date()

    # Define start and end of the day (00:00:00 to 23:00:00)
    start_datetime = datetime.combine(current_date, time.min)  # 00:00:00
    end_datetime = datetime.combine(current_date, time(23, 0, 0))  # 23:00:00

    # Check if a record exists in `tabInterim Transaction Access`
    # for the logged-in user within the specified date range
    interim_access = frappe.db.sql("""
        SELECT name FROM `tabInterim Transaction Access`
        WHERE employee = %s
        AND (
            (start_date BETWEEN %s AND %s)
            OR (end_date BETWEEN %s AND %s)
            OR (%s BETWEEN start_date AND end_date)
        )
        LIMIT 1
    """, (user, start_datetime, end_datetime, start_datetime, end_datetime, start_datetime))

    if not interim_access:
        # If no record is found, return False
        return False

    # Extract the name from the interim_access result
    interim_access_name = interim_access[0][0]

    # Check if a record exists in `tabClosed Sessions` with deposits = 1
    # and where parent matches the name from `tabInterim Transaction Access`
    deposits_record = frappe.db.sql("""
        SELECT name FROM `tabClosed Sessions`
        WHERE deposits = 1
        AND parent = %s
        LIMIT 1
    """, (interim_access_name,))

    # Return True if both conditions are met, otherwise False
    return bool(deposits_record)


@frappe.whitelist()
def check_interim_transaction_accessw(user, current_date):
    # Check if a record exists in `tabInterim Transaction Access`
    # for the logged-in user within the specified date range
    interim_access = frappe.db.sql("""
        SELECT name FROM `tabInterim Transaction Access`
        WHERE employee = %s
        AND %s BETWEEN start_date AND end_date
        LIMIT 1
    """, (user, current_date))

    if not interim_access:
        # If no record is found, return False
        return False

    # Extract the name from the interim_access result
    interim_access_name = interim_access[0][0]

    # Check if a record exists in `tabClosed Sessions` with deposits = 1
    # and where parent matches the name from `tabInterim Transaction Access`
    deposits_record = frappe.db.sql("""
        SELECT name FROM `tabClosed Sessions`
        WHERE 
         withdraw = 1
        AND parent = %s
        LIMIT 1
    """, ( interim_access_name))

    # Return True if both conditions are met, otherwise False
    return bool(deposits_record)

@frappe.whitelist()
def update_transaction3(docer, docname, amount, reason):
    # Perform the update using SQL
    frappe.db.sql("""
        UPDATE `tab{}` 
        SET  frozen_amount=%s,  loan_freeze_reason=%s
        WHERE name=%s
    """.format(docer), ( amount, reason, docname))
    
    frappe.db.commit()

    return True

@frappe.whitelist()
def update_transaction2(docer, docname, amount, reason):
    # Perform the update using SQL
    frappe.db.sql("""
        UPDATE `tab{}` 
        SET  savings_amount_frozen=%s,  savings_freeze_reason=%s
        WHERE name=%s
    """.format(docer), ( amount, reason, docname))
    
    frappe.db.commit()

    return True

@frappe.whitelist()
def save_document(doc):
    try:
        doc = frappe.get_doc(doc)
        doc.save()
        frappe.db.commit()
        return {"status": "success", "doc": doc.as_dict()}
    except Exception as e:
        frappe.log_error(message=str(e), title="Save Document Error")
        return {"status": "error", "message": str(e)}


@frappe.whitelist(allow_guest=True)
def get_skipped_days_and_dates():
    # Fetch skipped days and dates from the 'No Working Days2' DocType
    records = frappe.get_list(
        'No Working Days2',
        filters={'parenttype': 'Calender Settings'},
        fields=['skipped_type', 'day', 'date']
    )

    skipped_days = []
    skipped_dates = []

    for record in records:
        if record.skipped_type == 'Days':
            skipped_days.append(record.day)
        elif record.skipped_type == 'Date':
            skipped_dates.append(record.date)

    return skipped_days, skipped_dates


@frappe.whitelist(allow_guest=True)
def search_loan_ag(keyword: str = None):
    results = []

    if keyword and len(keyword) >= 1:
        # Sanitize keyword for SQL query
        keyword = f"%{keyword}%"

        # Fetch user IDs from the Employee table
        employee_data = frappe.db.sql("""
            SELECT name
            FROM `tabEmployee`
            WHERE user LIKE %(keyword)s
        """, {"keyword": keyword}, as_dict=True)

        # Accumulate user IDs as strings
        staffids = [str(row["name"]) for row in employee_data]

        if staffids:
            # Combine user IDs into a single string
            dafa = "".join(staffids)

            # Fetch clients based on staff_id containing the keyword
            data = frappe.db.sql("""
                SELECT *
                FROM `tabLoan Application Plus` AS client
                WHERE client.loan_portfolio LIKE %(keyword)s
            """, {"keyword": dafa}, as_dict=True)

            if data:
                results = data

    return results


@frappe.whitelist(allow_guest=True)
def search_bank_ag(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabEmployee` as client
        WHERE client.user like %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data

    return results

@frappe.whitelist(allow_guest=True)
def get_total_50note(keyword: str = None):
    note_types = [50, 100, 500, 1000, 2000, 5000, 10000, 20000, 50000]
    differences = {}

    user = get_phone_number("Employee", "user", filters={"account": keyword})

    for note_type in note_types:
        try:
            # Total purchases
            total_purchase_query = frappe.db.sql("""
                SELECT COALESCE(SUM(cd.qty), 0) AS total_value
                FROM `tabFloat Purchase` ap 
                INNER JOIN `tabDenominations` cd ON cd.parent = ap.name
                WHERE ap.account_name = %(account_name)s
                AND cd.note = %(note_type)s
            """, {
                "account_name": keyword,
                "note_type": note_type
            }, as_dict=True)

            total_purchase = total_purchase_query[0].get('total_value', 0) if total_purchase_query else 0

            # Total deposits
            total_deposit_query = frappe.db.sql("""
                SELECT COALESCE(SUM(cd.qty), 0) AS total_value
                FROM `tabDeposit` ap 
                INNER JOIN `tabDenominations` cd ON cd.parent = ap.name
                WHERE ap.modified_by = %(account_name)s
                AND cd.note = %(note_type)s
            """, {
                "account_name": user,
                "note_type": note_type
            }, as_dict=True)

            total_deposit = total_deposit_query[0].get('total_value', 0) if total_deposit_query else 0

            # Total sales
            total_sell_query = frappe.db.sql("""
                SELECT COALESCE(SUM(cd.qty), 0) AS total_value
                FROM `tabFloat Sell` ap 
                INNER JOIN `tabDenominations` cd ON cd.parent = ap.name
                WHERE ap.from_account = %(account_name)s
                AND cd.note = %(note_type)s
            """, {
                "account_name": keyword,
                "note_type": note_type
            }, as_dict=True)

            total_sell = total_sell_query[0].get('total_value', 0) if total_sell_query else 0

            # Total withdrawals
            total_withdrawal_query = frappe.db.sql("""
                SELECT COALESCE(SUM(cd.qty), 0) AS total_value
                FROM `tabWithdraw` ap 
                INNER JOIN `tabDenominations` cd ON cd.parent = ap.name
                WHERE ap.modified_by = %(account_name)s
                AND cd.note = %(note_type)s
            """, {
                "account_name": user,
                "note_type": note_type
            }, as_dict=True)

            total_withdrawal = total_withdrawal_query[0].get('total_value', 0) if total_withdrawal_query else 0

            # Calculate difference
            difference = (total_purchase + total_deposit) - (total_sell + total_withdrawal)
            differences[note_type] = difference

        except Exception as e:
            frappe.log_error(f"Error executing SQL for note_type {note_type} with account_name {keyword}: {str(e)}", "get_total_differences")

    return differences


def get_phone_number(table, column, filters):
    query = f"SELECT {column} FROM `tab{table}` WHERE account = %s"
    result = frappe.db.sql(query, filters['account'], as_dict=True)
    if result and result[0].get(column):
        return result[0][column]
    else:
        frappe.throw(f"Client with name {filters['account']} not found")





@frappe.whitelist(allow_guest=True)
def get_cash_account_balance_today(keyword: any = None):
    dataemail = "" 
    results = []
    query2 = "SELECT user FROM `tabEmployee` WHERE account = %(acct)s"
    ownerdata = frappe.db.sql(query2, {"acct": keyword}, as_dict=True)
    for data in ownerdata:
        dataemail = data["user"]

    now = now_datetime()
    yesterday = now - timedelta(days=1)
    now = now + timedelta(days=2)
    start_time = datetime.combine(yesterday, datetime.min.time())
    end_time = datetime.combine(now, datetime.min.time())

    total_deposits_derived = _sum("Float Purchase", "amount", filters={
        "docstatus": 1,
        "account_name": keyword,
        "creation": [">=", start_time],
        "creation": ["<=", now]
    })

    total_withdrawals_derived = _sum("Float Sell", "amount", filters={
        "docstatus": 1,
        "from_account": keyword,
        "creation": [">=", start_time],
        "creation": ["<=", now]
    })

    datat = frappe.db.sql("""
        SELECT *
        FROM `tabSaving Transaction` as client
        WHERE client.owner like %(keyword)s
        AND client.creation BETWEEN %(start_time)s AND %(end_time)s
    """, {"keyword": dataemail, "start_time": start_time, "end_time": end_time}, as_dict=True)
    
    if datat:
        for data in datat:
            if "Deposit Fees" in data["description"]:
                dd=0
            if "Deposit" in data["description"] and "Deposit Fees" not in data["description"]:
                total_deposits_derived += data["amount"]
            if "Withdraw" in data["description"]:
                total_withdrawals_derived += data["amount"]
            if "Apply charge" in data["description"]:
                total_deposits_derived += data["amount"]
        results = datat

    balance = total_deposits_derived - total_withdrawals_derived
    return balance


@frappe.whitelist(allow_guest=True)
def get_cash_account_balance_monthly(keyword: any = None):
    dataemail = "" 
    results = []
    query2 = "SELECT user FROM `tabEmployee` WHERE account = %(acct)s"
    ownerdata = frappe.db.sql(query2, {"acct": keyword}, as_dict=True)
    for data in ownerdata:
        dataemail = data["user"]

    now = now_datetime()
    start_of_month = now.replace(day=1)
    end_time = datetime.combine(now, datetime.min.time()) - timedelta(seconds=1)

    last_month = start_of_month - relativedelta(months=1)
    start_time = last_month.replace(day=1)

    total_deposits_derived = _sum("Float Purchase", "amount", filters={
        "docstatus": 1,
        "account_name": keyword,
        "creation": [">=", start_time],
        "creation": ["<=", end_time]
    })

    total_withdrawals_derived = _sum("Float Sell", "amount", filters={
        "docstatus": 1,
        "from_account": keyword,
        "creation": [">=", start_time],
        "creation": ["<=", end_time]
    })

    datat = frappe.db.sql("""
        SELECT *
        FROM `tabSaving Transaction` as client
        WHERE client.owner = %(keyword)s
        AND client.creation BETWEEN %(start_time)s AND %(end_time)s
    """, {"keyword": dataemail, "start_time": start_time, "end_time": end_time}, as_dict=True)
    
    if datat:
        for data in datat:
            if "Deposit Fees" in data["description"]:
                dd=0
            elif "Deposit" in data["description"] and "Deposit Fees" not in data["description"]:
                total_deposits_derived += data["amount"]
            elif "Withdraw" in data["description"]:
                total_withdrawals_derived += data["amount"]
            elif "Apply charge" in data["description"]:
                total_deposits_derived += data["amount"]
        results = datat

    balance = total_deposits_derived - total_withdrawals_derived
    return balance


@frappe.whitelist(allow_guest=True)
def get_cash_account_balance_annual(keyword: any = None):
    dataemail = "" 
    results = []
    query2 = "SELECT user FROM `tabEmployee` WHERE account = %(acct)s"
    ownerdata = frappe.db.sql(query2, {"acct": keyword}, as_dict=True)
    for data in ownerdata:
        dataemail = data["user"]

    now = now_datetime()
    start_of_year = now.replace(month=1, day=1)
    end_time = datetime.combine(now, datetime.min.time()) - timedelta(seconds=1)

    last_year = start_of_year - relativedelta(years=1)
    start_time = last_year.replace(month=1, day=1)

    total_deposits_derived = _sum("Float Purchase", "amount", filters={
        "docstatus": 1,
        "account_name": keyword,
        "creation": [">=", start_time],
        "creation": ["<=", end_time]
    })

    total_withdrawals_derived = _sum("Float Sell", "amount", filters={
        "docstatus": 1,
        "from_account": keyword,
        "creation": [">=", start_time],
        "creation": ["<=", end_time]
    })

    datat = frappe.db.sql("""
        SELECT *
        FROM `tabSaving Transaction` as client
        WHERE client.owner = %(keyword)s
        AND client.creation BETWEEN %(start_time)s AND %(end_time)s
    """, {"keyword": dataemail, "start_time": start_time, "end_time": end_time}, as_dict=True)
    
    if datat:
        for data in datat:
            if "Deposit Fees" in data["description"]:
                dd=0
            elif "Deposit" in data["description"] and "Deposit Fees" not in data["description"]:
                total_deposits_derived += data["amount"]
            elif "Withdraw" in data["description"]:
                total_withdrawals_derived += data["amount"]
            elif "Apply charge" in data["description"]:
                total_deposits_derived += data["amount"]
        results = datat

    balance = total_deposits_derived - total_withdrawals_derived
    return balance


@frappe.whitelist()
def create_client(**kwargs):
    kwargs["doctype"] = "Client"

    doc = frappe.get_doc(kwargs)

    if kwargs["id_document_type"]:
        doc.append("identifiers", {
            "document_type": kwargs["id_document_type"],
            "id_number": kwargs["id_number"]
        })

    if kwargs["residential"]:
        residential = frappe._dict(kwargs["residential"])

        # for i in range(len(addresses)):
        client_address = {
            "address_type": "Residential" or "",
            "address_line_1": residential.address_line_1 or "",
            "shop_number": residential.shop_number or ""
        }
        doc.append("addresses", client_address)

    if kwargs["work"]:
        residential = frappe._dict(kwargs["work"])

        # for i in range(len(addresses)):
        client_address = {
            "address_type": "Work" or "",
            "address_line_1": residential.address_line_1 or "",
            "shop_number": residential.shop_number or ""
        }
        doc.append("addresses", client_address)

    if kwargs["next_of_kin"]:
        next_of_kin = frappe._dict(kwargs["next_of_kin"])

        doc.append("next_of_kins", {
            "relationship": next_of_kin.relationship,
            "full_name": next_of_kin.full_name,
            "mobile": next_of_kin.mobile or None,
            "gender": next_of_kin.gender or None,
            "age": next_of_kin.age or 0,
            "marital_status": next_of_kin.marital_status or None
        })

    doc.insert(ignore_permissions=True)

    return doc
import random
import urllib.parse
import requests
@frappe.whitelist(allow_guest=True)
def login_app(username: str = None, password: str = None):
    if not username or len(username) < 1:
        return {"message": "Please provide a valid username"}
    
    keyword = f"%{username}%"
    
    data = frappe.db.sql("""
        SELECT 
            client.*,
            emp.roles, 
            emp.coa_account, 
            emp.mobile,
            emp.branch
        FROM 
            `tabUser` AS client
        LEFT JOIN 
            `tabEmployee` AS emp
        ON 
            client.name = emp.user
        WHERE 
            client.name LIKE %(keyword)s
    """, {"keyword": keyword}, as_dict=True)

    if data:

        # -----------------------------
        # CHECK EMPLOYEE ROLE = Agent
        # -----------------------------
        if data[0].get("roles") != "Agent":
            return {"message": "Access denied. User is not an Agent"}

        # Retrieve the mobile number from the query result
        mobile_number = data[0].get("mobile") if data[0].get("mobile") else None
        
        if not mobile_number:
            return {"message": "Mobile number not found for the user"}
        
        if not frappe.local.flags.ignore_accounting_periods:
            accounting_periods = frappe.db.sql(
                """ SELECT
                    ap.name as name
                FROM
                    `tabAccounting Period` ap, `tabClosed Document` cd
                WHERE
                    ap.name = cd.parent
                    AND ap.branch = %(branch)s
                    AND ap.company = %(company)s
                    AND cd.closed = 0
                    AND cd.document_type = %(voucher_type)s
                    AND %(date)s between ap.start_date and ap.end_date
                    """,
                {
                    "date": now_datetime(),
                    "branch": data[0].get("branch"),
                    "voucher_type": "Deposit",
                    "company": "UWEZO FINANCIAL SERVICES LTD"
                },
                as_dict=1,
            )
            
        if not accounting_periods:
            data[0]["acc"] = 1
            data[0]["otp"] = 0 
        else:
            data[0]["acc"] = 0
            otp = random.randint(1000, 9999)
       
            message = f"Your Uwezo Agent App login OTP code is {otp}."
            send_sms(message=message, phone=mobile_number)
     
            data[0]["otp"] = otp  

        return {"message": "Data found, OTP sent", "data": data}
    
    return {"message": "No data found"}


@frappe.whitelist(allow_guest=True)
def create_opening_transactions():
    records = frappe.get_list("fix_account_opeing", fields=["name", "account", "amount"])

    for r in records:
        account = r.account
        amount = r.amount

        date_to_use = frappe.db.get_value("Savings Account", {"name": account}, "creation")
        if not date_to_use:
            continue

        branch = frappe.db.get_value("Savings Account", {"name": account}, "branch")
        if not branch:
            continue

        next_id = uuid.uuid4().hex
        deposit_type = "account opening3"

        frappe.db.sql("""
            INSERT INTO `tabSaving Transaction`
            (name, creation, modified, modified_by, owner, docstatus, account,
             transaction_type, transaction_type_name, posting_date, branch, amount,
             reference, description, is_parent, deposited_by, allow_charges,
             allow_overdraw, deposit, is_opening, account_branch)
            VALUES
            (%s, %s, %s, %s, %s, 1, %s,
             %s, %s, %s, %s, %s,
             %s, %s, 0, %s, %s,
             %s, %s, %s, %s)
        """, (
            str(next_id), date_to_use, date_to_use,
            frappe.session.user, frappe.session.user,
            account, "Deposit", deposit_type,
            date_to_use, branch, amount,
            deposit_type, deposit_type,
            frappe.session.user, 0,
            0, amount, 1, branch
        ))

    frappe.db.commit()
    return "done"


@frappe.whitelist(allow_guest=True)
def login_app2(username: str = None, password: str = None):
    import random
    import urllib.parse
    import requests

    if not username or len(username) < 1:
        return {"message": "Please provide a valid username"}
    
    keyword = f"%{username}%"
    
    data = frappe.db.sql("""
        SELECT 
            client.*,
            emp.roles, 
            emp.coa_account, 
            emp.mobile,
            emp.branch
        FROM 
            `tabUser` AS client
        LEFT JOIN 
            `tabEmployee` AS emp
        ON 
            client.name= emp.user
        WHERE 
            client.name LIKE %(keyword)s
    """, {"keyword": keyword}, as_dict=True)

    if data:
        # Retrieve the mobile number from the query result
        mobile_number = data[0].get("mobile") if data[0].get("mobile") else None
        
        if not mobile_number:
            return {"message": "Mobile number not found for the user"}
        
        if not frappe.local.flags.ignore_accounting_periods:
            accounting_periods = frappe.db.sql(
                """ SELECT
                    ap.name as name
                FROM
                    `tabAccounting Period` ap, `tabClosed Document` cd
                WHERE
                    ap.name = cd.parent
                    AND ap.branch = %(branch)s
                    AND ap.company = %(company)s
                    AND cd.closed = 0
                    AND cd.document_type = %(voucher_type)s
                    AND %(date)s between ap.start_date and ap.end_date
                    """,
                {
                    "date": now_datetime(),
                    "branch": data[0].get("branch"),
                    "voucher_type": "Deposit",
                    "company": "UWEZO FINANCIAL SERVICES LTD"
                },
                as_dict=1,
            )
            
        if not accounting_periods:
            data[0]["acc"] = 1
           
        else:
            data[0]["acc"] = 0
            

        
        return {"message": "Data found, OTP sent", "data": data}
    
    return {"message": "No data found"}

@frappe.whitelist(allow_guest=True)
def login_app_desker(username: str = None, password: str = None):
    import random
    from frappe.utils import now_datetime

    if not username or len(username) < 1:
        return {"message": "Please provide a valid username"}

    keyword = f"%{username}%"

    data = frappe.db.sql("""
        SELECT 
            client.name AS user_email,
            emp.roles,
            emp.coa_account,
            emp.mobile,
            emp.branch,
            emp.last_name,
            emp.email
        FROM 
            `tabUser` AS client
        LEFT JOIN 
            `tabEmployee` AS emp
            ON client.name = emp.user
        WHERE 
            client.name LIKE %(keyword)s
    """, {"keyword": keyword}, as_dict=True)

    if not data:
        return {"message": "No data found"}

    user = data[0]
    mobile_number = user.get("mobile")
    last_name = user.get("last_name")
    email = user.get("email")

    if not mobile_number:
        return {"message": "Mobile number not found for the user"}
    import re

    # Check if message exists in last 24 hours
    existing_msg = frappe.db.sql("""
        SELECT message_body
        FROM `tabMessage Archive`
        WHERE mobile=%(mobile)s
          AND creation>=NOW() - INTERVAL 24 HOUR
        ORDER BY creation DESC
        LIMIT 1
    """, {"mobile": mobile_number}, as_dict=True)

    if existing_msg:
        saved = existing_msg[0].message_body
        otp_match = re.search(r"\b(\d{6})\b", saved)
        extracted_otp = otp_match.group(1) if otp_match else None

        
        return {
            "message": "Data found",
            "otp": extracted_otp,
            "phone": mobile_number,
            "data": user
        }

    # Simulate accounting period check
    accounting_periods = frappe.db.sql("""
        SELECT ap.name
        FROM `tabAccounting Period` ap
        JOIN `tabClosed Document` cd ON ap.name = cd.parent
        WHERE ap.branch = %(branch)s
            AND ap.company = %(company)s
            AND cd.closed = 0
            AND cd.document_type = %(voucher_type)s
            AND %(date)s BETWEEN ap.start_date AND ap.end_date
    """, {
        "date": now_datetime(),
        "branch": user.get("branch"),
        "voucher_type": "Deposit",
        "company": "UWEZO FINANCIAL SERVICES LTD"
    }, as_dict=True)

    # ✅ Generate OTP
    otp = random.randint(100000, 999999)
    send_gmail(receiver_email=email,message=otp)

    # Decide whether to send OTP based on accounting period
    if accounting_periods:
        acc_status = 0
    else:
        acc_status = 1

# Attach OTP and account status to response
    user["acc"] = acc_status
    user["otp"] = otp  # returning OTP in response
    user["mobile"] = mobile_number


    message = (
        f"Dear {last_name}, your Uwezo login verification code is {otp}. "
        f"This code will expire in 24hrs. Do not share it with anyone. "
        f"Thank you, Uwezo Team."
    )

    send_sms(message=message, phone=mobile_number)
    send_message_to_clients_opening2(recipients=mobile_number,message=message)


        

    return {
        "message": "Data found",
        "otp": otp,
        "phone": mobile_number,
        "data": user
    }

import smtplib, html
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
@frappe.whitelist(allow_guest=True)
def send_gmail(receiver_email, message):
    sender_email = "uwezodata@gmail.com"
    app_password = "tvke tcyp ueyz avsx"
    subject = "Your One-Time Passcode (OTP)"
    otp = html.escape(str(message).strip())
    text = f"Your OTP is: {otp}\n\nIf you did not request this, please ignore this email."
    html_content = f"""\
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{{margin:0;padding:0;background:#f4f6f8;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial;color:#334155}}
.container{{width:100%;padding:24px;display:flex;justify-content:center;box-sizing:border-box}}
.card{{max-width:560px;width:100%;background:#fff;border-radius:12px;box-shadow:0 6px 20px rgba(17,24,39,0.08);padding:28px;box-sizing:border-box}}
.brand{{display:flex;align-items:center;gap:12px;margin-bottom:18px}}
.brand-logo{{width:44px;height:44px;border-radius:8px;background:linear-gradient(135deg,#2563eb,#7c3aed);display:inline-flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:18px}}
.brand-name{{font-size:16px;font-weight:600;color:#0f172a}}
h1{{margin:0 0 6px 0;font-size:20px;color:#0f172a}}
p.lead{{margin:0 0 20px 0;color:#475569;font-size:14px;line-height:1.5}}
.otp{{display:inline-block;padding:18px 28px;border-radius:12px;font-size:28px;letter-spacing:6px;font-weight:700;background:linear-gradient(90deg,#eef2ff,#fff7ed);color:#0f172a;text-align:center;margin:12px 0 18px 0}}
.cta{{display:inline-block;text-decoration:none;padding:12px 18px;border-radius:10px;font-weight:600;background:#2563eb;color:#fff;box-shadow:0 6px 18px rgba(37,99,235,0.18)}}
.note{{margin-top:16px;font-size:12px;color:#64748b}}
.footer{{margin-top:18px;border-top:1px solid #eef2f7;padding-top:12px;font-size:12px;color:#94a3b8}}
@media(max-width:480px){{.otp{{font-size:24px;letter-spacing:4px;padding:12px 18px}}}}
</style></head>
<body><div class="container"><div class="card">
<div class="brand"><div class="brand-logo">U</div><div class="brand-name">Uwezo Data — Security</div></div>
<h1>Your verification code</h1>
<p class="lead">Use the code below to complete your action. This code will expire in <strong>10 minutes</strong>.</p>
<div class="otp">{otp}</div>
<p><a href="#" class="cta" onclick="return false;">Copy code</a></p>
<p class="note">If you didn't request this code, you can safely ignore this email.</p>
<div class="footer">Uwezo Data • Kampala, Uganda<br>This is an automated message — please do not reply.</div>
</div></div></body></html>"""
    msg = MIMEMultipart("alternative")
    msg["From"], msg["To"], msg["Subject"] = sender_email, receiver_email, subject
    msg.attach(MIMEText(text, "plain"))
    msg.attach(MIMEText(html_content, "html"))
    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(sender_email, app_password)
            server.send_message(msg)
        print(f"✅ Email sent to {receiver_email}")
    except Exception as e:
        print("❌ Error sending email:", e)


@frappe.whitelist(allow_guest=True)
def send_gmail2(receiver_email, username):
    sender_email = "uwezodata@gmail.com"
    app_password = "tvke tcyp ueyz avsx"
    subject = "Uwezo Data – Temporary Login Credentials (Valid for 24 Hours)"

    temp_password = "uwezo1234"
    portal_url = "http://uwezo.live:8000/#login"

    # Plain text fallback
    text = f"""
Dear {username},

This email contains temporary login credentials for your Uwezo Data account.

Username: {username}
Temporary Password: {temp_password}

These credentials are valid for the next 24 hours only.

Please sign in using the link below and reset your password immediately for security purposes:
{portal_url}

If you did not request this action, kindly disregard this message.

Uwezo Data Security Team
"""

    # HTML Email – Bank-grade professional layout
    html_content = f"""
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {{
    margin: 0;
    padding: 0;
    background: #f1f5f9;
    font-family: Arial, Helvetica, sans-serif;
    color: #1e293b;
}}

.container {{
    width: 100%;
    padding: 24px;
    box-sizing: border-box;
    display: flex;
    justify-content: center;
}}

.card {{
    width: 100%;
    max-width: 600px;
    background: #ffffff;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
    box-shadow: 0 4px 14px rgba(0,0,0,0.06);
    padding: 32px;
    box-sizing: border-box;
}}

.header {{
    margin-bottom: 24px;
    border-bottom: 1px solid #e2e8f0;
    padding-bottom: 12px;
}}

.header-title {{
    font-size: 18px;
    font-weight: 600;
    color: #0f172a;
}}

.section-title {{
    font-size: 16px;
    font-weight: 600;
    margin-top: 16px;
    margin-bottom: 6px;
    color: #0f172a;
}}

.info-box {{
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    padding: 12px 16px;
    border-radius: 6px;
    font-size: 14px;
    margin-bottom: 12px;
    color: #0f172a;
}}

.button {{
    display: inline-block;
    margin-top: 24px;
    padding: 12px 20px;
    background: #0d47a1;
    color: #ffffff !important;
    text-decoration: none;
    border-radius: 4px;
    font-size: 14px;
    font-weight: 600;
}}

.notice {{
    font-size: 12px;
    color: #475569;
    margin-top: 20px;
    line-height: 1.4;
}}

.footer {{
    font-size: 11px;
    color: #64748b;
    border-top: 1px solid #e2e8f0;
    margin-top: 24px;
    padding-top: 12px;
}}
</style>
</head>

<body>
<div class="container">
<div class="card">

<div class="header">
    <div class="header-title">Uwezo Data – Password Reset Notification</div>
</div>

<p>
This message contains secure temporary credentials issued for your account.  
For your protection, these credentials remain valid for <strong>24 hours only</strong>.
</p>

<div class="section-title">Username</div>
<div class="info-box">{username}</div>

<div class="section-title">Temporary Password</div>
<div class="info-box">{temp_password}</div>

<p>
Kindly sign in using the link below and reset your password immediately to complete the security process.
</p>

<a href="{portal_url}" class="button">Access Secure Portal</a>

<div class="notice">
If you did not request a password reset, please disregard this message.  
Your account access will remain unchanged.
</div>

<div class="footer">
Uwezo Data • Kampala, Uganda<br>
This is an automated system email. Please do not reply.
</div>

</div>
</div>
</body>
</html>
"""

    msg = MIMEMultipart("alternative")
    msg["From"], msg["To"], msg["Subject"] = sender_email, receiver_email, subject
    msg.attach(MIMEText(text, "plain"))
    msg.attach(MIMEText(html_content, "html"))

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(sender_email, app_password)
            server.send_message(msg)
        print(f"Email sent to {receiver_email}")
    except Exception as e:
        print("Error sending email:", e)


import frappe
from frappe.auth import LoginManager
@frappe.whitelist(allow_guest=True)
def verify_password_otp(username, password, otp=None):
    # fetch OTP from wherever you stored it (cache/db)
    # stored_otp = frappe.cache().get(f"otp:{username}")
    # if not stored_otp or otp != stored_otp:
    #     return {"status": "fail", "message": "Incorrect OTP"}

    # Verify password
    try:
        login_manager = LoginManager()
        login_manager.authenticate(user=username, pwd=password)
        login_manager.post_login()
        frappe.local.login_manager = login_manager
        frappe.db.commit()
        return {"status": "success"}
    except frappe.exceptions.AuthenticationError:
        return {"status": "fail", "message": "Incorrect password"}

## Desktop
import frappe
@frappe.whitelist(allow_guest=True)
def login_desktop(username: str = None, password: str = None):
    import random
    import urllib.parse
    import requests

    if not username or len(username) < 1:
        return {"message": "Please provide a valid username"}
    
    keyword = f"%{username}%"
    
    data = frappe.db.sql("""
        SELECT 
            client.*,
            emp.roles, 
            emp.coa_account, 
            emp.mobile,
            emp.branch
        FROM 
            `tabUser` AS client
        LEFT JOIN 
            `tabEmployee` AS emp
        ON 
            client.name= emp.user
        WHERE 
            client.name LIKE %(keyword)s
    """, {"keyword": keyword}, as_dict=True)

    if data:
        # Retrieve the mobile number from the query result
        mobile_number = data[0].get("mobile") if data[0].get("mobile") else None
        
        if not mobile_number:
            return {"message": "Mobile number not found for the user"}
        
        # Generate and send OTP
        otp = send_sms_notification(mobile_number)
        data[0]["otp"] = otp  # Attach OTP to the response data
        
        return {"message": "Data found, OTP sent", "data": data}
    
    return {"message": "No data found"}


@frappe.whitelist(allow_guest=True)
def login_desktop2(username: str = None, password: str = None):
    if not username or len(username) < 1:
        return {"message": "Please provide a valid username"}

    try:
        otp = send_sms_notificationw(username, password)

        data = [{"username": username, "otp": otp}]  # Assuming you want to return some data structure

        return {
            "message": "Data found, OTP sent",
            "data": data
        }

    except Exception as e:
        frappe.log_error(f"Login error: {str(e)}", "login_desktop2")
        return {
            "message": "An error occurred while processing your request",
            "error": str(e)
        }


@frappe.whitelist(allow_guest=True)
def get_device(device_id: str = None, userid: str = None):
    try:
        # Validate input parameters
        if device_id is None and userid is None:
            raise ValueError("At least device_id or userid is required")
        if device_id is not None and userid is None:
            raise ValueError("Both device_id and userid must be provided together to fetch data")
        if userid is not None and device_id is None:
            raise ValueError("Both device_id and userid must be provided together to fetch data")

        # Build filter conditions to ensure both device_id and userid match
        conditions = {'device_id': device_id, 'user': userid}

        # Query the device table based on the provided conditions
        device = frappe.db.get_all('Device', filters=conditions, fields=['name', 'device_id', 'owner', 'branch', 'user', 'active'])

        # Check if a device is found
        if not device:
            return {"message": "No device found matching the provided parameters"}

        # Return the found device(s)
        return {"device": device[0]}

    except Exception as e:
        return {"error": str(e)}

    return {"message": "No data found"}

@frappe.whitelist(allow_guest=True)
def update_name_mobile_from_fix_number():
    fix_numbers = frappe.get_all(
        "fix_numbers",
        fields=["external_id", "mobile"]
    )
    updated = 0
    for fix in fix_numbers:
        ext_id = (fix.external_id or "").strip()
        mobile = (fix.mobile or "").replace(" ", "")

        if ext_id and mobile:
            if frappe.db.exists("Client", ext_id):
                # Correct DocType name here
                frappe.db.set_value("Client", ext_id, "mobile", mobile)
                updated += 1
    frappe.db.commit()
    return f"{updated} 'Client' records updated successfully."


@frappe.whitelist(allow_guest=True)
def get_client_transactions(user: str = None, start_date: str = None, end_date: str = None, search: str = None, client_type: str = None):
    # Validate inputs


        # SQL query to fetch transactions from tabClient based on the user and date range
    data = frappe.db.sql("""
        SELECT 
        *
        FROM 
            `tabClient` AS client
        WHERE 
            client.branch = %(user)s
          and  client.full_name like %(search)s
            AND client.creation BETWEEN %(start_date)s AND %(end_date)s
               ORDER BY client.creation DESC

        LIMIT 20
    """, {"user": user, "search": f"%{search}%", "start_date": start_date, "end_date": end_date}, as_dict=True)

    if data:
        # Optionally format the amount (example)
        # for transaction in data:
        #     transaction['formatted_amount'] = f"${transaction['amount']:.2f}"
        
        return {"message": "Transactions found", "data": data}
    
    return {"message": "No transactions found"}

@frappe.whitelist(allow_guest=True)
def get_hr(user: str = None):
    # Validate inputs
   
        # SQL query to fetch transactions from tabClient based on the user and date range
    data = frappe.db.sql("""
        SELECT 
        *
        FROM 
            `tabBanking Account` AS client
        WHERE 1
                     
        
    """, {"user": user}, as_dict=True)

    if data:
        # Optionally format the amount (example)
        # for transaction in data:
        #     transaction['formatted_amount'] = f"${transaction['amount']:.2f}"
        
        return {"message": "Transactions found", "data": data}
    
    return {"message": "No transactions found"}


@frappe.whitelist(allow_guest=True)
def get_branches(user: str = None):
    # Validate inputs
   
        # SQL query to fetch transactions from tabClient based on the user and date range
    data = frappe.db.sql("""
        SELECT 
        *
        FROM 
            `tabSaving Product` AS client
        WHERE 1
           
            
        
    """, {"user": user}, as_dict=True)

    if data:
        # Optionally format the amount (example)
        # for transaction in data:
        #     transaction['formatted_amount'] = f"${transaction['amount']:.2f}"
        
        return {"message": "Transactions found", "data": data}
    
    return {"message": "No transactions found"}
    
@frappe.whitelist(allow_guest=True)
def get_savings_transactions_app(user: str = None, start_date: str = None, end_date: str = None):
    # Required fields for the frontend
    fields = """
        client.name,
        client.account,
        client.client_name,
        client.description,
        client.owner,
        client.amount,
        client.fees_total,
        client.creation,
        client.loan
    """

    # Initialize condition list and filter values
    conditions = []
    filters = {}

    # Add user filter if provided
    if user:
        filters["user"] = f"%{user}%"
        conditions.append("""
            (client.account LIKE %(user)s
            OR client.client_name LIKE %(user)s
            OR client.loan LIKE %(user)s
            OR client.name LIKE %(user)s)
        """)

    # Add date filter if both dates are provided
    if start_date and end_date:
        filters["start_date"] = start_date
        filters["end_date"] = end_date
        conditions.append("client.creation BETWEEN %(start_date)s AND %(end_date)s")

    # If no filters, default to TRUE condition
    where_clause = " AND ".join(conditions) if conditions else "1=1"

    # Final query
    query = f"""
        SELECT {fields}
        FROM `tabSaving Transaction` AS client
        WHERE {where_clause}
        ORDER BY client.creation DESC
        LIMIT 100
    """

    # Execute query
    data = frappe.db.sql(query, filters, as_dict=True)

    if data:
        return {"message": "Records found", "data": data}

    return {"message": "No records found", "data": []}


@frappe.whitelist(allow_guest=True)
def get_savings_transactions_app_s(user: str = None, start_date: str = None, end_date: str = None):
    # Required fields for the frontend
    fields = """
        client.name,
        client.account,
        client.client_name,
        client.description,
        client.owner,
        client.amount,
        client.fees_total,
        client.creation,
        client.loan
    """

    # Initialize condition list and filter values
    conditions = []
    filters = {}

    # Add user filter if provided
    if user:
        filters["user"] = f"%{user}%"
        conditions.append("""
            (client.account LIKE %(user)s
            OR client.client_name LIKE %(user)s
            OR client.loan LIKE %(user)s
            OR client.name LIKE %(user)s)
        """)

    # Add date filter if both dates are provided
    if start_date and end_date:
        filters["start_date"] = start_date
        filters["end_date"] = end_date
        conditions.append("client.creation BETWEEN %(start_date)s AND %(end_date)s")

    # If no filters, default to TRUE condition
    where_clause = " AND ".join(conditions) if conditions else "1=1"

    # Final query
    query = f"""
        SELECT {fields}
        FROM `tabSaving Transaction` AS client
        WHERE {where_clause}
        ORDER BY client.creation ASC
       
    """

    # Execute query
    data = frappe.db.sql(query, filters, as_dict=True)

    if data:
        return {"message": "Records found", "data": data}

    return {"message": "No records found", "data": []}


@frappe.whitelist(allow_guest=True)
def get_savings_transactions_app2(user: str = None, start_date: str = None, end_date: str = None):
    # Required fields for the frontend
    fields = """
        client.name,
        client.account,
        client.client_name,
        client.description,
        client.owner,
        client.amount,
        client.fees_total,
        client.creation,
        client.loan
    """

    # Initialize condition list and filter values
    conditions = []
    filters = {}

    # Add user filter if provided
    if user:
        filters["user"] = f"%{user}%"
        conditions.append("""
            (client.account LIKE %(user)s
            OR client.client_name LIKE %(user)s
            OR client.loan LIKE %(user)s
            OR client.name LIKE %(user)s)
        """)

   

    # If no filters, default to TRUE condition
    where_clause = " AND ".join(conditions) if conditions else "1=1"

    # Final query
    query = f"""
        SELECT {fields}
        FROM `tabSaving Transaction` AS client
        WHERE {where_clause}
        ORDER BY client.creation DESC
        LIMIT 30
    """

    # Execute query
    data = frappe.db.sql(query, filters, as_dict=True)

    if data:
        return {"message": "Records found", "data": data}

    return {"message": "No records found", "data": []}

@frappe.whitelist(allow_guest=True)
def get_charges_desktop(user: str = None):
    user_pattern = f"%{user}%"

    query = """
        SELECT 
            name,
            charge,
            saving_charge_name AS charge_name,
            charge_time_type_name,
            charge_calculation_type,
            amount,
            'Savings' AS type
        FROM 
            `tabSavings Charges`
        WHERE 
            saving_charge_name LIKE %(user)s
            OR charge LIKE %(user)s
            OR name LIKE %(user)s

        UNION

        SELECT 
            name,
            charge,
            loan_charge_name AS charge_name,
            charge_time_type_name,
            charge_calculation_type,
            amount,
            'Loan' AS type
        FROM 
            `tabLoan Charge`
        WHERE 
            loan_charge_name LIKE %(user)s
            OR charge LIKE %(user)s
            OR name LIKE %(user)s
    """

    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}

@frappe.whitelist(allow_guest=True)
def get_district(user: str = None):
    user_pattern = f"%{user}%"

    query = """
        SELECT 
           *
        FROM 
            `tabDistrict II`
        WHERE 
           
             name LIKE %(user)s

    """

    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}

@frappe.whitelist(allow_guest=True)
def get_division(user: str = None):
    user_pattern = f"%{user}%"

    query = """
        SELECT 
           *
        FROM 
            `tabDivision II`
        WHERE 
           
             district LIKE %(user)s

    """

    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}


@frappe.whitelist(allow_guest=True)
def get_sub_county(user: str = None):
    user_pattern = f"%{user}%"

    query = """
        SELECT 
           *
        FROM 
            `tabSub County II`
        WHERE 
           
             district LIKE %(user)s

    """

    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}




@frappe.whitelist(allow_guest=True)
def get_parish(user: str = None):
    user_pattern = f"%{user}%"

    query = """
        SELECT 
           *
        FROM 
            `tabParish II`
        WHERE 
           
             division LIKE %(user)s

    """

    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}



@frappe.whitelist(allow_guest=True)
def get_village(user: str = None):
    user_pattern = f"%{user}%"

    query = """
        SELECT 
           *
        FROM 
            `tabVillage II`
        WHERE 
           
             division LIKE %(user)s

    """

    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}


@frappe.whitelist(allow_guest=True)
def get_profesions(user: str = None):
    user_pattern = f"%{user}%"

    query = """
        SELECT 
           *
        FROM 
            `tabProfessions`
        WHERE 
           
             name LIKE %(user)s

    """

    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}


@frappe.whitelist(allow_guest=True)
def get_payment_desktop(user: str = None):
    user_pattern = f"%{user}%"

    query = """
        SELECT 
            name,
            employee_name,
            approval_status ,
            is_paid,
            grand_total,
          
            status
        FROM 
            `tabCash Receipt`
        WHERE 
            name LIKE %(user)s
            OR employee_name LIKE %(user)s
       
        UNION

        SELECT 
            name,
            employee_name,
            approval_status ,
            is_paid,
            grand_total,
       
            status
        FROM 
            `tabPayment I`
        WHERE 
            name LIKE %(user)s
            OR employee_name LIKE %(user)s
        limit 100
    """

    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}


@frappe.whitelist(allow_guest=True)
def search_loan_ag2(user: str = None):

    # Add wildcards for partial match
    user_pattern = f"%{user}%"

    # Execute the SQL query to fetch records and return the full name
    query = """
        SELECT 
           *
        FROM 
            `tabLoan Application Plus` AS client
        WHERE 
            client.clients LIKE %(user)s
            OR client.client_name LIKE %(user)s
            OR client.mobile_contacts LIKE %(user)s
            OR client.name LIKE %(user)s
        limit 100
    """
    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    # Return the results with appropriate messages
    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}

@frappe.whitelist(allow_guest=True)
def search_loan_banker2(user: str = None):
    if not user:
        return {"message": "Missing search parameter"}

    # No wildcards since we want an exact match
    query = """
        SELECT 
            *
        FROM 
            `tabEmployee` AS client
        WHERE 
            client.coa_account = %(user)s
        LIMIT 100
    """
    data = frappe.db.sql(query, {"user": user}, as_dict=True)

    # Return the results with appropriate messages
    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}

@frappe.whitelist(allow_guest=True)
def search_loan_banker3(br: str = None, user: str = None):
    if not br:
        return {"message": "Missing branch parameter"}

    conditions = "branch = %(branch)s"
    filters = {"branch": br}

    if user:
        conditions += " AND account like %(user)s"
        filters["user"] = user

    query = f"""
        SELECT 
            *
        FROM 
            `tabEmployee`
        WHERE 
            {conditions}
        LIMIT 100
    """
    data = frappe.db.sql(query, filters, as_dict=True)

    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}


@frappe.whitelist(allow_guest=True)
def search_loan_banker(user: str = None):

    # Add wildcards for partial match
    user_pattern = f"%{user}%"

    # Execute the SQL query to fetch records and return the full name
    query = """
        SELECT 
           *
        FROM 
            `tabEmployee` AS client
        WHERE 
            client.full_name LIKE %(user)s
            OR client.account LIKE %(user)s
            OR client.coa_account LIKE %(user)s
            OR client.name LIKE %(user)s
        limit 100
    """
    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    # Return the results with appropriate messages
    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}

@frappe.whitelist(allow_guest=True)
def get_float_desktop(user: str = None):
    user_pattern = f"%{user}%"

    query = """
        SELECT 
            name,
            from_account,
            account_name ,
            date,
            amount,
            created_by,
            posting_date,
            'Float Purchase' as type
        FROM 
            `tabFloat Purchase`
        WHERE 
            from_account LIKE %(user)s
            OR account_name LIKE %(user)s
            OR name LIKE %(user)s
       

        UNION

        SELECT 
          name,
            from_account,
            account_name ,
            date,
            amount,
            created_by,
            posting_date,
            'Float Sell' as type
        FROM 
            `tabFloat Sell`
        WHERE 
            from_account LIKE %(user)s
            OR account_name LIKE %(user)s
            OR name LIKE %(user)s
             limit 100
    """

    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}

@frappe.whitelist(allow_guest=True)
def get_client_desktop(user: str = None):

    # Add wildcards for partial match
    user_pattern = f"%{user}%"

    # Execute the SQL query to fetch records and return the full name
    query = """
        SELECT 
            CONCAT(
                COALESCE(client.first_name, ''), ' ',
                COALESCE(client.middle_name, ''), ' ',
                COALESCE(client.last_name, '')
            ) AS full_name2
            ,client.*
        FROM 
            `tabClient` AS client
        WHERE 
            client.full_name LIKE %(user)s
            OR client.mobile LIKE %(user)s
            OR client.name LIKE %(user)s
        limit 100
    """
    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    # Return the results with appropriate messages
    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}


@frappe.whitelist(allow_guest=True)
def get_client_loan(user: str = None):

    # Add wildcards for partial match
    user_pattern = f"%{user}%"

    # Execute the SQL query to fetch records and return the full name
    query = """
        SELECT 
     
            client.*
        FROM 
            `tabLoan Application Plus` AS client
        WHERE 
            client.clients LIKE %(user)s
            OR client.client_name LIKE %(user)s
            OR client.name LIKE %(user)s
        limit 100
    """
    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    # Return the results with appropriate messages
    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}


@frappe.whitelist(allow_guest=True)
def get_client_desktop2(user: str = None):

    # Add wildcards for partial match
    user_pattern = f"%{user}%"

    # Execute the SQL query to fetch records and return the full name
    query = """
        SELECT 
           client.*
        FROM 
            `tabJoint Accounts` AS client
        WHERE 
            client.full_name LIKE %(user)s
            OR client.mobile LIKE %(user)s
            OR client.name LIKE %(user)s
       limit 100
    """
    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    # Return the results with appropriate messages
    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}



@frappe.whitelist(allow_guest=True)
def get_client_desktop3(user: str = None):

    # Add wildcards for partial match
    user_pattern = f"%{user}%"

    # Execute the SQL query to fetch records and return the full name
    query = """
        SELECT 
           client.*
        FROM 
            `tabGroup Account` AS client
        WHERE 
            client.full_name LIKE %(user)s
            OR client.mobile LIKE %(user)s
            OR client.name LIKE %(user)s
       limit 100
    """
    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    # Return the results with appropriate messages
    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}

@frappe.whitelist(allow_guest=True)
def get_accounter(branch: str = None):
    # Base query for account names
    query = """
        SELECT
            client.*
        FROM
            `tabAccount` AS client
        WHERE
            (
                client.name LIKE '121230%%' OR
                client.name LIKE '121140%%' OR
                client.name LIKE '221410%%'
            )
    """

    query_params = {}

    # Conditionally add the branch filter if a branch is provided
    if branch:
        query += " AND client.branch = %(branch)s"
        query_params["branch"] = branch # Use the exact branch value

    query += " LIMIT 100"

    data = frappe.db.sql(query, query_params, as_dict=True)

    if data:
        return {"status": "success", "message": "Records found", "data": data}
    return {"status": "fail", "message": "No records found"}


@frappe.whitelist(allow_guest=True)
def get_accounter4(branch: str = None):
    # Base query for account names
    query = """
        SELECT
            client.*
        FROM
            `tabAccount` AS client
        WHERE
            1
    """

    query_params = {}

    # Conditionally add the branch filter if a branch is provided
    if branch:
        query += " AND client.branch = %(branch)s"
        query_params["branch"] = branch # Use the exact branch value


    data = frappe.db.sql(query, query_params, as_dict=True)

    if data:
        return {"status": "success", "message": "Records found", "data": data}
    return {"status": "fail", "message": "No records found"}


@frappe.whitelist(allow_guest=True)
def get_accounter2(branch: str = None, root_type: str = None):
    # Base query for account names
    query = """
        SELECT
            client.*
        FROM
            `tabAccount` AS client
        WHERE
            1=1  -- Start with a true condition to easily append AND clauses
    """

    query_params = {}

    # Conditionally add the branch filter if a branch is provided
    if branch:
        query += " AND client.branch = %(branch)s"
        query_params["branch"] = branch

    # Conditionally add the root_type filter if a root_type is provided
    if root_type:
        query += " AND client.root_type = %(root_type)s"
        query_params["root_type"] = root_type

    query += " LIMIT 100"

    data = frappe.db.sql(query, query_params, as_dict=True)

    if data:
        return {"status": "success", "message": "Records found", "data": data}
    return {"status": "fail", "message": "No records found"}



@frappe.whitelist(allow_guest=True)
def get_savings_account(user: str = None):

    # Add wildcards for partial match
    user_pattern = f"%{user}%"

    # Execute the SQL query to fetch records and return the full name
    query = """
        SELECT 
           client.*
        FROM 
            `tabSaving Product` AS client
        WHERE 
         
             client.branch LIKE %(user)s
      
    """
    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    # Return the results with appropriate messages
    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}


@frappe.whitelist(allow_guest=True)
def get_savings_account1(user: str = None):

    # Add wildcards for partial match
    user_pattern = f"%{user}%"

    # Execute the SQL query to fetch records and return the full name
    query = """
        SELECT 
           client.*
        FROM 
            `tabLoan Product` AS client
        WHERE 
         
             client.branch LIKE %(user)s
      
    """
    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    # Return the results with appropriate messages
    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}

@frappe.whitelist(allow_guest=True)
def get_savings_account2(user: str = None):

    # Add wildcards for partial match
    user_pattern = f"%{user}%"

    # Execute the SQL query to fetch records and return the full name
    query = """
        SELECT 
           client.*
        FROM 
            `tabLoan Product` AS client
        WHERE 
         
             client.name LIKE %(user)s
      
    """
    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    # Return the results with appropriate messages
    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}

@frappe.whitelist(allow_guest=True)
def get_client_transactions2app(user: str = None, search: str = None):
    query = """
        SELECT *
        FROM `tabSavings Account` AS client
        WHERE client.branch = %(user)s
        AND (client.client_name LIKE %(search)s OR client.name LIKE %(search)s)
        LIMIT 100
    """
    data = frappe.db.sql(query, {
        "user": user if user else "",
        "search": f"%{search}%" if search else "%"
    }, as_dict=True)

    if data:
        return {"message": "Records found", "data": data}
    return {"message": "No records found"}






@frappe.whitelist(allow_guest=True)
def get_client_transactions2appd(user: str = None):
    # Add wildcards for partial match
    user_pattern = f"%{user}%"
    # Execute the SQL query to fetch records and return the full name
    query = f"""
        SELECT 
            client.*,
             client2.mobile,client2.gender
        FROM 
            `tabSavings Account` AS client
            join `tabClient` AS client2
            on client.client = client2.name
        WHERE 
            client.client_name LIKE %(user)s
   
            OR client.name LIKE %(user)s
            limit 20
    """
    data = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    # Return the results with appropriate messages
    if data:
        return {"message": "Records found", "data": data}
    
    return {"message": "No records found"}
@frappe.whitelist(allow_guest=True)
def get_client_transactions2appdjt(user: str = None):
    user_pattern = f"%{user}%"

    # Step 1: Find the Group Account that matches the user input
    query = """
        SELECT *
        FROM `tabSavings Account` AS client
        WHERE client.client_type = 'Group Account'
          AND (
              client.name LIKE %(user)s
              OR client.account_number LIKE %(user)s
              OR client.client_name LIKE %(user)s
          )
        LIMIT 1
    """
    group_account = frappe.db.sql(query, {"user": user_pattern}, as_dict=True)

    if not group_account:
        return {"message": "No Group Account found"}

    group_account_name = group_account[0].get("client") or group_account[0].get("name")

    # Step 2: Fetch only members from 'Group Account Members' child table
    members = frappe.db.get_all(
        "Group Account Members",
        filters={"parent": group_account_name},
        fields=["accountsn", "client_name", "client"]
    )

    if not members:
        return {"message": "No members found for this Group Account"}

    return {
        "message": "Group Account members found",
        "group_account": group_account_name,
        "members": members
    }




@frappe.whitelist(allow_guest=True)
def get_client_transactions2(user: str = None, search: str = None, client_type: str = None):
    # Validate inputs
  

   
        # SQL query to fetch transactions from tabClient based on the user and date range
    data_sql = """
        SELECT 
        *
        FROM 
            `tabSavings Account` AS client
        WHERE 
            client.branch = %(user)s
            AND client.saving_product = %(client_type)s
            AND client.client_name LIKE %(search)s
     
            or 
            client.branch = %(user)s
            AND client.name LIKE %(search)s
            AND client.saving_product = %(client_type)s
       
            or 
            client.branch = %(user)s
            AND client.account_number LIKE %(search)s
            AND client.saving_product = %(client_type)s
       
        LIMIT 20
    """
    
    if client_type == "" or client_type == None:
        data_sql =  """
        SELECT 
        *
        FROM 
            `tabSavings Account` AS client
        WHERE 
            client.branch = %(user)s
       
            AND client.client_name LIKE %(search)s
            
            or 
            client.branch = %(user)s
            AND client.name LIKE %(search)s
            
           
            or 
            client.branch = %(user)s
            AND client.account_number LIKE %(search)s
          
           
            LIMIT 20
        """

    data = frappe.db.sql(data_sql, {"user": user, "search": f"%{search}%","client_type":client_type}, as_dict=True)
        

    if data:
        # Optionally format the amount (example)
        # for transaction in data:
        #     transaction['formatted_amount'] = f"${transaction['amount']:.2f}"
        
        return {"message": "Transactions found", "data": data}
    
    return {"message": "No transactions found"}
@frappe.whitelist(allow_guest=True)
def get_savings_transactions(user: str = None, start_date: str = None, end_date: str = None, search: str = None, client_type: str = None, owner=None, page: int = 1, page_size: int = 20):
    # Validate inputs
    if not user:
        return {"status": "error", "message": "Please provide a valid username"}
    
    if not start_date or not end_date:
        return {"status": "error", "message": "Please provide valid start and end dates"}
    
    try:
        datetime.strptime(start_date, "%Y-%m-%d")
        datetime.strptime(end_date, "%Y-%m-%d")
    except ValueError:
        return {"status": "error", "message": "Invalid date format. Use YYYY-MM-DD"}
    
    client_type = client_type.lower() if client_type else ""
    search = search if search else ""
    page_size=20
    # Calculate offset for pagination
    offset = (page - 1) * page_size
    
    # Base query for fetching transactions
    base_query = """
        SELECT 
            st.transaction_type_name,
            st.amount,
            st.fees_total,
            st.name,
            st.branch,
            st.owner,
            st.account,
            st.client_name,
            st.posting_date,
            st.external_id,
            sa.saving_product_name
        FROM 
            `tabSaving Transaction` AS st
        JOIN  
            `tabSavings Account` AS sa 
            ON st.account = sa.name
        WHERE 
            st.branch = %(user)s
            AND st.creation BETWEEN %(start_date)s AND %(end_date)s
            AND (
                st.owner = %(owner)s
                OR st.user = %(owner)s
            )
    """

    # Add search condition
    if search:
        base_query += " AND (st.name LIKE %(search)s OR st.account LIKE %(search)s)"
    
    # Add client_type condition if provided
    if client_type:
        base_query += " AND st.description LIKE %(client_type)s"
    
    # Add ordering and pagination
    base_query += " ORDER BY st.creation DESC LIMIT %(page_size)s OFFSET %(offset)s"
    
    try:
        # Execute the query
        data = frappe.db.sql(base_query, {
            "user": user,
            "owner": owner,
            "search": f"{search}%",  # Optimized search
            "client_type": f"%{client_type}%",
            "start_date": start_date,
            "end_date": end_date,
            "page_size": page_size,
            "offset": offset
        }, as_dict=True)
    except Exception as e:
        return {"status": "error", "message": f"Database error: {str(e)}"}
    
    if data:
        return {"status": "success", "message": "Transactions found", "data": data}
    
    return {"status": "success", "message": "No transactions found"}

@frappe.whitelist(allow_guest=True)
def get_savings_transactionsapp(user: str = None, start_date: str = None, end_date: str = None, search: str = None, client_type: str = None):
    # Validate inputs
    if not user:
        return {"status": "error", "message": "Please provide a valid username"}
    
    if not start_date or not end_date:
        return {"status": "error", "message": "Please provide valid start and end dates"}
    

    try:
        dd=0
    except ValueError:
        return {"status": "error", "message": "Invalid date format. Use YYYY-MM-DD"}
    
    client_type = client_type.lower() if client_type else ""
    
    # Base query for fetching transactions
    base_query = """
        SELECT 
             st.transaction_type_name,
              st.amount,
                st.fees_total,
                 st.name,
                  st.account,
                    st.client_name,
                      st.posting_date,
                        st.external_id,
            sa.saving_product_name,
            sa.status

          
        FROM 
            `tabSaving Transaction` AS st
        JOIN  
            `tabSavings Account` AS sa 
        ON 
            st.account = sa.name
        WHERE 
            st.branch = %(user)s
            AND sa.status != 'Inactive'
            AND st.creation BETWEEN %(start_date)s AND %(end_date)s
            AND (
                st.name LIKE %(search)s 
                OR st.account LIKE %(search)s
               
            )
    """
    
    # Add client_type condition if provided
    if client_type != "":
        base_query += " AND st.description LIKE %(client_type)s "
    
    # Limit to 50 results
    base_query += " ORDER BY st.creation DESC LIMIT 10"
    
    try:
        # Execute the query
        data = frappe.db.sql(base_query, {
            "user": user,
            "search": f"%{search}%",
            "client_type": f"%{client_type}%",
            "start_date": start_date,
            "end_date": end_date
        }, as_dict=True)
    except Exception as e:
        return {"status": "error", "message": f"Database error: {str(e)}"}
    
    if data:
        return {"status": "success", "message": "Transactions ", "data": data}
    
    return {"status": "success", "message": "No transactions found"}

@frappe.whitelist(allow_guest=True)
def deactivate_inactive_savings_accounts():
    """
    Set savings accounts to 'Inactive' if overdraft_derived is 90+ days old.
    """
    try:
        frappe.db.sql("""
            UPDATE `tabSavings Account`
            SET status = 'Inactive'
            WHERE overdraft_derived <= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
        """)
        frappe.db.commit()
        return {"status": "success", "message": "Inactive accounts updated successfully."}
    except Exception as e:
        frappe.log_error(frappe.get_traceback(), "Deactivate Inactive Savings Accounts")
        return {"status": "error", "message": str(e)}




@frappe.whitelist(allow_guest=True)
def get_all_loans(user: str = None, start_date: str = None, end_date: str = None, search: str = None, client_type: str = None):
    # Validate inputs
    if not user or len(user) < 1:
        return {"message": "Please provide a valid username"}
    
    if not start_date or not end_date:
        return {"message": "Please provide valid start and end dates"}
    
    # Base query for fetching transactions
    base_query = """
        SELECT 
            st.*,
            sa.saving_product_name
        FROM 
            `tabLoan Application Plus` AS st 
         JOIN  
            `tabSavings Account` AS sa 
        ON 
            st.clients = sa.name
        WHERE 
            st.branch = %(user)s
            AND (
                st.name LIKE %(search)s 
                OR st.client_name LIKE %(search)s
                OR st.account_number LIKE %(search)s
            )
          
    """
    
    # Add client_type condition if provided
    if client_type:
        base_query += " AND st.status = %(client_type)s"
    
   

    # Limit to 10 results
    base_query += " LIMIT 15"

    # Execute the query
    data = frappe.db.sql(base_query, {"user": user, "search": f"%{search}%", "client_type": client_type, "start_date": start_date, "end_date": end_date}, as_dict=True)

    if data:
        return {"message": "Transactions found", "data": data}
    
    return {"message": "No transactions found"}



@frappe.whitelist(allow_guest=True)
def get_banking_account(user: str = None, start_date: str = None, end_date: str = None, search: str = None, client_type: str = None):

    # Base query for fetching transactions
    base_query = """
        SELECT 
            st.*
        FROM 
            `tabBanking Account` AS st 
 
        WHERE 
            st.branch = %(user)s
            AND (
                st.name LIKE %(search)s 
                OR st.account_name LIKE %(search)s
                OR st.chart_of_account LIKE %(search)s
            )
          
    """
   

    # Limit to 10 results
    base_query += " LIMIT 15"

    # Execute the query
    data = frappe.db.sql(base_query, {"user": user, "search": f"%{search}%", "client_type": client_type, "start_date": start_date, "end_date": end_date}, as_dict=True)

    if data:
        return {"message": "Transactions found", "data": data}
    
    return {"message": "No transactions found"}




@frappe.whitelist(allow_guest=True)
def get_employee(user: str = None, start_date: str = None, end_date: str = None, search: str = None, client_type: str = None):
    
    # Base query for fetching transactions
    base_query = """
        SELECT 
            st.*
        FROM 
            `tabEmployee` AS st 
 
        WHERE 
            st.branch = %(user)s
            AND (
                st.account LIKE %(search)s 
                OR st.full_name LIKE %(search)s
                OR st.user LIKE %(search)s
            )
          
    """
   

    # Limit to 10 results
    base_query += " LIMIT 15"

    # Execute the query
    data = frappe.db.sql(base_query, {"user": user, "search": f"%{search}%", "client_type": client_type, "start_date": start_date, "end_date": end_date}, as_dict=True)

    if data:
        return {"message": "Transactions found", "data": data}
    
    return {"message": "No transactions found"}



@frappe.whitelist(allow_guest=True)
def get_float_sell(user: str = None, start_date: str = None, end_date: str = None, search: str = None, client_type: str = None):
    
    # Base query for fetching transactions
    base_query = """
        SELECT 
            st.*
        FROM 
            `tabFloat Sell` AS st 
        WHERE 
            st.branch = %(user)s
             AND st.creation BETWEEN %(start_date)s AND %(end_date)s
            AND (
                st.from_account LIKE %(search)s 
                OR st.account_name LIKE %(search)s
                OR st.amount LIKE %(search)s
            )
          
    """
   

    # Limit to 10 results
    base_query += " LIMIT 15"

    # Execute the query
    data = frappe.db.sql(base_query, {"user": user, "search": f"%{search}%", "client_type": client_type, "start_date": start_date, "end_date": end_date}, as_dict=True)

    if data:
        return {"message": "Transactions found", "data": data}
    
    return {"message": "No transactions found"}



@frappe.whitelist(allow_guest=True)
def get_float_purchase(user: str = None, start_date: str = None, end_date: str = None, search: str = None, client_type: str = None):
    
    # Base query for fetching transactions
    base_query = """
        SELECT 
            st.*
        FROM 
            `tabFloat Purchase` AS st 
 
        WHERE 
            st.branch = %(user)s
             AND st.creation BETWEEN %(start_date)s AND %(end_date)s
            AND (
                st.from_account LIKE %(search)s 
                OR st.account_name LIKE %(search)s
                OR st.amount LIKE %(search)s
            )
          
    """
   

    # Limit to 10 results
    base_query += " LIMIT 15"

    # Execute the query
    data = frappe.db.sql(base_query, {"user": user, "search": f"%{search}%", "client_type": client_type, "start_date": start_date, "end_date": end_date}, as_dict=True)

    if data:
        return {"message": "Transactions found", "data": data}
    
    return {"message": "No transactions found"}

def send_sms_notification(phone_number):

    import urllib.parse
    import requests

    try:
        # Generate a 6-digit OTP
        import random

        otp = random.randint(1000, 9999)

        message = f"Your Uwezo desktop login OTP code is {otp}."

        # Prepare the URL for the SMS API request
        url = f"https://mortarbulksms.online/apisend_uwezo.php?number={urllib.parse.quote(phone_number)}&name={urllib.parse.quote(message)}"

        # Set headers for the API request
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': 'Bearer 68o3IgTdNwAvm0BBGDVeklrdUoJKXDIzRWRpYzRVIP5MKr4CPkpfZJAjc38He1lDtDTGXIJy6BwLkO8x'
        }

        # Send the GET request to the SMS API
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an HTTPError for bad responses
        
        return otp
    except requests.exceptions.RequestException as e:
        frappe.throw(f"Error sending SMS: {e}")
    except Exception as error:
        frappe.throw(f"An unexpected error occurred: {error}")

def send_sms_notificationw(phone_number,am):

    import urllib.parse
    import requests

    try:
        # Generate a 6-digit OTP
        import random

        otp = random.randint(1000, 9999)

        message = f"Your Withdraw Code for Shs {am} is  {otp}."

        # Prepare the URL for the SMS API request
        url = f"https://mortarbulksms.online/apisend_uwezo.php?number={urllib.parse.quote(phone_number)}&name={urllib.parse.quote(message)}"

        # Set headers for the API request
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': 'Bearer 68o3IgTdNwAvm0BBGDVeklrdUoJKXDIzRWRpYzRVIP5MKr4CPkpfZJAjc38He1lDtDTGXIJy6BwLkO8x'
        }

        # Send the GET request to the SMS API
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an HTTPError for bad responses
        
        return otp
    except requests.exceptions.RequestException as e:
        frappe.throw(f"Error sending SMS: {e}")
    except Exception as error:
        frappe.throw(f"An unexpected error occurred: {error}")

  
@frappe.whitelist(allow_guest=True)
def create_apply_charge_transaction(savings_account_id, method=None):
    import frappe
    from frappe.utils import now_datetime
    from datetime import datetime

    # Fetch charge info
    charge = frappe.db.get_value("Charge", {"name": "CH-3508904"}, ["name", "amount", "account", "charge_name"], as_dict=True)
    if not charge:
        frappe.throw("Charge CH-3508904 not found")

    # Fetch savings account info
    savings_account = frappe.db.get_value(
        "Savings Account",
        {"name": savings_account_id},
        ["name", "branch", "company", "saving_product"],
        as_dict=True
    )
    if not savings_account:
        frappe.throw("Savings Account not found")

    transaction_type = "Activation charge"
    posting_date = now_datetime()
    amount_disbursed = charge.amount

    # 1️⃣ Insert into `tabSaving Transaction`
    charge_transaction_name = frappe.generate_hash(length=10)
    frappe.db.sql("""
        INSERT INTO `tabSaving Transaction`
        (name, creation, modified, owner, docstatus, account, transaction_type, posting_date,
         branch, amount, reference, charge, description, is_parent, allow_charges,
         allow_overdraw, charge_type, apply_charge, account_branch)
        VALUES (%s, NOW(), NOW(), 'Administrator', 1, %s, %s, %s, %s, %s, %s, %s, %s,
                1, 0, 1, 'Savings Account', %s, %s)
    """, (
        charge_transaction_name,
        savings_account_id,
        transaction_type,
        posting_date,
        savings_account.branch,
        amount_disbursed,
        f'apply-charge-{savings_account_id}',
        charge.name,
        f'Apply charge {charge.charge_name}: {amount_disbursed}',
        charge.name,
        savings_account.branch
    ))

    # 2️⃣ GL Entry 1 - Income side
    coa_account_name3 = frappe.db.get_value("Account", {"name": charge.account}, "name")

    gl_entry1_name = frappe.generate_hash(length=10)
    frappe.db.sql("""
        INSERT INTO `tabGeneral Ledger II`
        (name, creation, modified, owner, docstatus, account, label_for_report, transaction_type,
         transaction_type_name, posting_date, company, branch, amount, credit, debit, main_parent,
         sub_parent, category, savings_account)
        VALUES (%s, NOW(), NOW(), 'Administrator', 1, %s, %s, 1, %s, %s, %s, %s, %s, %s, 0,
                'Income', 'Income', %s, %s)
    """, (
        gl_entry1_name,
        charge.account,
        coa_account_name3,
        "Savings Activation Charge",
        datetime.now().date(),
        savings_account.company,
        savings_account.branch,
        amount_disbursed,
        amount_disbursed,
        coa_account_name3,
        savings_account_id
    ))

    # 3️⃣ GL Entry 2 - Customer Balance (Liabilities)
    customer_balance_account = frappe.db.get_value(
        "Saving Product",
        {"name": savings_account.saving_product},
        "customer_balance_account"
    )
    coa_account_name2 = frappe.db.get_value("Account", {"name": customer_balance_account}, "name")

    gl_entry2_name = frappe.generate_hash(length=10)
    frappe.db.sql("""
        INSERT INTO `tabGeneral Ledger II`
        (name, creation, modified, owner, docstatus, account, label_for_report, transaction_type,
         transaction_type_name, posting_date, company, branch, amount, credit, debit, main_parent,
         sub_parent, category, savings_account)
        VALUES (%s, NOW(), NOW(), 'Administrator', 1, %s, %s, 1, %s, %s, %s, %s, %s, 0, %s,
                'Liabilities', 'Balances On Customer Account', %s, %s)
    """, (
        gl_entry2_name,
        customer_balance_account,
        coa_account_name2,
        "Savings Activation Charge",
        datetime.now().date(),
        savings_account.company,
        savings_account.branch,
        amount_disbursed,
        amount_disbursed,
        coa_account_name2,
        savings_account_id
    ))

    # 4️⃣ Link transaction back to Savings Account
    frappe.db.sql("""
        UPDATE `tabSavings Account`
        SET status = %s, modified = NOW()
        WHERE name = %s
    """, ("Active", savings_account_id))

    frappe.db.commit()

    return amount_disbursed


@frappe.whitelist(allow_guest=True)
def create_apply_charge_transaction_monthly(mnth):
    import frappe
    from frappe.utils import now_datetime
    from datetime import datetime
    import calendar
    month_number = list(calendar.month_name).index(mnth) 
    today = datetime.now() 
    last_day = calendar.monthrange(today.year, month_number)[1] 
    last_datetime = datetime(today.year, month_number, last_day, 23, 0, 0)
  

    savings_accounts = frappe.db.sql("""
        SELECT 
            sa.name AS savings_account_id,
            sa.branch,
            sa.company,
            sa.saving_product,
            sp.monthly_fees AS monthly_fee,
            sp.monthly_fees_account AS income_account
        FROM `tabSavings Account` sa
        JOIN `tabSaving Product` sp ON sa.saving_product = sp.name
        WHERE sa.status <> 'Inactive'
            AND sp.monthly_fees > 0
            AND sa.creation <= %s
    """, (last_datetime,), as_dict=True)

    if not savings_accounts:
        frappe.msgprint("No inactive savings accounts found for monthly charge.")
        return []

    processed_accounts = []

    for acc in savings_accounts:
        savings_account_id = acc.savings_account_id
        branch = acc.branch
        company = acc.company
        monthly_fee = acc.monthly_fee
        income_account = acc.income_account

        if not monthly_fee or not income_account:
            continue

        transaction_type =  f'Monthly Charge-{mnth}'
        posting_date = now_datetime()
        amount_disbursed = monthly_fee

        charge_transaction_name = frappe.generate_hash(length=10)
        frappe.db.sql("""
            INSERT INTO `tabSaving Transaction`
            (name, creation, modified, owner, docstatus, account, transaction_type, posting_date,
            branch, amount, reference, charge, description, is_parent, allow_charges,
            allow_overdraw, charge_type, apply_charge, account_branch)
            VALUES (%s, %s, NOW(), 'Administrator', 1, %s, %s, %s, %s, %s, %s, %s, %s,
                    1, 0, 1, 'Savings Account', %s, %s)
        """, (
          
            charge_transaction_name,
            last_datetime,
            savings_account_id,
            transaction_type,
            posting_date,
            branch,
            amount_disbursed,
            f'Monthly Charge-{mnth}',
            income_account,
            f'Monthly Charge-{mnth}',
            income_account,
            branch
        ))


        coa_account_name_income = frappe.db.get_value("Account", {"name": income_account}, "name")

        gl_entry1_name = frappe.generate_hash(length=10)
        frappe.db.sql("""
            INSERT INTO `tabGeneral Ledger II`
            (name, creation, modified, owner, docstatus, account, label_for_report, transaction_type,
             transaction_type_name, posting_date, company, branch, amount, credit, debit, main_parent,
             sub_parent, category, savings_account)
            VALUES (%s, %s, NOW(), 'Administrator', 1, %s, %s, 1, %s, %s, %s, %s, %s, %s, 0,
                    'Income', 'Income', %s, %s)
        """, (
            gl_entry1_name,
            last_datetime,
            income_account,
            coa_account_name_income,
            "Monthly Maintenance Fee",
            datetime.now().date(),
            company,
            branch,
            amount_disbursed,
            amount_disbursed,
            coa_account_name_income,
            savings_account_id
        ))

        customer_balance_account = frappe.db.get_value(
            "Saving Product",
            {"name": acc.saving_product},
            "customer_balance_account"
        )
        coa_account_name_liability = frappe.db.get_value("Account", {"name": customer_balance_account}, "name")

        gl_entry2_name = frappe.generate_hash(length=10)
        frappe.db.sql("""
            INSERT INTO `tabGeneral Ledger II`
            (name, creation, modified, owner, docstatus, account, label_for_report, transaction_type,
             transaction_type_name, posting_date, company, branch, amount, credit, debit, main_parent,
             sub_parent, category, savings_account)
            VALUES (%s, %s, NOW(), 'Administrator', 1, %s, %s, 1, %s, %s, %s, %s, %s, 0, %s,
                    'Liabilities', 'Balances On Customer Account', %s, %s)
        """, (
            gl_entry2_name,
            last_datetime,
            customer_balance_account,
            coa_account_name_liability,
            "Monthly Maintenance Fee",
            datetime.now().date(),
            company,
            branch,
            amount_disbursed,
            amount_disbursed,
            coa_account_name_liability,
            savings_account_id
        ))

        frappe.db.commit()
        processed_accounts.append(savings_account_id)

    frappe.msgprint(f"Monthly maintenance fee applied to {len(processed_accounts)} savings accounts successfully.")

    # Return all processed account names
    return processed_accounts

@frappe.whitelist(allow_guest=True)
def runllalldata():
    if not frappe.has_permission("MFIS Charge Admin Role"):
        frappe.throw("Insufficient permissions to start this job.")

    frappe.enqueue(
        'mfis.clients.create_apply_charge_transaction_monthly',
        queue='long',
        timeout=1500, # 25 minutes
        mnth="October",
        job_name=f"monthly_charge_task_October" # Add a unique name for tracking
    )

    return f"Monthly charge job for October  successfully queued."

@frappe.whitelist(allow_guest=True)
def runllalldata_monthly():
    if not frappe.has_permission("MFIS Charge Admin Role"):
        frappe.throw("Insufficient permissions to start this job.")

    month_name = datetime.now().strftime("%B")
    today = datetime.today()
    last_day = calendar.monthrange(today.year, today.month)[1]

    if today.day == last_day:
        frappe.enqueue(
            'mfis.clients.create_apply_charge_transaction_monthly',
            queue='long',
            timeout=1500,
            mnth=month_name,
            job_name=f"monthly_charge_task_{today.strftime('%Y_%m')}"
        )
        return f"✅ Monthly charge job for {month_name} successfully queued."
    else:
        return f"⏭️ Today ({today.strftime('%Y-%m-%d')}) is not the last day of the month. No job queued."

@frappe.whitelist(allow_guest=True)
def get_loan_disbursement_date(ref_no):
    """
    Fetch disbursement date for a given loan reference from Loan Disbursement doctype.
    Checks both 'loan' and 'name' fields for match.
    """
    if not ref_no:
        return {"error": "Missing loan reference number"}

    # Try by 'loan' field first
    result = frappe.db.sql("""
        SELECT disbursement_date, name 
        FROM `tabLoan Disbursement`
        WHERE loan = %s
        LIMIT 1
    """, (ref_no,), as_dict=True)

    # If not found, try matching by record name
    if not result:
        result = frappe.db.sql("""
            SELECT disbursement_date, name 
            FROM `tabLoan Disbursement`
            WHERE name = %s
            LIMIT 1
        """, (ref_no,), as_dict=True)

    if result:
        return {
            "disbursement_date": result[0].get("disbursement_date"),
            "disbursement_name": result[0].get("name")
        }
    else:
        return {"error": f"No disbursement record found for loan {ref_no}"}

def send_sms_notification2(phone_number):

    import urllib.parse
    import requests

    try:
        # Generate a 6-digit OTP
        import random

        otp = random.randint(1000, 9999)
        phone_number_clean = urllib.parse.quote(phone_number.replace("-", ""))
        message = f"Your Uwezo Agent App login OTP code is {otp}."

        send_sms(message=message,phone=phone_number_clean)


        return otp
    except requests.exceptions.RequestException as e:
        frappe.throw(f"Error sending SMS: {e}")
    except Exception as error:
        frappe.throw(f"An unexpected error occurred: {error}")


@frappe.whitelist(allow_guest=True)
def create_deposit_transaction(owner: str = None, account: str = None, amount: float = None):
    try:
        if owner is None or account is None or amount is None:
            raise ValueError("Owner, account, and amount are required")

        # Generating current timestamp
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        name = f"transaction_{current_time}"
        dn=f"Deposit by {owner}"
        # Define the SQL insert statement
        sql = f"""INSERT INTO `tabSaving Transaction` 
                  (name, creation, modified, deposited_by, docstatus, idx, account, amount, credit, debit, balance, transaction_type, transaction_type_name, description)
                  VALUES ('{name}', '{current_time}', '{current_time}', '{owner}', 1, 1, '{account}', {amount}, {amount}, 0.00, {amount}, 1, '{dn}', '{dn}');"""

        # Execute the SQL statement
        frappe.db.sql(sql)

        # Commit the transaction
        frappe.db.commit()

        return "Transaction created successfully"
    except Exception as e:
        return f"Error: {str(e)}"

@frappe.whitelist(allow_guest=True)
def create_device(device_id: str = None, owner: str = None, branch: str = None, user: str = None):
    try:
        if device_id is None or owner is None or branch is None:
            raise ValueError("Device ID, owner, and branch are required")

        # Check if the device already exists to avoid duplicates
        existing_device = frappe.db.exists('Device', {'device_id': device_id, 'branch': branch})
        if existing_device:
            return {"message": "Device already exists"}

        # Generating current timestamp
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        name = f"device_{device_id}_{current_time}"

        # Define the SQL insert statement using parameterized queries
        sql = """INSERT INTO `tabDevice` 
                 (name, creation, modified, owner, docstatus, idx, device_id, allowed, branch, active, user)
                 VALUES (%s, %s, %s, %s, 1, 1, %s, 1, %s, 1, %s);"""

        # Execute the SQL statement with parameters
        frappe.db.sql(sql, (name, current_time, current_time, owner, device_id, branch, user))

        # Commit the transaction
        frappe.db.commit()

        return {"message": "Device created successfully"}
    except Exception as e:
        return {"error": str(e)}





@frappe.whitelist(allow_guest=True)
def create_loan_transaction(owner: str = None, loan: str = None, amount: float = None, transaction_type: str = None):
    try:
        if owner is None or loan is None or amount is None or transaction_type is None:
            raise ValueError("Owner, loan, amount, and transaction_type are required")

        # Generating current timestamp
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        dn="Loan Deposit"
        # Define the SQL insert statement
        sql = f"""INSERT INTO `tabLoan Transaction2` 
                  (name, creation, modified, owner, docstatus, idx, loan, transaction_type, amount, credit, debit, 
                  principal_repaid_derived, principal_recovered, interest_repaid_derived, interest_recovered, 
                  fees_repaid_derived, fees_recovered, penalties_repaid_derived, penalties_recovered, 
                  reversed, reversible, created_on, status)
                  VALUES ('transaction_{current_time}', '{current_time}', '{current_time}', '{owner}', 0, 1, '{loan}', 
                  '{dn}', {amount}, 0.00, {amount}, 0.000000000, 0.000000000, 0.000000000, 0.000000000, 
                  0.000000000, 0.000000000, 0.000000000, 0.000000000, 0, 0, NULL, 'Pending');"""

        # Execute the SQL statement
        frappe.db.sql(sql)

        # Commit the transaction
        frappe.db.commit()

        return "Loan Transaction created successfully"
    except Exception as e:
        return f"Error: {str(e)}"

#########################################################################################################################################################
import frappe
from datetime import datetime, timedelta
from datetime import date
import frappe
@frappe.whitelist()
def process_loan_payment(loan_id, payment_amount, user, docer=None, is_saving=0):
    payment_amount = float(payment_amount)
    remaining_amount = payment_amount
    # Fetch loan and loan product details
    loan = frappe.get_doc("Loan Application Plus", loan_id)
    loanp = frappe.get_doc("Loan Product", loan.loan_type)
    today = datetime.today() 
    isskippale = 0
    if today.weekday() == 5 or today.weekday() == 6:
        isskippale = 1

    # Fetch arrears, daily interest, and penalties
 
    arrears = get_arrears(loan_id)
    
    daily_interest = get_daily_interest(loan_id)
    daily_interest2 = daily_interest
   

    # arrears_payment, penalty_payment, daily_interest_payment = 0, 0, 0
    arrears_payment, penalty_payment, daily_interest_payment = 0, 0, 0
    

    # Apply payment to arrears first
    if remaining_amount > 0:
        arrears_payment = min(remaining_amount, arrears)
        if arrears_payment > payment_amount:
            arrears_payment = payment_amount
        if arrears_payment > 0:
            frappe.db.sql("""
            SET SQL_SAFE_UPDATES = 0;
        
            """, {"checked": 1, "name": docer.name})
            frappe.db.commit()

            frappe.db.sql("""
                UPDATE `tabLoan Repayment`
                SET ispaypen2 = %(checked)s, penaltyamount = %(penalty_amount)s
                WHERE name = %(name)s
                """, 
                {"checked": arrears_payment, "penalty_amount": 0, "name": docer.name}
            )

            frappe.db.commit()
            frappe.db.sql("""
                UPDATE `tabLoan Transaction2`
                SET ispaypen2 = %(checked)s, penaltyamount = %(penalty_amount)s
                WHERE name = %(name)s
                """, 
                {"checked": arrears_payment, "penalty_amount": 0, "name": docer.name}
            )

            frappe.db.commit()



          

       
        remaining_amount -= arrears_payment

    # Apply payment to penalties next
    if remaining_amount > 0:
        penalty_payment =  get_penalties(loan_id)
        if penalty_payment > 0:
            frappe.db.sql("""
            SET SQL_SAFE_UPDATES = 0;
            
            """, {"checked": 1, "name": docer.name})
            frappe.db.commit()



            frappe.db.sql("""
                UPDATE `tabLoan Repayment`
                SET ispaypen = %(checked)s, penaltyamount = %(penalty_amount)s
                WHERE name = %(name)s
                """, 
                {"checked": 1, "penalty_amount": penalty_payment, "name": docer.name}
            )

            frappe.db.commit()


            frappe.db.sql("""
                UPDATE `tabLoan Transaction2`
                SET ispaypen = %(checked)s, penaltyamount = %(penalty_amount)s
                WHERE name = %(name)s
                """, 
                {"checked": 1, "penalty_amount": penalty_payment, "name": docer.name}
            )

            frappe.db.commit()
        
        
        if penalty_payment > payment_amount:
            penalty_payment = payment_amount
       
        remaining_amount -= penalty_payment

     
    if isskippale == 0:
        # Apply payment to daily interest next
        if remaining_amount > 0:
            if daily_interest > payment_amount:
                daily_interest_payment = payment_amount
            else:
                daily_interest_payment = daily_interest
            remaining_amount -= daily_interest_payment

    
    # Create journal entries for arrears, penalties, and daily interest
    create_journal_entry(loanp, loan, arrears_payment, penalty_payment, daily_interest_payment, payment_amount, user, docer,daily_interest2)
  
    # Apply remaining amount to principal if any
    if remaining_amount > 0:
        if is_saving == 1:
            pay_principal2(loan_id, remaining_amount,payment_amount, user)
        else:
            pay_principal(loan_id, remaining_amount,payment_amount, user)
    
        
@frappe.whitelist()
def get_arrears(loan_id):
    current_date = date.today()
    loan = frappe.get_doc("Loan Application Plus", loan_id)
    loanp = frappe.get_doc("Loan Product", loan.loan_type)
     # Get all entries created between start and end of the day
    repayment_today2 = frappe.get_all(
                    "General Ledger II",
                    filters={
                        "account": loanp.interest_receivables_account,
                        "loan" : loan.name
                      
                    },
                    fields=["name", "credit","debit"]
    )

    return sum(((p['debit'] - p['credit']) ) for p in repayment_today2) or 0
 

def fetch_skipped_days_and_dates():
    result = frappe.get_all('No Working Days2', fields=['skipped_type', 'day', 'Date'], filters={'parenttype': 'Calender Settings'})
    skipped_days = [record.day for record in result if record.skipped_type == 'Day']
    skipped_dates = [record.Date for record in result if record.skipped_type == 'Date']
    return skipped_days, skipped_dates

def calculate_constant_due_amount(loan_date, loan_amount, loan_interest, loan_term, grace_period, repayment_type):
    loan_term = int(loan_term)
    grace_period = int(grace_period)

    loan_timestamp = datetime.strptime(loan_date.strftime('%Y-%m-%d'), "%Y-%m-%d")
    interest_rate_per_day = (loan_interest / 100) / 365
    daily_interest = loan_amount * interest_rate_per_day
    skipped_days, skipped_dates = fetch_skipped_days_and_dates()
    grace_period_interest = grace_period * daily_interest

    accumulated_interest = 0
    valid_repayment_days = 0

    for i in range(grace_period, loan_term):
        repayment_date = loan_timestamp + timedelta(days=i)
        formatted_date = repayment_date.strftime("%Y-%m-%d")
        if formatted_date in skipped_dates or repayment_date.strftime('%A') in skipped_days:
            accumulated_interest += daily_interest
            continue
        valid_repayment_days += 1

    total_interest = ((loan_term - grace_period) * daily_interest) + grace_period_interest
    constant_due_amount = (loan_amount + total_interest) / valid_repayment_days if valid_repayment_days > 0 else 0
    return constant_due_amount
@frappe.whitelist()
def get_penalties(loan_id):
    # Fetch all penalties for the given loan
    penalties = frappe.db.get_all("Loan Penalty II", filters={"loan": loan_id}, fields=["amount"])
    
    # If no penalties, return 0
    if not penalties:
        return 0
    
    # Get loan and loan product details
    loan = frappe.get_doc("Loan Application Plus", loan_id)
    loanp = frappe.get_doc("Loan Product", loan.loan_type)
    
    # Fetch repayments that go towards the loan penalty account
    repayment_today2 = frappe.get_all(
        "General Ledger II",
        filters={
            "category": loanp.loan_penalty_account,
            "loan": loan.name
        },
        fields=["credit"]
    )
    
    # Get total waived penalties
    vbar = get_total_loan_waived_penalty(loan_id)
    total_waived_penalties = vbar.get('total_penalties', 0)
    
    # Calculate total penalties
    total_penalties = sum([p['amount'] for p in penalties])
    
    # Calculate the amount already paid towards penalties
    paid_amount = sum([repayment['credit'] for repayment in repayment_today2]) if repayment_today2 else 0
    
    # Calculate remaining penalties after considering waived and paid amounts
    remaining_penalties = total_penalties - (total_waived_penalties + paid_amount)
    
    # Ensure no negative penalties are returned
    return max(remaining_penalties, 0)


@frappe.whitelist()
def get_receivablescashflow():
    penalties = frappe.db.get_all("General Ledger II", filters={"main_parent": "Assets", "sub_parent": "Receivable"}, fields=["debit"])
    return sum((p['debit'] ) for p in penalties) or 0
    
@frappe.whitelist()
def get_sharedcapital(br):
    branch = frappe.get_doc("Branch", br)
    accounter = frappe.get_doc("Account", branch.sharedcapital)
    penalties = frappe.db.get_all("General Ledger II", filters={"category": accounter.name}, fields=["debit","credit"])
    return sum((p['credit']) for p in penalties) or 0



from frappe.utils import now
from frappe.utils import get_datetime
import re  
import sqlite3
import sqlite3

import mysql.connector
from mysql.connector import Error

#####Desktop Ui Api###########################################################################################################
@frappe.whitelist(allow_guest=True)
def insert_client_data(database, branch, first_name, middle_name, last_name, mobile, date_of_birth,
                       profession, district, divisions, sub_county, parish, village,
                       district2, divisions2, subcounty2, parish2, village2, company, own):
    # Step 1: Fetch all existing names for the branch
    if branch == "Kikuubo":
        branch = "10"
    else:
        branch = "20"

    query = "SELECT name FROM `tabClient` WHERE name LIKE %s"
    branch_prefix = f"CL-{branch}-%"
    existing_names = frappe.db.sql(query, (branch_prefix,), as_list=True)

    # Step 2: Extract numeric parts from existing names and find the next position
    existing_numbers = []
    for row in existing_names:
        name = row[0]
        try:
            # Extract the numeric part after the last hyphen
            numeric_part = int(name.split('-')[-1])
            existing_numbers.append(numeric_part)
        except (ValueError, IndexError):
            # Skip invalid entries (shouldn't happen if naming conventions are followed)
            continue

    next_position = max(existing_numbers, default=0) + 1  # Get the next available position
    new_id = f"CL-{branch}-{next_position}"
    full_name = f"{first_name} {middle_name if middle_name else ''} {last_name}".strip()

    # Step 3: Prepare the insert query using parameterized queries
    insert_query = """
        INSERT INTO `tabClient` 
        (name, branch, first_name, middle_name, last_name, mobile, date_of_birth, profession, district, divisions, sub_county, parish, village, 
        district2, divisions2, subcounty2, parish2, village2, company, title, creation, full_name, owner)
        VALUES 
        (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 
        %s, %s, %s, %s, %s, %s, %s, NOW(), %s, %s)
    """

    # Step 4: Define the values for the insert query
    values = (
        new_id, branch, first_name, middle_name, last_name, mobile, date_of_birth, profession, district, divisions,
        sub_county, parish, village, district2, divisions2, subcounty2, parish2, village2, "UWEZO FINANCIAL SERVICES LTD", company, full_name, own
    )

    # Step 5: Execute the query and commit the transaction
    try:
        frappe.db.sql(insert_query, values)
        frappe.db.commit()
        return {"status": "success", "new_id": new_id}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@frappe.whitelist(allow_guest=True)
def insert_savings_account(branch, branch_name, company, client_type, client, client_name, phone_number,
                           email, saving_product_name, account_number, opening_balance=0, overdraft_limit=0, 
                           overdraft_interest_rate=0, allow_overdraft=False, allow_sms=False, owner=None):
    """
    Inserts a new savings account into the `tabSavings Account` table.
    """

    # Generate a unique name for the account
    account_prefix = f"SA-{branch[:3].upper()}-"
    query = "SELECT name FROM `tabSavings Account` WHERE name LIKE %s"
    existing_names = frappe.db.sql(query, (account_prefix + "%",), as_list=True)

    # Extract existing numbers and determine the next ID
    existing_numbers = []
    for row in existing_names:
        try:
            numeric_part = int(row[0].split('-')[-1])
            existing_numbers.append(numeric_part)
        except (ValueError, IndexError):
            continue

    next_position = max(existing_numbers, default=0) + 1
    new_account_id = f"{account_prefix}{next_position}"

    # SQL Insert query for `tabSavings Account`
    insert_query = """
        INSERT INTO `tabSavings Account` 
        (name, branch, branch_name, company, client_type, client, client_name, phone_number, email,
         saving_product_name, account_number, opening_balance, overdraft_limit, overdraft_interest_rate,
         allow_overdraft, allow_sms, owner, creation, modified, docstatus, idx)
        VALUES 
        (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW(), NOW(), 0, 0)
    """
    values = (
        new_account_id, branch, branch_name, company, client_type, client, client_name, phone_number, email,
        saving_product_name, account_number, opening_balance, overdraft_limit, overdraft_interest_rate,
        allow_overdraft, allow_sms, owner
    )

    try:
        frappe.db.sql(insert_query, values)
        frappe.db.commit()
        return {"status": "success", "new_account_id": new_account_id}
    except Exception as e:
        frappe.db.rollback()
        return {"status": "error", "message": str(e)}
from datetime import datetime

@frappe.whitelist(allow_guest=True)
def calculate_total_outstanding():
    import frappe
    try:
        savings_accounts = frappe.get_all("Savings Account", fields=["name"])
        for account in savings_accounts:
            savings_account = frappe.get_doc("Savings Account", account["name"])
            total_outstanding = get_total_outstanding(savings_account.name)
            print(f"Account: {savings_account.name}, Total Outstanding: {total_outstanding}")
    except Exception as e:
        frappe.log_error(frappe.get_traceback(), "Calculate Total Outstanding Error")
        print(f"An error occurred: {str(e)}")


@frappe.whitelist(allow_guest=True)
def insert_float_sell(CreditAccount, DebitAccount, TotalAmount, FullName, AccountNumber, DepositedBy, Company, Branch, status="Active", owner=None):
    """
    Inserts a new float sell record into the `tabFloat Sell` table.
    """
    # Generate a unique name for the float sell
    name_prefix = "FS-"
    query = "SELECT name FROM `tabFloat Sell` WHERE name LIKE %s"
    existing_names = frappe.db.sql(query, (name_prefix + "%",), as_list=True)

    # Extract existing numbers and determine the next ID
    existing_numbers = []
    for row in existing_names:
        try:
            numeric_part = int(row[0].split('-')[-1])
            existing_numbers.append(numeric_part)
        except (ValueError, IndexError):
            continue

    next_position = max(existing_numbers, default=0) + 1
    new_float_sell_id = f"{name_prefix}{next_position}"

    # Generate today's date
    today_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # SQL Insert query for `tabFloat Sell`
    insert_query = """
        INSERT INTO `tabFloat Sell`
        (name, from_account, account_name, date, status, amount, company, created_by, posting_date, owner, creation, modified, docstatus, idx)
        VALUES
        (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 0, 0)
    """
    values = (
        new_float_sell_id, CreditAccount, FullName, today_date, status, TotalAmount,
        Company, DepositedBy, today_date, owner, today_date, today_date
    )

    try:
        frappe.db.sql(insert_query, values)
        frappe.db.commit()
        return {"status": "success", "new_float_sell_id": new_float_sell_id}
    except Exception as e:
        frappe.db.rollback()
        return {"status": "error", "message": str(e)}

@frappe.whitelist(allow_guest=True)
def reverse_savings_transactions(docname):
    frappe.db.sql("""
        UPDATE `tabSaving Transaction`
        SET flagged = 1
        WHERE reference = %s
    """, (docname,))

    frappe.db.commit()

    return True


@frappe.whitelist(allow_guest=True)
def insert_float_purchase(CreditAccount, DebitAccount, TotalAmount, FullName, AccountNumber, DepositedBy, Company, Branch, status="Active", owner=None):
    """
    Inserts a new float sell record into the `tabFloat Sell` table.
    """
    # Generate a unique name for the float sell
    name_prefix = "FS-"
    query = "SELECT name FROM `tabFloat Purchase` WHERE name LIKE %s"
    existing_names = frappe.db.sql(query, (name_prefix + "%",), as_list=True)

    # Extract existing numbers and determine the next ID
    existing_numbers = []
    for row in existing_names:
        try:
            numeric_part = int(row[0].split('-')[-1])
            existing_numbers.append(numeric_part)
        except (ValueError, IndexError):
            continue

    next_position = max(existing_numbers, default=0) + 1
    new_float_sell_id = f"{name_prefix}{next_position}"

    # Generate today's date
    today_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # SQL Insert query for `tabFloat Sell`
    insert_query = """
        INSERT INTO `tabFloat Purchase`
        (name, from_account, account_name, date, status, amount, company, created_by, posting_date, owner, creation, modified, docstatus, idx)
        VALUES
        (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 0, 0)
    """
    values = (
        new_float_sell_id, CreditAccount, FullName, today_date, status, TotalAmount,
        Company, DepositedBy, today_date, owner, today_date, today_date
    )

    try:
        frappe.db.sql(insert_query, values)
        frappe.db.commit()
        return {"status": "success", "new_float_sell_id": new_float_sell_id}
    except Exception as e:
        frappe.db.rollback()
        return {"status": "error", "message": str(e)}

import frappe
from frappe.utils import now_datetime
import time

last_run_time = None

import frappe
import requests
import urllib.parse
from frappe.utils import now_datetime

import frappe
import requests
import urllib.parse
from frappe.utils import now_datetime
from datetime import datetime

@frappe.whitelist()
def process_pending_messages():
    settings = frappe.get_single("Message Archive Settings")
    if not settings.default_queue_enabled:
        return

    now = now_datetime()
    t = now.time()

        # Convert from_time / stop_time from string to datetime.time
    ft = datetime.strptime(str(settings.from_time), "%H:%M:%S").time() if settings.from_time else None
    st = datetime.strptime(str(settings.stop_time), "%H:%M:%S").time() if settings.stop_time else None

    # Enforce sending time window
    if ft and st:
        if ft < st and not (ft <= t <= st):
            return
        if ft >= st and not (t >= ft or t <= st):
            return

    # Mark messages that are past scheduled_at but were not sent yet as Failed
    frappe.db.sql("""
        UPDATE `tabMessage Archive`
        SET status='Failed', message_response='Missed schedule'
        WHERE status='Pending'
        AND scheduled_at <= %s
    """, now)

    # Reset future messages to Pending (optional if needed)
    frappe.db.sql("""
        UPDATE `tabMessage Archive`
        SET status='Pending'
        WHERE scheduled_at > %s
    """, now)

    # Re-enable future messages for sending in order
    frappe.db.sql("""
        UPDATE `tabMessage Archive`
        SET default_queue_enabled = 1
        WHERE status='Pending'
        AND scheduled_at > %s
    """, now)

    # Fetch future messages in order of scheduled time
    messages = frappe.get_all(
        "Message Archive",
        filters={"status": "Pending", "default_queue_enabled": 1},
        fields=["name", "mobile", "message_body", "scheduled_at"],
        order_by="scheduled_at asc"
    )

    for m in messages:
        try:
            phone = m.mobile.replace("+", "").strip()
            msg = urllib.parse.quote(m.message_body.strip())
            url = f"https://mortarbulksms.online/apisend_uwezo2.php?number={phone}&name={msg}"
            r = requests.get(url, timeout=15)
            r.raise_for_status()

            frappe.db.set_value(
                "Message Archive", m.name,
                {"status": "Sent", "message_response": r.text, "recipient_count": 1}
            )

        except Exception as e:
            frappe.db.set_value(
                "Message Archive", m.name,
                {"status": "Failed", "message_response": str(e)}
            )

    frappe.db.commit()


 
@frappe.whitelist(allow_guest=True)
def insert_loan_deposit(
    CreditAccount, DebitAccount, TotalAmount, FullName, AccountNumber, DepositedBy, 
    Company, Branch, status="Active", owner=None
):
    """
    Inserts a new loan repayment record into the `tabLoan Repayment` table.
    """
    from datetime import datetime

    # Query to find the highest existing loan repayment ID
    query = "SELECT name FROM `tabLoan Repayment` ORDER BY name DESC LIMIT 1"
    existing_names = frappe.db.sql(query, as_list=True)

    # Determine the next available loan repayment ID
    next_position = 1
    if existing_names:
        try:
            next_position = int(existing_names[0][0]) + 1
        except ValueError:
            next_position = 1

    today_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    current_user = owner
    loanerd = frappe.get_doc("Loan Application Plus", {"name": DebitAccount})
    savings_accounter = frappe.get_doc("Savings Account", {"name": loanerd.clients})
    client_doc = frappe.get_doc("Client", savings_accounter.client)

    amount = float(TotalAmount)  # or int(TotalAmount) if it’s always whole numbers
    message = (
            f"Loan Payment UGX {amount:,.0f} with Agent-.Account {DebitAccount} Date: {today_date} Thnks 4 Choosing Uwezo"
    )
    send_message_to_clients_opening(recipients=client_doc.mobile,message=message)

    # SQL Insert query for `tabLoan Repayment`
    insert_query = """
        INSERT INTO `tabLoan Repayment`
        (name, created_by, loan, client_name, amount, transaction, modified_by, 
        payment_method, branch, company, docstatus, idx, creation, modified, owner)
        VALUES
        (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 1, 0, %s, %s, %s)
    """

    # Retry until a unique ID is found
    while True:
        new_repayment_id = str(next_position)
        values = (
            new_repayment_id, CreditAccount, DebitAccount, FullName, TotalAmount, 
            "Loan Repayment", current_user, "Cash", Branch, Company, 
            today_date, today_date, current_user
        )
        try:
            frappe.db.sql(insert_query, values)
            frappe.db.commit()
            return {"status": "success", "LoanRepayment": new_repayment_id}
        except Exception as e:
            if "Duplicate entry" in str(e) and "for key 'PRIMARY'" in str(e):
                # ID exists, try next
                next_position += 1
                continue
            else:
                frappe.db.rollback()
                return {"status": "error", "message": str(e)}

import frappe
from datetime import datetime

import frappe
import random
import string
from datetime import datetime

def random_hash(length=6):
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))

@frappe.whitelist(allow_guest=True)
def generate_unique_saving_id():
    while True:
        # Generate an ID in the millions range (e.g., 1000000 to 9999999)
        saving_id = random.randint(1_000_000, 9_999_999)
        
        # Check if it already exists
        exists = frappe.db.exists("Saving Transaction", {"name": saving_id})
        if not exists:
            return saving_id

# Usage
saving_id = generate_unique_saving_id()
print("Generated unique saving_id:", saving_id)

import frappe
from datetime import datetime, timedelta
@frappe.whitelist(allow_guest=True)
def get_last_transaction_amount2(account, date):
    # Extract only the date part
    date_only = date.split(" ")[0]
    date_obj = datetime.strptime(date_only, "%Y-%m-%d")
    next_day = date_obj + timedelta(days=1)

    data = frappe.db.sql("""
        SELECT owner
        FROM `tabSaving Transaction`
        WHERE account = %s
          AND creation >= %s
          AND creation < %s
        ORDER BY creation DESC
        LIMIT 1
    """, (account, date_obj, next_day), as_dict=True)

    return data[0]['owner'] if data else None

import frappe
from frappe.utils import nowdate, date_diff

@frappe.whitelist(allow_guest=True)
def get_password_reset_days_left(user):
    # Use frappe.db.get_single_value() as 'for_single' is not supported
    # Fallback to check multiple possible locations for the setting
    reset_days = frappe.db.get_single_value("System Settings", "password_reset_days") \
                 or frappe.db.get_single_value("System Settings", "reset_password_days") \
                 or frappe.db.get_single_value("Password Policy", "password_reset_days") \
                 or 0

    # Ensure reset_days is an integer for arithmetic
    try:
        reset_days = int(reset_days or 0)
    except (ValueError, TypeError):
        return None

    if reset_days == 0:
        return None

    # Determine the last password reset date (remains the same)
    last_reset = frappe.db.get_value("User", user, "last_password_reset_date") \
                 or frappe.db.get_value("User", user, "creation")

    # Calculate days passed and days remaining
    days_used = date_diff(nowdate(), last_reset)
    
    return max(reset_days - days_used, 0)


@frappe.whitelist(allow_guest=True)
def get_last_transaction_amount(account, date):
    data = frappe.db.sql("""
        SELECT amount
        FROM `tabSaving Transaction`
        WHERE account = %s AND DATE(creation) = %s
        ORDER BY creation DESC, creation DESC
        LIMIT 1
    """, (account, date), as_dict=True)

    return data[0]['amount'] if data else 0
@frappe.whitelist(allow_guest=True)
def insert_deposit(CreditAccount, DebitAccount, TotalAmount, FullName, AccountNumber, DepositedBy,
                   Company, Branch, owner=None, Saving_Product=None):

    """
    Insert Deposit with DP-XXXXXX ID, Saving Transaction, and Deposit Fees.
    Duplicate-free entries on ALL inserts.
    """

    today_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    current_user = owner

    employee = frappe.db.get_value(
        "Employee",
        {"user": current_user},
        ["name", "full_name"],
        as_dict=True
    )

    employee_id = employee.name
    employee_fullname = employee.full_name

    try:

        # ==============================================================
        # 1) DUPLICATE-FREE DEPOSIT ID
        # ==============================================================

        while True:
            deposit_id = f"DP-{random_hash(6)}"
            if not frappe.db.exists("Deposit", deposit_id):
                break

        # INSERT Deposit
        frappe.db.sql("""
            INSERT INTO `tabDeposit`
            (name, account, suba, client_name, account_branch, amount, currency, deposited_by,
             posting_date, branch, company, docstatus, idx, creation, modified, owner, modified_by)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 1, 0, %s, %s, %s, %s)
        """, (
            deposit_id, AccountNumber, DebitAccount, FullName, Branch, TotalAmount, "USD",
            DepositedBy, today_date, Branch, Company,
            today_date, today_date, current_user, current_user
        ))

        # ==============================================================
        # 2) DUPLICATE-FREE SAVING TRANSACTION ID
        # ==============================================================

        while True:
            saving_id = generate_unique_saving_id()
            if not frappe.db.exists("Saving Transaction", saving_id):
                break

        frappe.db.sql("""
            INSERT INTO `tabSaving Transaction`
            (name, account, transaction_type, client_name, account_branch, amount, reference, fees_total,
             posting_date, branch, company, docstatus, idx, creation, modified, owner, modified_by,
             transaction_type_name, description)
            VALUES (%s, %s, %s, %s, %s, %s, %s, 0, %s, %s, %s, 1, 0,
                    %s, %s, %s, %s, %s, %s)
        """, (
            str(saving_id), AccountNumber, "1", FullName, Branch, TotalAmount, deposit_id,
            today_date, Branch, Company,
            today_date, today_date, current_user, current_user, "Deposit", "Deposit"
        ))

        frappe.db.sql("""
            UPDATE `tabDeposit`
            SET savings_id = %s
            WHERE name = %s
        """, (str(saving_id), deposit_id))

        # ==============================================================
        # 3) PROCESS FEES (DUPLICATE-FREE FEE TRANSACTION IDs)
        # ==============================================================

        savings_accounter = frappe.get_doc("Savings Account", {"name": AccountNumber})
        client_doc = frappe.get_doc("Client", savings_accounter.client)
        Saving_Product = frappe.get_doc("Saving Product", {"name": savings_accounter.saving_product})

        if Saving_Product:
            for fee in Saving_Product.get("product_charges"):
                charge_name = fee.get("charge")
                charge_doc = frappe.get_doc("Charge", {"name": charge_name})

                if fee.get("branch") == savings_accounter.branch and \
                        "Deposit Fees" in charge_doc.charge_name:

                    # DUPLICATE-FREE FEE SAVING TRANSACTION ID
                    while True:
                        fee_tx_id = generate_unique_saving_id()
                        if not frappe.db.exists("Saving Transaction", fee_tx_id):
                            break

                    transaction_type_fee = frappe.get_value(
                        "Saving Transaction Type",
                        {"type_name": "Deposit Charge"}
                    )

                    frappe.db.sql("""
                        INSERT INTO `tabSaving Transaction`
                        (name, account, transaction_type, transaction_type_name, user,
                         posting_date, branch, deposit, amount, debit, client_account,
                         reference, description, is_parent, allow_charges,
                         creation, modified, owner, modified_by, docstatus, idx)
                        VALUES (%s, %s, %s, %s, %s,
                                %s, %s, %s, %s, %s, %s,
                                %s, %s, 1, 0,
                                %s, %s, %s, %s, 1, 0)
                    """, (
                        str(fee_tx_id), AccountNumber, transaction_type_fee,
                        "Deposit Fees", current_user,
                        today_date, Branch, deposit_id,
                        charge_doc.amount, charge_doc.amount, AccountNumber,
                        deposit_id, "Deposit Fees",
                        today_date, today_date, current_user, current_user
                    ))

        frappe.db.commit()

        # ==============================================================
        # ENQUEUE SMS
        # ==============================================================

        amount = float(TotalAmount)
        from_date = "2019-01-01"
        to_date = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")

        frappe.enqueue(
            "mfis.clients.send_sms_background",
            account=AccountNumber,
            from_date=from_date,
            to_date=to_date,
            account2="NULL",
            ag=employee_fullname,
            amount=amount,
            employee_id=employee_id,
            AccountNumber=AccountNumber,
            today_date=today_date,
            mobile=client_doc.mobile,
            queue="default",
            timeout=300
        )
        # send_sms_background(
        #     account=AccountNumber,
        #     from_date=from_date,
        #     to_date=to_date,
        #     account2="NULL",
        #     ag=employee_fullname,
        #     amount=amount,
        #     employee_id=employee_id,
        #     AccountNumber=AccountNumber,
        #     today_date=today_date,
        #     mobile=client_doc.mobile
        # )

        return {"status": "success", "Savings": str(saving_id)}

    except Exception as e:
        frappe.db.rollback()
        return {"status": "error", "message": str(e)}

@frappe.whitelist(allow_guest=True)
def send_sms_background(account, from_date, to_date, account2, ag, amount, employee_id, AccountNumber, today_date, mobile):

    # Step 1 — Generate report
    report_last = generate_savings_report_last(
        account=account,
        from_date=from_date,
        to_date=to_date,
        account2=account2,
        ag=ag
    )

    # Step 2 — Extract last balance and date
    last_balance = report_last.get("last_balance", 0)
    last_date = report_last.get("last_date", "")

    # Step 3 — Format balance
    last_balance_formatted = "{:,}".format(last_balance)

    # Step 4 — Build the message
    message = (
        f"Deposit UGX {amount:,.0f} with Agent.{employee_id}.Account "
        f"{AccountNumber}. Balance:{last_balance_formatted}. "
        f"Date: {today_date} Thnks 4 Choosing Uwezo"
    )

    # Step 5 — Send SMS
    send_message_to_clients_opening(
        recipients=mobile,
        message=message
    )

@frappe.whitelist(allow_guest=True)
def run_charges2(loanname=None):
    loan = frappe.get_doc("Loan Application Plus", {"name": loanname})
    # Fetch charges
    charge_app = frappe.get_doc("Charge", "CH-0011")
    charge_crb = frappe.get_doc("Charge", "CH-0019")
    amount_app = charge_app.amount
    amount_crb = charge_crb.amount
    # Adjust for specific loan product
    loan_product = frappe.get_doc("Loan Product", loan.loan_type)
    if loan_product.name == "MFI Loan":
        amount_app = 120000

    fixed_date = "2025-10-11 08:16:22"
    inserted_names = []

    transactions = [
        {
            "transaction_type_name": "Loan Application Fees",
            "amount": amount_app,
            "description": f'Loan Charge {charge_app.charge_name} for {loan.name}'
        },
        {
            "transaction_type_name": "CRB Fees",
            "amount": amount_crb,
            "description": f'Loan Charge {charge_crb.charge_name} for {loan.name}'
        }
    ]
    trx_name = 100111555542
    for trx in transactions:
        trx_name += 1
        # Get transaction type
        transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": trx['transaction_type_name']})

        # Create a doc to generate a valid Frappe name
        temp_doc = frappe.get_doc({
            'doctype': 'Saving Transaction',
            'account': loan.clients,
            'transaction_type': transaction_type,
            'posting_date': fixed_date,
            'branch': loan.branch,
            'amount': trx['amount'],
            'debit': trx['amount'],
            'client_name': loan.client_name,
            'reference': loan.name,
            'description': trx['description'],
            'is_parent': 1,
            'allow_charges': 0,
            'loan': loan.name,
        })


        # Now insert directly into MySQL using this name
        frappe.db.sql("""
            INSERT INTO `tabSaving Transaction`
            (`name`, `account`, `transaction_type`, `posting_date`, `branch`, `amount`, `debit`, `client_name`, `reference`,
             `description`, `is_parent`, `allow_charges`, `loan`, `creation`, `modified`, `owner`, `docstatus`)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'Administrator', 1)
        """, (
            trx_name, loan.clients, transaction_type, fixed_date, loan.branch, trx['amount'], trx['amount'],
            loan.client_name, loan.name, trx['description'], 1, 0, loan.name,fixed_date,fixed_date
        ))

        inserted_names.append(trx_name)

    frappe.db.commit()  # Commit changes

    return {
        "message": "Charges applied successfully",
        "transactions": inserted_names
    }

@frappe.whitelist(allow_guest=True)
def insert_loan_repayment(
    loan_id,
    repayment_amount,
    payment_method,
    client_name,
    branch,
    company,
    penalty_amount=0.0,
    status="Completed",
    transaction_reference=None,
    owner=None
):
    """
    Inserts a new loan repayment record into the `tabLoan Repayment` table.

    Args:
        loan_id (str): The ID of the loan being repaid.
        repayment_amount (float): The amount of the repayment.
        payment_method (str): The method of payment (e.g., "Cash", "Bank Transfer").
        client_name (str): The full name of the client making the repayment.
        branch (str): The branch associated with the loan repayment.
        company (str): The company associated with the loan repayment.
        penalty_amount (float, optional): Any penalty amount included in the repayment. Defaults to 0.0.
        status (str, optional): The status of the repayment (e.g., "Paid", "Pending"). Defaults to "Paid".
        transaction_reference (str, optional): A reference for the transaction. Defaults to None.
        owner (str, optional): The owner of the record. Defaults to frappe.session.user.

    Returns:
        dict: A dictionary indicating the status of the operation ("success" or "error")
              and a message (the new repayment ID on success, or an error message).
    """
    # Safely get next numeric ID using auto-increment style logic
    # We cast 'name' to UNSIGNED to ensure proper numeric sorting for MAX
    existing_names = frappe.db.sql("SELECT MAX(CAST(name AS UNSIGNED)) FROM `tabLoan Repayment`", as_list=True)
    # If no existing records, MAX will return NULL, so default to 0
    next_position = (existing_names[0][0] or 0) + 1
    # Use numeric ID as string for the 'name' field
    new_repayment_id = str(next_position)

    # Get current timestamp and user information
    today_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    today_date = datetime.now().strftime("%Y-%m-%d") # For the 'created_on' field
    current_user = owner if owner else frappe.session.user

    # Insert into tabLoan Repayment
    loan_repayment_insert_query = """
        INSERT INTO `tabLoan Repayment`
        (name, loan, amount, payment_method, status, branch, company, client_name,
         penaltyamount, created_on, transaction, docstatus, idx, creation, modified,
         owner, modified_by, created_by, old_amount, is_import, flagged)
        VALUES
        (%s, %s, %s, %s, %s, %s, %s, %s,
         %s, %s, %s, 1, 0, %s, %s,
         %s, %s, %s, 0.0, 0, 0)
    """
    loan_repayment_values = (
        new_repayment_id,
        loan_id,
        repayment_amount,
        payment_method,
        status,
        branch,
        company,
        client_name,
        penalty_amount,
        today_date,              # created_on (date only)
        transaction_reference,   # transaction
        today_datetime,          # creation
        today_datetime,          # modified
        current_user,            # owner
        current_user,            # modified_by
        current_user,            # created_by
    )

    try:
        frappe.db.sql(loan_repayment_insert_query, loan_repayment_values)
        frappe.db.commit()
        return {"status": "success", "message": new_repayment_id}
    except Exception as e:
        frappe.db.rollback()
        # Log the error for debugging purposes in Frappe logs
        frappe.log_error(message=str(e), title="Loan Repayment Insertion Error")
        return {"status": "error", "message": str(e)}


@frappe.whitelist(allow_guest=True)
def insert_loan_disbursement(
    loan, branch, payment_type, loan_fund, disbursed_amount, disbursed_by,
    company, status="Active", owner=None
):
    """
    Inserts a new loan disbursement record into the `tabLoan Disbursement` table
    using raw SQL via frappe.db.sql(), copying the numeric ID generation logic
    from the provided insert_deposit function.
    """
    try:
        current_user = owner if owner else frappe.session.user
        current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        current_date = datetime.now().strftime("%Y-%m-%d") # For disbursement_date

        # Safely get next numeric ID using auto-increment style logic,
        # copying the approach from insert_deposit for `tabLoan Disbursement`.
        existing_names = frappe.db.sql("SELECT MAX(CAST(name AS UNSIGNED)) FROM `tabLoan Disbursement`", as_list=True)
        next_position = (existing_names[0][0] or 0) + 1  # Use 0 if NULL, then add 1

        # Use numeric ID as string for the 'name' field
        new_doc_name = str(next_position)

        # Construct the SQL INSERT query with placeholders (%s)
        insert_query = """
            INSERT INTO `tabLoan Disbursement` (
                name,                  -- The generated numeric name
                loan,
                branch,
                payment_type,
                loan_fund,
                disbursement_date,
                disbursed_amount,
                disbursed_by,
                company,
                docstatus,             -- Set to 1 as per insert_deposit logic
                owner,
                creation,
                modified,
                modified_by,
                idx                    -- Explicitly setting idx as 0
            ) VALUES (
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s
            )
        """

        # Prepare the values in the exact order corresponding to the placeholders
        insert_values = (
            new_doc_name,          # The generated unique numeric name
            loan,
            branch,
            payment_type,
            loan_fund,
            current_date,          # disbursement_date (formatted as YYYY-MM-DD string)
            int(disbursed_amount), # Explicitly cast disbursed_amount to an integer
            disbursed_by,
            company,
            1,                     # docstatus: 1 for Submitted (as per insert_deposit)
            current_user,          # owner
            current_datetime,      # creation timestamp
            current_datetime,      # modified timestamp
            current_user,          # modified_by
            0                      # idx: 0 (as per insert_deposit)
        )

        # Execute the SQL query using frappe.db.sql()
        frappe.db.sql(insert_query, insert_values)

        # Commit the transaction if the query was successful
        frappe.db.commit()

        # Return the generated document name in the success message
        return {"status": "success", "message": f"Loan disbursement record '{new_doc_name}' inserted successfully via raw SQL."}

    except Exception as e:
        # Rollback the transaction if any error occurs during the insertion
        frappe.db.rollback()
        # Log the error for debugging purposes in Frappe's error logs
        frappe.log_error(f"Error inserting loan disbursement via raw SQL: {e}", "Loan Disbursement Raw SQL Error")
        # Return an error response to the caller
        return {"status": "error", "message": str(e)}


def get_next_saving_transaction_id():
    # Get max numeric name in tabSaving Transaction and increment, skipping duplicates
    max_id = frappe.db.sql("SELECT MAX(CAST(name AS UNSIGNED)) FROM `tabSaving Transaction`", as_list=True)[0][0]
    next_id = (max_id or 0) + 1

    while True:
        exists = frappe.db.exists("Saving Transaction", str(next_id))
        if not exists:
            return str(next_id)
        next_id += 1
import frappe
from datetime import datetime

@frappe.whitelist(allow_guest=True)
def insert_withdrawal(
    CreditAccount, DebitAccount, TotalAmount, FullName, AccountNumber, DepositedBy, 
    Company, Branch, status="Active", owner=None, reason=None, otp_code=None
):
    """
    Inserts a new withdrawal record into the `tabWithdraw` table and an associated 
    record into `tabSaving Transaction`, using raw SQL to bypass ORM validation errors.
    """
    # Generate next numeric name ID for Withdraw
    try:
        existing_names = frappe.db.sql(
            "SELECT MAX(CAST(name AS UNSIGNED)) FROM `tabWithdraw`", as_list=True
        )
        next_position = (existing_names[0][0] or 0) + 1
        new_withdrawal_id = str(next_position)
    except Exception as e:
        return {"status": "error", "message": f"Failed to get next withdrawal ID: {str(e)}"}

    # Generate Saving Transaction ID
    try:
        new_deposit_id = get_next_saving_transaction_id()
    except Exception as e:
        return {"status": "error", "message": f"Failed to get saving transaction ID: {str(e)}"}

    # Timestamps and user info
    today_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    current_user = owner if owner else frappe.session.user
    withdrawn_by = DepositedBy

    # Insert into tabWithdraw using SQL
    deposit_insert_query = """
        INSERT INTO `tabWithdraw`
        (name, account, old_amount, client_name, account_branch, amount, currency, user,
         posting_date, branch, company, reason, otp_code, docstatus, idx, creation, modified, owner, modified_by)
        VALUES
        (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 1, 0, %s, %s, %s, %s)
    """
    deposit_values = (
        new_withdrawal_id, AccountNumber, CreditAccount, FullName, Branch, TotalAmount, "USD", withdrawn_by,
        today_date, Branch, Company, reason, otp_code,
        today_date, today_date, current_user, current_user
    )

    try:
        frappe.db.sql(deposit_insert_query, deposit_values)
    except Exception as e:
        frappe.db.rollback()
        return {"status": "error", "message": f"Withdraw insert failed: {str(e)}"}

    # Insert into tabSaving Transaction
    savings_transaction_insert_query = """
        INSERT INTO `tabSaving Transaction`
        (name, account, transaction_type, client_name, account_branch, amount, reference, fees_total, 
         posting_date, branch, company, docstatus, idx, creation, modified, owner, modified_by, 
         transaction_type_name, description)
        VALUES
        (%s, %s, %s, %s, %s, %s, %s, 0, %s, %s, %s, 1, 0, %s, %s, %s, %s, %s, %s)
    """
    savings_values = (
        new_deposit_id, AccountNumber, "1", FullName, Branch, TotalAmount, "Withdraw Reference",
        today_date, Branch, Company, today_date, today_date, current_user, current_user, "Withdraw", "Withdraw"
    )

    try:
        frappe.db.sql(savings_transaction_insert_query, savings_values)
        frappe.db.commit()
        return {"status": "success", "message": new_deposit_id}
    except Exception as e:
        frappe.db.rollback()
        return {"status": "error", "message": f"Saving Transaction insert failed: {str(e)}"}


@frappe.whitelist(allow_guest=True)
def insert_client(
    name, creation, owner, branch, gender, status, mobile, country, email, date_of_birth,
    first_name, middle_name, last_name, full_name, type, active, district, sub_county,
    parish, village
):
    from frappe.utils import now

    today = creation or now()
    current_user = frappe.session.user
    modified_by = current_user
    full_name_final = full_name or f"{first_name} {last_name}"

    insert_query = """
        INSERT INTO `tabClient`
        (name, creation, modified, modified_by, owner, docstatus, idx,
         branch, gender, status, mobile, country, email, date_of_birth,
         first_name, middle_name, last_name, full_name, type, active,
         district, sub_county, parish, village, company, date_of_modification)
        VALUES
        (%s, %s, %s, %s, %s, 0, 0,
         %s, %s, %s, %s, %s, %s, %s,
         %s, %s, %s, %s, %s, %s,
         %s, %s, %s, %s, %s, %s)
    """

    values = (
        name, today, today, modified_by, owner,
        branch, gender, status, mobile, country, email, date_of_birth,
        first_name, middle_name, last_name, full_name_final, type, active,
        district, sub_county, parish, village,
        frappe.db.get_default("company"), today
    )

    try:
        frappe.db.sql(insert_query, values)
        frappe.db.commit()
        return {"status": "success", "client_name": name}
    except Exception as e:
        frappe.db.rollback()
        return {"status": "error", "message": str(e)}

import frappe
from frappe.utils import now
import uuid

@frappe.whitelist(allow_guest=True)
def insert_loan_application(
    clients, title, gender, first_name, last_name, middle_name, status,
    date_of_birth, mobile_contacts, client_name, account_number,
    company, branch, loan_type, loan_tenure, loan_interest, loan_interest_expected,
    grace_period_on_disbursment, collection_fees, savings_portfolio,
    payment_intervals, approved_principle, loan_fees_payment_date,
    principal, loan_purpose, disbursedon, closure_date, loan_portfolio,
    cash_collateral, amount
):
    try:
        name = str(uuid.uuid4())  # Use UUID for unique 'name'
        creation_time = now()

        insert_query = """
            INSERT INTO `tabLoan Application Plus` (
                name, creation, modified, docstatus, idx,
                clients, title, gender, first_name, last_name, middle_name,
                status, registered, date_of_birth, mobile_contacts, client_name,
                account_number, company, branch, loan_type, loan_tenure,
                loan_interest, loan_interest_expected, grace_period_on_disbursment,
                collection_fees, savings_portfolio, payment_intervals, approved_principle,
                loan_fees_payment_date, principal, loan_purpose, disbursedon,
                closure_date, loan_portfolio, cash_collateral, amount
            ) VALUES (
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s,
                %s, %s, %s,
                %s, %s, %s, %s,
                %s, %s, %s, %s,
                %s, %s, %s, %s
            )
        """

        values = (
            name, creation_time, creation_time, 0, 0,
            clients, title, gender, first_name, last_name, middle_name,
            status, 0, date_of_birth, mobile_contacts, client_name,
            account_number, company, branch, loan_type, loan_tenure,
            loan_interest, loan_interest_expected, grace_period_on_disbursment,
            collection_fees, savings_portfolio, payment_intervals, approved_principle,
            loan_fees_payment_date, principal, loan_purpose, disbursedon,
            closure_date, loan_portfolio, cash_collateral, amount
        )

        frappe.db.sql(insert_query, values)
        frappe.db.commit()

        return {
            "message": {
                "status": "success",
                "message": name
            }
        }

    except Exception as e:
        return {
            "message": {
                "status": "error",
                "message": f"Insert failed: {str(e)}"
            }
        }
import frappe
from frappe.utils import nowdate, now

import frappe
from frappe.model.naming import make_autoname



@frappe.whitelist(allow_guest=True)
def insert_payment_i2r(sql=None):
    try:
        # If raw SQL is provided and starts with 'insert', execute it
        if sql:
            sql_lower = sql.strip().lower()
            if sql_lower.startswith("insert"):
                frappe.db.sql(sql)
                frappe.db.commit()
                return {
                    "message": {
                        "status": "success",
                        "message": "Done"
                    }
                }
            else:
                return {
                    "message": {
                        "status": "error",
                        "message": "Only INSERT statements are allowed."
                    }
                }
        else:
            return {
                "message": {
                    "status": "error",
                    "message": "No SQL statement provided."
                }
            }

    except Exception as e:
        frappe.db.rollback()
        frappe.log_error(frappe.get_traceback(), "Insert Payment I2 SQL Error")
        return {
            "message": {
                "status": "error",
                "message": f"MySQL Insert failed: {e}"
            }
        }



@frappe.whitelist(allow_guest=True)
def insert_payment_ir(
    choose_payment_type, employee_name, approval_status, payment_mode,
    cost_center, expense_approver, is_paid, payment_account,
    grand_total, amount_in_words, status, company, branch, posting_date, sql=None
):
    try:
        # Convert is_paid to int
        is_paid_int = 1 if str(is_paid).lower() in ["yes", "1", "true"] else 0

        # Generate a name using Frappe's naming series
        name = make_autoname("CSH-I-.#####")

        # Safely insert with proper escaping
        sql_insert = """
            INSERT INTO `tabCash Receipt` (
                `name`, `payment_mode`, `employee_name`, `approval_status`,
                `cost_center`, `expense_approver`, `is_paid`, `payment_account`,
                `grand_total`, `amount_in_words`, `status`, `company`, `branch`, `posting_date`,
                `docstatus`, `idx`, `flagged`
            ) VALUES (%s, %s, %s, %s, %s,  %s, %s, %s, %s, %s, %s, %s, %s, %s, 0, 0, 0)
        """

        frappe.db.sql(sql_insert, (
            name, choose_payment_type, employee_name, approval_status,
            cost_center, expense_approver, is_paid_int, payment_account,
            float(grand_total), amount_in_words, status, company, branch, posting_date
        ))

        frappe.db.commit()

        return {
            "message": {
                "status": "success",
                "message": name
            }
        }

    except Exception as e:
        frappe.db.rollback()
        frappe.log_error(frappe.get_traceback(), "Payment I Insert SQL Error")
        return {
            "message": {
                "status": "error",
                "message": f"MySQL Insert failed: {e}"
            }
        }



@frappe.whitelist(allow_guest=True)
def insert_payment_i2(sql=None):
    try:
        # If raw SQL is provided and starts with 'insert', execute it
        if sql:
            sql_lower = sql.strip().lower()
            if sql_lower.startswith("insert"):
                frappe.db.sql(sql)
                frappe.db.commit()
                return {
                    "message": {
                        "status": "success",
                        "message": "Done"
                    }
                }
            else:
                return {
                    "message": {
                        "status": "error",
                        "message": "Only INSERT statements are allowed."
                    }
                }
        else:
            return {
                "message": {
                    "status": "error",
                    "message": "No SQL statement provided."
                }
            }

    except Exception as e:
        frappe.db.rollback()
        frappe.log_error(frappe.get_traceback(), "Insert Payment I2 SQL Error")
        return {
            "message": {
                "status": "error",
                "message": f"MySQL Insert failed: {e}"
            }
        }



@frappe.whitelist(allow_guest=True)
def insert_payment_i(
    choose_payment_type, employee_name, approval_status, payment_mode,
    cost_center, expense_approver, is_paid, payment_account,
    grand_total, amount_in_words, status, company, branch, posting_date, sql=None
):
    try:
        # Convert is_paid to int
        is_paid_int = 1 if str(is_paid).lower() in ["yes", "1", "true"] else 0

        # Generate a name using Frappe's naming series
        name = make_autoname("PAY-I-.#####")

        # Safely insert with proper escaping
        sql_insert = """
            INSERT INTO `tabPayment I` (
                `name`, `payment_mode`, `employee_name`, `approval_status`, `choose_payment_type`,
                `cost_center`, `expense_approver`, `is_paid`, `payment_account`,
                `grand_total`, `amount_in_words`, `status`, `company`, `branch`, `posting_date`,
                `docstatus`, `idx`, `flagged`
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 0, 0, 0)
        """

        frappe.db.sql(sql_insert, (
            name, choose_payment_type, employee_name, approval_status, payment_mode,
            cost_center, expense_approver, is_paid_int, payment_account,
            float(grand_total), amount_in_words, status, company, branch, posting_date
        ))

        frappe.db.commit()

        return {
            "message": {
                "status": "success",
                "message": name
            }
        }

    except Exception as e:
        frappe.db.rollback()
        frappe.log_error(frappe.get_traceback(), "Payment I Insert SQL Error")
        return {
            "message": {
                "status": "error",
                "message": f"MySQL Insert failed: {e}"
            }
        }



@frappe.whitelist(allow_guest=True)
def insert_savings_account(
    name, creation, owner, branch, branch_name, company, client_type, client,
    account_agent, client_name, phone_number, email, saving_product_name,
    saving_product, is_fixed, is_check, status, is_joint_account,
    account_number, external_number, opening_balance
):
    from frappe.utils import now

    today = creation or now()
    modified_by = frappe.session.user

    insert_query = """
        INSERT INTO `tabSavings Account`
        (name, creation, modified, modified_by, owner, docstatus, idx,
         branch, branch_name, company, client_type, client, account_agent,
         client_name, phone_number, email, saving_product_name, saving_product,
         total_withdrawals_derived, is_fixed, is_check, status, is_joint_account,
         available_balance_derived, account_number, external_number, opening_balance,
         balance_derived, total_deposits_derived, overdraft_derived,
         minimum_balance_for_interest_calculation)
        VALUES
        (%s, %s, %s, %s, %s, 0, 0,
         %s, %s, %s, %s, %s, %s,
         %s, %s, %s, %s, %s,
         0.0, %s, %s, %s, %s,
         0.0, %s, %s, %s,
         0.0, 0.0, 0.0,
         0.0)
    """

    values = (
        name, today, today, modified_by, owner,
        branch, branch_name, company, client_type, client, account_agent,
        client_name, phone_number, email, saving_product_name, saving_product,
        is_fixed, is_check, status, is_joint_account,
        account_number, external_number, opening_balance
    )

    try:
        frappe.db.sql(insert_query, values)
        frappe.db.commit()
        return {"status": "success", "account_name": name}
    except Exception as e:
        frappe.db.rollback()
        frappe.log_error(frappe.get_traceback(), "Insert Savings Account Failed")
        return {"status": "error", "message": str(e)}


@frappe.whitelist(allow_guest=True)
def insert_charge(account, account_branch, saving_product, charge_type, charge, charge_name,
                  currency, amount, branch, company, transaction=None, owner=None):
    from datetime import datetime

    def err(e):
        return {"status": "error", "message": str(e)}

    current_user = owner or frappe.session.user
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")

    start_id = 107252754698
    max_retries = 1000
    new_charge_id = start_id

    for _ in range(max_retries):
        exists = frappe.db.sql("""
            SELECT COUNT(*) FROM (
                SELECT name FROM `tabApply Charge` WHERE name = %s
                UNION ALL
                SELECT name FROM `tabSaving Transaction` WHERE name = %s
            ) AS combined
        """, (str(new_charge_id), str(new_charge_id)), as_list=True)

        if exists and exists[0][0] == 0:
            break
        new_charge_id += 1
    else:
        return {"status": "error", "message": f"Could not find free ID after {max_retries} attempts"}

    new_charge_id = str(new_charge_id)

    charge_insert_query = """
        INSERT INTO `tabApply Charge`
        (name, creation, modified, modified_by, owner, docstatus, idx,
         account, account_branch, saving_product, charge_type, charge, charge_name,
         currency, amount, posting_date, branch, company, transaction)
        VALUES
        (%s, %s, %s, %s, %s, 1, 0,
         %s, %s, %s, %s, %s, %s,
         %s, %s, %s, %s, %s, %s)
    """
    charge_values = (
        new_charge_id, now, now, current_user, current_user,
        account, account_branch, saving_product, charge_type, charge, charge_name,
        currency, amount, now, branch, company, transaction
    )

    saving_transaction_query = """
        INSERT INTO `tabSaving Transaction`
        (name, account, transaction_type, client_name, account_branch, amount, reference, fees_total,
         posting_date, branch, company, docstatus, idx, creation, modified, owner, modified_by,
         transaction_type_name, description)
        VALUES
        (%s, %s, %s, %s, %s, %s, %s, 0,
         %s, %s, %s, 1, 0, %s, %s, %s, %s,
         %s, %s)
    """
    saving_values = (
        new_charge_id, account, "2", saving_product, account_branch, amount, charge_name,
        now, branch, company, now, now, current_user, current_user,
        "Charge", charge_name
    )

    try:
        frappe.db.sql(charge_insert_query, charge_values)
        frappe.db.sql(saving_transaction_query, saving_values)
        frappe.db.commit()
        return {"status": "success", "message": "Charge inserted", "charge_id": new_charge_id}
    except Exception as e:
        frappe.db.rollback()
        return err(e)


@frappe.whitelist(allow_guest=True)
def insert_withdraw(CreditAccount, DebitAccount, TotalAmount, FullName, AccountNumber, DepositedBy, Company, Branch, status="Active", owner=None):
    """
    Inserts a new deposit record into the `tabDeposit` table.
    """
    # Query to find the highest existing deposit ID (numeric only)
    query = "SELECT name FROM `tabWithdraw` ORDER BY name DESC LIMIT 1"
    existing_names = frappe.db.sql(query, as_list=True)

    # Determine the next available deposit ID (integer)
    next_position = 1  # Default to 1 if no records exist
    if existing_names:
        try:
            # Extract the numeric part of the last deposit ID
            next_position = int(existing_names[0][0]) + 1
        except ValueError:
            next_position = 1  # Default to 1 if there is an issue with the ID

    # Generate the new deposit ID as an integer
    new_deposit_id = next_position

    next_position2 = 1  # Default to 1 if no records exist
    if existing_names:
        try:
            # Extract the numeric part of the last deposit ID
            next_position2 = int(existing_names[0][0]) + 1
        except ValueError:
            next_position2 = 1  # Default to 1 if there is an issue with the ID

    # Generate the new deposit ID as an integer
    new_deposit_id2 = next_position2

    # Generate today's date
    today_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # SQL Insert query for `tabDeposit`
    insert_query = """
        INSERT INTO `tabWithdraw`
        (name, account, name1, client_name, account_branch, amount, currency, modified_by, posting_date, branch, company, docstatus, idx, creation, modified, owner)
        VALUES
        (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 0, 0, %s, %s, %s)
    """
    values = (
        new_deposit_id, CreditAccount, DebitAccount, FullName, Branch, TotalAmount, "USD", DepositedBy,
        today_date, Branch, Company, today_date, today_date, owner if owner else frappe.session.user
    )

    try:
        frappe.db.sql(insert_query, values)
        frappe.db.commit()
    except Exception as e:
        frappe.db.rollback()
        return {"status": "error", "message": str(e)}


    insert_query = """
        INSERT INTO `tabSaving Transaction`
        (name, account, transaction_type, client_name, account_branch, amount, reference, fees_total, posting_date, branch, company, docstatus, idx, creation, modified, owner)
        VALUES
        (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 0, 0, %s, %s, %s)
    """
    values = (
        new_deposit_id2, CreditAccount, DebitAccount, FullName, Branch, TotalAmount, "USD", DepositedBy,
        today_date, Branch, Company, today_date, today_date, owner if owner else frappe.session.user
    )

    try:
        frappe.db.sql(insert_query, values)
        frappe.db.commit()
        return {"status": "success", "Savings": new_deposit_id2}
    except Exception as e:
        frappe.db.rollback()
        return {"status": "error", "message": str(e)}


@frappe.whitelist()
def get_daily_interest(loan_id):
    from frappe.utils import get_datetime
    current_date = date.today()
    loan = frappe.get_doc("Loan Application Plus", loan_id)
    loanp = frappe.get_doc("Loan Product", loan.loan_type)
    grace_period_on_disbursement = loan.grace_period_on_disbursment
    loanstart = frappe.get_value("Loan Disbursement", {"loan": loan_id}, "disbursement_date")
   
    if isinstance(loanstart, datetime):
        loan_date = datetime.strptime(loanstart, '%Y-%m-%d %H:%M:%S')
    else:
        loan_date = datetime.strptime(loanstart, '%Y-%m-%d %H:%M:%S')
    loan_tenure = loan.loan_tenure
    principal = loan.principal
    payment_intervals = loan.payment_intervals
    annual_interest_rate = (loan.loan_interest+loan.collection_fees)


   
    

    daily_interest = ((annual_interest_rate / 100) / 30) * principal
    if payment_intervals == "Weeks":
        daily_interest = daily_interest * 8
    elif payment_intervals == "Months":
        daily_interest = daily_interest * 30
    
    if grace_period_on_disbursement > 0:
        loan_date += timedelta(days=grace_period_on_disbursement)
            
            # Update the comparison to ensure both are datetime objects
        if current_date >= loan_date.date():

            loan_payments = frappe.get_all(
                    "Loan Repayment", 
                    filters={
                        'loan': loan.name, 
                        'created_on': current_date # Today's date
                    }, 
                    fields=['amount']
                )

                # Sum the total paid amount
            total_paid = sum(payment['amount'] for payment in loan_payments)

            start_of_day = get_datetime(f"{current_date} 00:00:00")
            end_of_day = get_datetime(f"{current_date} 23:59:59")

                # Get all entries created between start and end of the day
            repayment_today2 = frappe.get_all(
                    "General Ledger II",
                    filters={
                        "account": loanp.loan_interest_account, 
                        "creation": ["between", [start_of_day, end_of_day]],
                        "loan" : loan.name,
                        "isar":0
                    },
                    fields=["name", "credit"]
                )

            paid_amount = sum([repayment['credit'] for repayment in repayment_today2])

    
            repayment_today = frappe.get_all("Loan Repayment", 
                                                filters={
                                                    "loan": loan.name, 
                                                    "created_on": current_date
                                                },
                                                fields=["name", "amount"])
            repayment_amount = sum([repayment['amount'] for repayment in repayment_today])
          
            
            
            if repayment_amount >= daily_interest:

                if paid_amount >= daily_interest:
                    return 0 
                else:
                    return daily_interest - paid_amount


                return 0
            else:

                return daily_interest - paid_amount
        else:
            return 0
    else:

            # Update the comparison to ensure both are datetime objects
            from frappe.utils import nowdate, get_datetime
            if current_date >= loan_date.date():
        
                start_of_day = get_datetime(f"{current_date} 00:00:00")
                end_of_day = get_datetime(f"{current_date} 23:59:59")

                # Get all entries created between start and end of the day
                repayment_today2 = frappe.get_all(
                    "General Ledger II",
                    filters={
                        "account": loanp.loan_interest_account, 
                        "creation": ["between", [start_of_day, end_of_day]],
                        "loan" : loan.name,
                        "isar": 0
                    },
                    fields=["name", "credit"]
                )

                paid_amount = sum([repayment['credit'] for repayment in repayment_today2])

    
                repayment_today = frappe.get_all("Loan Repayment", 
                                                filters={
                                                    "loan": loan.name, 
                                                    "created_on": current_date
                                                },
                                                fields=["name", "amount"])
                                                
                repayment_amount = sum([repayment['amount'] for repayment in repayment_today])
          
            
            
                if repayment_amount >= daily_interest:

                    if paid_amount >= daily_interest:
                        return 0 
                    else:
                       return daily_interest - paid_amount


                    return 0
                else:

                    return daily_interest - paid_amount
 




def create_journal_entry(loan_product, loan, arrears_payment, penalty_payment, daily_interest_payment, payment_amount, user, docer, daily_interest2):
    """
    Creates the required journal entries for arrears, penalties, and daily interest.
    """
    if arrears_payment > 0:
        
        coa_account = frappe.db.get_value('Employee', {'user': user}, 'coa_account')
        create_journal_entry_for_account(
                account_name=loan_product.interest_receivables_account,
                amount=arrears_payment,
                debit=False,
                transaction_type_name="Arreas Repayment",
                company=loan.company,
                branch=loan.branch,
                loan=loan
            )
            
        create_journal_entry_for_account(
                account_name=loan_product.loan_account,
                amount=arrears_payment,
                debit=True,
                transaction_type_name="Arreas Repayment",
                company=loan.company,
                branch=loan.branch,
                loan=loan
            )

    if penalty_payment > 0:

        create_journal_entry_for_account(
                account_name=loan_product.loan_account,
                amount=penalty_payment,
                debit=True,
                transaction_type_name="Penalty Repayment",
                company=loan.company,
                branch=loan.branch,
                loan=loan
            )

        create_journal_entry_for_account(
            account_name=loan_product.loan_penalty_account,
            amount=penalty_payment,
            debit=False,
            transaction_type_name="Penalty Repayment",
            company=loan.company,
            branch=loan.branch,
            loan=loan,
            isincome=1
        )

    if daily_interest_payment > 0:

        if daily_interest2 > payment_amount:
            coa_account = frappe.db.get_value('Employee', {'user': user}, 'coa_account')
           
            create_journal_entry_for_account(
                account_name=coa_account,
                amount=daily_interest_payment,
                debit=True,
                transaction_type_name="Loan Repayment",
                company=loan.company,
                branch=loan.branch,
                loan=loan
            )


            create_journal_entry_for_account(
                account_name=loan_product.loan_account,
                amount=daily_interest_payment,
                debit=False,
                transaction_type_name="Loan Repayment",
                company=loan.company,
                branch=loan.branch,
                loan=loan,
                isincome=1
            )


            create_journal_entry_for_account(
                account_name=loan_product.loan_account,
                amount=daily_interest_payment,
                debit=True,
                transaction_type_name="Interest Payment",
                company=loan.company,
                branch=loan.branch,
                loan=loan
            )


            create_journal_entry_for_account(
                account_name=loan_product.loan_interest_account,
                amount=daily_interest_payment,
                debit=False,
                transaction_type_name="Interest Payment",
                company=loan.company,
                branch=loan.branch,
                loan=loan,
                isincome=1
            )

        else:

            create_journal_entry_for_account(
                account_name=loan_product.loan_interest_account,
                amount=daily_interest_payment,
                debit=False,
                transaction_type_name="Interest Repayment",
                company=loan.company,
                branch=loan.branch,
                loan=loan,
                isincome=1
            )

            create_journal_entry_for_account(
                account_name=loan_product.loan_account,
                amount=daily_interest_payment,
                debit=True,
                transaction_type_name="Interest Repayment",
                company=loan.company,
                branch=loan.branch,
                loan=loan
            )

def create_journal_entry_for_account(account_name, amount, debit=True, transaction_type_name="Payment", company=None, branch=None, loan=None, isincome=0, isar=0):
    """
    Creates a General Ledger II entry for the provided account.
    """

    # Retrieve account details
    account_details = get_account_details(account_name)
    
    # Determine credit or debit
    debit_amount = amount if debit else 0
    credit_amount = 0 if debit else amount
    
    # Set default company and branch if not provided
    company = company or frappe.defaults.get_global_default('company')
    branch = branch or frappe.defaults.get_global_default('branch')
    inc = account_details['main_parent']
    if isincome==1:
        inc = "Income"
        print(loan)
    # Create the journal entry
    entry = frappe.get_doc({
        'doctype': 'General Ledger II',
        'account': account_name,
        'label_for_report': account_name,
        'transaction_type': 1,  # Assuming 1 is for normal payment, change as per your system
        'transaction_type_name': transaction_type_name,
        'posting_date': datetime.now().date(),
        'company': company,
        'branch': branch,
        'amount': amount,
        'credit': credit_amount,
        'debit': debit_amount,
        'main_parent': inc,
        'sub_parent': account_details['sub_parent'],
        'category': account_details['category'],
        'loan': loan,
        'isar':isar
    })
    
    # Insert and submit the journal entry
    entry.insert()
    entry.submit()
    frappe.db.commit()  # Explicitly commit the transaction

def pay_principal(loan_id, remaining_amount, amounter, user):
    # Fetch loan and loan product details
    loan = frappe.get_doc("Loan Application Plus", loan_id)
    loanp = frappe.get_doc("Loan Product", loan.loan_type)

    # Get account details for principal outstanding and loan accounts
    principal_account_details = get_account_details(loanp.principle_outstanding_account)
    loan_account_details = get_account_details(loanp.loan_account)
   
    
    # Define transaction type name
    transaction_type_name2 = "Principle Payment"
    transaction_type_name = "Loan Repayment"
    current_user = user
    coa_account = frappe.db.get_value('Employee', {'user': current_user}, 'coa_account')
    coa_account_name = frappe.get_doc("Account", {"name": coa_account})
    cash_account = get_account_details(coa_account_name)

    fffdrr = frappe.get_doc("Account", {"name": loanp.principle_outstanding_account}) 
    # Create General Ledger II entries for principal payment
    entries = [
        {
            'doctype': 'General Ledger II',
            'account': coa_account_name,
            'label_for_report': coa_account_name,
            'transaction_type': 1,  # Assuming 1 is for normal payment
            'transaction_type_name': transaction_type_name,
            'posting_date': datetime.now().date(),
            'company': loan.company,
            'branch': loan.branch,
            'amount': amounter,
            'credit': 0,
            'debit': amounter,
            'main_parent': "Assets",
            'sub_parent': "Cash & Cash Equivalents",
            'category': coa_account_name,
            'loan':loan_id
        },
        {
            'doctype': 'General Ledger II',
            'account': loanp.loan_account,
            'label_for_report': loanp.loan_account,
            'transaction_type': 1,  # Assuming 1 is for normal payment
            'transaction_type_name': transaction_type_name,
            'posting_date': datetime.now().date(),
            'company': loan.company,
            'branch': loan.branch,
            'amount': amounter,
            'credit': amounter,
            'debit': 0,
            'main_parent': loan_account_details['main_parent'],
            'sub_parent': loan_account_details['sub_parent'],
            'category': loan_account_details['category'],
            'loan':loan_id
        },
        {
            'doctype': 'General Ledger II',
            'account': loanp.principle_outstanding_account,
            'label_for_report': loanp.principle_outstanding_account,
            'transaction_type': 1,  # Assuming 1 is for normal payment
            'transaction_type_name': transaction_type_name2,
            'posting_date': datetime.now().date(),
            'company': loan.company,
            'branch': loan.branch,
            'amount': remaining_amount,
            'credit': remaining_amount,
            'debit': 0,
            'main_parent': principal_account_details['main_parent'],
            'sub_parent': principal_account_details['sub_parent'],
            'category': fffdrr,
            'loan':loan_id
        },
        {
            'doctype': 'General Ledger II',
            'account': loanp.loan_account,
            'label_for_report': loanp.loan_account,
            'transaction_type': 1,  # Assuming 1 is for normal payment
            'transaction_type_name': transaction_type_name2,
            'posting_date': datetime.now().date(),
            'company': loan.company,
            'branch': loan.branch,
            'amount': remaining_amount,
            'credit': 0,
            'debit': remaining_amount,
            'main_parent': loan_account_details['main_parent'],
            'sub_parent': loan_account_details['sub_parent'],
            'category': loan_account_details['category'],
            'loan':loan_id
        }
    ]

    # Insert and submit all journal entries
    for entry in entries:
        doc = frappe.get_doc(entry)
        doc.insert()
        doc.submit()
    frappe.db.commit()  # Explicitly commit the transaction

def get_account_details(account_name):
    account_doc = frappe.get_doc("Account", account_name)
    # Map root_type to main_parent
    root_type = account_doc.root_type
    if root_type == "Asset":
        main_parent = "Assets"
    elif root_type == "Expense":
        main_parent = "Expenses"
    elif root_type == "Liability":
        main_parent = "Liabilities"
    elif root_type == "Income":
        main_parent = "Equity"
    else:
        main_parent = "Unknown"  # Handle unexpected root_type
    
    sub_parent = account_doc.account_type
    category = account_doc.name  # Ensure this is a string

    return {
        'main_parent': main_parent,
        'sub_parent': sub_parent,
        'category': account_name
    }

def generate_loan_schedule_2(loan_id, loanstart, max_date):
    loan_date = datetime.strptime(loanstart.strftime('%Y-%m-%d'), '%Y-%m-%d')
    loan = frappe.get_doc("Loan Application Plus", loan_id)
    grace_period_on_disbursement = loan.grace_period_on_disbursment

    loan_amount = loan.principal
    loan_interest = loan.loan_interest
    loan_term = int(loan.loan_tenure)
    

    skipped_days, skipped_dates = fetch_skipped_days_and_dates()
    interest_rate_per_day = (loan_interest / 100) / 365

    repayment_dates = []
    current_date = loan_date + timedelta(days=grace_period_on_disbursement)

    if max_date:
        last_date = datetime.strptime(max_date.strftime('%Y-%m-%d'), '%Y-%m-%d')
    else:
        last_date = loan_date + timedelta(days=loan_term)

    total_repayments = 0

    while current_date <= last_date:
        date_str = current_date.strftime('%Y-%m-%d')
        day_of_week = current_date.strftime('%A')

        if date_str in skipped_dates or day_of_week in skipped_days:
            current_date += timedelta(days=1)
            continue

        repayment_dates.append({'date': date_str})
        total_repayments += 1
        current_date += timedelta(days=1)

    return repayment_dates

def pay_principal2(loan_id, remaining_amount, amounter, user):
    # Fetch loan and loan product details
    loan = frappe.get_doc("Loan Application Plus", loan_id)
    loanp = frappe.get_doc("Loan Product", loan.loan_type)

    # Get account details for principal outstanding and loan accounts
    principal_account_details = get_account_details(loanp.principle_outstanding_account)
    loan_account_details = get_account_details(loanp.loan_account)
   
    
    # Define transaction type name
    transaction_type_name = "Principle Payment"
    current_user = user
    coa_account = frappe.db.get_value('Employee', {'user': current_user}, 'coa_account')
    coa_account_name = frappe.get_doc("Account", {"name": coa_account})
    cash_account = get_account_details(coa_account_name)

    fffdrr = frappe.get_doc("Account", {"name": loanp.principle_outstanding_account}) 
    # Create General Ledger II entries for principal payment
    entries = [
      
        {
            'doctype': 'General Ledger II',
            'account': loanp.principle_outstanding_account,
            'label_for_report': loanp.principle_outstanding_account,
            'transaction_type': 1,  # Assuming 1 is for normal payment
            'transaction_type_name': transaction_type_name,
            'posting_date': datetime.now().date(),
            'company': loan.company,
            'branch': loan.branch,
            'amount': remaining_amount,
            'credit': remaining_amount,
            'debit': 0,
            'main_parent': principal_account_details['main_parent'],
            'sub_parent': principal_account_details['sub_parent'],
            'category': fffdrr,
            'loan':loan_id
        },
        {
            'doctype': 'General Ledger II',
            'account': loanp.loan_account,
            'label_for_report': loanp.loan_account,
            'transaction_type': 1,  # Assuming 1 is for normal payment
            'transaction_type_name': transaction_type_name,
            'posting_date': datetime.now().date(),
            'company': loan.company,
            'branch': loan.branch,
            'amount': remaining_amount,
            'credit': 0,
            'debit': remaining_amount,
            'main_parent': loan_account_details['main_parent'],
            'sub_parent': loan_account_details['sub_parent'],
            'category': loan_account_details['category'],
            'loan':loan_id
        }
    ]

    # Insert and submit all journal entries
    for entry in entries:
        doc = frappe.get_doc(entry)
        doc.insert()
        doc.submit()
    frappe.db.commit()  # Explicitly commit the transaction



#########################################################################################################################################################

@frappe.whitelist(allow_guest=True)
def search_employee_api(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM tabEmployee as employee
     JOIN tabRole as rl ON employee.roles = rl.role_name
        WHERE employee.mobile like %(keyword)s or employee.user like %(keyword)s
        """, {"keyword": keyword}, as_dict=True)

        if data:
            results = data
    return results

@frappe.whitelist(allow_guest=True)
def search_Branches_api(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM tabBranch as tb
        WHERE  tb.company like %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results

@frappe.whitelist(allow_guest=True)
def search_roles_api(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM tabRole as tb
        WHERE  tb.role_name like %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results


@frappe.whitelist(allow_guest=True)
def search_bankingaccount_api(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabBanking Account` as tb
        WHERE  tb.account_name like %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results

@frappe.whitelist(allow_guest=True)
def search_bankingaccount_api(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabBanking Account` as tb
        WHERE  tb.account_name like %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results

#savings


@frappe.whitelist(allow_guest=True)
def get_last_running_balance(loan_id):
    # Fetch loan document
    loan_data = frappe.get_doc("Loan Application Plus", loan_id)
    loan_disbursement = frappe.db.get_list(
        "Loan Disbursement",
        filters={"loan": loan_id},
        fields=["disbursement_date", "disbursed_amount"],
        limit=1
    )

    if not loan_disbursement:
        frappe.throw("Loan Disbursement record not found for the selected loan.")

    loan_start_date = loan_disbursement[0].disbursement_date
    disbursed_amount = loan_disbursement[0].disbursed_amount
    loan_interest_expected = float(loan_data.loan_interest_expected)

    # Fetch all relevant transactions for the loan
    transaction_query = f"""
        SELECT
            transactions.creation AS posting_date,
            transaction_types.description AS description,
            transactions.amount AS amount,
            transactions.principal_repaid_derived + transactions.principal_recovered AS principal,
            transactions.interest_repaid_derived + transactions.interest_recovered AS interest,
            transactions.penalties_repaid_derived + transactions.penalties_recovered AS penalty
        FROM `tabLoan Transaction2` AS transactions
        JOIN `tabLoan Transaction Type` AS transaction_types ON transactions.transaction_type = transaction_types.name
        WHERE transactions.loan = '{loan_id}'
          AND transaction_types.description NOT IN ('Apply Interest')
        UNION ALL
        SELECT
            repayment.creation AS posting_date,
            'Loan Repayment' AS description,
            repayment.amount AS amount,
            0 AS principal,
            0 AS interest,
            0 AS penalty
        FROM `tabLoan Repayment` AS repayment
        WHERE repayment.loan = '{loan_id}'
        UNION ALL
        SELECT
            waive.creation AS posting_date,
            CONCAT('Waive Loan II-', waive.waive_type) AS description,
            waive.amount AS amount,
            0 AS principal,
            0 AS interest,
            0 AS penalty
        FROM `tabWaive Loan II` AS waive
        WHERE waive.loan = '{loan_id}'
        UNION ALL
        SELECT
            writeoff.creation AS posting_date,
            CONCAT('Write off II-', writeoff.waive_type) AS description,
            writeoff.amount AS amount,
            0 AS principal,
            0 AS interest,
            0 AS penalty
        FROM `tabWrite Off Loan II` AS writeoff
        WHERE writeoff.loan = '{loan_id}'
        ORDER BY posting_date ASC
    """

    transactions = frappe.db.sql(transaction_query, as_dict=True)
    running_balance = float("0")
    # Initial balance includes both disbursed amount and interest
    running_balance = disbursed_amount + loan_interest_expected

    # Process transactions to update running balance
    for txn in transactions:
        description = txn.get("description")
        amount = txn.get("amount", 0)
        principal = txn.get("principal", 0)
        interest = txn.get("interest", 0)
        penalty = txn.get("penalty", 0)

        # Handle repayment-like transactions
        if description in ("Loan Repayment", "Write off II-Principle", "Savings To Loan Transfer", "Loan Closure"):
            running_balance -= amount
        elif penalty > 0:
            running_balance += penalty

    return running_balance

@frappe.whitelist(allow_guest=True)
def search_client_desk(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabClient` as tb
       left JOIN `tabClient Address` as rl ON tb.name = rl.parent
        left JOIN `tabClient Identifiers` as rl2 ON tb.name = rl2.parent
        WHERE  tb.full_name like %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results

@frappe.whitelist(allow_guest=True)
def search_savingaccounts_desk(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabSavings Account` as tb
        WHERE  tb.phone_number like %(keyword)s or tb.client_name like %(keyword)s or tb.name like %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results


@frappe.whitelist(allow_guest=True)
def search_savingcharges_desk(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabSavings Charges` as tb
        WHERE  tb.saving_charge_name like %(keyword)s 
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results

import frappe
@frappe.whitelist()
def generate_savings_report_last(account, from_date=None, to_date=None, account2=None, ag=None):
    """
    Generates savings report following all debit/credit rules.
    Returns only the last balance, last posting date, and updates total_deposits_derived with last transaction owner.
    """
    if account2 == "NULL":
        account2 = None

    # Create temporary table
    frappe.db.sql("""
        CREATE TEMPORARY TABLE IF NOT EXISTS tmp_transactions (
            posting_date DATETIME(6),
            transaction_id VARCHAR(64),
            description TEXT,
            debit DECIMAL(18,4) DEFAULT 0,
            credit DECIMAL(18,4) DEFAULT 0,
            balance DECIMAL(18,4) DEFAULT 0,
            owner VARCHAR(140)
        )
    """)

    # Clear table
    frappe.db.sql("TRUNCATE TABLE tmp_transactions")

    # Insert transactions with rules
    frappe.db.sql("""
        INSERT INTO tmp_transactions (posting_date, transaction_id, description, debit, credit, balance, owner)
        SELECT
            t1.creation AS posting_date,
            t1.name AS transaction_id,
            CASE
                WHEN LOWER(t1.description) LIKE '%%security deposit%%' THEN
                    CASE WHEN LOWER(t1.transaction_type_name)='deposit' THEN CONCAT('D-', t1.description)
                    ELSE CONCAT('W-', t1.description) END
                ELSE t1.description
            END AS description,
            
            CASE
                WHEN LOWER(t1.description) LIKE '%%deposit fees%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%account opening3%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%account opening2%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%account opening%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%opening balance%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%monthly %%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%withdraw%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%withdraw fees%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%withdraw penalty%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%transfer from%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%transfer to%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%cash collateral%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%charge%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%loan security%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%loan closure%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%sacco contribution%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%dsecurity%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%wsecurity%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%security deposit%%' THEN
                    CASE WHEN LOWER(t1.transaction_type_name)='deposit' THEN 0 ELSE t1.amount END
                WHEN LOWER(t1.description) LIKE '%%security%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%approval%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%fees payment%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%disbursement%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%loan application fee%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%loan charge %%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%loan insurance%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%refund of loan insurance%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%loan repayment%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%deposit%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%reconciliation%%' THEN t1.amount
                ELSE 0
            END AS debit,

            CASE
                WHEN LOWER(t1.description) LIKE '%%deposit fees%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%account opening3%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%account opening2%%' THEN -t1.amount
                WHEN LOWER(t1.description) LIKE '%%account opening%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%opening balance%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%monthly %%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%withdraw%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%withdraw fees%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%withdraw penalty%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%transfer from%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%transfer to%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%cash collateral%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%charge%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%loan security%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%loan closure%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%sacco contribution%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%dsecurity%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%wsecurity%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%security deposit%%' THEN
                    CASE WHEN LOWER(t1.transaction_type_name)='deposit' THEN t1.amount ELSE 0 END
                WHEN LOWER(t1.description) LIKE '%%security%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%approval%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%fees payment%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%disbursement%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%loan application fee%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%loan charge %%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%loan insurance%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%refund of loan insurance%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%loan repayment%%' THEN 0
                WHEN LOWER(t1.description) LIKE '%%deposit%%' THEN t1.amount
                WHEN LOWER(t1.description) LIKE '%%reconciliation%%' THEN 0
                ELSE t1.amount
            END AS credit,

            0 AS balance,
            t1.owner

        FROM `tabSaving Transaction` t1
        LEFT JOIN `tabDeposit` t2 ON t2.name = t1.deposit
        WHERE t1.account=%s
          AND t1.flagged=0
          AND (%s IS NULL OR t1.creation >= %s)
          AND (%s IS NULL OR t1.creation <= %s)
          AND (%s IS NULL OR t2.suba=%s)
        ORDER BY t1.creation, t1.name
    """, (account, from_date, from_date, to_date, to_date, account2, account2))

    # Running balance
    frappe.db.sql("SET @running_balance = 0")
    frappe.db.sql("""
        UPDATE tmp_transactions
        SET balance = (@running_balance := @running_balance + credit - debit)
        ORDER BY posting_date, transaction_id
    """)

    # Get last balance, date, and owner
    last = frappe.db.sql("""
        SELECT balance, posting_date, owner
        FROM tmp_transactions
        WHERE posting_date IS NOT NULL
        ORDER BY posting_date DESC, transaction_id DESC
        LIMIT 1
    """, as_dict=True)

    # Update Savings Account
    if last:
        frappe.db.sql("""
            UPDATE `tabSavings Account`
            SET 
                balance_derived = %s,
                overdraft_derived = %s,
                total_deposits_derived = %s,
                modified = NOW()
            WHERE name = %s
        """, (last[0].balance, last[0].posting_date, ag, account))

        return {
            "last_balance": round(last[0].balance),
            "last_date": last[0].posting_date,
            "last_owner": last[0].owner
        }
    else:
        return {"last_balance": 0, "last_date": None, "last_owner": None}

import frappe
import requests
import json
@frappe.whitelist(allow_guest=True)
def send_sms(message, phone):
    """
    Sends an SMS message via external API.
    :param message: The text message to send
    :param phone: One or more phone numbers separated by commas
    """
    url = "http://45.77.66.10/api/send_sms"
    headers = {
        "Content-Type": "application/json",
        "Accept": "*/*",
        "Authorization": "Bearer 5ALQLnu2wSflQtt6Qal7GSNUbW6swdxLVwMPjgwOdJ9BONdJCTnKhVk7mjuKRiqMXUrzxgZBmhXTQBLW"  # Replace with actual token
    }

    payload = {
        "message": message,
        "numbers": phone
    }

    try:
        response = requests.post(url, headers=headers, data=json.dumps(payload))
        if response.status_code == 200:
            return {"status": "success", "response": response.text}
        else:
            return {"status": "error", "code": response.status_code, "response": response.text}
    except Exception as e:
        frappe.throw(f"Error sending SMS: {e}")


@frappe.whitelist(allow_guest=True)
def search_loancharges_desk(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabLoan Charge` as tb
        WHERE  tb.loan_charge_name like %(keyword)s 
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results

@frappe.whitelist()
def get_last_repayment_info(loan):
    data = frappe.db.sql("""
        SELECT 
            MAX(creation) AS last_repayment_date,
            SUM(amount) AS total_paid
        FROM `tabLoan Repayment`
        WHERE loan = %s AND flagged = 0
    """, (loan,), as_dict=True)

    return data[0] if data else {}



import urllib
import frappe
@frappe.whitelist()
def send_message_to_clients_opening(recipients, message, message_type="SMS"):
    try:
        number = urllib.parse.unquote(recipients).replace("+256", "+256-")
        # Get client records
        clients = frappe.get_all(
            "Client",
            filters={"mobile": ["in", number]},
            fields=["name", "full_name", "mobile", "email"]
        )


        # Call your function to insert messages into queue
        frappe.call(
            "mfis.clients.send_to_queue_message_mysql",
            recipients=clients,
            message=message,
            message_type=message_type
        )

        return {"status": "success", "message": "Message sent successfully!"}

    except Exception as e:
        frappe.log_error(message=frappe.get_traceback(), title="send_message_to_clients_opening Error")
        return {"status": "error", "message": str(e)}

@frappe.whitelist()
def send_message_to_clients_opening2(recipients, message, message_type="SMS"):
    try:
        number = urllib.parse.unquote(recipients).replace("+256", "+256-")
        # Get client records
        clients = frappe.get_all(
            "Employee",
            filters={"mobile": ["in", number]},
            fields=["name", "full_name", "mobile", "user"]
        )


        # Call your function to insert messages into queue
        frappe.call(
            "mfis.clients.send_to_queue_message_mysql",
            recipients=clients,
            message=message,
            message_type=message_type,
            tbs=1
        )

        return {"status": "success", "message": "Message sent successfully!"}

    except Exception as e:
        frappe.log_error(message=frappe.get_traceback(), title="send_message_to_clients_opening Error")
        return {"status": "error", "message": str(e)}

import frappe
import json
from frappe.utils import get_datetime, now_datetime
@frappe.whitelist()
def send_to_queue_message_mysql(recipients, message, message_type='SMS', title=None,
                          template=None, scheduled_at=None,
                          send_after_seconds=0, maximum_retry_attempts=0,
                          account=None, loan=None, tbs=0):

    if not recipients:
        frappe.throw("Recipients are required to send a message"+recipients)
    
    if isinstance(recipients, str):
        recipients = json.loads(recipients)

    send_after_seconds = frappe.db.get_single_value(
        "Message Archive Settings", "default_send_delay_seconds"
    )

    default_queue_enabled = frappe.db.get_single_value(
        "Message Archive Settings", "default_queue_enabled"
    )

    if tbs == 1:
        default_queue_enabled = 0

    from frappe.utils import get_datetime, add_to_date
    scheduled_val = add_to_date(get_datetime(), seconds=send_after_seconds)
    created_by = frappe.session.user
    status = "Pending"
    date_val = now_datetime()

    inserted_names = []

    for recipient in recipients:
        recipient_name = recipient.get("name")
        recipient_mobile = recipient.get("mobile")
        recipient_fullname = recipient.get("full_name")

        # Check for duplicate message (same recipient, same message, same timestamp)
        existing_message = frappe.db.exists(
            "Message Archive",
            {
                "mobile": recipient_mobile,
                "message_body": message,
                "date": date_val
            }
        )

        if existing_message:
            frappe.logger().info(f"Duplicate message detected for {recipient_mobile} at {date_val}, skipping...")
            continue

        doc = frappe.get_doc({
            "doctype": "Message Archive",
            "title": f"{recipient_fullname}'s Message",
            "type": message_type,
            "mobile": recipient_mobile,
            "message_body": message,
            "scheduled_at": scheduled_val,
            "send_after_seconds": send_after_seconds,
            "recipient_count": 0,
            "default_queue_enabled": default_queue_enabled,
            "maximum_retry_attempts": maximum_retry_attempts,
            "date": date_val,
            "created_by": created_by,
            "status": status,
            "template": template,
            "account": account,
            "loan": loan
        })
        doc.insert(ignore_permissions=True)
        inserted_names.append(doc.name)

    frappe.db.commit()

    return inserted_names



@frappe.whitelist()
def get_security_deposit_amount(loan, loan_amount):

    loan_amount = float(loan_amount)
    security_deposit_amount = 0

    # Fetch the Loan Application
    loan_doc = frappe.get_doc("Loan Application Plus", loan)

    # Fetch related Loan Product
    loanproduct = frappe.get_doc("Loan Product", {"name": loan_doc.loan_type})

    getbalancer = 0
    # Iterate through loan charges and process based on status
    for charge in loanproduct.product_charges:
        if charge.active and loan_doc.principal > 0:
            charger = frappe.get_doc("Charge", charge.charge)
            am = charger.amount
            if charger.charge_calculation_type == "Percentage":
                am = (charger.max_cap / 100) * loan_doc.principal

            date = nowdate()

            # First GL entry (income side)
            # coa_account_debit = frappe.get_doc("Account", charger.account)
            # debit_entry = frappe.get_doc({
            #     'doctype': 'General Ledger II',
            #     'account': charger.account,
            #     'label_for_report': coa_account_debit.name,
            #     'transaction_type': 1,
            #     'transaction_type_name': charger.charge_name,
            #     'posting_date': datetime.now().date(),
            #     'company': loan_doc.company,
            #     'branch': loan_doc.branch,
            #     'amount': am,
            #     'credit': am,
            #     'debit': 0,
            #     'main_parent': "Income",
            #     'sub_parent': "Income",
            #     'category': coa_account_debit.name,
            #     'savings_account': loan_doc.clients,
            #     'loan': loan_doc.name
            # })
            # debit_entry.insert()
            # debit_entry.submit()

            # # Second GL entry (customer liabilities side)
            # savings_accout = frappe.get_doc("Savings Account", {"name": loan_doc.clients})
            # saving_product = frappe.get_doc("Saving Product", {"name": savings_accout.saving_product})
            # coa_account_name2 = frappe.get_doc("Account", {"name": saving_product.customer_balance_account})
            # saving_transactionr2 = frappe.get_doc({
            #     'doctype': 'General Ledger II',
            #     'account': saving_product.customer_balance_account,
            #     'label_for_report': coa_account_name2.name,
            #     'transaction_type': 1,
            #     'transaction_type_name': charger.charge_name,
            #     'posting_date': datetime.now().date(),
            #     'company': loan_doc.company,
            #     'branch': loan_doc.branch,
            #     'amount': am,
            #     'credit': 0,
            #     'debit': am,
            #     'main_parent': "Liabilities",
            #     'sub_parent': "Balances On Customer Account",
            #     'category': coa_account_name2.name,
            #     'savings_account': loan_doc.clients,
            #     'loan': loan_doc.name
            # })
            # saving_transactionr2.insert()
            # saving_transactionr2.submit()

                        # Create Saving Transaction (moved here from bottom)
            transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": "1"})
            saving_transaction = frappe.get_doc({
                'doctype': 'Saving Transaction',
                'account': loan_doc.account_number,
                'transaction_type': transaction_type,
                'posting_date': date,
                'branch': loan_doc.branch,
                'amount': am,
                'debit': am,
                'client_name': loan_doc.client_name,  # Ensure field exists
                'reference': loan_doc.name,
                'description': f'Loan Charge {charger.charge_name} for {loan_doc.name}',
                'is_parent': 1,
                'allow_charges': 0,
                'loan': loan_doc.name
            })

            saving_transaction.insert()
            saving_transaction.submit()

    # Fetch child table rows for Security Deposit Rules
    rows = frappe.get_all(
        "Security_deposit",
        filters={"parent": loan_doc.loan_type},
        fields=["min", "max", "securitydeposit", "checkd"]
    )


    for row in rows:
        if float(row["min"]) <= loan_amount <= float(row["max"]):
            if row["checkd"]:  # If Org Amount is checked
                security_deposit_amount = round((loanproduct.security_deposit_ / 100) * loan_amount)
            else:
                security_deposit_amount = float(row["securitydeposit"]) or 0
            break

    if  security_deposit_amount  is None:
        return {"status": "error", "message": "No matching rule found for this loan amount."+str(security_deposit_amount)}

    updated_amount = security_deposit_amount

    coa_account_debit = frappe.get_doc("Account", loanproduct.cash_collateral_account)

    existing_entry = frappe.db.exists("General Ledger II", {
        "account": loanproduct.cash_collateral_account,
        "transaction_type_name": "Security Deposit",
        "company": loan_doc.company,
        "branch": loan_doc.branch,
        "savings_account": loan_doc.clients,
        "loan": loan
    })

  
    frappe.db.sql("""
        UPDATE `tabLoan Application Plus`
        SET principal = %(principal)s,
            amount = %(updated_amount)s,
            principal = %(loan_amount)s,
            cash_collateral = %(cash_collateral)s,
            workflow_state = %(workflow_state)s,
            status = %(workflow_state)s
        WHERE name = %(keyword)s
    """, {
        "updated_amount": updated_amount,
          "loan_amount": loan_amount,
        "principal": loan_doc.principal,
        "cash_collateral": "Cash Collateral",
        "workflow_state": "Branch Manager Approval",
        "keyword": loan
    })

    frappe.db.commit()

    # if existing_entry:
    #     return {"status": "success", "message": "Security deposit has already been charged for this loan."}
    # run_charges(loan_doc)
    # Create debit entry in GL for Cash Collateral Account
    debit_entry = frappe.get_doc({
        'doctype': 'General Ledger II',
        'account': loanproduct.cash_collateral_account,
        'label_for_report': coa_account_debit.name,
        'transaction_type': 1,
        'transaction_type_name': "Security Deposit",
        'posting_date': datetime.now().date(),
        'company': loan_doc.company,
        'branch': loan_doc.branch,
        'amount': updated_amount,
        'credit': updated_amount,
        'debit': 0,
        'main_parent': "Liabilities",
        'sub_parent': "Payable",
        'category': coa_account_debit,
        'savings_account': loan_doc.clients,
        'loan': loan
    })
    debit_entry.insert()
    debit_entry.submit()

    # Post to Customer Balance Account
    savings_account = frappe.get_doc("Savings Account", {"name": loan_doc.clients})
    saving_product = frappe.get_doc("Saving Product", {"name": savings_account.saving_product})
    coa_account_name2 = frappe.get_doc("Account", {"name": saving_product.customer_balance_account})

    existing_entry2 = frappe.db.exists("General Ledger II", {
        "account": saving_product.customer_balance_account,
        "transaction_type_name": "Security Deposit",
        "company": loan_doc.company,
        "branch": loan_doc.branch,
        "savings_account": loan_doc.clients,
        "loan": loan
    })

    # if existing_entry2:
    #     return {"status": "error", "message": "Security deposit has already been charged for this loan."}

    saving_transactionr2 = frappe.get_doc({
        'doctype': 'General Ledger II',
        'account': saving_product.customer_balance_account,
        'label_for_report': coa_account_name2,
        'transaction_type': 1,
        'transaction_type_name': "Security Deposit",
        'posting_date': datetime.now().date(),
        'company': loan_doc.company,
        'branch': loan_doc.branch,
        'amount': updated_amount,
        'credit': 0,
        'debit': updated_amount,
        'main_parent': "Liabilities",
        'sub_parent': "Balances On Customer Account",
        'category': coa_account_name2,
        'savings_account': loan_doc.clients,
        'loan': loan
    })
    saving_transactionr2.insert()
    saving_transactionr2.submit()
 
   


    return {"status": "success", "message": f"Loan application updated successfully for {loan_doc.loan_type}"}



@frappe.whitelist(allow_guest=True)
def force_reset(user_email):
    if not frappe.db.exists("User", user_email):
        return {"status": "error", "message": "User does not exist"}

    frappe.db.set_value("User", user_email, "force_password_reset", 1)
    frappe.db.commit()

    return {
        "status": "success",
        "message": f"User {user_email} will be forced to reset password on next login."
    }

@frappe.whitelist(allow_guest=True)
def get_password_status(username):
    from datetime import datetime

    log = frappe.get_all(
        "User Password Log",
        filters={"user": username, "is_expired": 0},
        fields=["password_change_on", "is_expired", "is_reset"],  # ✅ added is_reset
        order_by="password_change_on desc",
        limit=1
    )

    # no record = return accurate response
    if not log:
        return {
            "status": "no_record",
            "days_left": 0,
            "is_reset": 0   # ✅ default when no record exists
        }

    entry = log[0]
    change_on = entry.get("password_change_on")
    is_expired = entry.get("is_expired") or 0
    is_reset = entry.get("is_reset") or 0   # ✅ fetch is_reset

    if not change_on:
        return {
            "status": "no_record",
            "days_left": 0,
            "is_reset": is_reset
        }

    change_on = frappe.utils.get_datetime(change_on)
    today = datetime.now()

    # EXACT difference — zero assumptions
    days_left = (change_on - today).days

    # if change date is past, days_left will be negative
    if days_left <= 0:
        return {
            "status": "expired",
            "days_left": days_left,
            "is_reset": is_reset   # ✅ include
        }

    if days_left == 2:
        return {
            "status": "warning",
            "days_left": 2,
            "is_reset": is_reset   # ✅ include
        }

    return {
        "status": "ok",
        "days_left": days_left,
        "is_reset": is_reset       # ✅ include
    }



import subprocess, shlex
from typing import Dict, Any
import frappe
from datetime import datetime, timedelta

@frappe.whitelist(allow_guest=True)
def set_frappe_password(email: str, password: str) -> Dict[str, Any]:

    cmd = f"bench set-password {shlex.quote(email)}"
    try:
        r = subprocess.run(
            shlex.split(cmd),
            input=password + "\n",
            capture_output=True,
            text=True,
            check=True
        )

        # ➕ CREATE CUSTOM USER PASSWORD LOG ENTRY
        try:
            today = datetime.now()
            next_reset_date = today + timedelta(days=30)

            # INSERT NEW LOG
            log = frappe.get_doc({
                "doctype": "User Password Log",
                "user": email,
                "new_password": password,
                "password_change_on": next_reset_date,  # today + 30 days
                "days_left": 30,
                "is_expired": 0,
                "ip_address": frappe.local.request_ip if hasattr(frappe.local, "request_ip") else "",
                "device_info": frappe.get_request_header("User-Agent") or ""
            })
            log.insert(ignore_permissions=True)
            frappe.db.commit()

            # 🔥 EXPIRE ALL OLD LOGS FOR THIS USER
            frappe.db.sql("""
                UPDATE `tabUser Password Log`
                SET is_expired = 1
                WHERE user = %s AND name != %s
            """, (email, log.name))

            frappe.db.commit()

        except Exception as log_err:
            frappe.log_error(str(log_err), "Password Log Insert/Expire Error")

        return {
            "success": True,
            "stdout": r.stdout,
            "stderr": r.stderr
        }

    except subprocess.CalledProcessError as e:
        return {
            "success": False,
            "error": "Command failed",
            "stdout": e.stdout,
            "stderr": e.stderr,
            "return_code": e.returncode
        }

    except FileNotFoundError:
        return {
            "success": False,
            "error": "bench command not found."
        }


@frappe.whitelist(allow_guest=True)
def set_frappe_password2(email: str, password: str) -> Dict[str, Any]:

    cmd = f"bench set-password {shlex.quote(email)}"
    try:
        r = subprocess.run(
            shlex.split(cmd),
            input=password + "\n",
            capture_output=True,
            text=True,
            check=True
        )

        # ➕ CREATE CUSTOM USER PASSWORD LOG ENTRY
        try:
            today = datetime.now()
            next_reset_date = today + timedelta(days=2)

            # INSERT NEW LOG
            log = frappe.get_doc({
                "doctype": "User Password Log",
                "user": email,
                "new_password": password,
                "password_change_on": next_reset_date,  # today + 30 days
                "days_left": 1,
                "is_expired": 0,
                "is_reset":1,
                "ip_address": frappe.local.request_ip if hasattr(frappe.local, "request_ip") else "",
                "device_info": frappe.get_request_header("User-Agent") or ""
            })
            log.insert(ignore_permissions=True)
            frappe.db.commit()

            # 🔥 EXPIRE ALL OLD LOGS FOR THIS USER
            frappe.db.sql("""
                UPDATE `tabUser Password Log`
                SET is_expired = 1
                WHERE user = %s AND name != %s
            """, (email, log.name))

            frappe.db.commit()

            employee = frappe.db.get_value(
            "Employee",
            {"user": email},
            ["email", "mobile", "last_name"],  # or "first_name" if that's what you need
            as_dict=True
            )

            email2 = employee.email
            mobile_number = employee.mobile
            last_name = employee.last_name


            send_gmail2(email2,email)

            message = (
                f"Dear {last_name}, your temporary Uwezo login credentials are below:\n"
                f"Username: {email}\n"
                f"Password: {password}\n"
                f"Login: http://uwezo.live:8000/#login"
                f"Valid for 24 hours. Do not share these details.\n"
                f"Uwezo Data Security."
            )


            send_sms(message=message, phone=mobile_number)

        except Exception as log_err:
            frappe.throw(str(log_err), "Password Log Insert/Expire Error")

        return {
            "success": True,
            "stdout": r.stdout,
            "stderr": r.stderr
        }

    except subprocess.CalledProcessError as e:
        return {
            "success": False,
            "error": "Command failed",
            "stdout": e.stdout,
            "stderr": e.stderr,
            "return_code": e.returncode
        }

    except FileNotFoundError:
        return {
            "success": False,
            "error": "bench command not found."
        }

@frappe.whitelist(allow_guest=True)
def set_frappe_password3(email: str, password: str) -> Dict[str, Any]:

    try:
        # 🔥 EXPIRE ALL OLD LOGS FOR THIS USER
        frappe.db.sql("""
            UPDATE `tabUser Password Log`
            SET is_expired = 1
            WHERE user = %s
        """, (email,))

        frappe.db.commit()

        return {
            "success": True,
            "message": "All password Sessions Deactivated successfully."
        }

    except Exception as e:
        frappe.log_error(str(e), "Expire Password Logs Error")

        return {
            "success": False,
            "error": str(e)
        }


@frappe.whitelist()
def get_security_deposit_amountc(loan, loan_amount):

    loan_amount = float(loan_amount)
    security_deposit_amount = 0

    # Fetch the Loan Application
    loan_doc = frappe.get_doc("Loan Application Plus", loan)

    # Fetch related Loan Product
    loanproduct = frappe.get_doc("Loan Product", {"name": loan_doc.loan_type})

    getbalancer = 0
    # Iterate through loan charges and process based on status
    for charge in loanproduct.product_charges:
        if charge.active and loan_doc.principal > 0:
            charger = frappe.get_doc("Charge", charge.charge)
            am = charger.amount
            if charger.charge_calculation_type == "Percentage":
                am = (charger.max_cap / 100) * loan_doc.principal

            date = nowdate()

            # First GL entry (income side)
            # coa_account_debit = frappe.get_doc("Account", charger.account)
            # debit_entry = frappe.get_doc({
            #     'doctype': 'General Ledger II',
            #     'account': charger.account,
            #     'label_for_report': coa_account_debit.name,
            #     'transaction_type': 1,
            #     'transaction_type_name': charger.charge_name,
            #     'posting_date': datetime.now().date(),
            #     'company': loan_doc.company,
            #     'branch': loan_doc.branch,
            #     'amount': am,
            #     'credit': am,
            #     'debit': 0,
            #     'main_parent': "Income",
            #     'sub_parent': "Income",
            #     'category': coa_account_debit.name,
            #     'savings_account': loan_doc.clients,
            #     'loan': loan_doc.name
            # })
            # debit_entry.insert()
            # debit_entry.submit()

            # # Second GL entry (customer liabilities side)
            # savings_accout = frappe.get_doc("Savings Account", {"name": loan_doc.clients})
            # saving_product = frappe.get_doc("Saving Product", {"name": savings_accout.saving_product})
            # coa_account_name2 = frappe.get_doc("Account", {"name": saving_product.customer_balance_account})
            # saving_transactionr2 = frappe.get_doc({
            #     'doctype': 'General Ledger II',
            #     'account': saving_product.customer_balance_account,
            #     'label_for_report': coa_account_name2.name,
            #     'transaction_type': 1,
            #     'transaction_type_name': charger.charge_name,
            #     'posting_date': datetime.now().date(),
            #     'company': loan_doc.company,
            #     'branch': loan_doc.branch,
            #     'amount': am,
            #     'credit': 0,
            #     'debit': am,
            #     'main_parent': "Liabilities",
            #     'sub_parent': "Balances On Customer Account",
            #     'category': coa_account_name2.name,
            #     'savings_account': loan_doc.clients,
            #     'loan': loan_doc.name
            # })
            # saving_transactionr2.insert()
            # saving_transactionr2.submit()

                        # Create Saving Transaction (moved here from bottom)
            transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": "1"})
            saving_transaction = frappe.get_doc({
                'doctype': 'Saving Transaction',
                'account': loan_doc.account_number,
                'transaction_type': transaction_type,
                'posting_date': date,
                'branch': loan_doc.branch,
                'amount': am,
                'debit': am,
                'client_name': loan_doc.client_name,  # Ensure field exists
                'reference': loan_doc.name,
                'description': f'Loan Charge {charger.charge_name} for {loan_doc.name}',
                'is_parent': 1,
                'allow_charges': 0,
                'loan': loan_doc.name
            })

            saving_transaction.insert()
            saving_transaction.submit()



    return {"status": "success", "message": f"Emergency Fees Charged"}

import frappe

@frappe.whitelist()
def process_security_deposits_for_active_loans():
    """
    Runs through all active loans and applies the security deposit logic.
    """
    results = []

    # Fetch all active loan applications
    active_loans = frappe.get_all(
        "Loan Application Plus",
        filters={"status": "Running"},
        fields=["name", "approved_principle"]
    )

    if not active_loans:
        return {"status": "info", "message": "No active loans found."}

    for loan in active_loans:
        try:
       
            response = get_security_deposit_amount(loan["name"], loan["approved_principle"])
            results.append({"loan": loan["name"], "result": response})
        except Exception as e:
            frappe.log_error(frappe.get_traceback(), f"Security Deposit Processing Error for {loan['name']}")
            results.append({"loan": loan["name"], "result": str(e)})

    return {"status": "completed", "processed": results}

@frappe.whitelist(allow_guest=True)
def update_app_loan(keyword: any = None, amount: any = 0):
    loan = frappe.get_doc("Loan Application Plus", keyword)
    # accountbalance = float(get_total_outstanding(loan.clients))
    keyword2 = keyword
    updated_amount = 0
   

    try:
        amount = float(amount)
    except ValueError:
        return {"status": "error", "message": "Invalid amount provided"}

    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"

        results = frappe.db.sql("""
            SELECT loan_type, principal, clients, branch, company
            FROM `tabLoan Application Plus`
            WHERE 
            name LIKE %(keyword)s
        """, {"keyword": keyword})

        if results:
            loan_type, _, clients, branch, company = results[0]
            principal = amount

            security_deposit = frappe.db.sql("""
                SELECT securitydeposit, checkd
                FROM `tabSecurity_deposit`
                WHERE %(principal)s BETWEEN min AND max AND parent = %(loan_type)s
            """, {"principal": principal, "loan_type": loan_type})

            if security_deposit:
                return security_deposit
                security_deposit_rate, checkd_value = float(security_deposit[0][0]), int(security_deposit[0][1])
                saving_product = frappe.get_doc("Loan Product", {"name": loan_type})

                updated_amount = principal * (saving_product.security_deposit_ / 100) if checkd_value == 1 else security_deposit_rate * (saving_product.security_deposit_ / 100)

                if 1:
                    coa_account_debit = frappe.get_doc("Account", saving_product.cash_collateral_account)

                    existing_entry = frappe.db.exists("General Ledger II", {
                        "account": saving_product.cash_collateral_account,
                        "transaction_type_name": "Security Deposit",
                        "company": company,
                        "branch": branch,
                        "savings_account": clients,
                        "loan": keyword2
                    })

                    frappe.db.sql("""
                        UPDATE `tabLoan Application Plus`
                        SET principal = %(principal)s, amount = %(updated_amount)s, cash_collateral = %(cash_collateral)s
                        , workflow_state = %(workflow_state)s
                        , status = %(workflow_state)s
                        WHERE name LIKE %(keyword)s
                    """, {"updated_amount": updated_amount, "principal": principal, "cash_collateral": "Cash Collateral","workflow_state": "Branch Manager Approval", "keyword": keyword})

                    frappe.db.commit()
                    # t.join()
                    
                    if existing_entry:
                        return {"status": "success", "message": "Security deposit has already been charged for this loan."}
                    
                    debit_entry = frappe.get_doc({
                        'doctype': 'General Ledger II',
                        'account': saving_product.cash_collateral_account,
                        'label_for_report': coa_account_debit.name,
                        'transaction_type': 1,
                        'transaction_type_name': "Security Deposit",
                        'posting_date': datetime.now().date(),
                        'company': company,
                        'branch': branch,
                        'amount': updated_amount,
                        'credit': updated_amount,
                        'debit': 0,
                        'main_parent': "Liabilities",
                        'sub_parent': "Payable",
                        'category': coa_account_debit,
                        'savings_account': clients,
                        'loan': keyword2
                    })
                    debit_entry.insert()
                    debit_entry.submit()
                    
                    savings_account = frappe.get_doc("Savings Account", {"name": clients})
                    saving_product = frappe.get_doc("Saving Product", {"name": savings_account.saving_product})
                    coa_account_name2 = frappe.get_doc("Account", {"name": saving_product.customer_balance_account})
                    
                    existing_entry2 = frappe.db.exists("General Ledger II", {
                        "account": saving_product.customer_balance_account,
                        "transaction_type_name": "Security Deposit",
                        "company": company,
                        "branch": branch,
                        "savings_account": clients,
                        "loan": keyword2
                    })
                    
                    if existing_entry2:
                        return {"status": "error", "message": "Security deposit has already been charged for this loan."}
                    
                    saving_transactionr2 = frappe.get_doc({
                        'doctype': 'General Ledger II',
                        'account': saving_product.customer_balance_account,
                        'label_for_report': coa_account_name2,
                        'transaction_type': 1,
                        'transaction_type_name': "Security Deposit",
                        'posting_date': datetime.now().date(),
                        'company': company,
                        'branch': branch,
                        'amount': updated_amount,
                        'credit': 0,
                        'debit': updated_amount,
                        'main_parent': "Liabilities",
                        'sub_parent': "Balances On Customer Account",
                        'category': coa_account_name2,
                        'savings_account': clients,
                        'loan': keyword2
                    })
                    saving_transactionr2.insert()
                    saving_transactionr2.submit()

                    cash_collateral = amount * 0.25

       

                    return {"status": "success", "message": f"Loan application updated successfully for {loan_type}"}
                else:
                    return {"status": "error", "message": f"Failed to process Security Deposit due to insufficient balance. Security Deposit Amount: {(updated_amount):,} Account Balance: {accountbalance:,}"}
            else:
                return {"status": "error", "message": f"Security deposit settings for Amount {principal} on loan type - {loan_type} not provided!"}
        else:
            return {"status": "error", "message": "Loan type not found for the provided keyword"}
    else:
        return {"status": "error", "message": "Invalid keyword provided"}

@frappe.whitelist(allow_guest=True)
def calculate_principal_and_interest(principal, rate, time, loan_id, start_date, grace_period=0):
    try:
        principal = float(principal)
        rate = float(rate)
        time = int(time)
        start_date = datetime.strptime(start_date, "%Y-%m-%d")
        grace_period = int(grace_period)
    except ValueError:
        return {'error': 'Invalid input. Please ensure that principal, rate, time, start_date, and grace_period are valid.'}

    # Convert annual rate to daily rate
    daily_rate = (rate / 100) / 30

    repayment_schedule = []
    total_payment = 0
    non_skipped_days_count = 0

    # Calculate the number of non-skipped days after the grace period
    for i in range(grace_period, time):
        repayment_date = start_date + timedelta(days=i)
        if repayment_date.weekday() != 6:  # Assuming Sundays are skipped
            non_skipped_days_count += 1
    regular_principal_payment = principal / non_skipped_days_count
    for i in range(time):
        repayment_date = start_date + timedelta(days=i)
        if i < grace_period:
            interest = 0
            principal_payment = 0
            total_due = 0
        else:
            if repayment_date.weekday() == 6:  # Skip Sundays
                continue
            interest = principal * daily_rate
            principal_payment = regular_principal_payment
            total_due = principal_payment + interest

        repayment_schedule.append({
            'date': repayment_date.strftime("%Y-%m-%d"),
            'principal_daily': principal_payment,
            'interest_daily': interest,
            'total_due': total_due
        })

        total_payment += total_due

    # Extract the first payment details
    first_payment_details = repayment_schedule[0]

    return {
        'loan_id': loan_id,
        'interest_rate': rate,
        'loan_term': time,
        'start_date': start_date.strftime("%Y-%m-%d"),
        'end_date': (start_date + timedelta(days=time)).strftime("%Y-%m-%d"),
        'grace_period': grace_period,
        'first_payment_details': first_payment_details
    }

@frappe.whitelist()
def get_total_interest(loan=None):
    if not loan:
        frappe.throw("Loan filter is required")

    # Initialize total_interest
    total_interest = 0
    
    query_filters = {
        "loan": loan,
    }

    query = frappe.db.sql("""
    SELECT 
        transactions.creation AS posting_date, 
        transaction_types.type_name AS description,
        transactions.amount AS loan_deposit,
        0 AS debit,
        0 AS credit,
        transactions.principal_repaid_derived + transactions.principal_recovered AS principal,
        transactions.interest_repaid_derived + transactions.interest_recovered AS interest,
        transactions.penalties_repaid_derived + transactions.penalties_recovered AS penalty,
        transactions.name AS transaction_id,
        'None' AS dd,
        transactions.description AS org_desc
    FROM 
        `tabLoan Transaction2` AS transactions
    LEFT JOIN 
        `tabLoan Transaction Type` AS transaction_types 
    ON 
        transactions.transaction_type = transaction_types.name
    WHERE 
        transactions.loan = %(loan)s
        AND transactions.docstatus = 1

    UNION ALL

    SELECT 
        penalties.creation AS posting_date, 
        'Loan Penalty' AS description,
        0 AS loan_deposit,
        penalties.amount AS debit,
        0 AS credit,
        0 AS principal,
        0 AS interest,
        penalties.penalty AS penalty,
        penalties.name AS transaction_id,
        'None' AS dd,
        'None' AS org_desc
    FROM 
        `tabLoan Penalty II` AS penalties
    WHERE 
        penalties.loan = %(loan)s
        AND penalties.docstatus = 1

    UNION ALL

    SELECT 
        repayments.creation AS posting_date, 
        'Loan Repayment' AS description,
        repayments.amount AS loan_deposit,
        0 AS debit,
        0 AS credit,
        0 AS principal,
        0 AS interest,
        0 AS penalty,
        repayments.name AS transaction_id,
        repayments.payment_method AS dd,
        'None' AS org_desc
    FROM 
        `tabLoan Repayment` AS repayments
    WHERE 
        repayments.loan = %(loan)s
        AND repayments.docstatus = 1

    UNION ALL

    SELECT 
        waives.creation AS posting_date, 
        'Waive Loan II' AS description,
        waives.amount AS loan_deposit,
        0 AS debit,
        waives.amount AS credit,
        0 AS principal,
        0 AS interest,
        0 AS penalty,
        waives.name AS transaction_id,
        waives.waive_type AS dd,
        'None' AS org_desc
    FROM 
        `tabWaive Loan II` AS waives
    WHERE 
        waives.loan = %(loan)s
        AND waives.docstatus = 1

    UNION ALL

    SELECT 
        write_offs.creation AS posting_date, 
        'Write Off Loan II' AS description,
        write_offs.amount AS loan_deposit,
        0 AS debit,
        write_offs.amount AS credit,
        0 AS principal,
        0 AS interest,
        0 AS penalty,
        write_offs.name AS transaction_id,
        write_offs.waive_type AS dd,
        'None' AS org_desc
    FROM 
        `tabWrite Off Loan II` AS write_offs
    WHERE 
        write_offs.loan = %(loan)s
        AND write_offs.docstatus = 1
    
    ORDER BY 
        posting_date
    """, query_filters, as_dict=True)

    if not query:
        return 0

    transactions = []
    running_total = 0
    date_list = []
    repayment_dates = generate_loan_schedule(loan)
    interestleft=0
    for i in query:
        i["interest"] = 0
        i["penalty"] = 0

        if i["description"] == 'Waive Loan II':
            i["loan_deposit"] = 0
            i["description"] = i["description"] + "-" + i["dd"]
            if i["dd"] == "Penalties":
                i["penalty"] = i["credit"]
            else:
                i["interest"] = i["credit"] 

            running_total -= i["credit"]
        elif i["description"] == 'Write Off Loan II':
            i["description"] = i["description"] + "-" + i["dd"]
            i["loan_deposit"] = 0
            running_total -= i["credit"]
            if i["dd"] == "Principle":
                i["principal"] = i["credit"]
            else:
                i["interest"] = i["credit"]
        elif i["description"] == 'Repayment':
            i["description"] = i["org_desc"]
            datetime_obj = i["posting_date"]
            date_obj = datetime_obj.date()

            if date_obj not in date_list and str(date_obj) in repayment_dates:
                
                penalties = frappe.db.sql("""
                    SELECT loan_tenure, principal, payment_intervals, loan_interest
                    FROM `tabLoan Application Plus`
                    WHERE name LIKE %(keyword)s
                    """, {"keyword": loan}, as_dict=True)

                if penalties:
                    for penalty in penalties:
                        loan_tenure = penalty['loan_tenure']
                        principal = penalty['principal']
                        payment_intervals = penalty['payment_intervals']
                        annual_interest_rate =  penalty['loan_interest']
                        daily_interest = ((annual_interest_rate / 100) / 30) * (principal)
                        if interestleft > 0:
                            daily_interest = interestleft
                        
                        if daily_interest >= i["loan_deposit"]:
                            i["principal"] =  0
                            i["interest"] = i["loan_deposit"]
                            interestleft = daily_interest - i["loan_deposit"]
                        else:
                            date_list.append(date_obj)
                            i["principal"] = i["loan_deposit"] - daily_interest
                            i["interest"] = daily_interest
                else:
                    raise ValueError("No penalties found for the specified loan")

                running_total -= i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
            else:
                running_total -= i["loan_deposit"]
                i["principal"] = i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
                i["interest"] = 0
        elif i["description"] == 'Loan Repayment':
            loandata = frappe.get_doc("Loan Application Plus", loan)
            if i["dd"] == "Savings Account":
                i["description"] = "Repayment From Account(" + loandata.clients + ")"
            
            datetime_obj = i["posting_date"]
            date_obj = datetime_obj.date()

            if date_obj not in date_list and str(date_obj) in repayment_dates:
             
                penalties = frappe.db.sql("""
                    SELECT loan_tenure, principal, payment_intervals, loan_interest
                    FROM `tabLoan Application Plus`
                    WHERE name LIKE %(keyword)s
                    """, {"keyword": loan}, as_dict=True)

                if penalties:
                    for penalty in penalties:
                        loan_tenure = penalty['loan_tenure']
                        principal = penalty['principal']
                        payment_intervals = penalty['payment_intervals']
                        annual_interest_rate =  penalty['loan_interest']
                        daily_interest = ((annual_interest_rate / 100) / 30) * (principal)
                        if interestleft > 0:
                            daily_interest = interestleft
                        
                        if daily_interest >= i["loan_deposit"]:
                            i["principal"] =  0
                            i["interest"] = i["loan_deposit"]
                            interestleft = daily_interest - i["loan_deposit"]
                        else:
                            date_list.append(date_obj)
                            i["principal"] = i["loan_deposit"] - daily_interest
                            i["interest"] = daily_interest
                else:
                    raise ValueError("No penalties found for the specified loan")

                running_total -= i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
            else:
                running_total -= i["loan_deposit"]
                i["principal"] = i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
                i["interest"] = 0
            
        elif i["description"] == 'Disbursement' or i["description"] == 'Apply Interest':
            i["debit"] = i["loan_deposit"]
            running_total += i["loan_deposit"]
            i["loan_deposit"] = 0
        else:
            running_total += i["loan_deposit"] if i["description"] != 'Loan Penalty' else i["debit"]

        outstanding_balance = running_total

        transaction = {
            "posting_date": i["posting_date"],
            "description": i["description"],
            "loan_deposit": float(i["loan_deposit"]),
            "debit": float(i["debit"]),
            "credit": float(i["credit"]),
            "principal": float(i["principal"]),
            "interest": float(i["interest"]),
            "penalty": float(i["penalty"]),
            "outstanding": outstanding_balance,
            "transaction_id": i["transaction_id"]
        }

        transactions.append(transaction)

        if i["interest"]:
            total_interest += i["interest"]

    return total_interest


@frappe.whitelist()
def get_total_interestr(loan=None):
    if not loan:
        frappe.throw("Loan filter is required")

    # Initialize total_interest
    total_interest = 0
    
    query_filters = {
        "loan": loan,
    }

    query = frappe.db.sql("""
    SELECT 
        transactions.creation AS posting_date, 
        transaction_types.type_name AS description,
        transactions.amount AS loan_deposit,
        0 AS debit,
        0 AS credit,
        transactions.principal_repaid_derived + transactions.principal_recovered AS principal,
        transactions.interest_repaid_derived + transactions.interest_recovered AS interest,
        transactions.penalties_repaid_derived + transactions.penalties_recovered AS penalty,
        transactions.name AS transaction_id,
        'None' AS dd,
        transactions.description AS org_desc
    FROM 
        `tabLoan Transaction2` AS transactions
    LEFT JOIN 
        `tabLoan Transaction Type` AS transaction_types 
    ON 
        transactions.transaction_type = transaction_types.name
    WHERE 
        transactions.loan = %(loan)s
        AND transactions.docstatus = 1

    UNION ALL

    SELECT 
        penalties.creation AS posting_date, 
        'Loan Penalty' AS description,
        0 AS loan_deposit,
        penalties.amount AS debit,
        0 AS credit,
        0 AS principal,
        0 AS interest,
        penalties.penalty AS penalty,
        penalties.name AS transaction_id,
        'None' AS dd,
        'None' AS org_desc
    FROM 
        `tabLoan Penalty II` AS penalties
    WHERE 
        penalties.loan = %(loan)s
        AND penalties.docstatus = 1

    UNION ALL

    SELECT 
        repayments.creation AS posting_date, 
        'Loan Repayment' AS description,
        repayments.amount AS loan_deposit,
        0 AS debit,
        0 AS credit,
        0 AS principal,
        0 AS interest,
        0 AS penalty,
        repayments.name AS transaction_id,
        repayments.payment_method AS dd,
        'None' AS org_desc
    FROM 
        `tabLoan Repayment` AS repayments
    WHERE 
        repayments.loan = %(loan)s
        AND repayments.docstatus = 1

    UNION ALL

    SELECT 
        waives.creation AS posting_date, 
        'Waive Loan II' AS description,
        waives.amount AS loan_deposit,
        0 AS debit,
        waives.amount AS credit,
        0 AS principal,
        0 AS interest,
        0 AS penalty,
        waives.name AS transaction_id,
        waives.waive_type AS dd,
        'None' AS org_desc
    FROM 
        `tabWaive Loan II` AS waives
    WHERE 
        waives.loan = %(loan)s
        AND waives.docstatus = 1

    UNION ALL

    SELECT 
        write_offs.creation AS posting_date, 
        'Write Off Loan II' AS description,
        write_offs.amount AS loan_deposit,
        0 AS debit,
        write_offs.amount AS credit,
        0 AS principal,
        0 AS interest,
        0 AS penalty,
        write_offs.name AS transaction_id,
        write_offs.waive_type AS dd,
        'None' AS org_desc
    FROM 
        `tabWrite Off Loan II` AS write_offs
    WHERE 
        write_offs.loan = %(loan)s
        AND write_offs.docstatus = 1
    
    ORDER BY 
        posting_date
    """, query_filters, as_dict=True)

    if not query:
        return 0

    transactions = []
    running_total = 0
    interestleft=0
    date_list = []
    repayment_dates = generate_loan_schedule(loan)

    for i in query:
        i["interest"] = 0
        i["penalty"] = 0

        if i["description"] == 'Waive Loan II':
            i["loan_deposit"] = 0
            i["description"] = i["description"] + "-" + i["dd"]
            if i["dd"] == "Penalties":
                i["penalty"] = i["credit"]
            else:
                i["penalty"] = i["credit"] 

            running_total -= i["credit"]
        elif i["description"] == 'Write Off Loan II':
            i["description"] = i["description"] + "-" + i["dd"]
            i["loan_deposit"] = 0
            running_total -= i["credit"]
            if i["dd"] == "Principle":
                i["penalty"] = i["credit"]
            else:
                i["penalty"] = i["credit"]
        elif i["description"] == 'Repayment':
            i["description"] = i["org_desc"]
            datetime_obj = i["posting_date"]
            date_obj = datetime_obj.date()

            if date_obj not in date_list and str(date_obj) in repayment_dates:
                
                penalties = frappe.db.sql("""
                    SELECT loan_tenure, principal, payment_intervals, loan_interest
                    FROM `tabLoan Application Plus`
                    WHERE name LIKE %(keyword)s
                    """, {"keyword": loan}, as_dict=True)

                if penalties:
                    for penalty in penalties:
                        loan_tenure = penalty['loan_tenure']
                        principal = penalty['principal']
                        payment_intervals = penalty['payment_intervals']
                        annual_interest_rate =  penalty['loan_interest']
                        daily_interest = ((annual_interest_rate / 100) / 30) * (principal)
                        if interestleft > 0:
                            daily_interest = interestleft
                        
                        if daily_interest >= i["loan_deposit"]:
                            i["principal"] =  0
                            i["interest"] = i["loan_deposit"]
                            interestleft = daily_interest - i["loan_deposit"]
                        else:
                            date_list.append(date_obj)
                            i["principal"] = i["loan_deposit"] - daily_interest
                            i["interest"] = daily_interest
                else:
                    raise ValueError("No penalties found for the specified loan")

                running_total -= i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
            else:
                running_total -= i["loan_deposit"]
                i["principal"] = i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
                i["interest"] = 0
        elif i["description"] == 'Loan Repayment':
            loandata = frappe.get_doc("Loan Application Plus", loan)
            if i["dd"] == "Savings Account":
                i["description"] = "Repayment From Account(" + loandata.clients + ")"
            
            datetime_obj = i["posting_date"]
            date_obj = datetime_obj.date()

            if date_obj not in date_list and str(date_obj) in repayment_dates:
                penalties = frappe.db.sql("""
                    SELECT loan_tenure, principal, payment_intervals, loan_interest
                    FROM `tabLoan Application Plus`
                    WHERE name LIKE %(keyword)s
                    """, {"keyword": loan}, as_dict=True)

                if penalties:
                    for penalty in penalties:
                        loan_tenure = penalty['loan_tenure']
                        principal = penalty['principal']
                        payment_intervals = penalty['payment_intervals']
                        annual_interest_rate =  penalty['loan_interest']
                        daily_interest = ((annual_interest_rate / 100) / 30) * (principal)
                        if interestleft > 0:
                            daily_interest = interestleft
                        
                        if daily_interest >= i["loan_deposit"]:
                            i["principal"] =  0
                            i["interest"] = i["loan_deposit"]
                            interestleft = daily_interest - i["loan_deposit"]
                        else:
                            date_list.append(date_obj)
                            i["principal"] = i["loan_deposit"] - daily_interest
                            i["interest"] = daily_interest
                else:
                    raise ValueError("No penalties found for the specified loan")

                running_total -= i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
            else:
                running_total -= i["loan_deposit"]
                i["principal"] = i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
                i["interest"] = 0
            
        elif i["description"] == 'Disbursement' or i["description"] == 'Apply Interest':
            i["debit"] = i["loan_deposit"]
            running_total += i["loan_deposit"]
            i["loan_deposit"] = 0
        else:
            running_total += i["loan_deposit"] if i["description"] != 'Loan Penalty' else i["debit"]

        outstanding_balance = running_total

        transaction = {
            "posting_date": i["posting_date"],
            "description": i["description"],
            "loan_deposit": float(i["loan_deposit"]),
            "debit": float(i["debit"]),
            "credit": float(i["credit"]),
            "principal": float(i["principal"]),
            "interest": float(i["interest"]),
            "penalty": float(i["penalty"]),
            "outstanding": outstanding_balance,
            "transaction_id": i["transaction_id"]
        }

        transactions.append(transaction)

        if i["interest"]:
            total_interest += i["interest"]

    return total_interest




@frappe.whitelist()
def get_loan_payments_sim(loan_id):
    if not loan_id:
        frappe.throw(_("Loan ID is required"))
    payments = frappe.get_all(
        'Loan Transaction2',
        filters={'loan': loan_id},
        fields=['created_on', 'amount'],
        order_by='created_on asc'
    )
    return payments

@frappe.whitelist(allow_guest=True)
def search_savingproducts_desk(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabSaving Product` as tb
        WHERE  tb.product_name like %(keyword)s 
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results


@frappe.whitelist(allow_guest=True)
def search_loanproducts_desk(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabLoan Product` as tb
        WHERE  tb.name like %(keyword)s 
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results

from frappe.utils import now_datetime, add_days

@frappe.whitelist(allow_guest=True)
def getcurrent_cycle_running(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabSavings Cycle` as tb
        WHERE tb.status='running' and tb.savings_account like %(keyword)s 
        """, {"keyword": keyword}, as_dict=True)
        
        if data:
            results = data
        else:
            # Calculate the running total for the savings account
            account_name = keyword.strip('%')
            running_total = get_total_outstanding(account_name)

            savings_account = frappe.get_doc("Savings Account", {"name": account_name})
            saving_product = frappe.get_doc("Saving Product", {"name": savings_account.saving_product})
            interest_rate = saving_product.interest_rate
            fixed_interest_tenure = int(saving_product.cycle_period)  # Convert to integer
            account_holder_name = savings_account.client_name
            
            # Calculate stop_date by adding fixed_interest_tenure days to the current date
            start_date = now_datetime()
            stop_date = add_days(start_date, fixed_interest_tenure)
            
            # If no running cycle is found, create a new Savings Cycle
            new_cycle = frappe.get_doc({
                "doctype": "Savings Cycle",
                "savings_account": account_name,  # Assuming the keyword without wildcards is the account name
                "status": "Running",
                "account_holder_name": account_holder_name,  # Set to client_name from Savings Account
                "start_triggered_by": "First Deposit",
                "balance_on_start": running_total,
                "balance_on_close": 0.000,
                "interest_rate": interest_rate,  # Set the interest rate from Savings Product
                "start_date": start_date,  # Set the current date and time
                "stop_date": stop_date,  # Set the calculated stop date
                "total_interest_collected": 0.000,
                "end_triggered_by": None  # Assuming end_triggered_by is a string, set a default value
            })
            new_cycle.insert()
            frappe.db.commit()
            results = [new_cycle]
    return results

from frappe.utils import now_datetime, add_days

@frappe.whitelist(allow_guest=True)
def close_cycle_renew(account):
    try:
        # Fetch all running cycles for the given account
        running_cycles = frappe.get_all("Savings Cycle", filters={"savings_account": account, "status": "running"})
        
        for cycle in running_cycles:
            doc = frappe.get_doc("Savings Cycle", cycle.name)
            
            # Ensure numeric conversion
            balance_on_start = float(doc.balance_on_start or 0)
            interest_rate = float(doc.interest_rate or 0)
            total_interest_collected = 0
            
            # Calculate total interest collected for the old cycle
            for month in range(1, 13):
                total_interest_collected += (balance_on_start * interest_rate / 100) / 12
            total_interest_collected += balance_on_start * (interest_rate / 100)  # Bonus for the 12th month
            
            # Update the old cycle
            doc.status = "closed"
            doc.balance_on_close = get_total_outstanding(account)
            doc.end_triggered_by = "Withdraw"
            doc.total_interest_collected = 0
            doc.save()
        
        # Calculate the running total for the savings account
        running_total = get_total_outstanding(account)

        # Fetch the interest rate and tenure from the related Savings Product
        savings_account = frappe.get_doc("Savings Account", {"name": account})
        saving_product = frappe.get_doc("Saving Product", {"name": savings_account.saving_product})
        interest_rate = float(saving_product.interest_rate or 0)  # Convert to float
        fixed_interest_tenure = int(saving_product.cycle_period)  # Convert to integer
        account_holder_name = savings_account.client_name
        
        # Calculate stop_date by adding fixed_interest_tenure days to the current date
        start_date = now_datetime()
        stop_date = add_days(start_date, fixed_interest_tenure)

        # Create a new Savings Cycle
        new_cycle = frappe.get_doc({
            "doctype": "Savings Cycle",
            "savings_account": account,
            "status": "Running",
            "account_holder_name": account_holder_name,  # Set to client_name from Savings Account
            "start_triggered_by": "Withdraw",
            "balance_on_start": running_total,
            "balance_on_close": 0.000,
            "interest_rate": interest_rate,  # Set the interest rate from Savings Product
            "start_date": start_date,  # Set the current date and time
            "stop_date": stop_date,  # Set the calculated stop date
            "total_interest_collected": 0.000,
            "end_triggered_by": None  # Assuming end_triggered_by is a string, set a default value
        })
        new_cycle.insert()
        frappe.db.commit()

        return {"status": "success", "message": "All running cycles closed and new cycle started."}
    except Exception as e:
        frappe.log_error(f"Error in close_cycle_renew: {str(e)}")
        return {"status": "failed", "message": str(e)}


@frappe.whitelist(allow_guest=True)
def getloan_cycle_running(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabLoan cycles` as tb
        WHERE tb.status='running' and tb.loan like %(keyword)s 
        """, {"keyword": keyword}, as_dict=True)
        
        if data:
            results = data
        else:
            # Calculate the running total for the savings account
            account_name = keyword.strip('%')
            loan_app = frappe.get_doc("Loan Application Plus", {"name": account_name})
            loan_disbusment = frappe.get_doc("Loan Disbursement", {"loan": loan_app.name})
            interest_rate = loan_app.loan_interest
            principle = loan_app.principal  # Convert to integer
            interest_expected = loan_app.loan_interest_expected
            # Calculate stop_date by adding fixed_interest_tenure days to the current date
            start_date = loan_disbusment.disbursement_date
            stop_date = add_days(start_date, loan_app.loan_tenure)
            # If no running cycle is found, create a new Savings Cycle
            new_cycle = frappe.get_doc({
                "doctype": "Loan cycles",
                "loan": account_name,  # Assuming the keyword without wildcards is the account name
                "status": "Running",
                "account_holder_name": loan_app.client_name,  # Set to client_name from Savings Account
                "start_triggered_by": "Loan Disbursment",
                "balance_on_start":principle,
                "balance_on_close":interest_expected,
                "interest_rate": interest_rate,  # Set the interest rate from Savings Product
                "start_date": start_date,  # Set the current date and time
                "stop_date": stop_date,  # Set the calculated stop date
                "total_interest_collected": 0.000,
                "end_triggered_by": None  # Assuming end_triggered_by is a string, set a default value
            })
            new_cycle.insert()
            frappe.db.commit()
            results = [new_cycle]
    return results


@frappe.whitelist(allow_guest=True)
def update_savings_accounts_from_clients(batch_size=200000):
    try:
        while True:
            savings_accounts = frappe.db.sql("""
                SELECT name, External_ID, client
                FROM `tabSavings Account`
                WHERE client = 'CLN-102777654'
                LIMIT %s
            """, (batch_size,), as_dict=True)

            if not savings_accounts:
                break

            external_ids = tuple(account["External_ID"] for account in savings_accounts)
            if not external_ids:
                continue

            placeholders = ', '.join(['%s'] * len(external_ids))
            client_data = frappe.db.sql(f"""
                SELECT external_id, full_name as client_name, name
                FROM `tabClient`
                WHERE external_id IN ({placeholders})
            """, external_ids, as_dict=True)

            client_mapping = {
                client["external_id"]: {
                    "client_name": client["client_name"],
                    "client": client["name"]
                }
                for client in client_data
            }

            updates = [
                (
                    client_mapping[account["External_ID"]]["client_name"],
                    client_mapping[account["External_ID"]]["client"],
                    account["name"]
                )
                for account in savings_accounts
                if account["External_ID"] in client_mapping
            ]

            if updates:
                for update in updates:
                    frappe.db.sql("""
                        UPDATE `tabSavings Account`
                        SET client_name = %s, client = %s
                        WHERE name = %s
                    """, update)

            frappe.db.commit()

        return {"message": "All Savings Accounts updated successfully.", "status": "success"}

    except Exception as e:
        frappe.db.rollback()
        frappe.log_error(frappe.get_traceback(), 'Update Savings Accounts Error')
        return {"message": str(e), "status": "error"}
        
@frappe.whitelist(allow_guest=True)
def update_loan_applications_from_savings():
    try:
        frappe.db.sql("SET SQL_SAFE_UPDATES = 0")
        frappe.db.sql("SET FOREIGN_KEY_CHECKS = 0")
        frappe.db.sql("SET SQL_BIG_SELECTS = 1")

        frappe.db.sql("""
            UPDATE `tabLoan Application Plus` lap
            JOIN `tabSavings Account` sa
                ON sa.external_id = lap.loan_fees_payment_date
            SET lap.clients = sa.name,
                lap.client_name = sa.client_name,
                lap.account_number = sa.name
            WHERE lap.clients = '10955726420614'
        """)

        frappe.db.commit()

        return {
            "message": "Loan Applications updated from Savings Accounts successfully.",
            "status": "success"
        }

    except Exception as e:
        frappe.db.rollback()
        frappe.log_error(frappe.get_traceback(), 'Update Loan Applications from Savings Error')
        return {
            "message": str(e),
            "status": "error"
        }



@frappe.whitelist(allow_guest=True)
def update_savings_transactions():
    try:
        batch_size = 20  # Number of records to process per iteration
        while True:
            # Step 1: Fetch a batch of transactions with NULL client_name
            transactions = frappe.db.sql(f"""
                SELECT name, account_id
                FROM `tabSaving Transaction`
                WHERE client_name IS NULL
                LIMIT {batch_size}
            """, as_dict=True)

            if not transactions:
                # Exit the loop when no more transactions are left
                break

            # Extract account IDs from the transactions
            account_ids = tuple(transaction["account_id"] for transaction in transactions)

            # Step 2: Fetch related savings account data in one query
            if account_ids:
                savings_accounts = frappe.db.sql(f"""
                    SELECT external_number, client_name, name AS account_name
                    FROM `tabSavings Account`
                    WHERE external_number IN {account_ids}
                """, as_dict=True)

                # Map account_id to client_name and account
                account_mapping = {
                    account["external_number"]: {"client_name": account["client_name"], "account": account["account_name"]}
                    for account in savings_accounts
                }

                # Step 3: Prepare bulk update data
                updates = []
                for transaction in transactions:
                    account_id = transaction["account_id"]
                    if account_id in account_mapping:
                        client_name = account_mapping[account_id]["client_name"]
                        account_name = account_mapping[account_id]["account"]
                        updates.append((client_name, account_name, transaction["name"]))

                # Step 4: Execute bulk update
                if updates:
                    frappe.db.sql("""
                        UPDATE `tabSaving Transaction`
                        SET client_name = %s, account = %s
                        WHERE name = %s
                    """, updates, multi=True)

            # Commit the transaction after each batch
            frappe.db.commit()

        # Return success message after all records are processed
        return {"message": "All Savings Transactions updated successfully.", "status": "success"}
    
    except Exception as e:
        # Rollback in case of an error
        frappe.db.rollback()
        return {"message": str(e), "status": "error"}

    except Exception as e:
        # Handle and log exceptions
        frappe.log_error(frappe.get_traceback(), 'Update Savings Transactions Error')
        return {"message": f"An error occurred: {str(e)}", "status": "error"}


    except Exception as e:
        # Log the exception and return an error message
        frappe.log_error(message=str(e), title="Error in update_savings_transactions")
        return f"Error: {str(e)}"


@frappe.whitelist(allow_guest=True)
def save_document(doc):
        # Convert the JSON string to a dictionary
        doc_data = frappe.parse_json(doc)
        # Update the frozen_amount using raw SQL
        sql = """
            UPDATE `tabSavings Account`
            SET frozen_amount = %s
            WHERE name = %s
        """
        values = (doc_data.get("frozen_amount", 0), doc_data["name"])
        
        frappe.db.sql(sql, values)
        
        # Commit the transaction
        frappe.db.commit()
        
        return "Document updated and frozen_amount set successfully"

    
@frappe.whitelist(allow_guest=True)
def close_loancycle_renew(account):
    try:
        # Fetch all running cycles for the given account
        running_cycles = frappe.get_all("Loan cycles", filters={"loan": account, "status": "running"})
        
        for cycle in running_cycles:
            doc = frappe.get_doc("Loan cycles", cycle.name)
            
            # Ensure numeric conversion
            balance_on_start = float(doc.balance_on_start or 0)
            interest_rate = float(doc.interest_rate or 0)
            total_interest_collected = 0
            
            # Calculate total interest collected for the old cycle
            for month in range(1, 13):
                total_interest_collected += (balance_on_start * interest_rate / 100) / 12
            total_interest_collected += balance_on_start * (interest_rate / 100)  # Bonus for the 12th month
            
            # Update the old cycle
            doc.status = "closed"
            doc.save()
        
                   

        return {"status": "success", "message": "All running cycles closed "}
    except Exception as e:
        frappe.log_error(f"Error in close_cycle_renew: {str(e)}")
        return {"status": "failed", "message": str(e)}
    

@frappe.whitelist(allow_guest=True)
def fixed_account_closure():
    today = datetime.now().date()
    current_month = today.month
    current_year = today.year
    summary_details = "No savings accounts processed."
    
    # Fetch all savings accounts with their associated saving product
    savings_accounts = frappe.get_list("Savings Account", fields=["name", "saving_product"])
    
    for account in savings_accounts:
        try:
            # Retrieve the associated saving product document
            savings_product = frappe.get_doc("Saving Product", account.saving_product)
            
            # Skip if the saving product is not fixed
            if not savings_product.is_fixed:
                continue
            
            # Get parameters from the saving product document
            annual_rate = savings_product.interest_rate / 100  # Convert percentage to decimal
            monthly_rate = annual_rate / 12  # Monthly interest rate
            minimum_savings_per_month = savings_product.minimum_savings_per_month or 250000
            minimum_annual_savings = savings_product.minimum_annual_savings or 3000000
            
            # Retrieve the active savings cycle for the account
            active_cycle_list = frappe.get_list(
                "Savings Cycle",
                fields=["name", "savings_account", "start_date", "stop_date", "status"]
            )
            
            for active_list in active_cycle_list:
                if active_list.status == "Running" and active_list.savings_account == account.name:
                    # Get the first active cycle document
                    cycle_doc = frappe.get_doc("Savings Cycle", active_list.name)
                    
                    # Skip if the stop_date of the active cycle is not today
                    if cycle_doc.stop_date and cycle_doc.stop_date.date() != today:
                        continue
                    
                    total_interest = 0
                    total_interest_before_last_month = 0
                    is_disqualified = False
                    total_annual_savings = 0
                    month_details = []
                    
                    for month in range(1, 13):
                        month_name = calendar.month_name[month].lower()
                        # Calculate the start and end dates of the current month
                        start_of_month = datetime(current_year, month, 1)
                        end_of_month = (start_of_month.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)

                        
                        # Get the balance for the end of the current month
                        end_of_month_balance_str = cycle_doc.get(month_name) or '0'
                        end_of_month_balance = float(end_of_month_balance_str)  # Convert to float
                        
                        # Fetch deposit transactions within the start and end dates of the current month
                        deposits = frappe.get_all(
                            "Deposit",
                            filters={
                               
                                "account": account.name,
                                "posting_date": ["between", [start_of_month, end_of_month]]
                            },
                            fields=["amount", "posting_date"]
                                                        )
                        
                        # Calculate total deposits for the current month
                        total_deposits = sum(d.amount for d in deposits)
                        meets_minimum_savings = end_of_month_balance >= minimum_savings_per_month
                        
                        # Calculate interest for the month
                        if end_of_month_balance < minimum_savings_per_month:
                            interest_for_month = 0
                            month_details.append(f"{month_name.capitalize()}:\n"
                                             f"End-of-Month Balance: {end_of_month_balance:.2f}\n"
                                             f"Deposits: {total_deposits}\n"
                                             f"Meets Minimum Savings: {'No'} "
                                             f"({end_of_month_balance:.2f} < {minimum_savings_per_month:.2f})\n"
                                             f"Interest: 0.00\n"
                                             f"Total Annual Savings: {total_annual_savings:.2f}\n")
                        else:
                            interest_for_month = monthly_rate * end_of_month_balance
                            month_details.append(f"{month_name.capitalize()}:\n"
                                             f"End-of-Month Balance: {end_of_month_balance:.2f}\n"
                                             f"Deposits: {total_deposits:.2f}\n"
                                             f"Meets Minimum Savings: {'Yes'} "
                                             f"({end_of_month_balance:.2f} >= {minimum_savings_per_month:.2f})\n"
                                             f"Interest: {end_of_month_balance:.2f} * {monthly_rate:.4f} = {interest_for_month:.2f}\n"
                                             f"Total Annual Savings: {total_annual_savings + end_of_month_balance:.2f}\n")
                        
                        # Add to total annual savings
                        total_annual_savings += end_of_month_balance
                    
                        if month == 12:
                            total_interest += 2 * interest_for_month
                        else:
                            total_interest_before_last_month += interest_for_month
                            total_interest += interest_for_month
                    
                    # Check for disqualification and adjust total interest if necessary
                    if is_disqualified or total_annual_savings < minimum_annual_savings:
                        total_interest = 0
                        qualification_summary = "Check Qualifications:\nIs Disqualified: Yes (Some months have savings less than 250,000 or total annual savings do not exceed 3,000,000)"
                    else:
                        qualification_summary = f"Check Qualifications:\nIs Disqualified: No (All months have savings greater than 250,000, and total annual savings exceed 3,000,000)\n" \
                                            f"Total Annual Savings: {total_annual_savings:.2f} (exceeds the minimum requirement)"
                
                    # Compile the final summary details
                    interest_summary = f"Total Interest Calculation:\n" \
                                   f"Interest for January to November: {total_interest_before_last_month:.2f}\n" \
                                   f"December Interest (or last month): {total_interest - total_interest_before_last_month:.2f}\n" \
                                   f"Total Interest Collected: {total_interest:.2f}"
                
                    summary_details = "\n".join(month_details) + "\n\n" + qualification_summary + "\n\n" + interest_summary
                
                    # Update the cycle document with the calculated interest and savings
                    cycle_doc.total_interest_collected = total_interest
                    cycle_doc.total_annual_savings = total_annual_savings
                    cycle_doc.summary = summary_details  # Update summary with detailed calculation breakdown
                    
                    # Save the updated cycle document
                    cycle_doc.save()
                    
                    # Call the function to handle cycle closure
                    close_cycle_renew2(account.name)
        
            return summary_details
        except Exception as e:
            return f"Error processing account {account.name}: {e}", "Fixed Account Closure Error"


            
@frappe.whitelist(allow_guest=True)
def close_cycle_renew2(account):
    try:
        # Fetch all running cycles for the given account
        running_cycles = frappe.get_all("Savings Cycle", filters={"savings_account": account, "status": "running"})
        
        for cycle in running_cycles:
            doc = frappe.get_doc("Savings Cycle", cycle.name)
            
            # Ensure numeric conversion
            balance_on_start = float(doc.balance_on_start or 0)
            interest_rate = float(doc.interest_rate or 0)
            total_interest_collected = 0
            
            # Calculate total interest collected for the old cycle
            for month in range(1, 13):
                total_interest_collected += (balance_on_start * interest_rate / 100) / 12
            total_interest_collected += balance_on_start * (interest_rate / 100)  # Bonus for the 12th month
            
            # Update the old cycle
            doc.status = "closed"
            doc.balance_on_close = get_total_outstanding(account)
            doc.end_triggered_by = "Closing Cycle"
            doc.total_interest_collected = 0
            doc.save()
        
        # Calculate the running total for the savings account
        running_total = get_total_outstanding(account)

        # Fetch the interest rate and tenure from the related Savings Product
        savings_account = frappe.get_doc("Savings Account", {"name": account})
        saving_product = frappe.get_doc("Saving Product", {"name": savings_account.saving_product})
        interest_rate = float(saving_product.interest_rate or 0)  # Convert to float
        fixed_interest_tenure = int(saving_product.cycle_period)  # Convert to integer
        account_holder_name = savings_account.client_name
        
        # Calculate stop_date by adding fixed_interest_tenure days to the current date
        start_date = now_datetime()
        stop_date = add_days(start_date, fixed_interest_tenure)

        # Create a new Savings Cycle
        new_cycle = frappe.get_doc({
            "doctype": "Savings Cycle",
            "savings_account": account,
            "status": "Running",
            "account_holder_name": account_holder_name,  # Set to client_name from Savings Account
            "start_triggered_by": "New Cycle",
            "balance_on_start": running_total,
            "balance_on_close": 0.000,
            "interest_rate": interest_rate,  # Set the interest rate from Savings Product
            "start_date": start_date,  # Set the current date and time
            "stop_date": stop_date,  # Set the calculated stop date
            "total_interest_collected": 0.000,
            "end_triggered_by": None  # Assuming end_triggered_by is a string, set a default value
        })
        new_cycle.insert()
        frappe.db.commit()

        return {"status": "success", "message": "All running cycles closed and new cycle started."}
    except Exception as e:
        frappe.log_error(f"Error in close_cycle_renew: {str(e)}")
        return {"status": "failed", "message": str(e)}


@frappe.whitelist(allow_guest=True)
def search_savings_account_desk(keyword: any = None):
    results = []
    
    # Check if keyword is empty, if so, return all savings accounts
    if not keyword:
        data = frappe.db.sql("""
        SELECT *
        FROM `tabSavings Account`
        """, as_dict=True)
    elif len(keyword) < 3:
        return results
    else:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabSavings Account`
        WHERE name LIKE %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
    
    if data:
        results = data
    return results

@frappe.whitelist(allow_guest=True)
def search_savings_transaction_bydate_api(keyword: any = None, from_date: any = None, to_date: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        filters = {"keyword": keyword}
        query = """
        SELECT *
        FROM `tabSaving Transaction` as st  
        JOIN `tabSavings Account` as sa ON st.account = sa.name 
        JOIN tabClient as cl ON sa.client = cl.name
        WHERE cl.mobile LIKE %(keyword)s
        """
        if not from_date:
            from_date = datetime.now().strftime('%Y-%m-%d')
        if not to_date:
            to_date = datetime.now().strftime('%Y-%m-%d')

        filters["from_date"] = from_date
        filters["to_date"] = to_date

        query += " AND st.creation BETWEEN %(from_date)s AND %(to_date)s limit 100"
        
        data = frappe.db.sql(query, filters, as_dict=True)
        
        if data:
            results = data
    return results


@frappe.whitelist(allow_guest=True)
def search_loans_api_desk(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabLoan` as ln  join tabClient as cl on ln.client = cl.name join `tabLoan Product` as lp on ln.loan_product = lp.name
        WHERE  cl.mobile like %(keyword)s limit 100
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results

@frappe.whitelist(allow_guest=True)
def getintere(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabLoan` as ln  join tabClient as cl on ln.client = cl.name join `tabLoan Product` as lp on ln.loan_product = lp.name
        WHERE  cl.mobile like %(keyword)s limit 100
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results


@frappe.whitelist(allow_guest=True)
def process_charges2():

    # Retrieve all savings accounts
    savings_accounts = frappe.get_list("Savings Account", fields=["name", "saving_product"])  # Adjust fields if necessary

    for account in savings_accounts:
        try:
            # Retrieve the associated saving product document
            savings_product = frappe.get_doc("Saving Product", account.saving_product)

            # Get the total outstanding balance for the account
            total_outstanding = get_total_outstanding(account.name)

            # Update the balance field in the saving product document
            savings_product.balance_derived = total_outstanding
            savings_product.save()  # Save the updated document

            frappe.log_error(
                f"Updated Balance for Savings Product: {savings_product.name} to {total_outstanding}",
                "Process Charges 2"
            )

        except frappe.DoesNotExistError as e:
            frappe.log_error(f"Missing Resource: {str(e)}", "Process Charges 2")
        except Exception as e:
            frappe.log_error(f"Error processing account {account.name}: {str(e)}", "Process Charges 2")

    frappe.db.commit()
import frappe
import pymysql
from datetime import datetime


@frappe.whitelist(allow_guest=True)
def get_value(doctype, filters, fieldname):
    """
    Custom wrapper to fetch a single field value from a given doctype
    using filters (like frappe.db.get_value but available via mfis.client).
    """
    if isinstance(filters, str):
        filters = frappe.parse_json(filters)
    value = frappe.db.get_value(doctype, filters, fieldname)
    return { fieldname: value }
@frappe.whitelist(allow_guest=True)
def get_total_outstanding2(account):
    """
    Stream transaction data efficiently for a specific account, 
    compute running balances, and update account status.
    This version is fully compatible with Frappe 14 and removes the invalid index hint.
    """
    import frappe
    import pymysql
    from datetime import datetime

    filters = {'account': account}
    conditions, query_filters = build_conditions(filters)

    # ✅ Clean query without FORCE INDEX (removed to prevent OperationalError 1176)
    query = f"""
        SELECT 
            t1.creation, t1.description, t1.amount, t1.transaction_type_name, t1.name
        FROM `tabSaving Transaction` t1
        WHERE t1.account = %(account)s AND t1.flagged = 0 {conditions}
        ORDER BY t1.creation
    """

    conn = frappe.db.get_connection()

    # ✅ Use server-side cursor for efficiency on large datasets
    cursor = conn.cursor(pymysql.cursors.SSCursor)
    cursor.execute(query, query_filters)

    balance = total_credit = total_debit = 0.0
    last_posting_date = None
    batch_count = 0

    lower = str.lower
    classify = classify_transaction
    log = frappe.logger().info

    for row in cursor:
        posting_date, description, amount, transaction_type_name, transaction_id = row

        if not posting_date:
            continue

        if isinstance(posting_date, str):
            posting_date = datetime.strptime(posting_date[:10], "%Y-%m-%d")

        desc = lower(description or "")
        amt = float(amount or 0)
        last_posting_date = posting_date

        if "account opening" in desc:
            balance -= abs(amt)
            c = classify(desc, amt)
            total_credit += c["credit"]
            total_debit += c["debit"]
            continue

        c = classify(desc, amt)
        total_credit += c["credit"]
        total_debit += c["debit"]
        balance += c["credit"] - c["debit"]

        if "security deposit" in desc:
            desc2 = ("d" if transaction_type_name == "deposit" else "w") + desc
            c = classify(desc2, amt)
            total_credit += c["credit"]
            total_debit += c["debit"]
            balance += c["credit"] - c["debit"]

        batch_count += 1
        if batch_count % 100000 == 0:
            log(f"Processed {batch_count:,} rows for account {account}")

    cursor.close()

    if last_posting_date:
        today = datetime.today()
        days_diff = (today - last_posting_date).days
        status = "Inactive" if days_diff >= 90 else "Active"
        workflow_state = "Deactivated" if days_diff >= 90 else "Activated"

        frappe.db.sql(
            """
            UPDATE `tabSavings Account`
            SET balance_derived = %s,
                overdraft_derived = %s,
                status = %s,
                workflow_state = %s
            WHERE name = %s
            """,
            (balance, last_posting_date, status, workflow_state, account),
        )
        frappe.db.commit()

    log(f"Completed {batch_count:,} transactions for {account}. Final balance = {balance}")
    return balance



@frappe.whitelist(allow_guest=True)  
def get_total_outstanding(account):
    """
    Fetch transaction data from the database, categorize transactions,
    and calculate running balances for a specific account.
    """
    filters = {'account': account}  # Directly pass account as a filter
    conditions, query_filters = build_conditions(filters)

    query = f"""
    SELECT 
        t1.creation AS posting_date, 
        t1.description, 
        t1.amount,
        t2.suba,
        t1.transaction_type_name,
        t1.name AS transaction_id
    FROM `tabSaving Transaction` t1
    LEFT JOIN `tabDeposit` t2 ON t2.name = t1.deposit
    WHERE t1.account = %(account)s
      AND t1.flagged = 0
      {conditions}
    ORDER BY t1.creation
    """

    transactions = frappe.db.sql(query, query_filters, as_dict=True)

    if not transactions:
        return 0

    # Process transactions
    balance = 0
    total_credit = 0
    total_debit = 0
    for transaction in transactions:
        description = transaction.get("description", "").lower()
        amount = transaction.get("amount", 0)
        transaction_type_name = transaction.get("transaction_type_name")


        # Ensure correct amount for "account opening"
        if "account opening" in description:
            balance -= abs(amount)  
            amount = abs(amount) 

            # Classify transaction
            classification = classify_transaction(description, amount)
            transaction.update(classification)

            # Update totals
            total_credit += classification["credit"]
            total_debit += classification["debit"]

            # Compute running balance
            transaction["balance"] = balance

        else:
            # Classify transaction
            classification = classify_transaction(description, amount)
            transaction.update(classification)

            # Update totals
            total_credit += classification["credit"]
            total_debit += classification["debit"]

            # Compute running balance
            balance += classification["credit"] - classification["debit"]
            transaction["balance"] = balance 

            if "security deposit" in description:
                if transaction_type_name == "deposit":
                    description = "d" + description
                    transaction["description"] = "D-" + transaction["description"]
                else:
                    description = "w" + description
                    transaction["description"] = "W-" + transaction["description"]

                # Classify transaction again for security deposit
                classification = classify_transaction(description, amount)
                transaction.update(classification)

                # Update totals
                total_credit += classification["credit"]
                total_debit += classification["debit"]

                # Compute running balance
                balance += classification["credit"] - classification["debit"]
                transaction["balance"] = balance

    from datetime import datetime, timedelta

    posting_date = transaction["posting_date"]
    if isinstance(posting_date, str):
        posting_date = datetime.strptime(posting_date, "%Y-%m-%d")

    today = datetime.today()
    days_diff = (today - posting_date).days

    new_status = "Inactive" if days_diff >= 90 else "Active"
    new_status2 = "Deactivated" if days_diff >= 90 else "Activated"

    frappe.db.sql(
        """
        UPDATE `tabSavings Account`
        SET balance_derived = %s,
            overdraft_derived = %s,
            status = %s,
            workflow_state = %s
        WHERE name = %s
        """,
        (balance, transaction["posting_date"], new_status,new_status2, account),
    )

    frappe.db.commit()


    return balance


@frappe.whitelist(allow_guest=True)
def process_all_savings_accounts_balances():
    # Fetch all savings account names with single combined filter
    accounts = frappe.db.sql("""
        SELECT name
        FROM `tabSavings Account`
        WHERE overdraft_derived = '0.000000000'
          AND (status != 'Active' OR status = 'Inactive')
    """, as_dict=True)

    for account_doc in accounts:
        account = account_doc.name
        try:
            # Call your function for each account
            outstanding = get_total_outstanding(account)
            print(f"Account: {account}, Total Outstanding: {outstanding}")
        except Exception as e:
            print(f"Error processing account {account}: {e}")


def build_conditions(filters):
    """
    Build SQL conditions based on the filters provided.
    """
    conditions = []
    query_filters = {
        "account": filters["account"],
        "account2": filters.get("account2"),
        "branch": filters.get("branch"),
        "from_date": filters.get("from_date"), 
        "to_date": filters.get("to_date"),
    }

    if filters.get("from_date"):
        conditions.append("t1.creation >= %(from_date)s")
    if filters.get("to_date"):
        conditions.append("t1.creation <= %(to_date)s")
    if filters.get("account2"):
        conditions.append("t2.suba = %(account2)s")

    condition_str = " AND ".join(conditions)
    if condition_str:
        condition_str = " AND " + condition_str

    return condition_str, query_filters
def classify_transaction(description, amount):
    """
    Classify a transaction based on its description and assign credit/debit values.
    """
    amount = round(amount)
    description = description.lower().strip()

    # Define classification rules (order matters: specific first, general later)
    rules = [
        ("deposit fees", {"credit": 0, "debit": amount}),  
        ("account opening3", {"credit": 0, "debit": amount}),  
        ("account opening2", {"credit": amount, "debit": 0}),  # Already made negative in get_data
        ("account opening", {"credit": amount, "debit": amount}),
        ("opening balance", {"credit": amount, "debit": 0}),
        ("monthly ", {"credit": 0, "debit": amount}),
        ("withdraw fees", {"credit": 0, "debit": amount}),
        ("withdraw penalty", {"credit": 0, "debit": amount}),
        ("withdraw", {"credit": 0, "debit": amount}),
        ("cash collateral", {"credit": 0, "debit": amount}),
        ("transfer to", {"credit": 0, "debit": amount}),
        ("transfer from", {"credit": amount, "debit": 0}),
        ("charge", {"credit": 0, "debit": amount}),
        ("loan security", {"credit": amount, "debit": 0}),
        ("loan closure", {"credit": 0, "debit": amount}),
        ("dsecurity", {"credit": amount, "debit": 0}),
        ("wsecurity", {"credit": 0, "debit": amount}),
        ("security", {"credit": 0, "debit": amount}),
        ("approval", {"credit": 0, "debit": amount}),
        ("fees payment", {"credit": 0, "debit": amount}),
        ("disbursement", {"credit": amount, "debit": 0}),
        ("loan application fee", {"credit": 0, "debit": amount}),
        ("loan charge", {"credit": 0, "debit": amount}),
        ("loan insurance", {"credit": 0, "debit": amount}),
        ("refund of loan insurance", {"credit": amount, "debit": 0}),
        ("loan repayment", {"credit": 0, "debit": amount}),
        ("deposit", {"credit": amount, "debit": 0}),
        ("reconciliation", {"credit": 0, "debit": amount}),  # General rule
    ]

    # Match the description against rules
    for keyword, result in rules:
        if keyword in description:
            return result

    # Default classification (credit if amount > 0, otherwise debit)
    return {"credit": max(amount, 0), "debit": max(-amount, 0)}


from frappe.utils.background_jobs import enqueue
def create_loan_transactionsr(doc, method=None):
    loan = frappe.get_doc("Loan Application Plus", doc.loan)
    date = doc.disbursement_date
    payment_method = doc.get('payment_type', 'Cash')
    amount_disbursed = doc.disbursed_amount
    enqueue(
        method=savings_transaction2(date, loan, amount_disbursed),
        queue='long',
        timeout=300,
        now=False,
        job_name=None,
        event=None,
        is_async=True
    )

    enqueue(
        method=apply_interest_transaction(date, loan, payment_method),
        queue="long",
        timeout=300,
        now=False,
        job_name=None,
        event=None,
        is_async=True
    )

def savings_transaction2(date, loan, amount, trans_type="1"):
    transaction_type = frappe.get_value("Loan Transaction Type", {"type_name": trans_type})
    try:
        transaction_type = frappe.get_value("Loan Transaction Type", {"type_name": "1"})
        loan_transaction = frappe.get_doc({
            'doctype': 'Loan Transaction2',
            'client_account': loan.account_number,
            'account': loan.account_number,
            'transaction_type': transaction_type,
            'created_on': date,
            'branch': loan.branch,
            'amount': amount,
            'debit': amount,
            'client_account': loan.account_number,  # Ensure this field exists in the Saving Transaction doctype
            'reference': loan.name,
            'description': f'Loan {loan.name} Loan transaction',
            'loan': loan.name
        })
        loan_transaction.insert()
        loan_transaction.submit()

    except Exception as e:
        # Log the error with a more descriptive message
        frappe.log_error(f"Error in savings_transaction2 for loan {loan.name} on {date}: {e}")

# Example usage:
# savings_transaction2("2024-06-21", loan_object, 1000, "Deposit")

def apply_interest_transaction(date, loan, payment_method):
    dailyRate = (loan.loan_interest / 100) / 30  # Calculate daily interest rate
    loan_iter = round((dailyRate * loan.principal * loan.loan_tenure),2)  # Calculate daily interest amount
    try:
        transaction_type = frappe.get_value("Loan Transaction Type", {"type_name": "Apply Interest"})
        loan_transaction = frappe.get_doc({
            'doctype': 'Loan Transaction2',
            'client_account': loan.account_number,
            'account': loan.account_number,
            'transaction_type': transaction_type,
            'created_on': date,
            'branch': loan.branch,
            'amount': loan_iter,
            'debit': loan_iter,
            'client_account': loan.account_number,  # Ensure this field exists in the Saving Transaction doctype
            'reference': loan.name,
            'description': f'Loan {loan.name} Loan transaction',
            'loan': loan.name
        })
        loan_transaction.insert()
        loan_transaction.submit()

    except Exception as e:
        # Log the error with a more descriptive message
        frappe.log_error(f"Error in Loan Transaction2 for loan {loan.name} on {date}: {e}")

    


@frappe.whitelist(allow_guest=True)
def process_all_loan_disbursements():
    # Get all records of the Loan Disbursement document type
    loan_docs = frappe.get_all("Loan Disbursement", filters={}, fields=["name"])

    # Loop through each loan document and call create_loan_transactions
    for loan_doc in loan_docs:
        doc = frappe.get_doc("Loan Disbursement", loan_doc.name)
        
        # Call the create_loan_transactions function for each document
        create_loan_transactionsr(doc)


@frappe.whitelist(allow_guest=True)
def get_data(account, account2=None, branch=None, from_date=None, to_date=None):
    # Initialize conditions and query filters based on provided parameters
    conditions = []
    query_filters = {
        "account": account,
        "account2": account2,
        "branch": branch,
        "from_date": from_date,
        "to_date": to_date,
    }

    # Apply date filters to conditions
    if from_date:
        conditions.append("t1.creation >= %(from_date)s")
    if to_date:
        conditions.append("t1.creation <= %(to_date)s")

    # Combine conditions into a single string for the SQL query
    condition_str = " AND ".join(conditions)
    if condition_str:
        condition_str = " AND " + condition_str

    # Add account2 filter if provided
    account_condition = "AND t2.suba = %(account2)s" if account2 else ""

    # Construct the SQL query to get only the required fields
    query = f"""
    SELECT 
        t1.description, 
        t1.amount
    FROM `tabSaving Transaction` t1
    LEFT JOIN `tabDeposit` t2 ON t2.name = t1.deposit
    WHERE t1.account = %(account)s
      {account_condition}
      AND t1.flagged = 0
      {condition_str}
    """

    # Execute the query to fetch the transaction data
    transactions = frappe.db.sql(query, query_filters, as_dict=True)

    # Initialize totals
    total_credit = 0
    total_debit = 0
    balance = 0

    # Process each transaction to calculate totals
    for transaction in transactions:
        amount = transaction.get("amount", 0)
        description = transaction["description"].lower()

        # Classify as credit or debit based on description
        if "deposit" in description and "fees" not in description:
            total_credit += amount
        elif "cash transfer from" in description:
            total_credit += amount
        elif "cash collateral refund" in description:
            total_credit += amount
        elif "loan disbursment for" in description:
            total_credit += amount
        elif "deposit fees" in description or "withdrawal" in description:
            total_debit += amount
        else:
            total_debit += amount

    # Calculate the final balance
    balance = total_credit - total_debit

    # Return only the total values
    return {
        "total_credit": total_credit,
        "total_debit": total_debit,
        "balance": balance
    }


@frappe.whitelist(allow_guest=True)
def smsGuarantors_app_loan(amount: any = None, keyword: any = None):

    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        
        # Retrieve full names and mobile numbers of guarantors from both tables
        guarantors = frappe.db.sql("""
            SELECT cl.full_name, cl.mobile 
            FROM `tabLoan Application Plus` AS lp 
            JOIN `tabloan_guarntors` AS gr1 ON lp.name = gr1.parent 
            JOIN `tabClient` AS cl ON cl.name = gr1.client 
            WHERE lp.name LIKE %(keyword)s
            
            UNION
            
            SELECT gr3.full_name, gr3.mobile 
            FROM `tabLoan Application Plus` AS lp 
            JOIN `tabloan_guarntors` AS gr2 ON lp.name = gr2.parent 
            JOIN `tabGuarantors_` AS gr3 ON gr3.name = gr2.client 
            WHERE lp.name LIKE %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
               
        # Return the list of guarantors with full names and mobile numbers
        guarantors_list = [{"full_name": entry['full_name'], "mobile": entry['mobile']} for entry in guarantors]
        
        return {"status": "success", "guarantors": guarantors_list}
    else:
        return {"status": "error", "message": "Invalid keyword provided"}


@frappe.whitelist(allow_guest=True)
def get_total_loan_penalties(keyword: str = None):
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        
        # Retrieve sum of penalties for loans matching the keyword
        penalties = frappe.db.sql("""
            SELECT SUM(amount) AS total_amount
            FROM `tabLoan Penalty II`
            WHERE loan LIKE %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
        
        # Extract total amount of penalties
        total_amount = penalties[0]['total_amount'] if penalties and penalties[0]['total_amount'] else 0
        
        return {"status": "success", "total_penalties": total_amount}
    else:
        return {"status": "error", "message": "Invalid keyword provided or keyword length less than 3"}

@frappe.whitelist(allow_guest=True)
def get_data_loan_mg(filters=None):
    loan_id = filters
    loan_data = frappe.get_doc("Loan Application Plus", loan_id)
    loan_disbursements = frappe.get_all(
        "Loan Disbursement",
        filters={ "loan": loan_id},
        fields=["*"]
    )
    if loan_disbursements:
        loan_data2 = loan_disbursements[0]  # Get the first matching record
        disbursement_date = loan_data2.get('disbursement_date')


    loan_disbursement = frappe.db.get_list("Loan Disbursement", filters={"loan": loan_id}, fields=["disbursement_date", "disbursed_amount"], limit=1)

    if not loan_disbursement:
        frappe.throw("Loan Disbursement record not found for the selected loan.")
    payment_intervals = loan_data.payment_intervals
    loan_interest_expected_ = frappe.db.get_list(
        "Loan Transaction2",
        filters={"loan": loan_id, "transaction_type": 2},
        fields=["amount"],
       
    )
    loan_interest_expected = loan_interest_expected_[0]["amount"] if loan_interest_expected_ else 0
    grace_period = float(loan_data.grace_period_on_disbursment)
    interestrater = float(loan_data.loan_interest + loan_data.collection_fees)
    loan_start_date = loan_disbursement[0].disbursement_date
    disbursed_amount = loan_disbursement[0].disbursed_amount
    
    loan_start_date_dt = loan_start_date
    
    loan_tenure  = float(loan_data.loan_tenure)
    daily_interest_rate = (interestrater / 100) / 30 if 30 else 0
    penalty_rate = (2.5 / 100) / 30 if 30 else 0
    from mfis.clients import get_daily_interest
    daily_interest = get_daily_interest(loan_id)
        
 
    # frappe.throw(str(payment_intervals))

    transaction_query = f"""
        SELECT
            transactions.creation AS posting_date,
            transaction_types.description AS description,
            transactions.amount AS amount,
            0 AS credit,
            transactions.principal_repaid_derived + transactions.principal_recovered AS principal,
            transactions.interest_repaid_derived + transactions.interest_recovered AS interest,
            transactions.penalties_repaid_derived + transactions.penalties_recovered AS penalty,
            transactions.name AS transaction_id,
            transactions.description AS org_desc
        FROM `tabLoan Transaction2` AS transactions
        JOIN `tabLoan Transaction Type` AS transaction_types ON transactions.transaction_type = transaction_types.name
        WHERE transactions.loan = '{loan_id}'
            AND transaction_types.description NOT IN ('Apply Interest')
            #  

        UNION ALL

      

        SELECT
            repayment.creation AS posting_date,
            'Loan Repayment' AS description,
            repayment.amount AS amount,
            repayment.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            repayment.name AS transaction_id,
            '' AS org_desc
        FROM `tabLoan Repayment` AS repayment
        WHERE  repayment.loan = '{loan_id}' and flagged = 0

        UNION ALL

        SELECT
            waive.creation AS posting_date,
            CONCAT('Waive Loan II-', waive.waive_type) AS description,
            waive.amount AS amount,
            waive.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            waive.name AS transaction_id,
            '' AS org_desc
        FROM `tabWaive Loan II` AS waive
        WHERE waive.loan = '{loan_id}'

        UNION ALL

        SELECT
            writeoff.creation AS posting_date,
            CONCAT('Write off II-', writeoff.waive_type) AS description,
            writeoff.amount AS amount,
            writeoff.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            writeoff.name AS transaction_id,
            '' AS org_desc
        FROM `tabWrite Off Loan II` AS writeoff
        WHERE writeoff.loan = '{loan_id}'

        ORDER BY posting_date asc
    """

    existing_transactions = frappe.db.sql(transaction_query, as_dict=True)

    running_principal_balance = disbursed_amount + loan_interest_expected
    unpaid_interest_arreas = 0
    unpaid_penalty_arreas = 0
    principal_arreas = 0
    last_posted_date = None
    today_interest = 0
    days_in_arrears = 0
    total_debit = disbursed_amount + loan_interest_expected

    totals = {
        "total_credit": 0,
        "total_principal_paid": 0,
        "total_principal_paid2": 0,
        "total_interest_paid": 0,
        "total_interest_paid2": 0,
        "total_penalty_paid": 0,
        "total_unpaid_interest_arreas": 0,
        "total_unpaid_penalty_arreas": 0,
        "total_today_interest": 0,
        "total_principal_arreas": 0,
        "total_days_in_arrears": 0,
        "total_penalty_paid2": 0,
        "last_outstanding_balance": running_principal_balance + loan_interest_expected,
        "total_debit": total_debit,
        "total_interest_arreas": 0, 
    }

    output = []
    initial_outstanding_balance = running_principal_balance + loan_interest_expected
    interest_arreas = 0  # Initialize interest_arreas here
    totaldailpaid = 0
    lastpaidpriciple = 0
    lastpaidpriciple2 = 0
    penalty_paid = 0
    interest_paid2b = 0
    unpaidintrest = 0
    unpaidpenalt = 0
    unpaidpriciple = 0
    grace_date_repayment_made = False
    for txn in existing_transactions:
        amount = txn.get("amount", 0.0)

        penalty_paid2 = 0
        principal_paid = 0
        principal_paid2 = 0
        interest_paid = 0
        interest_paid2 = 0
        interest_paid_arrears = 0
        credit = 0
        debit = 0
        original_description = txn.get("org_desc","")
       
        start_date_str  = to_date_safe(loan_start_date)
        repayment_days_length = get_repayment_dates_length(str(start_date_str), grace_period, loan_tenure)
        current_date = txn["posting_date"] 

        daily_interest = disbursed_amount * ((interestrater / 100) / 30)
        daily_interest2 = disbursed_amount * ((interestrater / 100) / 30)
        grace_period_interest = grace_period * daily_interest
        total_interest = ((loan_tenure - grace_period) * daily_interest) + grace_period_interest
        constant_due_amount = (disbursed_amount + total_interest) / (repayment_days_length-1)     
        last_posted_date = current_date
        today = datetime.today()
        daily_interest_p2 = ((disbursed_amount + total_interest) / (repayment_days_length)) -daily_interest
        daily_interest_p = round((daily_interest_p2),0) 
        daily_interest_p2 = daily_interest_p           
        grace_period_days = grace_period

        if payment_intervals == "Weeks":
            grace_period_days=7
            grace_period = 7
        elif payment_intervals == "Months":
            grace_period_days=30
            grace_period = 30
        

        loan_start_date_str = start_date_str
        loan_start_date = getdate(loan_start_date_str)
        grace_period_end_date = loan_start_date + timedelta(days=grace_period_days)
        
        if today.weekday() == 1:
            daily_interest = (daily_interest*2)
        isskippale = 0
        if today.weekday() == 5 or today.weekday() == 6:
            isskippale = 1
        

        arrears_txn = {}
        if txn["description"] not in ("Disburserment"):

            if txn["posting_date"].weekday() == 0:
                daily_interest = daily_interest*2
                daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
            else:
                daily_interest = daily_interest2				
                daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
 

            if txn["description"] in ("Arreas"):
                if grace_date_repayment_made:
                    continue
                if  current_date == to_date_safe(grace_period_end_date) and grace_date_repayment_made == False:	
                    if grace_period_days > 0:
                        grace_date_repayment_made = True
                        if isinstance(txn["posting_date"], str):
                            txn_date = datetime.datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                        else:
                            txn_date = txn["posting_date"]
                        next_day = txn_date - timedelta(days=1)
                        posting_datetime = next_day.replace(hour=23, minute=0, second=0, microsecond=0)
                        unpaidintrest += daily_interest2*(grace_period_days)
                        daily_interest_p = daily_interest_p2 - unpaidintrest
                        arrears_txn = {
                            "posting_date": posting_datetime,
                            "description": "Arreas",
                            "amount": interest_arreas + unpaidpriciple,
                            "credit": 0,
                            "principal_arreas": unpaidpriciple,
                            "interest_arreas": unpaidintrest,
                            "penalty": 0,
                            "outstanding_balance" : running_principal_balance,
                            "transaction_id": f"ARRc-{frappe.generate_hash(length=8)}",
                            "org_desc": "Generated due to insufficient repayment"
                        }
                        output.append(arrears_txn)
                        # frappe.throw(str(current_date)+"---"+str(to_date_safe(today).date()))
                        if current_date == to_date_safe(today).date():

                            continue	
                    else:
                        daily_interest_p = daily_interest_p2
						 	
                if isinstance(txn["posting_date"], str):
                    txn_date = datetime.datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                else:
                    txn_date = txn["posting_date"]

                if txn["posting_date"].weekday() == 0:
                   
                    daily_interest = daily_interest2*2
                  
                    daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
                    
                else:
                    daily_interest = daily_interest2
                 
                    # daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest


                if daily_interest_p > 0:
                    unpaidpriciple += (daily_interest_p) 
                else:
                    unpaidpriciple += (daily_interest_p) 

                penalty_paid  += (1.25/100)/30*((unpaidpriciple))
                running_principal_balance += (1.25/100)/30*((unpaidpriciple))	
                unpaidintrest += (daily_interest) 
                unpaid_interest_arreas += daily_interest
                unpaid_penalty_arreas += penalty_paid

            elif txn["description"] in ("Penalty"):
                unpaid_penalty_arreas += amount
                debit = amount

            elif txn["description"] in ("Loan Repayment",):
                if txn["posting_date"].weekday() == 0:
                    daily_interest = daily_interest2*2
                    daily_interest_p = ((disbursed_amount + total_interest) / (repayment_days_length)) - daily_interest
                else:
                    daily_interest = daily_interest2
                if  current_date.date() >= to_date_safe(grace_period_end_date) and grace_date_repayment_made == False:	
                    if grace_period_days > 0:
                        if isinstance(txn["posting_date"], str):
                            txn_date = datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                        else:
                            txn_date = txn["posting_date"]
                        # frappe.throw(str(daily_interest))
                        yy=1
                        if  current_date.date() >= to_date_safe(grace_period_end_date):
                            yy=2
                        next_day = txn_date - timedelta(days=yy)
                        posting_datetime = next_day.replace(hour=23, minute=0, second=0, microsecond=0)
                        unpaidintrest += daily_interest2*(grace_period_days)
                        daily_interest_p = daily_interest_p2 - unpaidintrest
                        arrears_txn = {
                            "posting_date": posting_datetime,
                            "description": "Arreas",
                            "amount": interest_arreas + unpaidpriciple,
                            "debit": 0,
                            "principal_arreas": unpaidpriciple,
                            "interest_arreas": unpaidintrest,
                            "outstanding_balance" : running_principal_balance,
                            "penalty": 0,
                            "transaction_id": f"ARRa-{frappe.generate_hash(length=8)}",
                            "org_desc": "Generated due to insufficient repayment"
                        }
                        output.append(arrears_txn)	
                        grace_date_repayment_made = True
                    else:
                        daily_interest_p = daily_interest_p2 		
                if grace_period == 0 or current_date.date() >= to_date_safe(grace_period_end_date):
                    credit = amount
                    payment_allocation = credit
                    # 1. Pay Penalty Arrears
                    if payment_allocation > 0 and unpaid_penalty_arreas <= payment_allocation:
                        penalty_paid2 = unpaid_penalty_arreas
                        penalty_paid -= penalty_paid2
                        if penalty_paid < 0 :
                            penalty_paid=0
                        unpaid_penalty_arreas -= penalty_paid2
                        payment_allocation -= penalty_paid2
                        running_principal_balance -= penalty_paid2	
                    elif payment_allocation > 0:
                        penalty_paid2 = payment_allocation
                        penalty_paid -= penalty_paid2
                        if penalty_paid < 0 :
                            penalty_paid=0
                        unpaid_penalty_arreas -= penalty_paid2
                        payment_allocation = 0
                        running_principal_balance -= penalty_paid2

                    # 2. Pay Interest Arrears
                    if payment_allocation > 0 and unpaidintrest <= payment_allocation:
                        interest_paid_arrears = unpaidintrest
                        interest_paid += unpaidintrest
                        unpaidintrest -= interest_paid_arrears
                        payment_allocation -= interest_paid_arrears
                        running_principal_balance -= interest_paid_arrears
                    elif payment_allocation > 0:
                        interest_paid_arrears = payment_allocation
                        interest_paid += payment_allocation
                        unpaidintrest -= interest_paid_arrears
                        payment_allocation = 0
                        running_principal_balance -= interest_paid_arrears

                    if payment_allocation >= daily_interest:
                        interest_paid_today = daily_interest
                        interest_paid2 += interest_paid_today
                        interest_paid2b += interest_paid_today
                        payment_allocation -= interest_paid_today
                        running_principal_balance -= interest_paid_today						
                    else:
                        interest_paid_today = payment_allocation
                        unpaidintrest  += (daily_interest - interest_paid_today)
                        interest_paid2 += interest_paid_today
                        interest_paid2b += interest_paid_today
                        payment_allocation = 0
                        running_principal_balance -= interest_paid_today

                    # 4. Pay Principal Arrears
                    if payment_allocation > 0 and unpaidpriciple <= payment_allocation:
                        principal_paid_arrears = unpaidpriciple
                        unpaidpriciple -= principal_paid_arrears
                        principal_paid2 += principal_paid_arrears
                        payment_allocation -= principal_paid_arrears
                        running_principal_balance -= principal_paid_arrears
                    elif payment_allocation > 0:
                        principal_paid_arrears = payment_allocation
                        unpaidpriciple -= principal_paid_arrears
                        principal_paid2 += principal_paid_arrears
                        payment_allocation = 0
                        running_principal_balance -= principal_paid_arrears

                    # 5. Pay Current Principal
                    if payment_allocation >= daily_interest_p:
                        principal_paid_current = payment_allocation
                        principal_paid += principal_paid_current
                        payment_allocation -= principal_paid_current
                        running_principal_balance -= principal_paid_current
                    else:
                        principal_paid_current = payment_allocation
                        unpaidpriciple  += (daily_interest_p - principal_paid_current)
                        principal_paid += principal_paid_current
                        payment_allocation = 0
                        running_principal_balance -= principal_paid_current



                    if unpaidpriciple > 0:
                        if isinstance(txn["posting_date"], str):
                            txn_date = datetime.strptime(txn["posting_date"], "%Y-%m-%d").date()
                        else:
                            txn_date = txn["posting_date"]
                       
                        next_day = txn_date + timedelta(days=0)
                        posting_datetime = next_day.replace(hour=23, minute=0, second=0, microsecond=0)
                        penalty_paid  = (1.25/100)/30*((unpaidpriciple))
                        unpaid_penalty_arreas += penalty_paid
                        penalebalce = max(penalty_paid - penalty_paid2, 0)
                        if unpaidintrest < 0:
                            unpaidintrest = 0
                        arrears_txn = {
                            "posting_date": posting_datetime,
                            "description": "Arreas",
                            "amount": interest_arreas + unpaidpriciple+ principal_arreas,
                            "debit": penalty_paid,
                            "principal_arreas":   unpaidpriciple,
                            "interest_arreas": unpaidintrest,
							"penalty_paidbl":  unpaid_penalty_arreas,
                            "penalty_paid": penalty_paid,
                            "outstanding_balance" : running_principal_balance,
                            "transaction_id": f"ARRb-{frappe.generate_hash(length=8)}",
                            "org_desc": "Generated due to insufficient repayment"
                        }
                        output.append(arrears_txn)

                else:
                    credit = amount
                    payment_allocation = credit

                    # 5. Pay Current Principal
                    if payment_allocation > 0 and daily_interest_p <= payment_allocation:
                        principal_paid_current = credit
                        principal_paid += principal_paid_current
                        payment_allocation -= principal_paid_current
                        running_principal_balance -= principal_paid_current
                    else:
                        principal_paid_current = payment_allocation
                        principal_paid += principal_paid_current
                        payment_allocation -= principal_paid_current
                        running_principal_balance -= principal_paid_current

            elif txn["description"] in ( "Write off II-Principle", "Savings To Loan Transfer"):
                credit = amount
                payment_allocation = credit
                running_principal_balance -= amount
                principal_paid_current = payment_allocation
                principal_paid += principal_paid_current
                payment_allocation -= principal_paid_current
                running_principal_balance -= principal_paid_current

            elif txn["description"] in ( "Write off II-Interest"):
                credit = amount
                payment_allocation = credit
                running_principal_balance -= amount
                interest_paid_today = payment_allocation
                interest_paid2 += interest_paid_today 
                interest_paid2b += interest_paid_today
                payment_allocation -= interest_paid_today
                running_principal_balance -= interest_paid_today	

            elif txn["description"]  in ("Loan Closure"):
                amount = running_principal_balance
                debit = amount
                running_principal_balance -= credit
                payment_allocation = credit
                penalty_paid = 0

                # 4. Pay Principal Arrears
                if payment_allocation > 0 and principal_arreas <= payment_allocation:
                    principal_paid_arrears = min(payment_allocation, principal_arreas)
                    principal_arreas -= principal_paid_arrears
                    principal_paid2 += principal_paid_arrears
                    payment_allocation -= principal_paid_arrears
                else:
                    principal_paid_arrears = payment_allocation  # Pay whatever is left in payment_allocation
                    principal_arreas -= principal_paid_arrears
                    principal_paid2 += principal_paid_arrears
                    payment_allocation -= principal_paid_arrears

                    # 1. Pay Interest Arrears
                if payment_allocation > 0 and interest_arreas <= payment_allocation:
                    interest_paid_arrears = min(payment_allocation, unpaid_interest_arreas)
                    interest_paid_arrears = payment_allocation  # Pay whatever is left in payment_allocation
                    unpaid_interest_arreas -= interest_paid_arrears
                    if unpaid_interest_arreas < 0:
                        unpaid_interest_arreas = 0  # Prevent negative values
                    
                    payment_allocation -= interest_arreas
                    interest_paid += interest_arreas
                    interest_arreas -= interest_arreas
                    if interest_arreas < 0:
                        interest_arreas = 0  
                else:
                    # If payment_allocation is less than interest_arreas, pay the remaining amount in interest arrears
                    interest_paid_arrears = payment_allocation  # Pay whatever is left in payment_allocation
                    unpaid_interest_arreas -= interest_paid_arrears
                    if unpaid_interest_arreas < 0:
                        unpaid_interest_arreas = 0  # Prevent negative values
                    
                    payment_allocation -= interest_paid_arrears
                    interest_paid += interest_paid_arrears
                    interest_arreas -= interest_paid_arrears
                    if interest_arreas < 0:
                        interest_arreas = 0  # Prevent negative values


                # 2. Pay Penalty Arrears
                if payment_allocation > 0 and unpaid_penalty_arreas <= payment_allocation:
                    penalty_paid2 = min(payment_allocation, unpaid_penalty_arreas)
                    unpaid_penalty_arreas -= penalty_paid2
                    payment_allocation -= penalty_paid2
                else:
                    penalty_paid2 = payment_allocation  # Pay whatever is left in payment_allocation
                    unpaid_penalty_arreas -= penalty_paid2
                    payment_allocation -= penalty_paid2
               
			   
                    # 5. Pay Current Principal
                if payment_allocation >= daily_interest_p:
                    principal_paid_current = payment_allocation
                    principal_paid += principal_paid_current
                    payment_allocation -= principal_paid_current
                    running_principal_balance -= principal_paid_current
                else:
                    principal_paid_current = payment_allocation
                    principal_arreas  += (daily_interest_p - principal_paid_current)
                    principal_paid += principal_paid_current
                    payment_allocation = 0
                    running_principal_balance -= principal_paid_current
            elif txn["description"] not in ("Disbursement"):
                debit = amount # Handle other debit transactions

            

            lastpaidpriciple = principal_paid
            lastpaidpriciple2 = interest_paid2
            if interest_paid2 > daily_interest:
                localalace  =constant_due_amount-principal_paid
                # principal_arreas += localalace
                if localalace >= 0:
                    penalty_paid  += (2.5/100)/30*((localalace))
            totals["total_credit"] += credit
            totals["total_principal_paid"] += unpaidpriciple
            totals["total_principal_paid2"] += principal_paid2
            totals["total_interest_paid"] += interest_paid
            totals["total_interest_paid2"] += interest_paid2 
            totals["total_penalty_paid"] += penalty_paid
            totals["total_unpaid_interest_arreas"] = unpaid_interest_arreas
            totals["total_unpaid_penalty_arreas"] = unpaid_penalty_arreas
            totals["total_today_interest"] = today_interest
            totals["total_principal_arreas"] = principal_arreas
            totals["total_penalty_paid2"] += penalty_paid2
            totals["total_days_in_arrears"] += days_in_arrears
            totals["last_outstanding_balance"] = running_principal_balance 
            totals["total_debit"] += debit
            totals["total_interest_arreas"] = unpaidintrest

    return  totals

@frappe.whitelist(allow_guest=True)
def get_total_loan_penalties2(keyword: str = None):
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        
        # Retrieve sum of penalties for loans matching the keyword
        penalties = frappe.db.sql("""
            SELECT SUM(amount) AS total_amount
            FROM `tabLoan Repayment`
            WHERE loan LIKE %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
        
        # Extract total amount of penalties
        total_amount = penalties[0]['total_amount'] if penalties and penalties[0]['total_amount'] else 0
        
        return {"status": "success", "total_penalties": total_amount}
    else:
        return {"status": "error", "message": "Invalid keyword provided or keyword length less than 3"}
    
@frappe.whitelist(allow_guest=True)
def get_total_loan_waived(keyword: str = None):
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        
        # Retrieve sum of penalties for loans matching the keyword
        penalties = frappe.db.sql("""
            SELECT SUM(amount) AS total_amount
            FROM `tabWaive Loan II`
            WHERE waive_type = 'Interest' and loan LIKE %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
        
        # Extract total amount of penalties
        total_amount = penalties[0]['total_amount'] if penalties and penalties[0]['total_amount'] else 0
        
        return {"status": "success", "total_penalties": total_amount}
    else:
        return {"status": "error", "message": "Invalid keyword provided or keyword length less than 3"}

@frappe.whitelist(allow_guest=True)
def get_total_loan_waived_penalty(keyword: str = None):
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        
        # Retrieve sum of penalties for loans matching the keyword
        penalties = frappe.db.sql("""
            SELECT SUM(amount) AS total_amount
            FROM `tabWaive Loan II`
            WHERE waive_type = 'Penalties' and loan LIKE %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
        
        # Extract total amount of penalties
        total_amount = penalties[0]['total_amount'] if penalties and penalties[0]['total_amount'] else 0
        
        return {"status": "success", "total_penalties": total_amount}
    else:
        return {"status": "error", "message": "Invalid keyword provided or keyword length less than 3"}
    

@frappe.whitelist(allow_guest=True)
def get_total_loan_waived_penalty2(keyword: str = None):
    if keyword and len(keyword) >= 3:
        # Sanitize the keyword to prevent SQL injection attacks
      
        # Retrieve sum of penalties for loans matching the keyword
        penalties = frappe.db.sql("""
            SELECT SUM(amount) AS total_amount
            FROM `tabWaive Loan II`
            WHERE waive_type = 'Penalties' AND loan LIKE %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
        loan=""
        keyword_like = f"%{frappe.db.escape(keyword)}%"

       

        # Try finding an exact match first
        matching_loans = frappe.db.sql("""
            SELECT name 
            FROM `tabLoan Application Plus`
            WHERE name = %(keyword)s OR name LIKE %(keyword_like)s
            LIMIT 1
        """, {"keyword": keyword, "keyword_like": keyword_like}, as_dict=True)

        # If no loan applications match the keyword, return an error
        if not matching_loans:
            return {"status": "error", "message": "No loan applications found matching the keyword"}

        # Fetch the loan document based on the matching loan
        loan = frappe.get_doc("Loan Application Plus", matching_loans[0]['name'])
        loanp = frappe.get_doc("Loan Product", loan.loan_type)


        # Define start and end of day variables
        from frappe.utils import get_datetime, now_datetime
        today = now_datetime().date()
        start_of_day = get_datetime(f"{today} 00:00:00")
        end_of_day = get_datetime(f"{today} 23:59:59")

        repayment_today2 = frappe.get_all(
            "General Ledger II",
            filters={
                "account": loanp.loan_penalty_account,
                "creation": ["between", [start_of_day, end_of_day]],
                "loan": loan.name
            },
            fields=["name", "credit"]
        )

        # Calculate the total paid amount for the penalties
        paid_amount = sum([repayment['credit'] for repayment in repayment_today2])

        # Extract total amount of penalties, default to 0 if not available
        total_amount = penalties[0]['total_amount'] if penalties and penalties[0]['total_amount'] else 0

        return {"status": "success", "total_penalties": ( paid_amount)}

    else:
        return {"status": "error", "message": "Invalid keyword provided or keyword length less than 3"}

    
@frappe.whitelist(allow_guest=True)
def get_loan_statement2(loan: str = None, loan2: str = None):
    # SQL query to fetch transaction data
    query = frappe.db.sql(f"""
    
    SELECT 
        transactions.creation AS posting_date, 
        transaction_types.type_name AS description,
        transactions.amount AS loan_deposit,
        0 AS debit,
        0 AS credit,
        transactions.principal_repaid_derived + transactions.principal_recovered AS principal,
        transactions.interest_repaid_derived + transactions.interest_recovered AS interest,
        transactions.penalties_repaid_derived + transactions.penalties_recovered AS penalty,
        transactions.name AS transaction_id,
        'None' AS dd,
        transactions.description AS org_desc,
        0 AS is_loan_pen
    FROM 
        `tabLoan Transaction2` AS transactions
    LEFT JOIN 
        `tabLoan Transaction Type` AS transaction_types 
    ON 
        transactions.transaction_type = transaction_types.name
    WHERE 
        transactions.loan = '{loan}'
        AND transactions.docstatus = 1

    UNION ALL

    SELECT 
        penalties.creation AS posting_date, 
        'Loan Penalty' AS description,
        0 AS loan_deposit,
        penalties.amount AS debit,
        0 AS credit,
        0 AS principal,
        0 AS interest,
        penalties.penalty AS penalty,
        penalties.name AS transaction_id,
        'None' AS dd,
        'None' AS org_desc,
        1 AS is_loan_pen
    FROM 
        `tabLoan Penalty II` AS penalties
    WHERE 
        penalties.loan = '{loan}'
        AND penalties.docstatus = 1

    UNION ALL

    SELECT 
        repayments.creation AS posting_date, 
        'Loan Repayment' AS description,
        repayments.amount AS loan_deposit,
        0 AS debit,
        0 AS credit,
        0 AS principal,
        0 AS interest,
        0 AS penalty,
        repayments.name AS transaction_id,
        repayments.payment_method AS dd,
        'None' AS org_desc,
        0 AS is_loan_pen
    FROM 
        `tabLoan Repayment` AS repayments
    WHERE 
        repayments.loan = '{loan}'
        AND repayments.docstatus = 1

    UNION ALL

    SELECT 
        waives.creation AS posting_date, 
        'Waive Loan II' AS description,
        waives.amount AS loan_deposit,
        0 AS debit,
        waives.amount AS credit,
        0 AS principal,
        0 AS interest,
        0 AS penalty,
        waives.name AS transaction_id,
        waives.waive_type AS dd,
        'None' AS org_desc,
        0 AS is_loan_pen
    FROM 
        `tabWaive Loan II` AS waives
    WHERE 
        waives.loan = '{loan}'
        AND waives.docstatus = 1

    UNION ALL

    SELECT 
        write_offs.creation AS posting_date, 
        'Write Off Loan II' AS description,
        write_offs.amount AS loan_deposit,
        0 AS debit,
        write_offs.amount AS credit,
        0 AS principal,
        0 AS interest,
        0 AS penalty,
        write_offs.name AS transaction_id,
        write_offs.waive_type AS dd,
        'None' AS org_desc,
        0 AS is_loan_pen
    FROM 
        `tabWrite Off Loan II` AS write_offs
    WHERE 
        write_offs.loan = '{loan}'
        AND write_offs.docstatus = 1
    
    ORDER BY 
        posting_date
    """, as_dict=True)


    if not query:
        return [], 0 

    transactions = []
    penalties = frappe.db.get_all("Loan Penalty II", filters={"loan": loan}, fields=["amount"])
    total_penalties = sum((p['amount']) for p in penalties) or 0
    running_total = 0
    interestleft = 0
    date_list = []
    repayment_dates = generate_loan_schedule(loan)
    for i in query:
        i["interest"] = 0
        i["penalty"] = 0

        if i["description"] == 'Waive Loan II':
            i["loan_deposit"] = 0
            i["description"] = i["description"] + "-" + i["dd"]
            if i["dd"] == "Penalties":
                i["penalty"] = i["credit"]
            else:
                i["interest"] = i["credit"] 

            running_total -= i["credit"]
        elif i["description"] == 'Write Off Loan II':
            i["description"] = i["description"] + "-" + i["dd"]
            i["loan_deposit"] = 0
            running_total -= i["credit"]
            if i["dd"] == "Principle":
                i["principal"] = i["credit"]
            else:
                i["interest"] = i["credit"]
        elif i["description"] == 'Repayment':
            i["description"] = i["org_desc"]
            datetime_obj = i["posting_date"]
            date_obj = datetime_obj.date()

            # No need to convert to string and parse again
            # date_object is the same as date_obj in this case
            date_object = date_obj
            
            if i["is_loan_pen"] == 1:
                balancer = total_penalties - i["loan_deposit"]

                if balancer > 0:
                    total_penalties -= i["loan_deposit"]
                    running_total -= i["loan_deposit"]
                    i["principal"] = 0
                    i["credit"] = 0
                    i["interest"] = 0
                    i["penalty"] =  i["loan_deposit"]
                else:
                    i["loan_deposit"] = abs(balancer)
                    if date_obj not in date_list and str(date_object) in repayment_dates:
                    
                        penalties = frappe.db.sql("""
                            SELECT loan_tenure, principal, payment_intervals, loan_interest
                            FROM `tabLoan Application Plus`
                            WHERE name LIKE %(keyword)s
                            """, {"keyword": loan}, as_dict=True)

                        if penalties:
                            for penalty in penalties:
                                loan_tenure = penalty['loan_tenure']
                                principal = penalty['principal']
                                payment_intervals = penalty['payment_intervals']
                                annual_interest_rate =  penalty['loan_interest']
                                daily_interest = ((annual_interest_rate / 100) / 30) * ( principal) 
                                if interestleft > 0:
                                    daily_interest = interestleft
                                
                                if daily_interest >= i["loan_deposit"]:
                                    i["principal"] =  0
                                    i["interest"] = i["loan_deposit"]
                                    interestleft = daily_interest - i["loan_deposit"]
                                else:
                                    date_list.append(date_obj)
                                    i["principal"] = i["loan_deposit"] - daily_interest
                                    i["interest"] = daily_interest
                        else:
                            raise ValueError("No penalties found for the specified loan")

                        running_total -= i["loan_deposit"]
                        i["credit"] = i["loan_deposit"]
                    else:
                        running_total -= i["loan_deposit"]
                        i["principal"] = i["loan_deposit"]
                        i["credit"] = i["loan_deposit"]
                        i["interest"] = 0

                    running_total -= i["loan_deposit"]
                    i["penalty"] =  total_penalties
                    
            

            else:
                if date_obj not in date_list and str(date_object) in repayment_dates:
                
                    penalties = frappe.db.sql("""
                        SELECT loan_tenure, principal, payment_intervals, loan_interest
                        FROM `tabLoan Application Plus`
                        WHERE name LIKE %(keyword)s
                        """, {"keyword":loan}, as_dict=True)

                    if penalties:
                        for penalty in penalties:
                            loan_tenure = penalty['loan_tenure']
                            principal = penalty['principal']
                            payment_intervals = penalty['payment_intervals']
                            annual_interest_rate =  penalty['loan_interest']
                            daily_interest = ((annual_interest_rate / 100) / 30) * ( principal) 
                            if interestleft > 0:
                                daily_interest = interestleft
                            
                            if daily_interest >= i["loan_deposit"]:
                                i["principal"] =  0
                                i["interest"] = i["loan_deposit"]
                                interestleft = daily_interest - i["loan_deposit"]
                            else:
                                date_list.append(date_obj)
                                i["principal"] = i["loan_deposit"] - daily_interest
                                i["interest"] = daily_interest
                    else:
                        raise ValueError("No penalties found for the specified loan")

                    running_total -= i["loan_deposit"]
                    i["credit"] = i["loan_deposit"]
                else:
                    running_total -= i["loan_deposit"]
                    i["principal"] = i["loan_deposit"]
                    i["credit"] = i["loan_deposit"]
                    i["interest"] = 0

        elif i["description"] == 'Loan Repayment':
            loandata = frappe.get_doc("Loan Application Plus", loan)
            if i["dd"] == "Savings Account":
                i["description"] = "Repayment From Account(" + loandata.clients + ")"
            if isinstance(i["posting_date"], str):
                datetime_obj = datetime.datetime.strptime(i["posting_date"], "%Y-%m-%d")
            
            datetime_obj = i["posting_date"]
            date_obj = datetime_obj.date()

            # No need to convert to string and parse again
            # date_object is the same as date_obj in this case
            date_object = date_obj
            
            if i["is_loan_pen"] == 1:
                balancer = total_penalties - i["loan_deposit"]

                if balancer > 0:
                    total_penalties -= i["loan_deposit"]
                    running_total -= i["loan_deposit"]
                    i["principal"] = 0
                    i["credit"] = 0
                    i["interest"] = 0
                    i["penalty"] =  i["loan_deposit"]
                else:
                    i["loan_deposit"] = abs(balancer)
                    if date_obj not in date_list and str(date_object) in repayment_dates:
                    
                        penalties = frappe.db.sql("""
                            SELECT loan_tenure, principal, payment_intervals, loan_interest
                            FROM `tabLoan Application Plus`
                            WHERE name LIKE %(keyword)s
                            """, {"keyword": loan}, as_dict=True)

                        if penalties:
                            for penalty in penalties:
                                loan_tenure = penalty['loan_tenure']
                                principal = penalty['principal']
                                payment_intervals = penalty['payment_intervals']
                                annual_interest_rate =  penalty['loan_interest']
                                daily_interest = ((annual_interest_rate / 100) / 30) * ( principal) 
                                if interestleft > 0:
                                    daily_interest = interestleft
                                
                                if daily_interest >= i["loan_deposit"]:
                                    i["principal"] =  0
                                    i["interest"] = i["loan_deposit"]
                                    interestleft = daily_interest - i["loan_deposit"]
                                else:
                                    date_list.append(date_obj)
                                    i["principal"] = i["loan_deposit"] - daily_interest
                                    i["interest"] = daily_interest
                        else:
                            raise ValueError("No penalties found for the specified loan")

                        running_total -= i["loan_deposit"]
                        i["credit"] = i["loan_deposit"]
                    else:
                        running_total -= i["loan_deposit"]
                        i["principal"] = i["loan_deposit"]
                        i["credit"] = i["loan_deposit"]
                        i["interest"] = 0

                    running_total -= i["loan_deposit"]
                    i["penalty"] =  total_penalties
                    
            

            else:
                if date_obj not in date_list and str(date_object) in repayment_dates:
                
                    penalties = frappe.db.sql("""
                        SELECT loan_tenure, principal, payment_intervals, loan_interest
                        FROM `tabLoan Application Plus`
                        WHERE name LIKE %(keyword)s
                        """, {"keyword": loan}, as_dict=True)

                    if penalties:
                        for penalty in penalties:
                            loan_tenure = penalty['loan_tenure']
                            principal = penalty['principal']
                            payment_intervals = penalty['payment_intervals']
                            annual_interest_rate =  penalty['loan_interest']
                            daily_interest = ((annual_interest_rate / 100) / 30) * ( principal) 
                            if interestleft > 0:
                                daily_interest = interestleft
                            
                            if daily_interest >= i["loan_deposit"]:
                                i["principal"] =  0
                                i["interest"] = i["loan_deposit"]
                                interestleft = daily_interest - i["loan_deposit"]
                            else:
                                date_list.append(date_obj)
                                i["principal"] = i["loan_deposit"] - daily_interest
                                i["interest"] = daily_interest
                    else:
                        raise ValueError("No penalties found for the specified loan")

                    running_total -= i["loan_deposit"]
                    i["credit"] = i["loan_deposit"]
                else:
                    running_total -= i["loan_deposit"]
                    i["principal"] = i["loan_deposit"]
                    i["credit"] = i["loan_deposit"]
                    i["interest"] = 0

        elif i["description"] == 'Disbursement' or i["description"] == 'Apply Interest':
            i["debit"] = i["loan_deposit"]
            running_total += i["loan_deposit"]
            i["loan_deposit"] = 0
        else:
            running_total += i["loan_deposit"] if i["description"] != 'Loan Penalty' else i["debit"]

        outstanding_balance = running_total

        transaction = {
            "posting_date": i["posting_date"],
            "description": i["description"],
            "loan_deposit": float(i["loan_deposit"]),
            "debit": float(i["debit"]),
            "credit": float(i["credit"]),
            "principal": float(i["principal"]),
            "interest": float(i["interest"]),
            "penalty": float(i["penalty"]),
            "outstanding": outstanding_balance,
            "transaction_id": i["transaction_id"]
        }

        transactions.append(transaction)


    
    # Summing totals
    total_loan_deposit = sum(i["loan_deposit"] for i in transactions)
    total_debit = sum(i["debit"] for i in transactions)
    total_credit = sum(i["credit"] for i in transactions)
    total_principal = sum(i["principal"] for i in transactions)
    total_interest = sum(i["interest"] for i in transactions)
    total_penalty = sum(i["penalty"] for i in transactions)
    total_outstanding = transactions[-1]["outstanding"] if transactions else 0
    total_interest2 = 0
    total_interest2 = (total_interest - get_arrears(loan))

    # Return only the totals
    totals = {
        "loan_deposit": total_loan_deposit,
        "debit": total_debit,
        "credit": total_credit,
        "principal": total_principal,
        "interest": total_interest2,
        "penalty": total_penalty,
        "outstanding": total_outstanding
    }

    return totals



@frappe.whitelist(allow_guest=True)
def get_loan_statementr(loan):
    query_filters = {"loan": loan}
    
    # Query to gather all relevant transaction data
    query = frappe.db.sql("""
        SELECT 
            transactions.creation AS posting_date, 
            transaction_types.type_name AS description,
            transactions.amount AS loan_deposit,
            0 AS debit,
            0 AS credit,
            transactions.principal_repaid_derived + transactions.principal_recovered AS principal,
            transactions.interest_repaid_derived + transactions.interest_recovered AS interest,
            transactions.penalties_repaid_derived + transactions.penalties_recovered AS penalty,
            transactions.name AS transaction_id,
            'None' AS dd,
            transactions.description AS org_desc
        FROM 
            `tabLoan Transaction2` AS transactions
        LEFT JOIN 
            `tabLoan Transaction Type` AS transaction_types 
        ON 
            transactions.transaction_type = transaction_types.name
        WHERE 
            transactions.loan = %(loan)s
            AND transactions.docstatus = 1

        UNION ALL

        SELECT 
            penalties.creation AS posting_date, 
            'Loan Penalty' AS description,
            0 AS loan_deposit,
            penalties.amount AS debit,
            0 AS credit,
            0 AS principal,
            0 AS interest,
            penalties.penalty AS penalty,
            penalties.name AS transaction_id,
            'None' AS dd,
            'None' AS org_desc
        FROM 
            `tabLoan Penalty II` AS penalties
        WHERE 
            penalties.loan = %(loan)s
            AND penalties.docstatus = 1

        UNION ALL

        SELECT 
            repayments.creation AS posting_date, 
            'Loan Repayment' AS description,
            repayments.amount AS loan_deposit,
            0 AS debit,
            0 AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            repayments.name AS transaction_id,
            repayments.payment_method AS dd,
            'None' AS org_desc
        FROM 
            `tabLoan Repayment` AS repayments
        WHERE 
            repayments.loan = %(loan)s
            AND repayments.docstatus = 1

        UNION ALL

        SELECT 
            waives.creation AS posting_date, 
            'Waive Loan II' AS description,
            waives.amount AS loan_deposit,
            0 AS debit,
            waives.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            waives.name AS transaction_id,
            waives.waive_type AS dd,
            'None' AS org_desc
        FROM 
            `tabWaive Loan II` AS waives
        WHERE 
            waives.loan = %(loan)s
            AND waives.docstatus = 1

        UNION ALL

        SELECT 
            write_offs.creation AS posting_date, 
            'Write Off Loan II' AS description,
            write_offs.amount AS loan_deposit,
            0 AS debit,
            write_offs.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            write_offs.name AS transaction_id,
            write_offs.waive_type AS dd,
            'None' AS org_desc
        FROM 
            `tabWrite Off Loan II` AS write_offs
        WHERE 
            write_offs.loan = %(loan)s
            AND write_offs.docstatus = 1
        
        ORDER BY 
            posting_date
    """, query_filters, as_dict=True)

    if not query:
        return {
            "loan_deposit": 0,
            "debit": 0,
            "credit": 0,
            "principal": 0,
            "interest": 0,
            "penalty": 0,
            "outstanding": 0
        }

    transactions = []
    running_total = 0
    interestleft=0
    date_list = []
    repayment_dates = generate_loan_schedule(loan)
    
    for i in query:
        i["interest"] = 0
        i["penalty"] = 0

        # Processing different transaction types
        if i["description"] == 'Waive Loan II':
            i["loan_deposit"] = 0
            i["description"] += f"-{i['dd']}"
            if i["dd"] == "Penalties":
                i["penalty"] = i["credit"]
            else:
                i["interest"] = i["credit"]
            running_total -= i["credit"]

        elif i["description"] == 'Write Off Loan II':
            i["description"] += f"-{i['dd']}"
            i["loan_deposit"] = 0
            running_total -= i["credit"]
            if i["dd"] == "Principle":
                i["principal"] = i["credit"]
            else:
                i["interest"] = i["credit"]

        elif i["description"] == 'Repayment':
            i["description"] = i["org_desc"]
            datetime_obj = i["posting_date"]
            date_obj = datetime_obj.date()

            if date_obj not in date_list and str(date_obj) in repayment_dates:
               
                penalties = frappe.db.sql("""
                    SELECT loan_tenure, principal, payment_intervals, loan_interest
                    FROM `tabLoan Application Plus`
                    WHERE name LIKE %(keyword)s
                    """, {"keyword": loan}, as_dict=True)

                if penalties:
                    for penalty in penalties:
                        loan_tenure = penalty['loan_tenure']
                        principal = penalty['principal']
                        payment_intervals = penalty['payment_intervals']
                        annual_interest_rate = penalty['loan_interest']
                        daily_interest = ((annual_interest_rate / 100) / 30) * principal
                        if interestleft > 0:
                            daily_interest = interestleft
                        
                        if daily_interest >= i["loan_deposit"]:
                            i["principal"] =  0
                            i["interest"] = i["loan_deposit"]
                            interestleft = daily_interest - i["loan_deposit"]
                        else:
                            date_list.append(date_obj)
                            i["principal"] = i["loan_deposit"] - daily_interest
                            i["interest"] = daily_interest
                        
                    
                else:
                    raise ValueError("No penalties found for the specified loan")

                running_total -= i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
            else:
                running_total -= i["loan_deposit"]
                i["principal"] = i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
                i["interest"] = 0

        elif i["description"] == 'Loan Repayment':
            loandata = frappe.get_doc("Loan Application Plus", loan)
            if i["dd"] == "Savings Account":
                i["description"] = f"Repayment From Account({loandata.clients})"

            datetime_obj = i["posting_date"]
            date_obj = datetime_obj.date()

            if date_obj not in date_list and str(date_obj) in repayment_dates:
               
                penalties = frappe.db.sql("""
                    SELECT loan_tenure, principal, payment_intervals, loan_interest
                    FROM `tabLoan Application Plus`
                    WHERE name LIKE %(keyword)s
                    """, {"keyword": loan}, as_dict=True)

                if penalties:
                    for penalty in penalties:
                        loan_tenure = penalty['loan_tenure']
                        principal = penalty['principal']
                        payment_intervals = penalty['payment_intervals']
                        annual_interest_rate = penalty['loan_interest']
                        daily_interest = ((annual_interest_rate / 100) / 30) * Principal
                        if interestleft > 0:
                            daily_interest = interestleft
                        
                        if daily_interest >= i["loan_deposit"]:
                            i["principal"] =  0
                            i["interest"] = i["loan_deposit"]
                            interestleft = daily_interest - i["loan_deposit"]
                        else:
                            date_list.append(date_obj)
                            i["principal"] = i["loan_deposit"] - daily_interest
                            i["interest"] = daily_interest
                else:
                    raise ValueError("No penalties found for the specified loan")

                running_total -= i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
            else:
                running_total -= i["loan_deposit"]
                i["principal"] = i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
                i["interest"] = 0
            
        elif i["description"] == 'Disbursement' or i["description"] == 'Apply Interest':
            i["debit"] = i["loan_deposit"]
            running_total += i["loan_deposit"]
            i["loan_deposit"] = 0
        else:
            running_total += i["loan_deposit"] if i["description"] != 'Loan Penalty' else i["debit"]

        outstanding_balance = running_total

        transaction = {
            "posting_date": i["posting_date"],
            "description": i["description"],
            "loan_deposit": float(i["loan_deposit"]),
            "debit": float(i["debit"]),
            "credit": float(i["credit"]),
            "principal": float(i["principal"]),
            "interest": float(i["interest"]),
            "penalty": float(i["penalty"]),
            "outstanding": outstanding_balance,
            "transaction_id": i["transaction_id"]
        }

        transactions.append(transaction)
    
    # Summing totals
    total_loan_deposit = sum(i["loan_deposit"] for i in transactions)
    total_debit = sum(i["debit"] for i in transactions)
    total_credit = sum(i["credit"] for i in transactions)
    total_principal = sum(i["principal"] for i in transactions)
    total_interest = sum(i["interest"] for i in transactions)
    total_penalty = sum(i["penalty"] for i in transactions)
    total_outstanding = transactions[-1]["outstanding"] if transactions else 0
    total_interest2 = 0
    total_interest2 = (total_interest - get_arrears(loan))

    # Return only the totals
    totals = {
        "loan_deposit": total_loan_deposit,
        "debit": total_debit,
        "credit": total_credit,
        "principal": total_principal,
        "interest": total_interest2,
        "penalty": total_penalty,
        "outstanding": total_outstanding
    }

    return totals

@frappe.whitelist(allow_guest=True)
def getcurrentloandata(loan):
    query_filters = {"loan": loan}
    query = frappe.db.sql("""
        SELECT 
            transactions.creation AS posting_date, 
            transaction_types.type_name AS description,
            transactions.amount AS loan_deposit,
            0 AS debit,
            0 AS credit,
            transactions.principal_repaid_derived + transactions.principal_recovered AS principal,
            transactions.interest_repaid_derived + transactions.interest_recovered AS interest,
            transactions.penalties_repaid_derived + transactions.penalties_recovered AS penalty,
            transactions.name AS transaction_id,
            'None' AS dd,
            transactions.description AS org_desc,
            transactions.ispaypen AS is_loan_pen,
            transactions.ispaypen2 AS is_loan_pen2,
            transactions.penaltyamount AS tt_pen  
        FROM 
            `tabLoan Transaction2` AS transactions
        LEFT JOIN 
            `tabLoan Transaction Type` AS transaction_types 
        ON 
            transactions.transaction_type = transaction_types.name
        WHERE 
            transactions.loan = %(loan)s
            AND transactions.docstatus = 1

        UNION ALL

        SELECT 
            penalties.creation AS posting_date, 
            'Loan Penalty' AS description,
            0 AS loan_deposit,
            penalties.amount AS debit,
            0 AS credit,
            0 AS principal,
            0 AS interest,
            penalties.penalty AS penalty,
            penalties.name AS transaction_id,
            'None' AS dd,
            'None' AS org_desc,
            0 AS is_loan_pen,
            0 AS is_loan_pen2,
            0 AS tt_pen  
        FROM 
            `tabLoan Penalty II` AS penalties
        WHERE 
            penalties.loan = %(loan)s
            AND penalties.docstatus = 1

        UNION ALL

        SELECT 
            repayments.creation AS posting_date, 
            'Loan Repayment' AS description,
            repayments.amount AS loan_deposit,
            0 AS debit,
            0 AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            repayments.name AS transaction_id,
            repayments.payment_method AS dd,
            'None' AS org_desc,
            repayments.ispaypen AS is_loan_pen,
            repayments.ispaypen2 AS is_loan_pen2,
            repayments.penaltyamount AS tt_pen  
        FROM 
            `tabLoan Repayment` AS repayments
        WHERE 
            repayments.loan = %(loan)s
            AND repayments.docstatus = 1

             UNION ALL

        SELECT 
            repayments2.posting_date AS posting_date, 
            'Loan Repayment' AS description,
            repayments2.amount AS loan_deposit,
            0 AS debit,
            0 AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            repayments2.name AS transaction_id,
            '' AS dd,
            'None' AS org_desc,
           0 AS is_loan_pen,
           0 AS is_loan_pen2,
            0 AS tt_pen  
        FROM 
            `tabSavings To Loan Transfer` AS repayments2
        WHERE 
            repayments2.loan = %(loan)s
            AND repayments2.docstatus = 1

        UNION ALL

        SELECT 
            waives.creation AS posting_date, 
            'Waive Loan II' AS description,
            waives.amount AS loan_deposit,
            0 AS debit,
            waives.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            waives.name AS transaction_id,
            waives.waive_type AS dd,
            'None' AS org_desc,
            0 AS is_loan_pen,
            0 AS is_loan_pen2,
            0 AS tt_pen  
        FROM 
            `tabWaive Loan II` AS waives
        WHERE 
            waives.loan = %(loan)s
            AND waives.docstatus = 1

        UNION ALL

        SELECT 
            write_offs.creation AS posting_date, 
            'Write Off Loan II' AS description,
            write_offs.amount AS loan_deposit,
            0 AS debit,
            write_offs.amount AS credit,
            0 AS principal,
            0 AS interest,
            0 AS penalty,
            write_offs.name AS transaction_id,
            write_offs.waive_type AS dd,
            'None' AS org_desc,
            0 AS is_loan_pen,
            0 AS is_loan_pen2,
            0 AS tt_pen  
        FROM 
            `tabWrite Off Loan II` AS write_offs
        WHERE 
            write_offs.loan = %(loan)s
            AND write_offs.docstatus = 1
        
        ORDER BY 
            posting_date
    """, query_filters, as_dict=True)


    if not query:
        return [], 0 

    transactions = []
    penalties = frappe.db.get_all("Loan Penalty II", filters={"loan": loan}, fields=["amount"])
    total_penalties = sum((p['amount']) for p in penalties) or 0
    running_total = 0
    interestleft = 0
    date_list = []
    repayment_dates = generate_loan_schedule(loan)
    for i in query:
        i["interest"] = 0
        i["penalty"] = 0
        total_penalties = float(i["tt_pen"]) if i["tt_pen"] not in [None, ''] else 0.0
       

        if i["description"] == 'Waive Loan II':
            i["loan_deposit"] = 0
            i["description"] = i["description"] + "-" + i["dd"]
            if i["dd"] == "Penalties":
                i["penalty"] = i["credit"]
            else:
                i["interest"] = i["credit"] 

            running_total -= i["credit"]
        elif i["description"] == 'Write Off Loan II':
            i["description"] = i["description"] + "-" + i["dd"]
            i["loan_deposit"] = 0
            running_total -= i["credit"]
            if i["dd"] == "Principle":
                i["principal"] = i["credit"]
            else:
                i["interest"] = i["credit"]
        elif i["description"] == 'Repayment':
            i["description"] = i["org_desc"]
            datetime_obj = i["posting_date"]
            date_obj = datetime_obj.date()
            ortrrr = i["loan_deposit"] 
            # No need to convert to string and parse again
            # date_object is the same as date_obj in this case
            date_object = date_obj
            if 1:
               
                if i["is_loan_pen2"] > 2:
                    i["interest_arrears"] = i["is_loan_pen2"]
                    i["loan_deposit"] -= i["is_loan_pen2"]
                   
                

                if i["is_loan_pen"] == 1:
                    running_total -= i["loan_deposit"]

                    loan_deposit = float(i["loan_deposit"])
                    balancer = total_penalties - loan_deposit

                    if balancer > 0:
                        total_penalties -= i["loan_deposit"]
                       
                        i["principal"] = 0
                        i["credit"] = 0
                        i["interest"] = 0
                        i["penalty"] =  i["loan_deposit"]
                    else:
                        orgg = i["loan_deposit"]
                        i["loan_deposit"] = abs(balancer)
                        if date_obj not in date_list and str(date_object) in repayment_dates:
                        
                            penalties = frappe.db.sql("""
                                SELECT loan_tenure, principal, payment_intervals, loan_interest
                                FROM `tabLoan Application Plus`
                                WHERE name LIKE %(keyword)s
                                """, {"keyword": loan}, as_dict=True)

                            if penalties:
                                for penalty in penalties:
                                    loan_tenure = penalty['loan_tenure']
                                    principal = penalty['principal']
                                    payment_intervals = penalty['payment_intervals']
                                    annual_interest_rate =  penalty['loan_interest']
                                    daily_interest = ((annual_interest_rate / 100) / 30) * ( principal) 
                                    if interestleft > 0:
                                        daily_interest = interestleft
                                    
                                    if daily_interest >= i["loan_deposit"]:
                                        i["principal"] =  0
                                        i["interest"] = i["loan_deposit"]
                                        interestleft = daily_interest - i["loan_deposit"]
                                    else:
                                        date_list.append(date_obj)
                                        i["principal"] = i["loan_deposit"] - daily_interest
                                        i["interest"] = daily_interest
                            else:
                                raise ValueError("No penalties found for the specified loan")

                           
                            i["credit"] = ortrrr
                        else:
                           
                            i["principal"] = i["loan_deposit"]
                            i["loan_deposit"] = orgg
                            i["credit"] = orgg
                            i["interest"] = 0

                        
                        i["penalty"] =  total_penalties
                        i["loan_deposit"] = orgg
                        
                

                else:
                    if date_obj not in date_list and str(date_object) in repayment_dates:
                    
                        penalties = frappe.db.sql("""
                            SELECT loan_tenure, principal, payment_intervals, loan_interest
                            FROM `tabLoan Application Plus`
                            WHERE name LIKE %(keyword)s
                            """, {"keyword": loan}, as_dict=True)

                        if penalties:
                            for penalty in penalties:
                                loan_tenure = penalty['loan_tenure']
                                principal = penalty['principal']
                                payment_intervals = penalty['payment_intervals']
                                annual_interest_rate =  penalty['loan_interest']
                                daily_interest = ((annual_interest_rate / 100) / 30) * ( principal) 
                                if interestleft > 0:
                                    daily_interest = interestleft
                                
                                if daily_interest >= i["loan_deposit"]:
                                    i["principal"] =  0
                                    i["interest"] = i["loan_deposit"]
                                    interestleft = daily_interest - i["loan_deposit"]
                                else:
                                    date_list.append(date_obj)
                                    i["principal"] = i["loan_deposit"] - daily_interest
                                    i["interest"] = daily_interest
                        else:
                            raise ValueError("No penalties found for the specified loan")

                        running_total -= ortrrr
                        i["credit"] = ortrrr
                        i["loan_deposit"] = ortrrr
                        
                    else:
                        running_total -= i["loan_deposit"]
                        i["principal"] = i["loan_deposit"]
                        i["credit"] = i["loan_deposit"]
                        i["interest"] = 0

          
            
            

        elif i["description"] == 'Loan Repayment':
            loandata = frappe.get_doc("Loan Application Plus", loan)
            if i["dd"] == "Savings Account":
                i["description"] = "Repayment From Account(" + loandata.clients + ")"
            if isinstance(i["posting_date"], str):
                datetime_obj = datetime.datetime.strptime(i["posting_date"], "%Y-%m-%d")
            
            datetime_obj = i["posting_date"]
            date_obj = datetime_obj.date()
            ortrrr = i["loan_deposit"] 

            # No need to convert to string and parse again
            # date_object is the same as date_obj in this case
            date_object = date_obj
            if 1:
               
                if i["is_loan_pen2"] > 2:
                    i["interest_arrears"] = i["is_loan_pen2"]
                    i["loan_deposit"] -= i["is_loan_pen2"]
                   
                

                if i["is_loan_pen"] == 1:
                    running_total -= i["loan_deposit"]

                    loan_deposit = float(i["loan_deposit"])
                    balancer = total_penalties - loan_deposit

                    if balancer > 0:
                        total_penalties -= i["loan_deposit"]
                       
                        i["principal"] = 0
                        i["credit"] = 0
                        i["interest"] = 0
                        i["penalty"] =  i["loan_deposit"]
                    else:
                        orgg = i["loan_deposit"]
                        i["loan_deposit"] = abs(balancer)
                        if date_obj not in date_list and str(date_object) in repayment_dates:
                        
                            penalties = frappe.db.sql("""
                                SELECT loan_tenure, principal, payment_intervals, loan_interest
                                FROM `tabLoan Application Plus`
                                WHERE name LIKE %(keyword)s
                                """, {"keyword": loan}, as_dict=True)

                            if penalties:
                                for penalty in penalties:
                                    loan_tenure = penalty['loan_tenure']
                                    principal = penalty['principal']
                                    payment_intervals = penalty['payment_intervals']
                                    annual_interest_rate =  penalty['loan_interest']
                                    daily_interest = ((annual_interest_rate / 100) / 30) * ( principal) 
                                    if interestleft > 0:
                                        daily_interest = interestleft
                                    
                                    if daily_interest >= i["loan_deposit"]:
                                        i["principal"] =  0
                                        i["interest"] = i["loan_deposit"]
                                        interestleft = daily_interest - i["loan_deposit"]
                                    else:
                                        date_list.append(date_obj)
                                        i["principal"] = i["loan_deposit"] - daily_interest
                                        i["interest"] = daily_interest
                            else:
                                raise ValueError("No penalties found for the specified loan")

                           
                            i["credit"] = ortrrr
                        else:
                           
                            i["principal"] = i["loan_deposit"]
                            i["loan_deposit"] = orgg
                            i["credit"] = orgg
                            i["interest"] = 0

                        
                        i["penalty"] =  total_penalties
                        i["loan_deposit"] = orgg
                        
                

                else:
                    if date_obj not in date_list and str(date_object) in repayment_dates:
                    
                        penalties = frappe.db.sql("""
                            SELECT loan_tenure, principal, payment_intervals, loan_interest
                            FROM `tabLoan Application Plus`
                            WHERE name LIKE %(keyword)s
                            """, {"keyword": loan}, as_dict=True)

                        if penalties:
                            for penalty in penalties:
                                loan_tenure = penalty['loan_tenure']
                                principal = penalty['principal']
                                payment_intervals = penalty['payment_intervals']
                                annual_interest_rate =  penalty['loan_interest']
                                daily_interest = ((annual_interest_rate / 100) / 30) * ( principal) 
                                if interestleft > 0:
                                    daily_interest = interestleft
                                
                                if daily_interest >= i["loan_deposit"]:
                                    i["principal"] =  0
                                    i["interest"] = i["loan_deposit"]
                                    interestleft = daily_interest - i["loan_deposit"]
                                else:
                                    date_list.append(date_obj)
                                    i["principal"] = i["loan_deposit"] - daily_interest
                                    i["interest"] = daily_interest
                        else:
                            raise ValueError("No penalties found for the specified loan")

                        running_total -= ortrrr
                        i["credit"] = ortrrr
                        i["loan_deposit"] = ortrrr
                        
                    else:
                        running_total -= i["loan_deposit"]
                        i["principal"] = i["loan_deposit"]
                        i["credit"] = i["loan_deposit"]
                        i["interest"] = 0

        elif i["description"] == 'Disbursement' or i["description"] == 'Apply Interest':
            i["debit"] = i["loan_deposit"]
            running_total += i["loan_deposit"]
            i["loan_deposit"] = 0
        else:
            running_total += i["loan_deposit"] if i["description"] != 'Loan Penalty' else i["debit"]

        outstanding_balance = running_total
        if i["is_loan_pen2"] < 2:
            i["is_loan_pen2"]=0

        transaction = {
            "posting_date": i["posting_date"],
            "description": i["description"],
            "loan_deposit": float(i["loan_deposit"]),
            "debit": float(i["debit"]),
            "credit": float(i["credit"]),
            "principal": float(i["principal"]),
            "interest": float(i["interest"]),
            "interest_arrears": i["is_loan_pen2"],
            "penalty": float(i["penalty"]),
            "outstanding": outstanding_balance,
            "transaction_id": i["transaction_id"]
        }

        transactions.append(transaction)
    total_loan_deposit = sum(i["loan_deposit"] for i in transactions)
    total_debit = sum(i["debit"] for i in transactions)
    total_credit = sum(i["credit"] for i in transactions)
    total_principal = sum(i["principal"] for i in transactions)
    total_interest = sum(i["interest"] for i in transactions)
    total_interest_arrears = sum(i["interest_arrears"] for i in transactions)
    total_penalty = sum(i["penalty"] for i in transactions)
    total_outstanding = transactions[-1]["outstanding"] if transactions else 0
    total_interest2 = 0
    total_interest2 = (total_interest - get_arrears(loan))

    # Return only the totals
    totals = {
        "loan_deposit": total_loan_deposit,
        "debit": total_debit,
        "credit": total_credit,
        "principal": total_principal,
        "interest": total_interest2,
        "interest_arreas": total_interest_arrears,
        "penalty": total_penalty,
        "outstanding": total_outstanding
    }

    return totals

import frappe

@frappe.whitelist(allow_guest=True)
def get_write_offs(loan, loan2):
    amount = frappe.db.get_value(
        "Write Off Loan II",
        {"loan": loan, "waive_type": loan2},
        "amount"
    )
    return {"amount": amount or 0}


@frappe.whitelist(allow_guest=True)
def get_loan_statement3(loan: str = None, loan2: str = None):
    loan_application = frappe.get_doc("Loan Application Plus", loan)
    get_total_outstanding(loan_application.clients)
    # SQL query to fetch transaction data
    query = frappe.db.sql(f"""
    SELECT 
        transactions.creation AS posting_date, 
        transaction_types.type_name AS description,
        transactions.amount AS loan_deposit,
        0 AS debit,
        0 AS credit,
        transactions.principal_repaid_derived + transactions.principal_recovered AS principal,
        transactions.interest_repaid_derived + transactions.interest_recovered AS interest,
        transactions.penalties_repaid_derived + transactions.penalties_recovered AS penalty
    FROM 
        `tabLoan Transaction2` AS transactions
    LEFT JOIN 
        `tabLoan Transaction Type` AS transaction_types 
    ON 
        transactions.transaction_type = transaction_types.name
    WHERE 
        transactions.loan = '{loan}'
        AND transactions.docstatus = 1

    UNION ALL

    SELECT 
        penalties.creation AS posting_date, 
        'Loan Penalty' AS description,
        0 AS loan_deposit,
        penalties.amount AS debit,
        0 AS credit,
        0 AS principal,
        0 AS interest,
        0 AS penalty
    FROM 
        `tabLoan Penalty II` AS penalties
    WHERE 
        penalties.loan = '{loan}'
        AND penalties.docstatus = 1

    UNION ALL

    SELECT 
        repayments.creation AS posting_date, 
        'Loan Repayment' AS description,
        repayments.amount AS loan_deposit,
        0 AS debit,
        0 AS credit,
        0 AS principal,
        0 AS interest,
        0 AS penalty
    FROM 
        `tabLoan Repayment` AS repayments
    WHERE 
        repayments.loan = '{loan}'
        AND repayments.docstatus = 1

    

    UNION ALL

    SELECT 
        write_offs.creation AS posting_date, 
        'Write Off Loan II' AS description,
        write_offs.amount AS loan_deposit,
        0 AS debit,
        write_offs.amount AS credit,
        0 AS principal,
        0 AS interest,
        0 AS penalty
    FROM 
        `tabWrite Off Loan II` AS write_offs
    WHERE 
        write_offs.loan  = '{loan}'
        AND write_offs.waive_type = '{loan2}'
        AND write_offs.docstatus = 1


    ORDER BY 
        posting_date
        
    """, as_dict=True)

    if not query:
        return [{
            "posting_date": "Total",
            "description": "Total",
            "loan_deposit": 0,
            "debit": 0,
            "credit": 0,
            "principal": 0,
            "interest": 0,
            "penalty": 0,
            "outstanding": 0
        }]

    transactions = []
    running_total = 0
    for i in query:
        if i["description"] == 'Write Off Loan II':
            i["credit"] = float(i["credit"])
            running_total -= i["credit"]

        elif i["description"] == 'Waive Loan II':
            i["credit"] = float(i["credit"])
            running_total -= i["credit"]
        else:
            i["loan_deposit"] = float(i["loan_deposit"])
            i["debit"] = float(i["debit"])
            
            i["principal"] = float(i["principal"])
            i["interest"] = float(i["interest"])
            i["penalty"] = float(i["penalty"]) if i["penalty"] else 0  # Convert penalty to float, handle None
            running_total += i["loan_deposit"] - i["debit"] + i["credit"]

        outstanding_balance = running_total

        transaction = {
            "posting_date": i["posting_date"],
            "description": i["description"],
            "loan_deposit": i["loan_deposit"],
            "debit": i["debit"],
            "credit": i["credit"],
            "principal": i["principal"],
            "interest": i["interest"],
            "penalty": i["penalty"],
            "outstanding": outstanding_balance,
        }

        transactions.append(transaction)

    # Calculate totals
    total_loan_deposit = sum(i["loan_deposit"] for i in transactions)
    total_debit = sum(i["debit"] for i in transactions)
    total_credit = sum(i["credit"] for i in transactions)
    total_principal = sum(i["principal"] for i in transactions)
    total_interest = sum(i["interest"] for i in transactions)
    total_penalty = sum(i["penalty"] for i in transactions)
    total_outstanding = transactions[-1]["outstanding"] if transactions else 0

    totals = {
        "posting_date": "Total",
        "description": "Total",
        "loan_deposit": total_loan_deposit,
        "debit": total_debit,
        "credit": total_credit,
        "principal": total_principal,
        "interest": total_interest,
        "penalty": total_penalty,
        "outstanding": total_outstanding
    }

    transactions.append(totals)
    return totals

# Server Script or Custom Method (Python)
@frappe.whitelist()
def get_filtered_clients():
    # Fetch all clients with status "Active"
    active_clients = frappe.get_all('Savings Account', filters={'workflow_state': 'Activated','client_type': ['not in', ['Group Account', 'Joint Accounts']]  # Assuming 'Group' and 'Joint' are the names of the DocTypes
}, fields=['name'])
    
    # Fetch clients who have a "Running" loan application
    clients_with_running_loan = frappe.get_all('Loan Application Plus', filters={'status': 'Running'}, fields=['clients'])
    clients_with_running_loan = [client['clients'] for client in clients_with_running_loan]
    
    # Filter out clients who have a running loan application
    filtered_clients = [client['name'] for client in active_clients if client['name'] not in clients_with_running_loan]
    
    return filtered_clients


@frappe.whitelist()
def generate_loan_schedule(loan):
    # Retrieve loan details
    loan_application = frappe.get_doc("Loan Application Plus", loan)
    loan_application_date = get_loan_application_date(loan)
    
    if not loan_application_date:
        frappe.throw("Loan disbursement date not found")
    
    # Ensure loan_application_date is a datetime object
    if isinstance(loan_application_date, str):
        loan_date = datetime.strptime(loan_application_date, '%Y-%m-%d')
    else:
        loan_date = loan_application_date
    
    loan_amount = loan_application.principal
    loan_interest = loan_application.loan_interest
    loan_term = int(loan_application.loan_tenure)  # Convert to integer
    grace_period = int(loan_application.grace_period_on_disbursment)  # Convert to integer

    # Extract skipped dates and days
    skipped_days = []
    skipped_dates = []
    for entry in loan_application.calendar_settings:
        if entry.skipped_type == 'day' and entry.day:
            skipped_days.append(entry.day)
        elif entry.skipped_type == 'date' and entry.date:
            skipped_dates.append(entry.date.strftime('%Y-%m-%d'))

    # Calculate interest rates
    interest_rate_per_day = (loan_interest / 100) / 365
    
    # Initialize variables
    repayment_dates = []
    current_date = loan_date + timedelta(days=grace_period)
    last_date = loan_date + timedelta(days=loan_term)
    total_repayments = 0

    # Generate repayment schedule
    while current_date <= last_date:
        date_str = current_date.strftime('%Y-%m-%d')
        day_of_week = current_date.strftime('%A')

 
        # Check if current_date is a skipped date, skipped day, or Sunday
        if date_str in skipped_dates or day_of_week in skipped_days or day_of_week == 'Sunday':
            current_date += timedelta(days=1)
            continue


        # Calculate daily repayment
        daily_interest = loan_amount * interest_rate_per_day
        principal_repayment = (loan_amount / loan_term)  # Assuming equal principal repayments
        total_repayment = principal_repayment + daily_interest

        # Append repayment details
        repayment_dates.append({
            'date': current_date.strftime('%Y-%m-%d'),
            'principal_repayment': round(principal_repayment, 2),
            'interest_repayment': round(daily_interest, 2),
            'total_repayment': round(total_repayment, 2)
        })
        
        # Update total repayments
        total_repayments += total_repayment
        
        # Move to next repayment date
        current_date += timedelta(days=1)

    # Final adjustments if not all repayments were used
    if total_repayments < loan_amount:
        # Allocate remaining repayments to principal
        remaining_principal = loan_amount - total_repayments
        if repayment_dates:
            # Add remaining principal to the last repayment
            repayment_dates[-1]['principal_repayment'] += remaining_principal
            repayment_dates[-1]['total_repayment'] = repayment_dates[-1]['principal_repayment'] + repayment_dates[-1]['interest_repayment']
        total_repayments = loan_amount
    # frappe.throw(str(repayment_dates))
    # Return only the repayment dates
    return [entry['date'] for entry in repayment_dates]


@frappe.whitelist(allow_guest=True)
def get_list_glentries(filters=None, fields=None, limit_page_length=20):
    filters = frappe.parse_json(filters) if filters else {}
    fields = frappe.parse_json(fields) if fields else ["account", "debit", "credit", "posting_date"]
    
    # Query the GL Entry doctype
    data = frappe.get_list(
        'GL Entry II',
        filters=filters,
        fields=fields,
        limit_page_length=10
    )
    
    return {'message': data}


@frappe.whitelist(allow_guest=True)
def get_loan_statement(loan: str = None):
    # SQL query to fetch transaction data
    query = frappe.db.sql(f"""
    
    SELECT 
        transactions.creation AS posting_date, 
        transaction_types.type_name AS description,
        transactions.amount AS loan_deposit,
        0 AS debit,
        0 AS credit,
        transactions.principal_repaid_derived + transactions.principal_recovered AS principal,
        transactions.interest_repaid_derived + transactions.interest_recovered AS interest,
        transactions.penalties_repaid_derived + transactions.penalties_recovered AS penalty,
        transactions.name AS transaction_id,
        'None' AS dd,
        'None' AS org_desc
    FROM 
        `tabLoan Transaction2` AS transactions
    LEFT JOIN 
        `tabLoan Transaction Type` AS transaction_types 
    ON 
        transactions.transaction_type = transaction_types.name
    WHERE 
        transactions.loan = '{loan}'
        AND transactions.docstatus = 1

    UNION ALL

    SELECT 
        penalties.creation AS posting_date, 
        'Loan Penalty' AS description,
        0 AS loan_deposit,
        penalties.amount AS debit,
        0 AS credit,
        0 AS principal,
        0 AS interest,
        penalties.penalty AS penalty,
        penalties.name AS transaction_id,
        'None' AS dd,
        'None' AS org_desc
    FROM 
        `tabLoan Penalty II` AS penalties
    WHERE 
        penalties.loan = '{loan}'
        AND penalties.docstatus = 1

    UNION ALL

    SELECT 
        repayments.creation AS posting_date, 
        'Loan Repayment' AS description,
        repayments.amount AS loan_deposit,
        0 AS debit,
        0 AS credit,
        0 AS principal,
        0 AS interest,
        0 AS penalty,
        repayments.name AS transaction_id,
        repayments.payment_method AS dd,
        'None' AS org_desc
    FROM 
        `tabLoan Repayment` AS repayments
    WHERE 
        repayments.loan = '{loan}'
        AND repayments.docstatus = 1

    UNION ALL

    SELECT 
        waives.creation AS posting_date, 
        'Waive Loan II' AS description,
        waives.amount AS loan_deposit,
        0 AS debit,
        waives.amount AS credit,
        0 AS principal,
        0 AS interest,
        0 AS penalty,
        waives.name AS transaction_id,
        waives.waive_type AS dd,
        'None' AS org_desc
    FROM 
        `tabWaive Loan II` AS waives
    WHERE 
        waives.loan = '{loan}'
        AND waives.docstatus = 1

    UNION ALL

    SELECT 
        write_offs.creation AS posting_date, 
        'Write Off Loan II' AS description,
        write_offs.amount AS loan_deposit,
        0 AS debit,
        write_offs.amount AS credit,
        0 AS principal,
        0 AS interest,
        0 AS penalty,
        write_offs.name AS transaction_id,
        write_offs.waive_type AS dd,
        'None' AS org_desc
    FROM 
        `tabWrite Off Loan II` AS write_offs
    WHERE 
        write_offs.loan = '{loan}'
        AND write_offs.docstatus = 1
    
    ORDER BY 
        posting_date
    """, as_dict=True)


    if not query:
        return [], 0

    transactions = []
    running_total = 0
    interestleft = 0
    date_list = []
    loan_schedule = generate_loan_schedule(loan)
    repayment_dates = loan_schedule
    next_schedule_date= loan_schedule[0] if loan_schedule else None
    
    for i in query:
        i["interest"] = 0
        i["penalty"] = 0

        if i["description"] == 'Waive Loan II':
            i["loan_deposit"] = 0
            i["description"] = i["description"] + "-" + i["dd"]
            if i["dd"] == "Penalties":
                i["penalty"] = i["credit"]
            else:
                i["interest"] = i["credit"] 

            running_total -= i["credit"]
        elif i["description"] == 'Write Off Loan II':
            i["description"] = i["description"] + "-" + i["dd"]
            i["loan_deposit"] = 0
            running_total -= i["credit"]
            if i["dd"] == "Principle":
                i["principal"] = i["credit"]
            else:
                i["interest"] = i["credit"]
        elif i["description"] == 'Repayment':
            i["description"] = i["org_desc"]
            datetime_obj = i["posting_date"]
            date_obj = datetime_obj.date()

            # No need to convert to string and parse again
            # date_object is the same as date_obj in this case
            date_object = date_obj

            if date_obj not in date_list and str(date_object) in repayment_dates:
               
                penalties = frappe.db.sql("""
                    SELECT loan_tenure, principal, payment_intervals, loan_interest
                    FROM `tabLoan Application Plus`
                    WHERE name LIKE %(keyword)s
                    """, {"keyword": loan}, as_dict=True)

                if penalties:
                    for penalty in penalties:
                        loan_tenure = penalty['loan_tenure']
                        principal = penalty['principal']
                        payment_intervals = penalty['payment_intervals']
                        annual_interest_rate =  penalty['loan_interest']
                        daily_interest = ((annual_interest_rate / 100) / 30) * ( principal) 
                        if interestleft > 0:
                            daily_interest = interestleft
                        
                        if daily_interest >= i["loan_deposit"]:
                            i["principal"] =  0
                            i["interest"] = i["loan_deposit"]
                            interestleft = daily_interest - i["loan_deposit"]
                        else:
                            date_list.append(date_obj)
                            i["principal"] = i["loan_deposit"] - daily_interest
                            i["interest"] = daily_interest
                else:
                    raise ValueError("No penalties found for the specified loan")

                running_total -= i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
            else:
                running_total -= i["loan_deposit"]
                i["principal"] = i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
                i["interest"] = 0
        elif i["description"] == 'Loan Repayment':
            loandata = frappe.get_doc("Loan Application Plus", loan)
            
            repayment_date = datetime.strptime(i["posting_date"], "%Y-%m-%d")  # Convert repayment date to datetime
            
            if repayment_date not in loan_schedule_dates:
                days_between = (next_schedule_date - repayment_date).days
                daily_interest += 500  # Add daily interest for valid repayment dates
          
            
            next_schedule_date=repayment_date
            if i["dd"] == "Savings Account":
                i["description"] = "Repayment From Account(" + loandata.clients + ")"
            if isinstance(i["posting_date"], str):
                datetime_obj = datetime.datetime.strptime(i["posting_date"], "%Y-%m-%d")
            
            datetime_obj = i["posting_date"]
            date_obj = datetime_obj.date()

            # No need to convert to string and parse again
            # date_object is the same as date_obj in this case
            date_object = date_obj

            if date_obj not in date_list and str(date_object) in repayment_dates:
               
                penalties = frappe.db.sql("""
                    SELECT loan_tenure, principal, payment_intervals, loan_interest
                    FROM `tabLoan Application Plus`
                    WHERE name LIKE %(keyword)s
                    """, {"keyword": loan}, as_dict=True)

                if penalties:
                    for penalty in penalties:
                        loan_tenure = penalty['loan_tenure']
                        principal = penalty['principal']
                        payment_intervals = penalty['payment_intervals']
                        annual_interest_rate =  penalty['loan_interest']
                        daily_interest = ((annual_interest_rate / 100) / 30) * ( principal) 
                        if interestleft > 0:
                            daily_interest = interestleft
                        
                        if daily_interest >= i["loan_deposit"]:
                            i["principal"] =  0
                            i["interest"] = i["loan_deposit"]
                            interestleft = daily_interest - i["loan_deposit"]
                        else:
                            date_list.append(date_obj)
                            i["principal"] = i["loan_deposit"] - daily_interest
                            i["interest"] = daily_interest
                else:
                    raise ValueError("No penalties found for the specified loan")

                running_total -= i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
            else:
                running_total -= i["loan_deposit"]
                i["principal"] = i["loan_deposit"]
                i["credit"] = i["loan_deposit"]
                i["interest"] = 0
            
        elif i["description"] == 'Disbursement' or i["description"] == 'Apply Interest':
            i["debit"] = i["loan_deposit"]
            running_total += i["loan_deposit"]
            i["loan_deposit"] = 0
        else:
            running_total += i["loan_deposit"] if i["description"] != 'Loan Penalty' else i["debit"]

        outstanding_balance = running_total

        transaction = {
            "posting_date": i["posting_date"],
            "description": i["description"],
            "loan_deposit": float(i["loan_deposit"]),
            "debit": float(i["debit"]),
            "credit": float(i["credit"]),
            "principal": float(i["principal"]),
            "interest": float(i["interest"]),
            "penalty": float(i["penalty"]),
            "outstanding": outstanding_balance,
            "transaction_id": i["transaction_id"]
        }

        transactions.append(transaction)

    total_loan_deposit = sum(i["loan_deposit"] for i in transactions)
    total_debit = sum(i["debit"] for i in transactions)
    total_credit = sum(i["credit"] for i in transactions)
    total_principal = sum(i["principal"] for i in transactions)
    total_interest = sum(i["interest"] for i in transactions)
    total_penalty = sum(i["penalty"] for i in transactions)
    total_outstanding = transactions[-1]["outstanding"] if transactions else 0

    totals = {
        "posting_date": "Total",
        "description": "Total",
        "loan_deposit": total_loan_deposit,
        "debit": total_debit,
        "credit": total_credit,
        "principal": total_principal,
        "interest": total_interest,
        "penalty": total_penalty,
        "outstanding": total_outstanding
    }

    return totals
    


@frappe.whitelist(allow_guest=True)
def search_loan_bydates_api_desk(keyword: any = None, from_date: any = None, to_date: any = None):
    results = []
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        filters = {"keyword": keyword}
        query = """
        SELECT *
        FROM `tabLoan Transaction2` as lt  
        JOIN `tabLoan` as ln ON lt.loan = ln.name 
        JOIN tabClient as cl ON ln.client = cl.name
        WHERE cl.mobile LIKE %(keyword)s
        """
        if not from_date:
            from_date = datetime.now().strftime('%Y-%m-%d')
        if not to_date:
            to_date = datetime.now().strftime('%Y-%m-%d')

        filters["from_date"] = from_date
        filters["to_date"] = to_date

        query += " AND lt.creation BETWEEN %(from_date)s AND %(to_date)s limit 100"
        
        data = frappe.db.sql(query, filters, as_dict=True)
        
        if data:
            results = data
    return results


@frappe.whitelist(allow_guest=True)
def get_loan_repayment_dates(loan_id):
    """
    Fetch repayment dates for a given loan ID.
    """
    try:
        # Query the database for repayment dates
        repayment_dates = frappe.db.sql("""
            SELECT created_on
            FROM `tabLoan Repayment`
            WHERE loan = %s
            ORDER BY created_on
        """, (loan_id,), as_dict=True)

        # Extract dates from the result
        dates = [entry.created_on for entry in repayment_dates]
        return dates
    except Exception as e:
        frappe.log_error(f"Error fetching loan repayment dates for loan ID {loan_id}: {str(e)}")
        return []


@frappe.whitelist(allow_guest=True)
def get_total_repayments(loan_id: str) -> float:
    total_repayment = frappe.db.sql("""
        SELECT SUM(amount) 
        FROM `tabLoan Repayment` 
        WHERE loan = %s
    """, loan_id, as_dict=True)
    return total_repayment[0].get('SUM(amount)', 0) if total_repayment else 0



    ## Application Apis
@frappe.whitelist(allow_guest=True)
def search_client_api(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"

        data = frappe.db.sql("""
        SELECT *
        FROM tabClient as client
        WHERE  client.mobile like %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results


import frappe
import time

@frappe.whitelist(allow_guest=True)
def execute_sql_with_progress():
    # clients = frappe.get_all("Client", fields=["name", "first_name", "middle_name", "last_name"])

    # for client in clients:
    #     # Safely concatenate full_name, handling None values
    #     first_name = client.first_name or ""
    #     middle_name = client.middle_name or ""
    #     last_name = client.last_name or ""

    #     updated_fullname = f"{first_name} {middle_name} {last_name}".strip()

    #     # Update the fullname field
    #     frappe.db.set_value("Client", client.name, "full_name", updated_fullname)

    # frappe.db.commit()  # Save changes to the database
    savings_accounts = frappe.get_all("Savings Account", fields=["name", "external_number"])

    for account in savings_accounts:
        # Get the client record where external_number matches external_id
        if account.external_number:  # Check if external_number is not None
            client = frappe.get_all("Client", filters={"external_id": account.external_number}, fields=["name", "full_name"])
            
            # Update the client_name and client fields in the Savings Account record
            if client:
                # Since get_all() returns a list, we access the first result
                client = client[0]  # Take the first result from the list
                # Set the client_name to the fullname
                frappe.db.set_value("Savings Account", account.name, "client_name", client['full_name'])
                # Set the client field to the client id (name)
                frappe.db.set_value("Savings Account", account.name, "client", client['name'])

    frappe.db.commit()  # Save changes to the database



from typing import Optional

@frappe.whitelist(allow_guest=True)
def generate_signing_mandate(truncated_names: any = None):
    api_key = frappe.conf.get('openai_api_key')
    if not api_key:
        return "OpenAI API key is missing."

    openai.api_key = api_key

    try:
        response = openai.Completion.create(
            engine="text-davinci-003",  # Specify the model you want to use
            prompt=f"Generate a banking signing mandate for the following names: {truncated_names}",
            max_tokens=150
        )
        mandate = response.choices[0].text.strip()
        return mandate
    except Exception as e:
        frappe.log_error(f"OpenAI API error: {str(e)}", "OpenAI API Call")
        return None
import frappe

import random
@frappe.whitelist(allow_guest=True)
def insert_saving_transaction(account, client_name, transaction_type, amount, posting_date, 
                              transaction_type_name=None, modified_by=None, owner=None, company=None, 
                              branch=None, branch_name=None, savings_officer=None, status=None, 
                              external_id=None, useridold=None):
    
    # Function to generate a random unique number for the name
    def generate_unique_name():
        while True:
            random_number = random.randint(7000000000, 7999999999) 
            existing_record = frappe.db.sql(""" 
                SELECT name FROM `tabSaving Transaction` WHERE name = %s 
            """, (random_number,))
            if not existing_record:
                return random_number

    # Generate a unique random name
    unique_name = generate_unique_name()

    # Set defaults for optional parameters
    transaction_type_name = transaction_type_name or 'Default Type'
    modified_by = modified_by or 'System'
    owner = owner or 'User'
    company = company or 'Default Company'
    branch = branch or 'Default Branch'
    branch_name = branch_name or 'Default Branch Name'
    savings_officer = savings_officer or 'Default Officer'
    status = status or 'Active'
    external_id = external_id or 'Default External ID'
    useridold = useridold or 'Default User ID Old'

    # Prepare the SQL query to insert the data including `external_id` and `useridold`
    query = """
        INSERT INTO `tabSaving Transaction` (`name`, `account`, `client_name`, `transaction_type`, 
        `amount`, `posting_date`, `creation`, `modified`, `transaction_type_name`, `modified_by`, `owner`, 
        `company`, `branch`, `branch_name`, `savings_officer`, `status`, `external_id`, `useridold`)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    
    # Execute the query with all provided parameters
    frappe.db.sql(query, (unique_name, account, client_name, transaction_type, amount, posting_date, 
                          posting_date, posting_date, transaction_type_name, modified_by, owner, company, 
                          branch, branch_name, savings_officer, status, external_id, useridold))
    
    # Commit the transaction
    frappe.db.commit()
    
    # Return the unique name (ID) of the inserted document
    return unique_name

from datetime import datetime
def insert_into_ledger_double_entry(transaction, description, amount, debit=None, credit=None, saving_account_id=None):
    fff=0
     

@frappe.whitelist(allow_guest=True)
def mark_day_closed(doc):
    try:
        # Update the 'disabled' field of the submitted document
        frappe.db.set_value("Accounting Period", doc, "disabled", 1)
        
        # Retrieve the list of 'Closed Document' entries related to the given doc
        period_to_close = frappe.db.get_list("Closed Document", filters={"parent": doc}, pluck="name")
        
        # Log the doc for debugging purposes
        frappe.logger().info(f"Document to close: {doc}")
        
        # Check if there are any periods to close
        if len(period_to_close) > 0:
            for period in period_to_close:
                # Set the 'closed' field to 1 for each 'Closed Document' entry
                frappe.db.set_value("Closed Document", period, "closed", 1)

        return f"Document {doc} and related periods have been marked closed."

    except Exception as e:
        # Handle any exceptions and provide a meaningful error message
        frappe.throw(f"An error occurred while marking the document closed: {str(e)}")

@frappe.whitelist(allow_guest=True)
def runtestforreciveble():
    deposit_fees_receivable=0
    monthly_receivable=0
    account_receivable = frappe.get_list("General Ledger II", 
            filters={
                "savings_account": "107099195",
                "transaction_type_name": "accountrecivable"
            },
            fields=["name", "debit", "credit"]
        )

    remaining_amount = 50000

    for records in [account_receivable, deposit_fees_receivable, monthly_receivable]:
        for record in records:
            debit = record['debit']
            credit = record['credit']
            record_name = record['name']

            if remaining_amount <= 0:
                break

            if credit < debit:
                datadiffersn = debit - credit
                amount_to_adjust = min(remaining_amount, datadiffersn)

                if amount_to_adjust < 1:
                    amount_to_adjust = datadiffersn
                   
                # Update existing record
                frappe.db.sql("""
                    UPDATE `tabGeneral Ledger II` 
                    SET credit = credit + %s
                    WHERE name = %s
                """, (datadiffersn, record_name))
                frappe.db.commit()


                current_user = "kansiimejackie@uwezomicrofinance.com"
                coa_account = frappe.db.get_value('Employee', {'user': current_user}, 'coa_account')
                coa_account_name = frappe.get_doc("Account", {"name": coa_account})

                saving_transactionr2 = frappe.get_doc({
                        'parent_transaction': record_name, 'doctype': 'General Ledger II',
                        'account': coa_account_name,
                        'label_for_report': coa_account_name,
                        'transaction_type': 1,
                        'transaction_type_name': "Deposit",
                        'posting_date': datetime.now().date(),
                        'company': doc.company,
                        'branch': doc.branch,
                        'amount': amount_to_adjust,
                        'credit': 0,
                        'debit':datadiffersn,
                        'main_parent': "Assets",
                        'sub_parent': "Cash & Cash Equivalents",
                        'category': coa_account_name,
                        'savings_account': savings_account_id
                        })
                saving_transactionr2.insert()
                saving_transactionr2.submit()

                remaining_amount -= amount_to_adjust
                return "done"

            if remaining_amount > 0:
         
                return "paid due to excess"

    return account_receivable


@frappe.whitelist(allow_guest=True)
def transfer_saving_to_general_ledger():
    batch_size = 10000
    offset = 0
    
    while True:
        transactions = frappe.db.sql(f"""
            SELECT name, account, client_name, transaction_type, amount, posting_date, company, branch, status,
                transaction_type_name, client_account, debit, credit
            FROM `tabSaving Transaction` as savs
            WHERE name NOT IN (SELECT name FROM `tabGeneral Ledger II`)
           
            AND LOWER(transaction_type_name) NOT LIKE '%loan application fees%'
           
           
            AND LOWER(transaction_type_name) NOT LIKE '%disbursement%'
                          
           
            AND LOWER(transaction_type_name) NOT LIKE '%wrong account%'
            AND LOWER(transaction_type_name) NOT LIKE '%transfer%'
         
            AND LOWER(transaction_type_name) NOT LIKE '%loan-app%'
            AND LOWER(transaction_type_name) NOT LIKE '%reconciliation%'
            AND LOWER(transaction_type_name) NOT LIKE '%loan repayment%'
        
            and parent_transaction <> savs.name
            LIMIT {batch_size} OFFSET {offset};
        """, as_dict=True)



       
        if not transactions:
            break  # No more records
        
        for transaction in transactions:
            try:
                description = transaction.get("transaction_type_name", "").lower()
                amount = transaction.get("amount", 0)
                savings_account_id = transaction.get("account")
                
                
                try:
                    savings_account = frappe.get_doc("Savings Account", {"name": savings_account_id})
                 
           
            
                    
                    try:
                        if "opening balance" in description:
                            account_name = savings_account.name
                            savapname = savings_account.saving_product
                            try:
                                saving_product = frappe.get_doc("Saving Product", {"name": savapname})
                            
                                coa_account_name3 = frappe.get_doc("Account", {"name": saving_product.customer_balance_account})
                            except frappe.DoesNotExistError:
                                continue  # Skip if Saving Product or Account is not found
                            except Exception as e:
                                continue  # Skip other unexpected errors
                            
                            date = nowdate()
                            coa_account_name3 = coa_account_name3.name
                            
                            try:
                                parent_transaction = transaction.get("name")
                                company = savings_account.company
                                branch = savings_account.branch
                                posting_date = transaction.get("posting_date")
                                
                                query = """
                                    INSERT INTO `tabGeneral Ledger II` (`parent_transaction`, `account`, `label_for_report`, 
                                    `transaction_type`, `transaction_type_name`, `posting_date`, `company`, `branch`, `amount`, 
                                    `credit`, `debit`, `main_parent`, `sub_parent`, `category`, `savings_account`,`docstatus`)
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                """
                                values = (parent_transaction, coa_account_name3, coa_account_name3, 1, description, posting_date, 
                                        company, branch, amount, amount, 0, "Liabilities", "Balances On Customer Account", coa_account_name3, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()
                            

                                coa_account = frappe.db.get_value('Employee', {'user': "migration@uwezo.com"}, 'coa_account')
                                coa_account_name = frappe.get_doc(
                                        "Account", {"name": coa_account}
                                    )

                        
                                values = (parent_transaction, coa_account_name, coa_account_name, 1, description, posting_date, 
                                        company, branch, amount, 0, amount, "Assets", "Cash & Cash Equivalents", coa_account_name, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()

                            except Exception as e:
                                continue  # Skip transaction if deposit processing fails
                        elif "loan application fees" in description:
                            description = description.lower()
                            parts = description.split("loan-app", 1)

                            if len(parts) > 1:
                                result = f"loan{parts[1].strip()}".lower()
                                return result
                            else:
                                return "No loan-app found"

                            loan_id = description.split()[1]
                            account_name = savings_account.name
                            savapname = savings_account.saving_product
                            try:
                                saving_product = frappe.get_doc("Saving Product", {"name": savapname})
                                loan = frappe.get_doc("Loan Application Plus", {"name": loan_id})
                                loan_product = frappe.get_doc("Loan Product", {"name": loan.loan_type})
                            
                                coa_account_name3 = frappe.get_doc("Account", {"name": saving_product.customer_balance_account})
                              
                            except frappe.DoesNotExistError:
                                continue  # Skip if Saving Product or Account is not found
                            except Exception as e:
                                return  e.message  # Skip other unexpected errors
                            
                            date = nowdate()
                            coa_account_name3 = coa_account_name3.name
                            try:
                                parent_transaction = transaction.get("name")
                                company = savings_account.company
                                branch = savings_account.branch
                                posting_date = transaction.get("posting_date")
                                
                                query = """
                                    INSERT INTO `tabGeneral Ledger II` (`parent_transaction`, `account`, `label_for_report`, 
                                    `transaction_type`, `transaction_type_name`, `posting_date`, `company`, `branch`, `amount`, 
                                    `credit`, `debit`, `main_parent`, `sub_parent`, `category`, `savings_account`,`docstatus`)
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                """
                                values = (parent_transaction, coa_account_name3, coa_account_name3, 1, description, posting_date, 
                                        company, branch, amount, 0, amount, "Liabilities", "Balances On Customer Account", coa_account_name3, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()
                            

                                coa_account_name = frappe.get_doc("Account", {"name": loan_product.opening_fees_account})

                        
                                values = (parent_transaction, coa_account_name, coa_account_name, 1, description, posting_date, 
                                        company, branch, amount, amount, 0, "Income", "Income", coa_account_name, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()

                            except Exception as e:
                                continue  # Skip transaction if deposit processing fails
                        elif "security" in description or "security deposit" in description:
                            loan_id = description.split()[1]
                            account_name = savings_account.name
                            savapname = savings_account.saving_product
                            try:
                                saving_product = frappe.get_doc("Saving Product", {"name": savapname})
                                loan = frappe.get_doc("Loan Application Plus", {"name": loan_id})
                                loan_product = frappe.get_doc("Loan Product", {"name": loan.loan_type})
                            
                                coa_account_name3 = frappe.get_doc("Account", {"name": saving_product.customer_balance_account})
                              
                            except frappe.DoesNotExistError:
                                continue  # Skip if Saving Product or Account is not found
                            except Exception as e:
                                return  e.message  # Skip other unexpected errors
                            
                            date = nowdate()
                            coa_account_name3 = coa_account_name3.name
                            try:
                                parent_transaction = transaction.get("name")
                                company = savings_account.company
                                branch = savings_account.branch
                                posting_date = transaction.get("posting_date")
                                
                                query = """
                                    INSERT INTO `tabGeneral Ledger II` (`parent_transaction`, `account`, `label_for_report`, 
                                    `transaction_type`, `transaction_type_name`, `posting_date`, `company`, `branch`, `amount`, 
                                    `credit`, `debit`, `main_parent`, `sub_parent`, `category`, `savings_account`,`docstatus`)
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                """
                                values = (parent_transaction, coa_account_name3, coa_account_name3, 1, description, posting_date, 
                                        company, branch, amount, 0, amount, "Liabilities", "Balances On Customer Account", coa_account_name3, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()
                            

                                coa_account_name = frappe.get_doc("Account", {"name": loan_product.cash_collateral_account})

                        
                                values = (parent_transaction, coa_account_name, coa_account_name, 1, description, posting_date, 
                                        company, branch, amount, amount, 0, "Liabilities", "Payable", coa_account_name, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()

                            except Exception as e:
                                continue  # Skip transaction if deposit processing fails
                        elif "disbursement" in description:
                            insert_into_ledger_double_entry(transaction, description, amount, debit=amount, saving_account_id=savings_account_id)
                        elif "penalty charge" in description:
                            insert_into_ledger_double_entry(transaction, description, amount, debit=amount, saving_account_id=savings_account_id)
                        elif "monthly" in description:
                            account_name = savings_account.name
                            savapname = savings_account.saving_product
                            try:
                                saving_product = frappe.get_doc("Saving Product", {"name": savapname})
                            
                                coa_account_name3 = frappe.get_doc("Account", {"name": saving_product.customer_balance_account})
                                coa_account_name = frappe.get_doc("Account", {"name": saving_product.monthly_fees_account})
                            except frappe.DoesNotExistError:
                                continue  # Skip if Saving Product or Account is not found
                            except Exception as e:
                                return  e.message  # Skip other unexpected errors
                            
                            date = nowdate()
                            coa_account_name3 = coa_account_name3.name
                            try:
                                parent_transaction = transaction.get("name")
                                company = savings_account.company
                                branch = savings_account.branch
                                posting_date = transaction.get("posting_date")
                                
                                query = """
                                    INSERT INTO `tabGeneral Ledger II` (`parent_transaction`, `account`, `label_for_report`, 
                                    `transaction_type`, `transaction_type_name`, `posting_date`, `company`, `branch`, `amount`, 
                                    `credit`, `debit`, `main_parent`, `sub_parent`, `category`, `savings_account`,`docstatus`)
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                """
                                values = (parent_transaction, coa_account_name3, coa_account_name3, 1, description, posting_date, 
                                        company, branch, amount, 0, amount, "Liabilities", "Balances On Customer Account", coa_account_name3, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()
                            

                                coa_account_name = frappe.get_doc("Account", {"name": saving_product.monthly_fees_account})

                        
                                values = (parent_transaction, coa_account_name, coa_account_name, 1, description, posting_date, 
                                        company, branch, amount, amount, 0, "Income", "Income", coa_account_name, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()

                            except Exception as e:
                                continue  # Skip transaction if deposit processing fails
                        elif "approval txn" in description:
                            account_name = savings_account.name
                            savapname = savings_account.saving_product
                            try:
                                saving_product = frappe.get_doc("Saving Product", {"name": savapname})
                            
                                coa_account_name3 = frappe.get_doc("Account", {"name": saving_product.customer_balance_account})
                                coa_account_name = frappe.get_doc("Account", {"name": saving_product.monthly_fees_account})
                            except frappe.DoesNotExistError:
                                continue  # Skip if Saving Product or Account is not found
                            except Exception as e:
                                return  e.message  # Skip other unexpected errors
                            
                            date = nowdate()
                            coa_account_name3 = coa_account_name3.name
                            try:
                                parent_transaction = transaction.get("name")
                                company = savings_account.company
                                branch = savings_account.branch
                                posting_date = transaction.get("posting_date")
                                
                                query = """
                                    INSERT INTO `tabGeneral Ledger II` (`parent_transaction`, `account`, `label_for_report`, 
                                    `transaction_type`, `transaction_type_name`, `posting_date`, `company`, `branch`, `amount`, 
                                    `credit`, `debit`, `main_parent`, `sub_parent`, `category`, `savings_account`,`docstatus`)
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                """
                                values = (parent_transaction, coa_account_name3, coa_account_name3, 1, description, posting_date, 
                                        company, branch, amount, 0, amount, "Liabilities", "Balances On Customer Account", coa_account_name3, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()
                            

                                coa_account_name = frappe.get_doc("Account", {"name": saving_product.emergency_fees})

                        
                                values = (parent_transaction, coa_account_name, coa_account_name, 1, description, posting_date, 
                                        company, branch, amount, amount, 0, "Income", "Income", coa_account_name, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()

                            except Exception as e:
                                continue  # Skip transaction if deposit processing fails
                        elif "passbook charge" in description or "pass book charge" in description :
                            account_name = savings_account.name
                            savapname = savings_account.saving_product
                            try:
                                saving_product = frappe.get_doc("Saving Product", {"name": savapname})
                            
                                coa_account_name3 = frappe.get_doc("Account", {"name": saving_product.customer_balance_account})
                              
                            except frappe.DoesNotExistError:
                                continue  # Skip if Saving Product or Account is not found
                            except Exception as e:
                                return  e.message  # Skip other unexpected errors
                            
                            date = nowdate()
                            coa_account_name3 = coa_account_name3.name
                            try:
                                parent_transaction = transaction.get("name")
                                company = savings_account.company
                                branch = savings_account.branch
                                posting_date = transaction.get("posting_date")
                                
                                query = """
                                    INSERT INTO `tabGeneral Ledger II` (`parent_transaction`, `account`, `label_for_report`, 
                                    `transaction_type`, `transaction_type_name`, `posting_date`, `company`, `branch`, `amount`, 
                                    `credit`, `debit`, `main_parent`, `sub_parent`, `category`, `savings_account`,`docstatus`)
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                """
                                values = (parent_transaction, coa_account_name3, coa_account_name3, 1, description, posting_date, 
                                        company, branch, amount, 0, amount, "Liabilities", "Balances On Customer Account", coa_account_name3, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()
                            

                                coa_account_name = frappe.get_doc("Account", {"name": "432605 - PassBook Charge - K"})

                        
                                values = (parent_transaction, coa_account_name, coa_account_name, 1, description, posting_date, 
                                        company, branch, amount, amount, 0, "Income", "Income", coa_account_name, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()

                            except Exception as e:
                                continue  # Skip transaction if deposit processing fails
                        elif  "charge" in description and "passbook charge" not in description and "pass book charge" not in description:
                            insert_into_ledger_double_entry(transaction, description, amount, debit=amount, saving_account_id=savings_account_id)
                        elif any(keyword in description for keyword in ["wrong account", "transfer", "loan-app", "reconciliation"]):
                            insert_into_ledger_double_entry(transaction, description, amount, debit=amount, saving_account_id=savings_account_id)
                        elif "account opening fees" in description:
                            account_name = savings_account.name
                            savapname = savings_account.saving_product
                            try:
                                saving_product = frappe.get_doc("Saving Product", {"name": savapname})
                            
                                coa_account_name3 = frappe.get_doc("Account", {"name": saving_product.customer_balance_account})
                            
                            except frappe.DoesNotExistError:
                                continue  # Skip if Saving Product or Account is not found
                            except Exception as e:
                                return  e.message  # Skip other unexpected errors
                            
                            date = nowdate()
                            coa_account_name3 = coa_account_name3.name
                            try:
                                parent_transaction = transaction.get("name")
                                company = savings_account.company
                                branch = savings_account.branch
                                posting_date = transaction.get("posting_date")
                                
                                query = """
                                    INSERT INTO `tabGeneral Ledger II` (`parent_transaction`, `account`, `label_for_report`, 
                                    `transaction_type`, `transaction_type_name`, `posting_date`, `company`, `branch`, `amount`, 
                                    `credit`, `debit`, `main_parent`, `sub_parent`, `category`, `savings_account`,`docstatus`)
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                """
                                values = (parent_transaction, coa_account_name3, coa_account_name3, 1, description, posting_date, 
                                        company, branch, amount, 0, amount, "Liabilities", "Balances On Customer Account", coa_account_name3, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()
                            

                                coa_account_name = frappe.get_doc("Account", {"name": saving_product.acc})

                        
                                values = (parent_transaction, coa_account_name, coa_account_name, 1, description, posting_date, 
                                        company, branch, amount, amount, 0, "Income", "Income", coa_account_name, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()

                            except Exception as e:
                                continue  # Skip transaction if deposit processing fails                    
                        elif "withdraw" in description and "withdraw fees" not in description:
                            account_name = savings_account.name
                            savapname = savings_account.saving_product
                            try:
                                saving_product = frappe.get_doc("Saving Product", {"name": savapname})
                            
                                coa_account_name3 = frappe.get_doc("Account", {"name": saving_product.customer_balance_account})
                            except frappe.DoesNotExistError:
                                continue  # Skip if Saving Product or Account is not found
                            except Exception as e:
                                continue  # Skip other unexpected errors
                            
                            date = nowdate()
                            coa_account_name3 = coa_account_name3.name
                            
                            try:
                                parent_transaction = transaction.get("name")
                                company = savings_account.company
                                branch = savings_account.branch
                                posting_date = transaction.get("posting_date")
                                
                                query = """
                                    INSERT INTO `tabGeneral Ledger II` (`parent_transaction`, `account`, `label_for_report`, 
                                    `transaction_type`, `transaction_type_name`, `posting_date`, `company`, `branch`, `amount`, 
                                    `credit`, `debit`, `main_parent`, `sub_parent`, `category`, `savings_account`,`docstatus`)
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                """
                                values = (parent_transaction, coa_account_name3, coa_account_name3, 1, description, posting_date, 
                                        company, branch, amount, 0, amount, "Liabilities", "Balances On Customer Account", coa_account_name3, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()
                            

                                coa_account = frappe.db.get_value('Employee', {'user': "migration@uwezo.com"}, 'coa_account')
                                coa_account_name = frappe.get_doc(
                                        "Account", {"name": coa_account}
                                    )

                        
                                values = (parent_transaction, coa_account_name, coa_account_name, 1, description, posting_date, 
                                        company, branch, amount, amount, 0, "Assets", "Cash & Cash Equivalents", coa_account_name, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()

                            except Exception as e:
                                continue  # Skip transaction if deposit processing fails
                        elif "deposit fees" in description:
                            account_name = savings_account.name
                            savapname = savings_account.saving_product
                            try:
                                saving_product = frappe.get_doc("Saving Product", {"name": savapname})
                            
                                coa_account_name3 = frappe.get_doc("Account", {"name": saving_product.depositfees})
                            except frappe.DoesNotExistError:
                                continue  # Skip if Saving Product or Account is not found
                            except Exception as e:
                                return  e.message  # Skip other unexpected errors
                            
                            date = nowdate()
                            coa_account_name3 = coa_account_name3.name
                            try:
                                parent_transaction = transaction.get("name")
                                company = savings_account.company
                                branch = savings_account.branch
                                posting_date = transaction.get("posting_date")
                                
                                query = """
                                    INSERT INTO `tabGeneral Ledger II` (`parent_transaction`, `account`, `label_for_report`, 
                                    `transaction_type`, `transaction_type_name`, `posting_date`, `company`, `branch`, `amount`, 
                                    `credit`, `debit`, `main_parent`, `sub_parent`, `category`, `savings_account`,`docstatus`)
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                """
                                values = (parent_transaction, coa_account_name3, coa_account_name3, 1, description, posting_date, 
                                        company, branch, amount, amount, 0, "Income", "Income", coa_account_name3, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()
                            

                                coa_account = frappe.db.get_value('Employee', {'user': "migration@uwezo.com"}, 'coa_account')
                                coa_account_name = frappe.get_doc(
                                        "Account", {"name": coa_account}
                                    )

                        
                                values = (parent_transaction, coa_account_name, coa_account_name, 1, description, posting_date, 
                                        company, branch, amount, 0, amount, "Assets", "Cash & Cash Equivalents", coa_account_name, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()

                            except Exception as e:
                                continue  # Skip transaction if deposit processing fails
                        elif "deposit" in description and "deposit fees" not in description:
                            account_name = savings_account.name
                            savapname = savings_account.saving_product
                            try:
                                saving_product = frappe.get_doc("Saving Product", {"name": savapname})
                            
                                coa_account_name3 = frappe.get_doc("Account", {"name": saving_product.customer_balance_account})
                            except frappe.DoesNotExistError:
                                continue  # Skip if Saving Product or Account is not found
                            except Exception as e:
                                continue  # Skip other unexpected errors
                            
                            date = nowdate()
                            coa_account_name3 = coa_account_name3.name
                            
                            try:
                                parent_transaction = transaction.get("name")
                                company = savings_account.company
                                branch = savings_account.branch
                                posting_date = transaction.get("posting_date")
                                
                                query = """
                                    INSERT INTO `tabGeneral Ledger II` (`parent_transaction`, `account`, `label_for_report`, 
                                    `transaction_type`, `transaction_type_name`, `posting_date`, `company`, `branch`, `amount`, 
                                    `credit`, `debit`, `main_parent`, `sub_parent`, `category`, `savings_account`,`docstatus`)
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                """
                                values = (parent_transaction, coa_account_name3, coa_account_name3, 1, description, posting_date, 
                                        company, branch, amount, amount, 0, "Liabilities", "Balances On Customer Account", coa_account_name3, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()
                            

                                coa_account = frappe.db.get_value('Employee', {'user': "migration@uwezo.com"}, 'coa_account')
                                coa_account_name = frappe.get_doc(
                                        "Account", {"name": coa_account}
                                    )

                        
                                values = (parent_transaction, coa_account_name, coa_account_name, 1, description, posting_date, 
                                        company, branch, amount, 0, amount, "Assets", "Cash & Cash Equivalents", coa_account_name, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()

                            except Exception as e:
                                continue  # Skip transaction if deposit processing fails
                        elif "loan repayment" in description:
                            return description
                            loan_id = "description.split()[1]"
                            account_name = savings_account.name
                            savapname = savings_account.saving_product
                            try:
                                saving_product = frappe.get_doc("Saving Product", {"name": savapname})
                                loan = frappe.get_doc("Loan Application Plus", {"name": loan_id})
                                loan_product = frappe.get_doc("Loan Product", {"name": loan.loan_type})
                            
                                coa_account_name3 = frappe.get_doc("Account", {"name": saving_product.customer_balance_account})
                            except frappe.DoesNotExistError:
                                continue  # Skip if Saving Product or Account is not found
                            except Exception as e:
                                continue  # Skip other unexpected errors
                            
                            date = nowdate()
                            coa_account_name3 = coa_account_name3.name
                            
                            try:
                                parent_transaction = transaction.get("name")
                                company = savings_account.company
                                branch = savings_account.branch
                                posting_date = transaction.get("posting_date")
                                
                                query = """
                                    INSERT INTO `tabGeneral Ledger II` (`parent_transaction`, `account`, `label_for_report`, 
                                    `transaction_type`, `transaction_type_name`, `posting_date`, `company`, `branch`, `amount`, 
                                    `credit`, `debit`, `main_parent`, `sub_parent`, `category`, `savings_account`,`docstatus`)
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                """
                                values = (parent_transaction, coa_account_name3, coa_account_name3, 1, description, posting_date, 
                                        company, branch, amount, amount, 0, "Liabilities", "Balances On Customer Account", coa_account_name3, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()
                            

                                coa_account = frappe.db.get_value('Employee', {'user': "migration@uwezo.com"}, 'coa_account')
                                coa_account_name = frappe.get_doc(
                                        "Account", {"name": coa_account}
                                    )

                        
                                values = (parent_transaction, coa_account_name, coa_account_name, 1, description, posting_date, 
                                        company, branch, amount, 0, amount, "Assets", "Cash & Cash Equivalents", coa_account_name, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()

                            except Exception as e:
                                continue  # Skip transaction if deposit processing fails
                        elif "withdraw fees" in description:
                            account_name = savings_account.name
                            savapname = savings_account.saving_product
                            try:
                                saving_product = frappe.get_doc("Saving Product", {"name": savapname})
                            
                                coa_account_name3 = frappe.get_doc("Account", {"name": saving_product.withdrawfee})
                            except frappe.DoesNotExistError:
                                continue  # Skip if Saving Product or Account is not found
                            except Exception as e:
                                return  e.message  # Skip other unexpected errors
                            
                            date = nowdate()
                            coa_account_name3 = coa_account_name3.name
                            try:
                                parent_transaction = transaction.get("name")
                                company = savings_account.company
                                branch = savings_account.branch
                                posting_date = transaction.get("posting_date")
                                
                                query = """
                                    INSERT INTO `tabGeneral Ledger II` (`parent_transaction`, `account`, `label_for_report`, 
                                    `transaction_type`, `transaction_type_name`, `posting_date`, `company`, `branch`, `amount`, 
                                    `credit`, `debit`, `main_parent`, `sub_parent`, `category`, `savings_account`,`docstatus`)
                                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                """
                                values = (parent_transaction, coa_account_name3, coa_account_name3, 1, description, posting_date, 
                                        company, branch, amount, amount, 0, "Income", "Income", coa_account_name3, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()
                            

                                coa_account = frappe.db.get_value('Employee', {'user': "migration@uwezo.com"}, 'coa_account')
                                coa_account_name = frappe.get_doc(
                                        "Account", {"name": coa_account}
                                    )

                        
                                values = (parent_transaction, coa_account_name, coa_account_name, 1, description, posting_date, 
                                        company, branch, amount, 0, amount, "Assets", "Cash & Cash Equivalents", coa_account_name, account_name, "1")
                                frappe.db.sql(query, values)
                                frappe.db.commit()

                            except Exception as e:
                                continue  # Skip transaction if deposit processing fails

                        else:
                            return description  # Skip unrecognized transactions
                    except Exception as e:
                        continue  # Skip transaction if processing fails
                    except frappe.DoesNotExistError:
                        continue  # Skip to next transaction if Savings Account is not found
                except Exception as e:
                    continue  # Skip other unexpected errors
                    
            except Exception as e:
                continue  # Skip transaction if unexpected error occurs

        try:
            frappe.db.commit()
            offset += batch_size  # Move to the next batch
        except Exception as e:
            pass  # Skip commit errors






@frappe.whitelist(allow_guest=True)
def search_client_api_name(keyword: Optional[str] = None) -> list:
    results = []
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        
        data = frappe.db.sql("""
        SELECT name, first_name
        FROM `tabClient` AS client
        WHERE client.name LIKE %(keyword)s

        UNION

        SELECT name, first_name
        FROM `tabGuarantors_` AS guarantor
        WHERE guarantor.name LIKE %(keyword)s

        UNION

        SELECT name, first_name
        FROM `tabAccount Agent` AS agent
        WHERE agent.name LIKE %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
        
        if data:
            results = data
            
    return results



@frappe.whitelist(allow_guest=True)
def search_savings_api(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM tabClient as client left join `tabSavings Account` as sv on client.name = sv.client
        WHERE  client.mobile like %(keyword)s
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results


@frappe.whitelist(allow_guest=True)
def search_savings_transaction_api(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabSaving Transaction` as st  join `tabSavings Account` as sa on st.account = sa.name left join tabClient as cl on sa.client = cl.name
        WHERE  st.account like %(keyword)s order by st.creation asc 
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results

@frappe.whitelist(allow_guest=True)
def search_savings_transaction_api2(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabSaving Transaction` as st  join `tabSavings Account` as sa on st.account = sa.name join tabClient as cl on sa.client = cl.name
        WHERE  st.deposited_by like %(keyword)s order by st.creation DESC limit 10
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results


@frappe.whitelist(allow_guest=True)
def search_savings_transaction_bydate_api(keyword: any = None, from_date: any = None, to_date: any = None):
    results = []
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        filters = {"keyword": keyword}
        query = """
        SELECT *
        FROM `tabSaving Transaction` as st  
        JOIN `tabSavings Account` as sa ON st.account = sa.name 
        JOIN tabClient as cl ON sa.client = cl.name
        WHERE cl.mobile LIKE %(keyword)s
        """
        if not from_date:
            from_date = datetime.now().strftime('%Y-%m-%d')
        if not to_date:
            to_date = datetime.now().strftime('%Y-%m-%d')

        filters["from_date"] = from_date
        filters["to_date"] = to_date

        query += " AND st.creation BETWEEN %(from_date)s AND %(to_date)s limit 100"
        
        data = frappe.db.sql(query, filters, as_dict=True)
        
        if data:
            results = data
    return results

@frappe.whitelist(allow_guest=True)
def search_savings_transaction_bydate_api2(keyword: any = None, from_date: any = None, to_date: any = None):
    results = []
    if keyword and len(keyword) >= 1:
        keyword = f"%{keyword}%"
        filters = {"keyword": keyword}
        query = """
        SELECT *
        FROM `tabSaving Transaction` as st  
        JOIN `tabSavings Account` as sa ON st.account = sa.name 
        JOIN tabClient as cl ON sa.client = cl.name
        WHERE st.deposited_by LIKE %(keyword)s
        """
        if not from_date:
            from_date = datetime.now().strftime('%Y-%m-%d')
        if not to_date:
            to_date = datetime.now().strftime('%Y-%m-%d')

        filters["from_date"] = from_date
        filters["to_date"] = to_date

        query += " AND st.creation BETWEEN %(from_date)s AND %(to_date)s limit 100"
        
        data = frappe.db.sql(query, filters, as_dict=True)
        
        if data:
            results = data
    return results



@frappe.whitelist(allow_guest=True)
def search_loans_api(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabLoan` as ln  join tabClient as cl on ln.client = cl.name join `tabLoan Product` as lp on ln.loan_product = lp.name
        WHERE  cl.mobile like %(keyword)s limit 50
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results


@frappe.whitelist(allow_guest=True)
def search_loans_api2(keyword: any = None):
    results = []
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        data = frappe.db.sql("""
        SELECT *
        FROM `tabLoan` as ln  join tabClient as cl on ln.client = cl.name join `tabLoan Product` as lp on ln.loan_product = lp.name
        WHERE  cl.mobile like %(keyword)s or cl.full_name like %(keyword)s or ln.loan_application like %(keyword)s limit 50
        """, {"keyword": keyword}, as_dict=True)
        if data:
            results = data
    return results

@frappe.whitelist(allow_guest=True)
def change_officer3(account: any = None, staff_id: any = None):
    doc = frappe.get_doc(staff_id, account)
    if staff_id == "Client":
      return doc.full_name
    elif staff_id == "Guarantors_":
      return " ".join([doc.get(field) for field in ("first_name", "middle_name", "last_name") if doc.get(field)])
    elif staff_id == "Account Agent":
      return " ".join([doc.get(field) for field in ("first_name", "middle_name", "last_name") if doc.get(field)])
    elif staff_id == "Group Account":
      return doc.first_name                               
    elif staff_id == "Joint Accounts":
      return doc.full_name

@frappe.whitelist(allow_guest=True)
def search_loan_bydates_api(keyword: any = None, from_date: any = None, to_date: any = None):
    results = []
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        filters = {"keyword": keyword}
        query = """
        SELECT *
        FROM `tabLoan Transaction2` as lt  
        JOIN `tabLoan` as ln ON lt.loan = ln.name 
        JOIN tabClient as cl ON ln.client = cl.name
        WHERE cl.mobile LIKE %(keyword)s
        """
        if not from_date:
            from_date = datetime.now().strftime('%Y-%m-%d')
        if not to_date:
            to_date = datetime.now().strftime('%Y-%m-%d')

        filters["from_date"] = from_date
        filters["to_date"] = to_date

        query += " AND lt.creation BETWEEN %(from_date)s AND %(to_date)s limit 50"
        
        data = frappe.db.sql(query, filters, as_dict=True)
        
        if data:
            results = data
    return results

@frappe.whitelist(allow_guest=True)
def run_monthly_savings_charges():
    from frappe.utils import cint

    # 1. Fetch only required fields, only active accounts
    accounts = frappe.get_all(
        "Savings Account",
        filters={"status": ["!=", "Inactive"]},
        fields=["name", "saving_product"],
        order_by="name asc"
    )

    if not accounts:
        return "No active savings accounts found"

    # 2. Cache Saving Products to avoid repeated DB hits
    product_cache = {}

    for idx, acc in enumerate(accounts, start=1):
        if not acc.saving_product:
            continue

        # Load product once per product
        if acc.saving_product not in product_cache:
            product_cache[acc.saving_product] = frappe.get_doc(
                "Saving Product",
                acc.saving_product
            )

        savings_product = product_cache[acc.saving_product]

        # Skip if no monthly fees
        if not savings_product.monthly_fees or savings_product.monthly_fees <= 0:
            continue

        # 3. Call your existing logic (UNCHANGED)
        create_savings_transactions(acc, savings_product)

        # 4. Commit in batches (prevents locks & deadlocks)
        if idx % 10 == 0:
            frappe.db.commit()

    frappe.db.commit()
    return f"Monthly charges processed for {len(accounts)} accounts"

@frappe.whitelist(allow_guest=True)
def process_charges():
    # Import functions at the top of the file
    savings_accounts = frappe.get_list("Savings Account", fields=["name", "saving_product"])  # Adjust fields if necessary
    for account in savings_accounts:
        try:
            # Retrieve the associated saving product document
            savings_product = frappe.get_doc("Saving Product", account.saving_product)
            
            # Check if there have been any transactions in the last 90 days, excluding monthly charges
            last_90_days = add_days(now_datetime(), -90)
            transactions = frappe.get_all("Saving Transaction", filters={
                "account": account.name,
                "posting_date": [">=", last_90_days],
                "transaction_type": ["!=", 12]  # Exclude monthly fees
            })
            
            # If the product has monthly fees, create savings transactions
            frappe.throw(savings_product.monthly_fees)
            if savings_product.monthly_fees > 0:
                create_savings_transactions(account, savings_product)
                
            # Check if the saving product is fixed
            if savings_product.is_fixed:
                # Get the current month name
                current_month = calendar.month_name[datetime.now().month].lower()
                
                # Calculate the total outstanding balance using the function
                result = get_total_outstanding(account.name)
                total_outstanding = 0
                
                # Ensure the result is correctly extracted
                if isinstance(result, dict) and "message" in result:
                    total_outstanding = result["message"]
                else:
                    total_outstanding = result
                
                # Attempt to retrieve an existing cycle record
                existing_cycle = frappe.get_all("Savings Cycle", filters={"savings_account": account.name}, limit=1)
                
                if existing_cycle:
                    # If the cycle exists, load the document
                    cycle_doc = frappe.get_doc("Savings Cycle", existing_cycle[0].name)
                    
                    # Set the value for the current month field
                    cycle_doc.set(current_month, total_outstanding)
                    
                    # Ensure status is set to "Running"
                    if cycle_doc.status != "Running":
                        cycle_doc.status = "Running"
                    
                    # Save the cycle document
                    cycle_doc.save()

            # Deactivate account if no non-monthly charge transactions in the last 90 days
            if not transactions:
                frappe.db.set_value("Savings Account", account.name, "status", "Inactive")
                frappe.db.set_value("Savings Account", account.name, "workflow_state", "Inactive")
                frappe.db.commit()
                frappe.logger().info(f"Savings Account {account.name} deactivated due to inactivity.")
        
        except Exception as e:
            frappe.logger().error(f"Error processing account {account.name}: {e}")



import time
import frappe
from frappe.exceptions import QueryTimeoutError, QueryDeadlockError
from frappe.utils import nowdate
from datetime import datetime

# ============================================================
# 1. PUBLIC ENTRY POINT (ENQUEUE ONLY)
# ============================================================

@frappe.whitelist(allow_guest=True)
def enqueue_monthly_savings_charges():
    frappe.enqueue(
        method=run_monthly_savings_charges_bg,
        queue="long",
        timeout=60 * 60,
        job_name="Monthly Savings Charges",
        is_async=True,
    )
    return "Monthly savings charges job queued successfully"


# ============================================================
# 2. BACKGROUND WORKER
# ============================================================
@frappe.whitelist(allow_guest=True)
def run_monthly_savings_charges_bg():
    accounts = frappe.get_all(
        "Savings Account",
        filters={"status": ["!=", "Inactive"]},
        fields=["name", "saving_product"],
        order_by="name asc",
    )

    product_cache = {}

    for acc in accounts:
        try:
            if not acc.saving_product:
                continue

            if acc.saving_product not in product_cache:
                product_cache[acc.saving_product] = frappe.get_doc(
                    "Saving Product", acc.saving_product
                )

            product = product_cache[acc.saving_product]

            if not product.monthly_fees or product.monthly_fees <= 0:
                continue

            _safe_create_savings_charges(acc, product)
            frappe.db.commit()

        except Exception:
            frappe.db.rollback()
            frappe.log_error(
                frappe.get_traceback(),
                f"Monthly savings charges failed for account {acc.name}",
            )

    frappe.db.commit()


# ============================================================
# 3. DEADLOCK / TIMEOUT SAFE WRAPPER
# ============================================================
@frappe.whitelist(allow_guest=True)
def _safe_create_savings_charges(account, product, retries=3):
    for attempt in range(retries):
        try:
            create_savings_transactions(account, product)
            return
        except (QueryTimeoutError, QueryDeadlockError):
            frappe.db.rollback()
            if attempt == retries - 1:
                raise
            time.sleep(0.5)


# ============================================================
# 4. FULL BUSINESS LOGIC (NOT SKIPPED)
# ============================================================
@frappe.whitelist(allow_guest=True)
def create_savings_transactions(account, savings_product):
    date = nowdate()
    savings_account_id = account.name
    account_name = account.name

    amount_disbursed = savings_product.monthly_fees

    account2 = frappe.get_doc("Savings Account", account_name)
    monthly_fees_receivable = savings_product.monthly_fees_receivable
    monthly_fees_receivablen = frappe.get_doc("Account", {"name": monthly_fees_receivable})
    coa_account_name3 = frappe.get_doc("Account", {"name": savings_product.monthly_fees_account})

    transaction_type = frappe.get_value("Saving Transaction Type", {"type_name": "Deposit Charge"})

    saving_transaction = frappe.get_doc({
        'doctype': 'Saving Transaction',
        'account': account.name,
        'transaction_type': transaction_type,
        'posting_date': date,
        'branch': savings_product.branch,
        'amount': savings_product.monthly_fees,
        'debit': savings_product.monthly_fees,
        'client_account': account.name,
        'reference': account.name,
        'description': "Monthly Charges",
        'is_parent': 1,
        'allow_charges': 0
    })
    saving_transaction.insert()
    saving_transaction.submit()

    if account2.balance_derived < savings_product.monthly_fees:
        balance = account2.balance_derived

        if balance > 0:
            existing_entry = frappe.get_list("General Ledger II", filters={
                'account': monthly_fees_receivable,
                'transaction_type_name': "monthlyfessrecivable",
                'savings_account': savings_account_id
            }, fields=["name", "credit", "debit"])

            if existing_entry:
                frappe.db.sql("""
                    UPDATE `tabGeneral Ledger II`
                    SET credit = credit + %s,
                        debit = debit + %s
                    WHERE name = %s
                """, (balance, savings_product.monthly_fees, existing_entry[0]["name"]))
            else:
                saving_transactionr = frappe.get_doc({
                    'doctype': 'General Ledger II',
                    'account': monthly_fees_receivable,
                    'label_for_report': monthly_fees_receivablen.name,
                    'transaction_type': 1,
                    'transaction_type_name': "monthlyfessrecivable",
                    'posting_date': datetime.now().date(),
                    'company': savings_product.company,
                    'branch': savings_product.branch,
                    'amount': savings_product.monthly_fees,
                    'credit': balance,
                    'debit': savings_product.monthly_fees,
                    'main_parent': "Assets",
                    'sub_parent': "Debtors & Receivables",
                    'category': monthly_fees_receivablen,
                    'savings_account': savings_account_id
                })
                saving_transactionr.insert()
                saving_transactionr.submit()

            coa_account_name2 = frappe.get_doc("Account", {"name": savings_product.customer_balance_account})
            saving_transactionr2 = frappe.get_doc({
                'doctype': 'General Ledger II',
                'account': savings_product.customer_balance_account,
                'label_for_report': coa_account_name2.name,
                'transaction_type': 1,
                'transaction_type_name': "withdraw",
                'posting_date': datetime.now().date(),
                'company': savings_product.company,
                'branch': savings_product.branch,
                'amount': balance,
                'credit': 0,
                'debit': balance,
                'main_parent': "Liabilities",
                'sub_parent': "Balances On Customer Account",
                'category': coa_account_name2,
                'savings_account': savings_account_id
            })
            saving_transactionr2.insert()
            saving_transactionr2.submit()

        saving_transactionr = frappe.get_doc({
            'doctype': 'General Ledger II',
            'account': savings_product.monthly_fees_account,
            'label_for_report': coa_account_name3.name,
            'transaction_type': 1,
            'transaction_type_name': "Monthly Fees",
            'posting_date': datetime.now().date(),
            'company': savings_product.company,
            'branch': savings_product.branch,
            'amount': savings_product.monthly_fees,
            'credit': savings_product.monthly_fees,
            'debit': 0,
            'main_parent': "Income",
            'sub_parent': "Income",
            'category': coa_account_name3,
            'savings_account': savings_account_id
        })
        saving_transactionr.insert()
        saving_transactionr.submit()

    else:
        saving_transactionr = frappe.get_doc({
            'doctype': 'General Ledger II',
            'account': savings_product.monthly_fees_account,
            'label_for_report': coa_account_name3.name,
            'transaction_type': 1,
            'transaction_type_name': "Monthly Fees",
            'posting_date': datetime.now().date(),
            'company': savings_product.company,
            'branch': savings_product.branch,
            'amount': savings_product.monthly_fees,
            'credit': savings_product.monthly_fees,
            'debit': 0,
            'main_parent': "Income",
            'sub_parent': "Income",
            'category': coa_account_name3,
            'savings_account': savings_account_id
        })
        saving_transactionr.insert()
        saving_transactionr.submit()

        coa_account_name2 = frappe.get_doc("Account", {"name": savings_product.customer_balance_account})
        saving_transactionr2 = frappe.get_doc({
            'doctype': 'General Ledger II',
            'account': savings_product.customer_balance_account,
            'label_for_report': coa_account_name2.name,
            'transaction_type': 1,
            'transaction_type_name': "Monthly Fees",
            'posting_date': datetime.now().date(),
            'company': savings_product.company,
            'branch': savings_product.branch,
            'amount': savings_product.monthly_fees,
            'credit': 0,
            'debit': savings_product.monthly_fees,
            'main_parent': "Liabilities",
            'sub_parent': "Balances On Customer Account",
            'category': coa_account_name2,
            'savings_account': savings_account_id
        })
        saving_transactionr2.insert()
        saving_transactionr2.submit()


def savings_transaction(date, account, savings_product, amount, trans_type="12"):
    transaction_type = frappe.get_value("Saving Transaction Type", {"name": trans_type})
    
    try:
        saving_transaction = frappe.get_doc({
            'doctype': 'Saving Transaction',
            'account': account.name,
            'transaction_type': transaction_type,
            'posting_date': date,
            'branch': account.branch,
            'amount': amount,
            'debit': amount,
            'client_account': account.name,
            'reference': account.name,
            'description': f'Monthly Charge for {savings_product.product_name}',
            'is_parent': 1,
            'allow_charges': 0 # Ensure this field exists in the Saving Transaction doctype
        })

        saving_transaction.insert()
        saving_transaction.submit()

    except Exception as e:
        frappe.log_error(f"Error in savings_transaction: {e}")
        
@frappe.whitelist(allow_guest=True)
def search_loan_bydates_api2(keyword: any = None, from_date: any = None, to_date: any = None):
    results = []
    if keyword and len(keyword) >= 3:
        keyword = f"%{keyword}%"
        filters = {"keyword": keyword}
        query = """
        SELECT *
        FROM `tabLoan Transaction2` as lt  
        JOIN `tabLoan` as ln ON lt.loan = ln.name 
        JOIN tabClient as cl ON ln.client = cl.name
        WHERE ln.name  LIKE %(keyword)s or cl.mobile  LIKE %(keyword)s
        """
        if not from_date:
            from_date = datetime.now().strftime('%Y-%m-%d')
        if not to_date:
            to_date = datetime.now().strftime('%Y-%m-%d')

        filters["from_date"] = from_date
        filters["to_date"] = to_date

        query += " AND lt.creation BETWEEN %(from_date)s AND %(to_date)s limit 50"
        
        data = frappe.db.sql(query, filters, as_dict=True)
        
        if data:
            results = data
    return results
