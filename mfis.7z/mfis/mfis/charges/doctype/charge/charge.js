// Copyright (c) 2022, Abbey and contributors
// For license information, please see license.txt

frappe.ui.form.on('Charge', {
    onload: function(frm) {

        var current_user = frappe.session.user;
		frappe.db.get_value('Employee', { 'user': current_user }, 'branch', function(r) {
            if (r && r.branch) {
                let user_branch = r.branch;
                
				frm.set_value('branch', user_branch);
                frm.set_df_property('branch', 'read_only', 1);
            

            } });
        },
    charge_applies_to: function (frm){
        frm.set_query("charge_time_type", function (){
        return {
            "filters" : [
                ["type", "IN", [frm.doc.charge_applies_to]]
            ]
        }
    })
    }
});
