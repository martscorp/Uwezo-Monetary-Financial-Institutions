# Copyright (c) 2022, Abbey and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document

import frappe


class Charge(Document):
    def after_insert(self):
        create_charge(self)


def create_charge(doc, method=None):
    doctype = "Savings Charges"

    if doc.charge_applies_to == "Loan":
        doctype = "Charge"

    charge = frappe.new_doc(doctype)

    if doc.charge_applies_to == "Savings":
        charge.saving_charge_name = doc.charge_name
    if doc.charge_applies_to == "Loan":
        charge.loan_charge_name = doc.charge_name

    charge.charge = doc.name
    charge.charge_name = doc.charge_name
    charge.penalty = doc.penalty
    charge.active = 1
    charge.amount = doc.amount
    charge.charge_calculation_type = doc.charge_calculation_type
    charge.min_cap = doc.min_cap
    charge.min_cap = doc.min_cap
    charge.charge_time_type = doc.charge_time_type

    charge.insert(ignore_links=True, ignore_mandatory=True)
