import frappe
from frappe.utils.print_format import download_multi_pdf


@frappe.whitelist()
def repayment(loan, amount, date=None):
    validate_request(loan, amount)

    if date is None:
        date = frappe.utils.today()

    doc = frappe.get_doc({
        "doctype": "Loan Repayment",
        "loan": loan,
        "amount": amount,
        "created_on": date
    })

    doc.flags.ignore_permissions = True
    doc.save()

    frappe.local.response["message"] = {
        "success": 1,
        "id": doc.name,
        "creation": doc.creation,
        "docstatus": doc.docstatus,
        "loan": doc.loan,
        "created_on": doc.created_on,
        "amount": doc.amount,
        # "payment_method": "Cash",
        "branch": doc.branch,
        "client_name": doc.client_name,
    }


@frappe.whitelist()
def submit(id):
    doc = get_payment(id)

    doc.flags.ignore_permissions = True
    doc.submit()

    frappe.local.response["message"] = {
        "success": 1,
        "id": doc.name,
        "creation": doc.creation,
        "docstatus": doc.docstatus,
        "loan": doc.loan,
        "created_on": doc.created_on,
        "amount": doc.amount,
        # "payment_method": "Cash",
        "branch": doc.branch,
        "client_name": doc.client_name,
    }


@frappe.whitelist()
def cancel(id):
    doc = get_payment(id)

    doc.flags.ignore_permissions = True
    doc.cancel()

    frappe.local.response["message"] = {
        "success": 1,
        "message": "Document successfully canceled"
    }


@frappe.whitelist()
def get_pdf_print(id):
    doc = get_payment(id)

    return download_multi_pdf(doctype={
        "Loan Repayment": [id]
    },
        name=doc.name,
        format="Loan Repayment Slip",
        no_letterhead=True,
    )


def validate_request(loan, amount):
    if amount is None:
        frappe.local.response['message'] = {
            "success": 0,
            "message": "Please enter amount"
        }

    if loan is None:
        frappe.local.response["message"] = {
            "success": 0,
            "message": "Please enter loan"
        }

    if loan:
        exists = frappe.db.exists("Loan", {
            "status": "active",
            "name": loan
        })

        if exists is None:
            frappe.local.response["message"] = {
                "success": 0,
                "message": "Invalid Loan"
            }


def get_payment(id):
    doc = frappe.get_doc("Loan Repayment", id)

    if doc is None:
        frappe.local.response["message"] = {
            "success": 0,
            "message": "Invalid Repayment"
        }

    return doc


@frappe.whitelist(allow_guest=True)
def products():
    loan_products = []

    data = frappe.db.get_list("Loan Product", filters={"active": 1}, fields=["name", "product_name"])

    if data:
        loan_products = data

    return loan_products



