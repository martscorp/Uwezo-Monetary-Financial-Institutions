frappe.ui.form.on('Employee', {
    refresh: function(frm) {

             frm.add_custom_button("Activate", function () {

    frappe.prompt(
        [
            {
                fieldtype: "Password",
                label: "New Password (Default: uwezo1234)",
                fieldname: "new_pwd",
                reqd: 1,
                default: "uwezo1234"
            }
        ],
        function (values) {

            let user_email = frm.doc.user ;

            if (!user_email) {
                frappe.msgprint("⚠️ No email found on employee record.");
                return;
            }

            // 1️⃣ Reset password
            frappe.call({
                method: "mfis.clients.set_frappe_password2",
                args: {
                    email: user_email,
                    password: values.new_pwd
                },
                callback: function () {

                    // 2️⃣ Set status = Active after password reset succeeds
                    frappe.call({
                        method: "frappe.client.set_value",
                        args: {
                            doctype: "Employee",
                            name: frm.doc.name,
                            fieldname: "status",
                            value: "Active"
                        },
                        callback: function () {
                            frappe.msgprint("✅ Employee Activated and Password Reset Successfully.");
                            frm.reload_doc();
                        }
                    });

                }
            });

        },
        "Activate Employee",
        "Set Password"
    );

});

frm.add_custom_button("Deactivate", function () {

    frappe.confirm(
        "Are you sure you want to deactivate this employee and reset their password?",
        function () {

            // 1️⃣ Set Employee status = Suspended
            frappe.call({
                method: "frappe.client.set_value",
                args: {
                    doctype: "Employee",
                    name: frm.doc.name,
                    fieldname: "status",
                    value: "Suspended"
                },
                callback: function () {

                    // 2️⃣ Reset Password using your custom method
                    frappe.call({
                        method: "mfis.clients.set_frappe_password3",
                        args: {
                            email: frm.doc.user,   // user email from employee
                            password: "uwezo1234"     // default password
                        },
                        callback: function () {
                            frappe.msgprint("❌ Employee deactivated and password reset.");
                            frm.reload_doc();
                        }
                    });

                }
            });

        }
    );

});



        frm.add_custom_button('Transfer This Portfolio', () => {
            let d = new frappe.ui.Dialog({
                title: 'Choose New Owner',
                fields: [
                    {
                        label: 'Savings Officer',
                        fieldname: 'staff_id',
                        fieldtype: 'Link',
                        default: frm.doc.staff_id,
                        options: 'Employee',
                        get_query: () => {
                            return {
                                filters: {
                                  
                                    'roles': ['in', [frm.doc.roles]]
                                }
                            }
                        }
                    },
                    {
                        label: 'Savings Account',
                        fieldname: 'account',
                        fieldtype: 'Link',
                        default: frm.doc.name,
                        options: 'Savings Account',
                        hidden: 1
                    },

                ],
                primary_action_label: 'Submit',
                primary_action(values) {
                    frappe.call({
                        method: 'mfis.savings.doctype.savings_account.savings_account.change_officer2',
                        args: values,
                        btn: $('.primary-action'),
                        freeze: true,
                        callback: (r) => {
                            console.log('success')
                            frappe.show_alert({
                                message: __("Portfolio Update"),
                                indicator: 'green'
                            }, 5) 
                        },
                        error: (r) => {
                            frappe.throw('Something went wrong, try again')
                        }
                    })

                    d.hide();
                }
            })

            d.show()
        }, 'Manage Portfolio')
    }
});
