from . import __version__ as app_version

app_name = "mfis"
app_title = "Mfis"
app_publisher = "Abbey"
app_description = "Micro Finance Management System"
app_email = "mugieabbeym@gmail.com"
app_license = "MIT"

# Includes in <head>
# ------------------

app_include_js = "mfis.bundle.js"
# include js, css files in header of desk.html
# app_include_css = "/assets/mfis/css/mfis.css"
# app_include_js = "/assets/mfis/js/mfis.js"

# include js, css files in header of web template
# web_include_css = "/assets/mfis/css/mfis.css"
# web_include_js = "/assets/mfis/js/mfis.js"

# include custom scss in every website theme (without file extension ".scss")
# website_theme_scss = "mfis/public/scss/website"

# include js, css files in header of web form
# webform_include_js = {"doctype": "public/js/doctype.js"}
# webform_include_css = {"doctype": "public/css/doctype.css"}

# include js in page
# page_js = {"page" : "public/js/file.js"}

# include js in doctype views
# doctype_js = {"doctype" : "public/js/doctype.js"}
# doctype_list_js = {"doctype" : "public/js/doctype_list.js"}
# doctype_tree_js = {"doctype" : "public/js/doctype_tree.js"}
# doctype_calendar_js = {"doctype" : "public/js/doctype_calendar.js"}

treeviews = [
    "Account"
]

# Home Pages
# ----------

# application home page (will override Website Settings)
# home_page = "login"

# website user home page (by Role)
# role_home_page = {
#	"Role": "home_page"
# }

# Generators
# ----------

# automatically create page for each record of this doctype
# website_generators = ["Web Page"]

# Jinja
# ----------

# add methods and filters to jinja environment
# jinja = {
#	"methods": "mfis.utils.jinja_methods",
#	"filters": "mfis.utils.jinja_filters"
# }

# Installation
# ------------
setup_wizard_requires = "assets/mfis/js/setup_wizard.js"
setup_wizard_stages = "mfis.setup.setup_wizard.setup_wizard.get_setup_stages"
# before_install = "mfis.install.before_install"
after_install = "mfis.setup.setup_wizard.install.after_install"

# Uninstallation
# ------------

# before_uninstall = "mfis.uninstall.before_uninstall"
# after_uninstall = "mfis.uninstall.after_uninstall"

# Desk Notifications
# ------------------
# See frappe.core.notifications.get_notification_config

# notification_config = "mfis.notifications.get_notification_config"

# Permissions
# -----------
# Permissions evaluated in scripted ways
permission_query_conditions = {
    "Branch": "mfis.permissions.branch_query",
}

# permission_query_conditions = {
#	"Event": "frappe.desk.doctype.event.event.get_permission_query_conditions",
# }
#
# has_permission = {
#	"Event": "frappe.desk.doctype.event.event.has_permission",
# }

# DocType Class
# ---------------
# Override standard doctype classes

# override_doctype_class = {
#	"ToDo": "custom_app.overrides.CustomToDo"
# }

# Document Events
# ---------------
# Hook on document methods and events

doc_events = {
    # "*": {
    # 	"on_update": "method",
    # 	"on_cancel": "method",
    # 	"on_trash": "method"
    # }
    "Bank Transactions": {
        "before_save": [
                    "mfis.banking.doctype.float_request.float_request.check_for_float",
                ],
    },

    "Float Sell": {
        "before_save": [
                    "mfis.banking.doctype.float_request.float_request.check_for_float",
                ],
    },

    "Float Purchase": {
        "before_save": [
                    "mfis.banking.doctype.float_request.float_request.check_for_float",
                ],
    },


    "Saving Transaction": {
        "on_update": [

        ],
        "before_submit": [
            "mfis.savings.doctype.saving_transaction.saving_transaction.check_for_inter_branch",
            # "mfis.savings.doctype.saving_transaction.saving_transaction.update_charges",
            "mfis.savings.doctype.saving_transaction.saving_transaction.check_account_balance_before_withdraw",
            "mfis.savings.doctype.saving_transaction.saving_transaction.reverse_overdraft",
        ],
        "on_cancel": [
            "mfis.savings.doctype.saving_transaction.saving_transaction.update_client_balance",
        ],
        "on_update_after_submit": [
            # "mfis.savings.doctype.saving_transaction.saving_transaction.update_client_balance",
        ]

    },
    "Savings Account": {
        # "on_submit": [
        #     "mfis.savings.doctype.savings_account.savings_account.create_opening_balance2"
        # ]
    },
    "Loan Application Plus": {
        "on_submit": [
            "mfis.mfis.doctype.loan_application_plus.loan_application_plus.update_loan_application",
            "mfis.mfis.doctype.loan_application_plus.loan_application_plus.validate_guarantors",
            "mfis.mfis.doctype.loan_application_plus.loan_application_plus.auto_disburse"
        ],
        "on_cancel": [
            "mfis.mfis.doctype.loan_application_plus.loan_application_plus.update_loan_application_on_cancel"
        ],
        "on_change": [
            "mfis.mfis.doctype.loan_application_plus.loan_application_plus.check_for_approval_fees",
            "mfis.mfis.doctype.loan_application_plus.loan_application_plus.check_disbursement_charges",
            "mfis.mfis.doctype.loan_application_plus.loan_application_plus.notify_guarantors"
        ]
    }
    
,


    # "Withdraw": {
    #     "on_submit": [
    #         "mfis.savings.doctype.withdraw.withdraw.send_otp"
    #     ]
    # },

    "Float Purchase": {
        "on_submit": [
            "mfis.mfis.doctype.float_purchase.float_purchase.update_account_balance"
            # "mfis.banking.doctype.bank_transactions.bank_transactions.update_overdraft_value"
        ]
    }, 

     "Float Sell": {
        "on_submit": [
            "mfis.mfis.doctype.float_sell.float_sell.update_account_balance"
            # "mfis.banking.doctype.bank_transactions.bank_transactions.update_overdraft_value"
        ]
    }

}

# Scheduled Tasks
# ---------------

scheduler_events = {
    "cron": {
        "* * * * *": [
            "mfis.clients.process_pending_messages"  # runs every minute
        ],

       "0 23 * * *": [
            "mfis.clients.runllalldata_monthly"
        ]
    },
    "all": [
        # You can leave this empty if you don't need other tasks running every scheduler cycle
    ],
    "daily": [
        "mfis.clients.deactivate_inactive_savings_accounts"
        "mfis.savings.doctype.savings_account.monthly_charges.fixed_account_closure",
        "mfis.accounts.doctype.fiscal_year.fiscal_year.auto_create_fiscal_year",
        "mfis.accounts.doctype.accounting_period.accounting_period.close_day",
    ],
    "daily_long": [
        "mfis.savings.doctype.savings_account.monthly_charges.process_loan_repayments",
    ],
    "hourly_long": [
        # long-running hourly tasks
    ],
    "monthly_long": [
        "mfis.savings.doctype.savings_account.monthly_charges.process_charges"
    ],
}


# Testing
# -------

# before_tests = "mfis.install.before_tests"

# Overriding Methods
# ------------------------------
#
# override_whitelisted_methods = {
#	"frappe.desk.doctype.event.event.get_events": "mfis.event.get_events"
# }
#
# each overriding function accepts a `data` argument;
# generated from the base implementation of the doctype dashboard,
# along with any modifications made in other Frappe apps
# override_doctype_dashboards = {
#	"Task": "mfis.task.get_dashboard_data"
# }

# exempt linked doctypes from being automatically cancelled
#
# auto_cancel_exempted_doctypes = ["Auto Repeat"]

boot_session = "mfis.startup.boot.boot_session"

# User Data Protection
# --------------------

# user_data_fields = [
#	{
#		"doctype": "{doctype_1}",
#		"filter_by": "{filter_by}",
#		"redact_fields": ["{field_1}", "{field_2}"],
#		"partial": 1,
#	},
#	{
#		"doctype": "{doctype_2}",
#		"filter_by": "{filter_by}",
#		"partial": 1,
#	},
#	{
#		"doctype": "{doctype_3}",
#		"strict": False,
#	},
#	{
#		"doctype": "{doctype_4}"
#	}
# ]

# Authentication and authorization
# --------------------------------

# auth_hooks = [
#	"mfis.auth.validate"
# ]

fixtures = [
    # "Posting Periods",
    # "Workflow State",
    # "Charge Time Type",
    # "Saving Transaction Type",
    # "Loan Transaction Type",
    # "Client Types",
    # "Payment Method",
    # "Branch",
    # "Company",
    # "Loan Transaction Processing Strategy"
]

global_search_doctypes = {
    "Default": [
        {"doctype": "Client", "index": 0},
        {"doctype": "Saving Account", "index": 1},
        {"doctype": "Loan", "index": 2},
        {"doctype": "Saving Transaction", "index": 3},
        {"doctype": "Loan Transaction", "index": 4},
    ]
}

period_closing_doctypes = [
    "Deposit",
    "Withdraw",
    "Saving Transaction",
    "Savings Account",
    "Loan Transaction",
    "Payment I",
    "Cash Receipt",
    "Api Users",
]

treeviews = [
    "Account",
    "Cost Center"
]

accounting_dimension_doctypes = [
    "Saving Transaction",
]
