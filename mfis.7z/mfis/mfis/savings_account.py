import frappe


@frappe.whitelist(allow_guest=True, methods=["GET"])
def products():
    results = []
    query = frappe.db.get_list("Saving Product", fields=["name", "product_name"])

    if query:
        results = query

    return results


@frappe.whitelist(methods=["POST"])
def create(**kwargs):
    """

    Args:
        **kwargs: client, saving_product, external_number, staff_id

    Returns:
        doc

    """
    kwargs["doctype"] = "Savings Account"
    kwargs["client_type"] = "Client"

    employee = frappe.db.get_value("Employee", filters={
        "user": frappe.session.user
    }, fieldname="name")

    if employee:
        kwargs["staff_id"] = employee

    doc = frappe.get_doc(kwargs)

    doc.insert(ignore_permissions=True)

    return doc
